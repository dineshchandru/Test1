/***************************************************
 * Name : preferInitCheck.java
 * Date : 08 Mar 2006 
 * Desc : Initial Checking of the basic info of the crew
 ***************************************************/
package com.cathaypacific.crewdirect.roster;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @version 	1.0
 * @author
 */
public class preferInitCheck {

	private Connection con = null;
	
	public preferInitCheck() {
		super();
	}

	//	========================== Check Staff Basic Info by ERN=================	
  	public String BasicInfoCheckbyERN(String ern) {

		String err_msg = "no_err";
		String strsql = new String("");		

	  	try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;
			boolean exit = false;
			int rtn_count = 0;
			SimpleDateFormat mmyy_format = new SimpleDateFormat("MMM yyyy");
			Calendar rightNow = Calendar.getInstance();
			String date_now = mmyy_format.format(rightNow.getTime());
			
			//------------------- 1.0 Valid Crew Checking -------------------------------------
			strsql = "select count(*) as rtn_count from isdcrew.crewdb_4_all where ern = '"+ern+ "'";
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				rtn_count = rs.getInt("rtn_count");
			}			
			rs.close();
			if (rtn_count == 0) {
				exit = true ;
				err_msg = "Invalid crew ! You are not authorized to use this function.";
			}
             
			//------------------- 2.0 Get the details for verification --------------------------
		  	if (exit == false) {
		  		String base_port = new String("");
		  		String credit_scheme = new String("");
		  		String big_cat = new String("");
		  		String category = new String("");
		  		String cat_seniority = new String("");
		  		
				strsql = "select base_port, cos as credit_scheme, cat as big_cat, (cat1 || cat) as category, substr(cat2, 2, 1) as cat_seniority from isdcrew.crewdb_4_all where ern = '"+ern+"'";
				rs= stmt.executeQuery(strsql);
				while(rs.next()){
					base_port = rs.getString("base_port");
					credit_scheme = rs.getString("credit_scheme");
					big_cat = rs.getString("big_cat");
					category = rs.getString("category");
					cat_seniority = rs.getString("cat_seniority");				
				}
				rs.close();
				
				//-------------- 2.1 Base Port : HKG 
				if (!base_port.equals("HKG")) {
					exit = true;
					err_msg = "it's NOT applicable for Non-HKG based crew.";
				}
				//-------------- 2.2 No MU/CA crew
				if (exit == false && (credit_scheme.equals("U") || credit_scheme.equals("A"))) {
					exit = true;
					err_msg = "it's NOT applicable for MU or CA crew.";
				}
			    if (!big_cat.equals("BC") && date_now.equals("Dec 2007")) {
			        int day_now = rightNow.get(Calendar.DAY_OF_MONTH); //get current day
			        if (day_now < 17) {
						exit = true;
						err_msg = "it's only applicable to BC.";			           
			        }
			     }				
				//-------------- 2.3 Category
				if (exit == false && (!big_cat.equals("BC")&&!big_cat.equals("FP") ) ) {
					exit = true;
					err_msg = "it's not applicable to "+ big_cat +".";
				}					
				//-------------- 2.4 Acft Type Qualification - Q
				if (exit == false && (!category.equals("QBC") && !category.equals("QFP") )) {
					exit = true;
					err_msg = "it's not applicable to " + category + " qualification.";
				}
				//-------------- 2.5 Acft Type Qualification - N
				if (exit == false && big_cat.equals("BC") && (!cat_seniority.equals("N"))) {
					exit = true;
					err_msg = "it's only applicable to QBC-NN qualification.";
				}		
		  	}
		  	stmt.close();	
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferInitCheck.BasicInfoCheck]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferInitCheck.BasicInfoCheck]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
					err_msg = e.getMessage();	
			   }
			} //if  
		}					    	    	
		return err_msg;	
	}

	//	========================== Check Crew Cat by ERN=================	
  	public String CrewCatCheck(String ern, String buddy_ern) {

		String err_msg = "no_err";
		String strsql = new String("");		

	  	try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;
			boolean exit = false;
			int rtn_count = 0;
			boolean isok = false;
			//------------------- 1.0 Valid Crew Checking -------------------------------------
		  	String credit_scheme1 = new String("");
		  	String big_cat1 = new String("");
		  	String category1 = new String("");
		  	String cat_seniority1 = new String("");
		  	String cat_sen1 = new String("");
			strsql = "select base_port, cos as credit_scheme, cat as big_cat, (cat1 || cat) as category, cat2 as cat_seniority,substr(cat2,2,1) cat_sen from isdcrew.crewdb_4_all where ern = '"+ern+"'";
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				credit_scheme1 = rs.getString("credit_scheme");
				big_cat1 = rs.getString("big_cat");
				category1 = rs.getString("category");
				cat_seniority1 = rs.getString("cat_seniority");
				cat_sen1 = rs.getString("cat_sen");
			}
			rs.close();
		  	//stmt.close();
		  	//---------------- Buddy Crew Checking
		  	String credit_scheme2 = new String("");
		  	String big_cat2 = new String("");
		  	String category2 = new String("");
		  	String cat_seniority2 = new String("");
		  	String cat_sen2 = new String("");
		  	
			strsql = "select base_port, cos as credit_scheme, cat as big_cat, (cat1 || cat) as category, cat2 as cat_seniority,substr(cat2,2,1) cat_sen from isdcrew.crewdb_4_all where ern = '"+buddy_ern+"'";
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				credit_scheme2 = rs.getString("credit_scheme");
				big_cat2 = rs.getString("big_cat");
				category2 = rs.getString("category");
				cat_seniority2 = rs.getString("cat_seniority");
				cat_sen2 = rs.getString("cat_sen");
			}
			rs.close();
		  	stmt.close();		  	
			con.close();
			
			//-------------- 2.1 Same Category 
			if (!category1.equals(category2)) {
				exit = true;
				err_msg = "Your Category  "+ category1+" do not match with your Buddy ("+category2+").";
			};
			
			//-------------- 2.2 Same COS 
			if (exit == false && big_cat1.equals("FP") && !credit_scheme1.equals(credit_scheme2)) {
				exit = true;
				err_msg = "Your COS do not match with Buddy COS.";
			};		
			//-------------- 2.3 same the last 2 digits of the category  
			if (exit == false && !cat_seniority1.equals(cat_seniority2)) {
				if (big_cat1.equals("FP")) {
				   if ((cat_seniority1.equals("ON")||cat_seniority1.equals("OK")) && (cat_seniority2.equals("OK")|| cat_seniority2.equals("ON")) ) {
				   	  isok = true;
				   } else {
				      if ((cat_seniority1.equals("NN")||cat_seniority1.equals("NK")) && (cat_seniority2.equals("NK")|| cat_seniority2.equals("NN")) ) {
				   	     isok = true;
				      } else {
					     if (cat_seniority1.equals(cat_seniority2)) {
					   	    isok = true;
					     }				      	
				      }
				   }   
				   if (!isok){
				   	 exit = true;
				   	 err_msg = "Your Category "+big_cat1+ cat_seniority1+" do not match with Buddy ("+big_cat2+cat_seniority2+")."; 	 
				   }
				} else {
				  exit = true;
				  err_msg = "Your Category "+ big_cat1+cat_seniority1+" do not match with Buddy ("+big_cat2+cat_seniority2+")."; 	 
				};  
			};
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferInitCheck.CrewCatCheck]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferInitCheck.CrewCatCheck]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
					err_msg = e.getMessage();	
			   }
			} //if  
		}					    	    	
		return err_msg;	
	}
  	
	//	========================== Check Staff Basic Info by Crew ID =================	
	public String getERN(String crew_id) {

		String ern = new String("");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;

			String strsql = "select ern from isdcrew.crewdb_4_all where crew_id = '"+crew_id+ "'";
			rs= stmt.executeQuery(strsql);			
			while(rs.next()){
				ern = rs.getString("ern");
			}
			if (ern.equals("")) { ern = "invalid_crewid"; }
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
			   }
			} //if  
		}		
		return ern;			
	}

	//	========================== Check Staff Basic Info by Crew ID =================	
	public String getCrewID(String ern) {

		String crew_id = new String("");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;

			String strsql = "select crew_id from isdcrew.crewdb_4_all where ern = '"+ern+ "'";
			rs= stmt.executeQuery(strsql);			
			while(rs.next()){
				crew_id = rs.getString("crew_id");
			}
			if (ern.equals("")) { ern = "invalid_ern"; }
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
			   }
			} //if  
		}		
		return crew_id;			
	}
	//	========================== get Category by ERN =================	
	public String getCat(String ern) {

		String cat = new String("");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;

			String strsql = "select cat1||cat cat from isdcrew.crewdb_4_all where ern = '"+ern+ "'";
			rs= stmt.executeQuery(strsql);			
			while(rs.next()){
				cat = rs.getString("cat");
			}
			if (cat.equals("")) { cat = "invalid_cat"; }
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
			   }
			} //if  
		}		
		return cat;			
	}
	//	========================== get COS by ERN =================	
	public String getCos(String ern) {

		String cos = new String("");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;

			String strsql = "select cos from isdcrew.crewdb_4_all where ern = '"+ern+ "'";
			rs= stmt.executeQuery(strsql);			
			while(rs.next()){
				cos = rs.getString("cos");
			}
			if (cos.equals("")) { cos = "invalid_cos"; }
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
			   }
			} //if  
		}		
		return cos;			
	}
		
	//	========================== Check Staff Basic Info by Crew ID =================	
	public String getFilePath(String file_type) {

		String file_path = new String("");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;

			String strsql = "select file_path from crewdir.ccd_file_link where file_type = '"+file_type+ "'";
			rs= stmt.executeQuery(strsql);			
			while(rs.next()){
				file_path = rs.getString("file_path");
			}
			rs.close();
			if (file_path.equals("")) { file_path = "invalid_path"; }

			stmt.close();
			con.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
					e.printStackTrace();
			   }
			} //if  
		}		
		return file_path;			
	}

}
