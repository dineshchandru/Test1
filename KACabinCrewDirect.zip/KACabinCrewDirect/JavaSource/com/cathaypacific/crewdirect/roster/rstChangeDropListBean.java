/*
 * Created on Jun 23, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class rstChangeDropListBean {
	private String ack_key;
	private String ack_time;

	public rstChangeDropListBean(String ack_key,String ack_time) {
		this.ack_key = ack_key;
		this.ack_time = ack_time; 		
	}

	/**
	 * 
	 */
	public rstChangeDropListBean() {
		super();		
	}



	/**
	 * @return
	 */
	public String getAck_key() {
		return ack_key;
	}


	/**
	 * @param string
	 */
	public void setAck_key(String string) {
		ack_key = string;
	}


	/**
	 * @return
	 */
	public String getAck_time() {
		return ack_time;
	}

	/**
	 * @param string
	 */
	public void setAck_time(String string) {
		ack_time = string;
	}

}
