/***************************************************
 * Name : preferRequest
 * Date : 08 Mar 2006 
 * Desc : Initial Checking of the basic info of the crew
 ***************************************************/
package com.cathaypacific.crewdirect.roster;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.databeans.preferentialInfo;
import com.cathaypacific.crewdirect.databeans.preferentialList;

/**
 * @version 	1.0
 * @author
 */
public class preferRequest {

	private Object getRequesterInactive;
	private Connection con = null;
	preferentialList requester_list = new preferentialList();
	preferentialList invited_list = new preferentialList();
	preferentialList inactive_list = new preferentialList();	
	Vector vPreferDayoffList = new Vector();
	Vector vPreferFLyHourList = new Vector();
	String requester_status = new String("");

	public preferRequest() {
		super();
		getSelectionFields();
	}
	
	public preferRequest(String ern) {
		
	}
	
	public void getSelectionFields() {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			ResultSet rs = null;
			
			//------------------- 1.0 Get the preference Days off choice ------------------------
			String strsql = "select prefer_selection from crewdir.preferential_parameters where prefer_type = 'DAYS_OFF'";	
			rs= stmt.executeQuery(strsql);
			while(rs.next()){					
				vPreferDayoffList.addElement(rs.getString("prefer_selection"));
			}
			rs.close();
			vPreferDayoffList.trimToSize() ;

			//------------------- 2.0 Get the preference Flying hour choice ------------------------
			strsql = "select prefer_selection from crewdir.preferential_parameters where prefer_type = 'FLY_HOUR'";	
			rs= stmt.executeQuery(strsql);
			while(rs.next()){					
				vPreferFLyHourList.addElement(rs.getString("prefer_selection"));
			}
			rs.close();
			vPreferFLyHourList.trimToSize() ;
			
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRequest.preferRequest]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRequest.preferRequest]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
	}
	
	public int getRequesterApplication(String ern, String roster_month) {
		
		int rtn_count = 0 ;
		String err_msg = "no_err";
				
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();		
			ResultSet rs = null;			
			Vector vlist = new Vector();
			
			//------------------- 1.0 Check existing application (as Requester - for self & buddy)------------------------
			String strsql = "select count(*) as requester_count from crewdir.preferential_crewlist WHERE ern='"+ern+"' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and active_status = 'ACTIVE'";	
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				rtn_count = rs.getInt("requester_count");
			}			
			rs.close();

			if (rtn_count > 0) {
				strsql = "SELECT req_id, days_off, fly_hour, dayoff_afterflt, buddy_flying, ack_integrated, ack_terms, " +
						 "last_status, update_by, to_char(last_update, 'dd-Mon-yy hh24:mi') as last_update " +
						 "FROM crewdir.preferential_crewlist WHERE ern='"+ern+"' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and active_status = 'ACTIVE'";
				rs = stmt.executeQuery(strsql);
			
				while(rs.next()){
					preferInitCheck init_check = new preferInitCheck();					
					preferentialInfo requester_info = new preferentialInfo();
					requester_info.setRoster_month(roster_month);
					requester_info.setRequester_ern(ern);
					requester_info.setRequester_crewid(init_check.getCrewID(ern));
					requester_info.setReq_id(rs.getString("req_id"));
					requester_info.setDays_off(rs.getString("days_off"));
					requester_info.setFlying_hours(rs.getString("fly_hour"));                    
					requester_info.setDayoff_after_flight(rs.getString("dayoff_afterflt"));
					requester_info.setBuddy_flying(rs.getString("buddy_flying"));
					requester_info.setAck_integrated(rs.getString("ack_integrated"));
					requester_info.setAck_terms(rs.getString("ack_terms"));
					requester_info.setLast_status(rs.getString("last_status"));
					requester_info.setLast_update(rs.getString("last_update"));
					
					setRequester_status(rs.getString("last_status"));

					// ******* Get the buddy information
					String req_id = rs.getString("req_id");
					String buddy_flying = rs.getString("buddy_flying");
					int buddy_seq = 0;
					String buddy1_ern = new String("");
					String buddy1_crewid = new String("");
					String buddy1_status = new String("");
					String buddy2_ern = new String("");
					String buddy2_crewid = new String("");
					String buddy2_status = new String("");
										
					if (buddy_flying.equals("Y")) {
						Statement stmt_b = con.createStatement();
						strsql = "SELECT seq, ern, crew_id, status FROM crewdir.preferential_buddy WHERE to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and req_id = '"+req_id+"' order by seq";
						ResultSet rs_buddy = stmt_b.executeQuery(strsql);
			
						while(rs_buddy.next()) {
							buddy_seq = rs_buddy.getInt("seq");
							if (buddy_seq == 1) {
								buddy1_ern = rs_buddy.getString("ern");
								buddy1_crewid = rs_buddy.getString("crew_id");
								buddy1_status = rs_buddy.getString("status");	
							} else {
								buddy2_ern = rs_buddy.getString("ern");
								buddy2_crewid = rs_buddy.getString("crew_id");
								buddy2_status = rs_buddy.getString("status");
							}							
						}
						rs_buddy.close();
						stmt_b.close();

						if (buddy1_ern == null) { buddy1_ern = ""; }
						if (buddy1_crewid == null) { buddy1_crewid = ""; }
						if (buddy1_status == null) { buddy1_status = ""; }
						if (buddy2_ern == null) { buddy2_ern = ""; }
						if (buddy2_crewid == null) { buddy2_crewid = ""; }
						if (buddy2_status == null) { buddy2_status = ""; }
						
						if (buddy1_status.equals("Accepted") || buddy2_status.equals("Accepted")) {
							setRequester_status("Accepted");
						}
					}
					// ******* End of get buddy information
									
					requester_info.setBuddy1_ern(buddy1_ern);
					requester_info.setBuddy1_crewid(buddy1_crewid);
					requester_info.setBuddy1_status(buddy1_status);
					requester_info.setBuddy2_ern(buddy2_ern);
					requester_info.setBuddy2_crewid(buddy2_crewid);
					requester_info.setBuddy2_status(buddy2_status);
					
					vlist.addElement(requester_info);
				}
				rs.close();
			}
			vlist.trimToSize();
			requester_list.setPreferential_list(vlist);
			
			stmt.close();
			con.close();	
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRequest.getRequesterApplication]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRequest.getRequesterApplication]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return rtn_count ;
	}
	
	public int getInvitedApplication(String ern, String roster_month, String request_status) {

		int total_rejected_count = 0 ;
		String err_msg = "no_err";
				
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
					
			Statement stmt = con.createStatement();
			ResultSet rs = null;
			Vector vlist = new Vector();
			int rtn_count = 0;
			
			//------------------- 2.0 Check being invited application (as Receiver - being invited)------------------------
			String strsql = "select count(*) as invited_count from crewdir.preferential_buddy WHERE ern='"+ern+"' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and status in ("+request_status+")";
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				rtn_count = rs.getInt("invited_count");
			}			
			rs.close();
			total_rejected_count = total_rejected_count + rtn_count ;
			
			if (rtn_count > 0) {
				strsql = "SELECT b.req_id, cl.ern as requester_ern, cl.days_off, cl.fly_hour, cl.dayoff_afterflt, cl.buddy_flying, " +						 "cl.ack_integrated, cl.ack_terms, cl.last_status, cl.update_by, to_char(cl.last_update, 'dd-Mon-yy') as last_update " +
						 "FROM crewdir.preferential_crewlist cl, crewdir.preferential_buddy b where b.req_id = cl.req_id and " +
						 "b.ern='"+ern+"' and to_char(b.roster_month, 'Mon yyyy') = '"+roster_month+"' and status in("+request_status+") order by req_id";
				rs = stmt.executeQuery(strsql);
			
				while(rs.next()){	
					preferInitCheck init_check = new preferInitCheck();
					preferentialInfo invited_info = new preferentialInfo();
					invited_info.setRoster_month(roster_month);
					invited_info.setReq_id(rs.getString("req_id"));
					invited_info.setRequester_ern(rs.getString("requester_ern"));
					invited_info.setRequester_crewid(init_check.getCrewID(rs.getString("requester_ern")));
					invited_info.setDays_off(rs.getString("days_off"));
					invited_info.setFlying_hours(rs.getString("fly_hour"));                    
					invited_info.setDayoff_after_flight(rs.getString("dayoff_afterflt"));
					invited_info.setBuddy_flying(rs.getString("buddy_flying"));
					invited_info.setAck_integrated(rs.getString("ack_integrated"));
					invited_info.setAck_terms(rs.getString("ack_terms"));
					invited_info.setLast_status(rs.getString("last_status"));
					invited_info.setLast_update(rs.getString("last_update"));
					
					// ******* Get the buddy information
					String req_id = rs.getString("req_id");
					String buddy_flying = rs.getString("buddy_flying");
					int buddy_seq = 0;
					String buddy1_ern = new String("");
					String buddy1_crewid = new String("");
					String buddy1_status = new String("");
					String buddy2_ern = new String("");
					String buddy2_crewid = new String("");
					String buddy2_status = new String("");
										
					if (buddy_flying.equals("Y")) {
						Statement stmt_b = con.createStatement();
						strsql = "SELECT seq, ern, crew_id, status FROM crewdir.preferential_buddy WHERE to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and req_id = '"+req_id+"' order by seq";
						ResultSet rs_buddy = stmt_b.executeQuery(strsql);
			
						while(rs_buddy.next()) {
							buddy_seq = rs_buddy.getInt("seq");
							if (buddy_seq == 1) {
								buddy1_ern = rs_buddy.getString("ern");
								buddy1_crewid = rs_buddy.getString("crew_id");
								buddy1_status = rs_buddy.getString("status");	
							} else {
								buddy2_ern = rs_buddy.getString("ern");
								buddy2_crewid = rs_buddy.getString("crew_id");
								buddy2_status = rs_buddy.getString("status");
							}						
						}
						rs_buddy.close();
						stmt_b.close();

						if (buddy1_ern == null) { buddy1_ern = ""; }
						if (buddy1_crewid == null) { buddy1_crewid = ""; }
						if (buddy1_status == null) { buddy1_status = ""; }
						if (buddy2_ern == null) { buddy2_ern = ""; }
						if (buddy2_crewid == null) { buddy2_crewid = ""; }
						if (buddy2_status == null) { buddy2_status = ""; }									
					}
					// ******* End of get buddy information
										
					invited_info.setBuddy1_ern(buddy1_ern);
					invited_info.setBuddy1_crewid(buddy1_crewid);
					invited_info.setBuddy1_status(buddy1_status);
					invited_info.setBuddy2_ern(buddy2_ern);
					invited_info.setBuddy2_crewid(buddy2_crewid);
					invited_info.setBuddy2_status(buddy2_status);
					
					vlist.addElement(invited_info);
				}
				rs.close();
			}
			
			if (request_status.equals("'Withdraw', 'Rejected'")) {
				
				//------------------- 1.0 Check existing application, no buddy flying (as Requester - for self)------------------------
				strsql = "select count(*) as requester_count from crewdir.preferential_crewlist WHERE ern='"+ern+"' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and active_status = 'INACTIVE'";	
				rs = stmt.executeQuery(strsql);
				while(rs.next()){
					rtn_count = rs.getInt("requester_count");
				}			
				rs.close();
				total_rejected_count = total_rejected_count + rtn_count ;

				if (rtn_count > 0) {
					strsql = "SELECT req_id, ern as requester_ern, days_off, fly_hour, dayoff_afterflt, buddy_flying, ack_integrated, ack_terms, " +
							 "last_status, update_by, to_char(last_update, 'dd-Mon-yy') as last_update " +
							 "FROM crewdir.preferential_crewlist WHERE ern='"+ern+"' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and active_status = 'INACTIVE' order by req_id";	
					rs = stmt.executeQuery(strsql);
			
					while(rs.next()) {
						preferInitCheck init_check = new preferInitCheck();
						preferentialInfo requester_info = new preferentialInfo();
						requester_info.setRoster_month(roster_month);
						requester_info.setRequester_ern(rs.getString("requester_ern"));
						requester_info.setRequester_crewid(init_check.getCrewID(rs.getString("requester_ern")));						
						requester_info.setReq_id(rs.getString("req_id"));
						requester_info.setDays_off(rs.getString("days_off"));
						requester_info.setFlying_hours(rs.getString("fly_hour"));                    
						requester_info.setDayoff_after_flight(rs.getString("dayoff_afterflt"));
						requester_info.setBuddy_flying(rs.getString("buddy_flying"));
						requester_info.setAck_integrated(rs.getString("ack_integrated"));
						requester_info.setAck_terms(rs.getString("ack_terms"));
						requester_info.setLast_status(rs.getString("last_status"));
						requester_info.setLast_update(rs.getString("last_update"));
					
						// ******* Get the buddy information
						String req_id = rs.getString("req_id");
						String buddy_flying = rs.getString("buddy_flying");
						int buddy_seq = 0;
						String buddy1_ern = new String("");
						String buddy1_crewid = new String("");
						String buddy1_status = new String("");
						String buddy2_ern = new String("");
						String buddy2_crewid = new String("");
						String buddy2_status = new String("");
										
						if (buddy_flying.equals("Y")) {
							Statement stmt_b = con.createStatement();
							strsql = "SELECT seq, ern, crew_id, status FROM crewdir.preferential_buddy WHERE to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and req_id = '"+req_id+"' order by seq";
							ResultSet rs_buddy = stmt_b.executeQuery(strsql);
			
							while(rs_buddy.next()) {
								buddy_seq = rs_buddy.getInt("seq");
								if (buddy_seq == 1) {
									buddy1_ern = rs_buddy.getString("ern");
									buddy1_crewid = rs_buddy.getString("crew_id");
									buddy1_status = rs_buddy.getString("status");	
								} else {
									buddy2_ern = rs_buddy.getString("ern");
									buddy2_crewid = rs_buddy.getString("crew_id");
									buddy2_status = rs_buddy.getString("status");
								}							
							}
							rs_buddy.close();
							stmt_b.close();

							if (buddy1_ern == null) { buddy1_ern = ""; }
							if (buddy1_crewid == null) { buddy1_crewid = ""; }
							if (buddy1_status == null) { buddy1_status = ""; }
							if (buddy2_ern == null) { buddy2_ern = ""; }
							if (buddy2_crewid == null) { buddy2_crewid = ""; }
							if (buddy2_status == null) { buddy2_status = ""; }									
						}
						// ******* End of get buddy information
									
						requester_info.setBuddy1_ern(buddy1_ern);
						requester_info.setBuddy1_crewid(buddy1_crewid);
						requester_info.setBuddy1_status(buddy1_status);
						requester_info.setBuddy2_ern(buddy2_ern);
						requester_info.setBuddy2_crewid(buddy2_crewid);
						requester_info.setBuddy2_status(buddy2_status);
					
						vlist.addElement(requester_info);
					}
					rs.close();
				}
				vlist.trimToSize();				
				inactive_list.setPreferential_list(vlist);

			} else {
				vlist.trimToSize();				
				invited_list.setPreferential_list(vlist);
			}
			
			stmt.close();
			con.close();		
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRequest.getInvitedApplication]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRequest.getInvitedApplication]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return total_rejected_count ;
	}

	/**
	 * @return
	 */
	public Vector getVPreferDayoffList() {
		return vPreferDayoffList;
	}

	/**
	 * @return
	 */
	public Vector getVPreferFLyHourList() {
		return vPreferFLyHourList;
	}

	/**
	 * @return
	 */
	public Object getGetRequesterInactive() {
		return getRequesterInactive;
	}

	/**
	 * @return
	 */
	public preferentialList getInactive_list() {
		return inactive_list;
	}

	/**
	 * @return
	 */
	public preferentialList getInvited_list() {
		return invited_list;
	}

	/**
	 * @return
	 */
	public preferentialList getRequester_list() {
		return requester_list;
	}

	/**
	 * @return
	 */
	public String getRequester_status() {
		return requester_status;
	}

	/**
	 * @param string
	 */
	public void setRequester_status(String string) {
		requester_status = string;
	}

}
