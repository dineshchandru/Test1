/*
 * Created on Jun 24, 2010
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;

/**
 * @author ALVIN
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class BCMsgDropListBean {
	private String staffID;
	private String ack_time;
	private String create_time;
	private String css_msg;

	public BCMsgDropListBean(String staffID,String ack_time, String create_time, String css_msg) {
		this.staffID = staffID;
		this.ack_time = ack_time;
		this.create_time = create_time;
		this.css_msg = css_msg;
	}

	/**
	 * BCMsgDropListBean's constructor
	 */
	public BCMsgDropListBean() {
		super();		
	}

    /**
     * Get the staffID
     *
     * @return the staffID
     */
    public String getStaffID() {
        return staffID;
    }

    /**
     * Set the staffID
     *
     * @param staffID the staffID to set
     */
    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    /**
     * Get the ack_time
     *
     * @return the ack_time
     */
    public String getAck_time() {
        return ack_time;
    }

    /**
     * Set the ack_time
     *
     * @param ackTime the ack_time to set
     */
    public void setAck_time(String ackTime) {
        ack_time = ackTime;
    }

    /**
     * Get the create_time
     *
     * @return the create_time
     */
    public String getCreate_time() {
        return create_time;
    }

    /**
     * Set the create_time
     *
     * @param createTime the create_time to set
     */
    public void setCreate_time(String createTime) {
        create_time = createTime;
    }

    /**
     * Get the css_msg
     *
     * @return the css_msg
     */
    public String getCss_msg() {
        return css_msg;
    }

    /**
     * Set the css_msg
     *
     * @param cssMsg the css_msg to set
     */
    public void setCss_msg(String cssMsg) {
        css_msg = cssMsg;
    }
}
