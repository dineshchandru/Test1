/*
 * Created on Feb 26, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author oradba
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class rosterdateBean {

	private String rosterdate;

	public rosterdateBean() {
		super();
	}

	public rosterdateBean(Date rosterdate) {
		this.rosterdate=Date2String(rosterdate);
	}

	/**
	 * @return
	 */
	public String getRosterdate() {
		return rosterdate;
	}

	/**
	 * @param string
	 */
	public void setRosterdate(String string) {
		rosterdate = string;
	}

	private String Date2String(Date myDate){
		String str=null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
		str = formatter.format(myDate);
		return str;
	}

}
