/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class rosterdutyBean {
	
	private String rosterduty;
	
	public rosterdutyBean(){
		super();
	}

	public rosterdutyBean(String rosterduty){
		this.rosterduty = rosterduty;
	}
	
	/**
	 * @return
	 */
	public String getRosterduty() {
		return rosterduty;
	}

	/**
	 * @param string
	 */
	public void setRosterduty(String string) {
		rosterduty = string;
	}

}
