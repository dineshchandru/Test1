package com.cathaypacific.crewdirect.roster;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.databeans.preferentialInfo;
import com.cathaypacific.crewdirect.databeans.preferentialList;
import com.cathaypacific.crewdirect.services.number2alpha;

/**
 * @version 	1.0
 * @author
 */
public class preferRecord {

	private Connection con = null;
	String success_percent = new String("");
	
	public preferRecord() {
		super();
	}

	public String updateRecord(String req_id, String ern, String roster_month, String days_off, String fly_hour, String dayoff_afterflt, String buddy_flying, String buddy1_ern, String buddy1_crewid, String buddy1_status, String buddy2_ern, String buddy2_crewid, String buddy2_status, String ack_integrated, String ack_terms) {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			String strsql = new String("");

			//1.0 delete the preferential crewlist details
			strsql = "delete crewdir.preferential_crewlist where req_id = '"+req_id+"'";
			stmt.executeQuery(strsql);

			//2.0 delete the preferential buddy information
			strsql = "delete crewdir.preferential_buddy where req_id = '"+req_id+"'";
			stmt.executeQuery(strsql);

			//3.0 insert the records using the existing req_id
			insertRecord(req_id, ern, roster_month, days_off, fly_hour, dayoff_afterflt, buddy_flying, buddy1_ern, buddy1_crewid, buddy1_status, buddy2_ern, buddy2_crewid, buddy2_status, ack_integrated, ack_terms);

			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateRecord]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateRecord]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return err_msg ;
	}

	
	public String insertRecord(String req_id, String ern, String roster_month, String days_off, String fly_hour, String dayoff_afterflt, String buddy_flying, String buddy1_ern, String buddy1_crewid, String buddy1_status, String buddy2_ern, String buddy2_crewid, String buddy2_status, String ack_integrated, String ack_terms) {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			String strsql = new String("");

			//1.0 get the preferential key if it's a new application
			if (req_id.equals("")) {			
				strsql = "select preferential_key.nextval as preferential_key from dual"; 			
				ResultSet rs= stmt.executeQuery(strsql);		
				while(rs.next()){
					number2alpha encode_key = new number2alpha();										
					req_id = encode_key.genAlphaNumber(rs.getString("preferential_key"));
				}									        
				rs.close();
			}
	        	    			
			//2.0 execute sql & update main table(swap_req+swap_status)
			strsql = "insert into crewdir.preferential_crewlist (req_id, roster_month, active_status, ern, days_off, fly_hour, dayoff_afterflt, buddy_flying, ack_integrated, ack_terms, last_status, update_by, last_update) values " +
					 "('"+req_id+"', to_date('"+roster_month+"', 'Mon yyyy'), 'ACTIVE', '"+ern+"', '"+days_off+"', '"+fly_hour+"', '"+dayoff_afterflt+"', '"+buddy_flying+"', '"+ack_integrated+"', '"+ack_terms+"', 'Processing', '"+ern+"', sysdate)";
			stmt.executeQuery(strsql);
			
			//3.0 insert the buddy information
			if (buddy_flying.equals("Y")) {
				if (!buddy1_ern.equals("")) {
					strsql = "insert into crewdir.preferential_buddy (req_id, roster_month, seq, ern, crew_id, status, update_by, last_update) values " +
							 "('"+req_id+"', to_date('"+roster_month+"', 'Mon yyyy'), 1, '"+buddy1_ern+"', '"+buddy1_crewid+"', '"+buddy1_status+"', '"+ern+"', sysdate)";
					stmt.executeQuery(strsql);
				}
				if (!buddy2_ern.equals("")) {
					strsql = "insert into crewdir.preferential_buddy (req_id, roster_month, seq, ern, crew_id, status, update_by, last_update) values " +
							 "('"+req_id+"', to_date('"+roster_month+"', 'Mon yyyy'), 2, '"+buddy2_ern+"', '"+buddy2_crewid+"', '"+buddy2_status+"', '"+ern+"', sysdate)";
					stmt.executeQuery(strsql);
				}
			}
			
			//4.0 Get the successful indicator
			setSuccess_percent(getSuccessIndicator(con, stmt, roster_month));

			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRecord.insertRecord]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRecord.insertRecord]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return err_msg ;
	}
	
	public String updateAccepted(preferentialList invited_list, String req_id, String ern, String roster_month) {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			String strsql = new String("");
			String status_accepted = "Accepted";
			String status_rejected = "Rejected";
			int rtn_count = 0;

			int invited_count = invited_list.getPreferential_list().size();		
										 	        	    			
			//1.0 Accept one of the invitation and update in table preferential_buddy (individual record)
			strsql = "update crewdir.preferential_buddy set status = '"+status_accepted+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+req_id+"' and ern = '"+ern+"'";
			stmt.executeUpdate(strsql);

			//2.0 Reject the other outstanding invitation
			for (int i = 0 ; i < invited_count; i++) {
				preferentialInfo invited_info = (preferentialInfo) invited_list.getPreferential_list().elementAt(i);
				String rej_req_id = invited_info.getReq_id();

				if (!rej_req_id.equals(req_id)) {
					strsql = "update crewdir.preferential_buddy set status = '"+status_rejected+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+rej_req_id+"'";
					stmt.executeUpdate(strsql);
					
					strsql = "update crewdir.preferential_crewlist set active_status = 'INACTIVE', last_status = '"+status_rejected+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+rej_req_id+"'";
					stmt.executeUpdate(strsql);
				}
			}
						
			//Search whether the case have closed if both parties agreed or rejected
			strsql = "select count(distinct status) as rtn_count from crewdir.preferential_buddy where req_id = '"+req_id+"'";
			ResultSet rs = stmt.executeQuery(strsql);
			while (rs.next()) {
				rtn_count = rs.getInt("rtn_count");
			}
			rs.close();
			
			//3.0 update the last status if only one kind of status found
			if (rtn_count == 1) {
				strsql = "update crewdir.preferential_crewlist set last_status = '"+status_accepted+"', update_by = '"+ern+"', last_update = sysdate where active_status='ACTIVE' and req_id = '"+req_id+"'";
				stmt.executeUpdate(strsql);
			}
			
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateInvited]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateInvited]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return err_msg ;
	}
	
	public String updateRejected(preferentialList invited_list, String ern) {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			String strsql = new String("");
			String status_rejected = "Rejected";
			
			int invited_count = invited_list.getPreferential_list().size();					
			for (int i = 0 ; i < invited_count; i++) {
				preferentialInfo invited_info = (preferentialInfo) invited_list.getPreferential_list().elementAt(i);
				String req_id = invited_info.getReq_id();

				strsql = "update crewdir.preferential_buddy set status = '"+status_rejected+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+req_id+"'";
				stmt.executeUpdate(strsql);

				strsql = "update crewdir.preferential_crewlist set active_status = 'INACTIVE', last_status = '"+status_rejected+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+req_id+"'";
				stmt.executeUpdate(strsql);
			}
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateRejected]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateRejected]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return err_msg ;
	}
	
	public String updateWithdraw(String req_id, String ern) {
		
		String err_msg = "no_err";
		try{
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
			
			Statement stmt = con.createStatement();
			String strsql = new String("");
			String status_withdraw = "Withdraw";
			
			strsql = "update crewdir.preferential_buddy set status = '"+status_withdraw+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+req_id+"'";
			stmt.executeUpdate(strsql);

			strsql = "update crewdir.preferential_crewlist set active_status = 'INACTIVE', last_status = '"+status_withdraw+"', update_by = '"+ern+"', last_update = sysdate where req_id = '"+req_id+"'";
			stmt.executeUpdate(strsql);
			
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateWithdraw]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [preferRecord.updateWithdraw]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();

		} finally {
			
			if (con != null) {
			   try {
					 con.close();
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}	
		return err_msg ;
	}
	
	public String getSuccessIndicator(Connection con, Statement stmt, String roster_month) {
		
		String success_indicator = "no_err";
		try{
			int rtn_count = 0 ;
			
			String strsql = "select count(*) as rtn_count from crewdir.preferential_crewlist where to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' and active_status = 'ACTIVE'";	
			ResultSet rs= stmt.executeQuery(strsql);
			while(rs.next()){
				rtn_count = rs.getInt("rtn_count");
			}			
			rs.close();
			
			strsql = "select range_percent as success_indicator from crewdir.preferential_success where "+rtn_count+" between range_from and range_to";
			rs= stmt.executeQuery(strsql);
			while(rs.next()){
				success_indicator = rs.getString("success_indicator");
			}			
			rs.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
		}
		
		return success_indicator ;
	}

	/**
	 * @return
	 */
	public String getSuccess_percent() {
		return success_percent;
	}
	/**
	 * @param string
	 */
	public void setSuccess_percent(String string) {
		success_percent = string;
	}

}	
