package com.cathaypacific.crewdirect.roster;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class rosterdateList {
	
	private ArrayList arr_date;
		
	public rosterdateList(String myType) {
		if (myType.equals("FULL")) {
			genFullList();			
		}else{
			genFutureList();	
		}
	}

	public rosterdateList() {
		super();		
	}

	public void genFutureList( ) {
	Connection con= null;	
	ArrayList list= new ArrayList();	
	Date maxDate = null;
	Date minDate = null;
	Calendar cal = Calendar.getInstance();  //set today
	
	
	try{	
			
		//1.0 connect to db and put data by month into list
		dbconnect db = new dbconnect();
		con = db.getConn();	        
		ResultSet rs=null;			
		Statement stmt=null;			 			 			
				 			 		
 		// 2.0 find max date	
		String SQL =  "SELECT DISTINCT MAX(ROSTER_DATE)+1 as MAX_R_DATE,SYSDATE+2 as MIN_R_DATE " +
					  "FROM CREWDIR.V_ROSTER_PUBLIC ";
					   
		stmt = con.createStatement();		
		rs= stmt.executeQuery(SQL);		
		while(rs.next()){										
			maxDate = rs.getDate("MAX_R_DATE");										
			minDate = rs.getDate("MIN_R_DATE");			
			//3.0 create list of date from today upto maxdate			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy");									
			String EndDate = formatter.format(maxDate); 
			String StartDate = formatter.format(minDate);						
			cal.setTime(minDate);				
			while (!StartDate.equals(EndDate) ){		    	
				list.add(new rosterdateBean(cal.getTime()));
				Date current = this.addDay(cal,1).getTime();						
				StartDate = formatter.format(current); 					
				cal.setTime(current);			
			}
		}									        
		rs.close();
		stmt.close(); 
		
	}catch (SQLException sqlex) {
		  sqlex.printStackTrace();	
		  if (con!=null) {
				try {
				   con.close();
				}catch( SQLException e){
				   e.printStackTrace();
				}		   	  
		  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  
		this.setArr_date(list);
	}
//-----------------------------------------------------
	public void genFullList( ) {
	Connection con = null;	
	ArrayList list= new ArrayList();	
	Date maxDate = null;
	Date minDate = null;
	Calendar cal = Calendar.getInstance();  //set today
	
	try{	
			
		//1.0 connect to db and put data by month into list
		
		dbconnect db = new dbconnect();
		con = db.getConn();	        
		ResultSet rs=null;			
		Statement stmt=null;			 			 					 			 		
		// 2.0 find max date	
		String SQL =  "SELECT DISTINCT MAX(ROSTER_DATE)+1 AS MAX_ROSTER_DATE," +
					  "MIN(ROSTER_DATE) AS MIN_ROSTER_DATE " +	
					  "FROM CREWDIR.V_ROSTER_PUBLIC ";  				
		
		stmt = con.createStatement();		
		rs= stmt.executeQuery(SQL);				
		while(rs.next()){										
			maxDate = rs.getDate("MAX_ROSTER_DATE");										
			minDate = rs.getDate("MIN_ROSTER_DATE");
			
			//3.0 create list of date from today upto maxdate			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy");									
			String EndDate = formatter.format(maxDate); 
			String StartDate = formatter.format(minDate);						
			
			cal.setTime(minDate);	
			while (!StartDate.equals(EndDate) ){		    	
				list.add(new rosterdateBean(cal.getTime()));
				Date current = this.addDay(cal,1).getTime();						
				StartDate = formatter.format(current); 					
				cal.setTime(current);			
			}
			
		}									        
		rs.close();
		stmt.close(); 
		
	}catch (SQLException sqlex) {
		  sqlex.printStackTrace();	
		  if (con!=null) {
				try {
				   con.close();
				}catch( SQLException e){
				   e.printStackTrace();
				}		   	  
		  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  
		this.setArr_date(list);
	}


	private Calendar addDay(Calendar cal,int i){
		//cal.roll(Calendar.DATE,true);
		cal.add(Calendar.DAY_OF_MONTH,i );
		return cal;	
	}

/**
 * @return
 */
public ArrayList getArr_date() {
	return arr_date;
}

/**
 * @param list
 */
public void setArr_date(ArrayList list) {
	arr_date = list;
}

}
