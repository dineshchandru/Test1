/*
 * Created on May 12, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;
public class rstChangeBeanList {
    
    //show most recent roster changes
    private String ern;
    private String Ack_Key;
	private Connection con=null;
	private int lst_count=0;    	
	private rstBean[] rosters;

	//show notification message header Info
	private String msgStaffID;
	private String msgType;
	private String msgRange;
	private String msgAckTime;
	
	
	
	public rstChangeBeanList() {
		super();
	}
	
	public rstChangeBeanList(String iern,String ack_key) {
		this.ern = iern;
		this.Ack_Key = ack_key;
		getRoster();
	}

	public rstChangeBeanList(String iern) {
		this.ern = iern;
		this.Ack_Key = "recent";
		getRoster();
	}


	public void getRoster(){
		boolean haverecord = false;
		String RangeStart=null;
		String RangeEnd=null;
		String SQL;
		String rst_from_mq_key = null;
		try{	
						
						
						
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt=null;

			//1.0 find last CrewNote or RosterChange Info
			if (Ack_Key.equals("recent")){
				//remarked by vicki for KACCD stagin 17.4.2008
				SQL = 	"SELECT DISTINCT STAFFID," +
						"to_char(START_DATE,'DD-MON-YY') START_DATE," +
						"to_char(END_DATE,'DD-MON-YY') END_DATE, "+
						"MSG_TYPE, ROSTER_FROM_MQ_PKEY," +
						"ACK_TIMESTAMP,ACK_TIME FROM V_CREW_NOTE " +
						"WHERE STAFFID ='" + ern +"' AND "+
						"ACK_TIMESTAMP = (SELECT DISTINCT MAX(ACK_TIMESTAMP) FROM V_CREW_NOTE WHERE STAFFID ='"+ern+"')";
				
				/*SQL = 	"SELECT DISTINCT STAFFID," +
						"to_char(START_DATE,'DD-MON-YY') START_DATE," +
						"to_char(END_DATE,'DD-MON-YY') END_DATE, "+
						"MSG_TYPE, ROSTER_FROM_MQ_PKEY," +
						"ACK_TIMESTAMP,ACK_TIME FROM V_CREW_NOTE " +
						"WHERE STAFFID ='1234' AND "+
						"ACK_TIMESTAMP = (SELECT DISTINCT MAX(ACK_TIMESTAMP) FROM V_CREW_NOTE WHERE STAFFID ='1234')";*/
				System.out.println("ack key = recent : " + SQL);
				
			}else{

				//remarked by vicki for KACCD stagin 17.4.2008
				SQL = "SELECT DISTINCT STAFFID," +
					  "to_char(START_DATE,'DD-MON-YY') START_DATE," +
					  "to_char(END_DATE,'DD-MON-YY') END_DATE, "+
				      "MSG_TYPE, ROSTER_FROM_MQ_PKEY," +
				      "ACK_TIMESTAMP,ACK_TIME FROM V_CREW_NOTE " +
					  "WHERE STAFFID ='" + ern +"' AND "+
					  "ROSTER_FROM_MQ_PKEY='"+Ack_Key+"'";
					  
				/*SQL = "SELECT DISTINCT STAFFID," +
					  "to_char(START_DATE,'DD-MON-YY') START_DATE," +
					  "to_char(END_DATE,'DD-MON-YY') END_DATE, "+
				      "MSG_TYPE, ROSTER_FROM_MQ_PKEY," +
				      "ACK_TIMESTAMP,ACK_TIME FROM V_CREW_NOTE " +
					  "WHERE STAFFID ='1234' AND "+
					  "ROSTER_FROM_MQ_PKEY='"+Ack_Key+"'";*/
				System.out.println("ack key != recent : " + SQL);
			}		  
				  
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);
			while(rs.next()){													
                  RangeStart = rs.getString("START_DATE");
				  RangeEnd = rs.getString("END_DATE");
				  msgStaffID = ern;
				  rst_from_mq_key = rs.getString("ROSTER_FROM_MQ_PKEY");
				  msgType =  rs.getString("MSG_TYPE");
				  msgAckTime = rs.getString("ACK_TIME");
				  msgRange = RangeStart + " TO " + RangeEnd;
				  haverecord=true;
			}									        
			rs.close();
			
			//2.0 get roster within the date range
			if (haverecord == true ){			 			 								

				rosters = new rstBean[100];	
				//remarked by vicki for KACCD stagin 17.4.2008
				//PAX0884 start
				/*
				SQL =  	"SELECT DISTINCT * " + 
						"FROM V_RST_CHANGE "+
						"WHERE StaffID='"+ ern +"' AND P_KEY ='" +rst_from_mq_key +"' "+										
						"ORDER BY ROSTER_DATE,SORT_ORDER";
				*/
				SQL =	"SELECT DISTINCT v.*, CASE WHEN k.STAFF_ID IS NOT NULL THEN 'Y' ELSE 'N' END AS ROSTER_UPDATED " + 
						"FROM V_RST_CHANGE v "+
						"LEFT OUTER JOIN KA_DC_DELTA k ON v.STAFFID = k.STAFF_ID AND v.ROSTER_DATE = k.ROSTER_DATE_W_DELTA " +
						"WHERE StaffID='"+ ern +"' AND P_KEY ='" +rst_from_mq_key +"' "+										
						"ORDER BY ROSTER_DATE,SORT_ORDER";
				
				//PAX0884 end
				
				/*SQL =  	"SELECT DISTINCT * " + 
						"FROM V_RST_CHANGE "+
						"WHERE StaffID='1234' AND P_KEY ='" +rst_from_mq_key +"' "+										
						"ORDER BY ROSTER_DATE,SORT_ORDER";*/
				System.out.println("rstChangeBeanList have record : " + SQL);
				rs= stmt.executeQuery(SQL);
				while(rs.next()){													
					String ern     = rs.getString("STAFFID");
					Date roster_date   = rs.getDate("ROSTER_DATE");
					String duty        = rs.getString("DUTY");						
					String sp_duty     = rs.getString("SP_DUTY");
					String ac_type     = rs.getString("AC_TYPE");
					String dep_time    = rs.getString("FLT_DEP");
					String arr_time    = rs.getString("FLT_ARR");
					String begin_time  = rs.getString("DUTY_START");
					String end_time    = rs.getString("DUTY_END");
					String from        = rs.getString("SECTOR_FROM");
					String to          = rs.getString("SECTOR_TO") ;
					String duty_time   = rs.getString("DUTY_TIME");	
					String block_time  = rs.getString("BLOCK_TIME"); 
					//PAX0884 start
					String roster_updated  = rs.getString("ROSTER_UPDATED");

					//rstBean myBean = new rstBean(ern,roster_date,duty,sp_duty,ac_type,from,to,dep_time,arr_time,begin_time,end_time,duty_time,block_time);
				    rstBean myBean = new rstBean(ern,roster_date,duty,sp_duty,ac_type,from,to,dep_time,arr_time,begin_time,end_time,duty_time,block_time,roster_updated,"0");
					//PAX0884 end				
					rosters[lst_count] = myBean;
					lst_count++;
				}									        
				rs.close();
			}
			stmt.close(); 
			 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 						
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						



	}
    

	/**
	 * @return
	 */
	public String getERN() {
		return ern;
	}

	/**
	 * @return
	 */
	public int getLst_count() {
		return lst_count;
	}

	/**
	 * @return
	 */
	public String getMsgAckTime() {
		return msgAckTime;
	}

	/**
	 * @return
	 */
	public String getMsgStaffID() {
		return msgStaffID;
	}

	/**
	 * @return
	 */
	public String getMsgRange() {
		return msgRange;
	}

	/**
	 * @return
	 */
	public String getMsgType() {
		return msgType;
	}

	/**
	 * @return
	 */
	public rstBean[] getRosters() {
		return rosters;
	}

}
