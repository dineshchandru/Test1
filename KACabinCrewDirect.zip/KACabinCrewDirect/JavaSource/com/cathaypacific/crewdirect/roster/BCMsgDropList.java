/*
 * Created on Jun 24, 2010
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class BCMsgDropList {
    
	private Connection con=null;	
	private BCMsgDropListBean [] ack_lst =  new BCMsgDropListBean [100];
	private int ack_lst_cnt = 0;

	public BCMsgDropList() {
		super();
	}

	public BCMsgDropList(String iStaffID) {
			
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn();
			
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 		

			String SQL =  "SELECT DISTINCT ACK_TIME, CREATE_TIME, CCS_MSG " +
						  "FROM KA_MQ_BCMSG WHERE STAFFID ='" + iStaffID + "' "+
						  "ORDER BY ACK_TIME DESC";
			
			stmt = con.createStatement();		
			
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				String ack_time = rs.getString("ACK_TIME");
				String create_time = rs.getString("CREATE_TIME");
				String css_msg = rs.getString("CCS_MSG");
				ack_lst [ack_lst_cnt] = new BCMsgDropListBean(iStaffID, ack_time, create_time, css_msg);
				ack_lst_cnt++; 							
			}									        
			rs.close();
			stmt.close();		
		  
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 						
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  	
	}
	


	/**
	 * @return
	 */
	public BCMsgDropListBean[] getAck_lst() {
		return ack_lst;
	}

	/**
	 * @return
	 */
	public int getAck_lst_cnt() {
		return ack_lst_cnt;
	}

}
