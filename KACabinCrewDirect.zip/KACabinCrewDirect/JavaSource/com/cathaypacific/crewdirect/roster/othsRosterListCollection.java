package com.cathaypacific.crewdirect.roster;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.swap.sw_r_BlockRosterBean;
import com.cathaypacific.crewdirect.swap.sw_r_DutyBean;
import com.cathaypacific.crewdirect.swap.sw_r_PeriodBean;
import com.cathaypacific.crewdirect.swap.sw_r_RosterDateBean;
//----------

public class othsRosterListCollection {
	  	
	private Connection con=null;
	
    private int lst_count = 0 ; 	    
	private int maxListCount = 0 ; 
    private int Cur_CNT = 0 ; 
	private String []crew_id=new String [50];	
	private String []crew_info=new String[50];	 	   	

	private othsRosterBean[][] ERNS = new othsRosterBean[50][200];		
	private String [] ern_list =new String[50];
    private int [] ERNS_CNT = new int [50];
	private int ern_list_cnt = 0;

    private othsRosterBean[][] rosters = new othsRosterBean[50][200];

    //sw indicator variables
    private sw_r_PeriodBean [] rPeriod = new sw_r_PeriodBean[200];
    private int r_Period_cnt = 0 ;  
	
    private sw_r_DutyBean [] rDuty = new sw_r_DutyBean[200];
    private int r_Duty_cnt = 0 ;   
	
    private sw_r_RosterDateBean [] rRosterDate = new sw_r_RosterDateBean[200];
    private int r_RosterDate_cnt = 0 ;  

	private sw_r_BlockRosterBean [] rBlockDate = new sw_r_BlockRosterBean[200];
	private int r_BlockDate_cnt = 0 ;  

	private String myMonth = new String("");
	//-----------------------

	//------------------ Find By DayOFF ----------------
	public othsRosterListCollection(String ern, String start_date, String day_num, String imonth) {
		// PBI#1906 - begin
		try {
		// PBI#1906 - end

		//1.0 get connection 
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();	        
		} catch (Exception ex) {
			ex.printStackTrace();		
		}

		//2.0 get ERN
		FindErnByRandom(ern, start_date, Integer.parseInt(day_num));
		this.myMonth = imonth;
		
		//3.0 get roster data
		generateRosterData(ern); 		    	    

        //4.0 close connection
			if (con != null) {
				try {
					 con.close();
			   	} catch (SQLException e) {
					e.printStackTrace();
				}
			}//if  
		// PBI#1906 - begin
		} finally {
		if (con != null) {
			try {
				 con.close();
		   	} catch (SQLException e) {
				e.printStackTrace();
			}
		}//if  
	}
		// PBI#1906 - end
	}

 	//------------------find by crewID----------------
	public othsRosterListCollection(String ern, String imonth, String [] crew_id) {
		// PBI#1906 - begin
	try {
		// PBI#1906 - end

		this.myMonth =imonth; 
		
		//1.0 get connection 
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();	        
		} catch (Exception ex) {
			ex.printStackTrace();		    			
		}

		//2.0 get Ern List
		FindErnByCrewID(ern,crew_id);		
		generateRosterData(ern);

		//3.0 close connection
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} //if  		
		// PBI#1906 - begin
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if  
		}
		// PBI#1906 - end
	}
	
	//-------------------------------------------------------------
	public othsRosterListCollection() {
		super();
	}

	//-------------------------------------------------------------
	private void generateRosterData(String req_ern) {
		for (int x = 0; x < ern_list_cnt; x++){
			Cur_CNT = x;			
			ERNS[x] = getRoster(req_ern, myMonth, ern_list[x]);
			ERNS_CNT[x] = lst_count;			
			if (lst_count > maxListCount) {
//				spileol added on 22/09/2016 for code remediation addedextra print
				System.out.println("111111");
				maxListCount = lst_count; 
			}			  
		}					   			
	}

    //------------------Find ERN by given CrewID-------------------
	private void FindErnByCrewID(String myERN, String [] crew_id) {
				
		try {	
			if (con == null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			ResultSet rsx = null;
			Statement stmtx = null; 
			stmtx = con.createStatement();						
			String sql = new String("");			
			ern_list_cnt = 0;

			//add myself 
			ern_list[ern_list_cnt]= myERN;
			ern_list_cnt++;

			for (int y = 0; y < crew_id.length; y++) {
			   if (crew_id[y] != null) {	
			   				 							   
					// get ERN 
					if (crew_id[y].indexOf("'") > 0)  //elimate double quote
						crew_id[y] = crew_id[y].substring(0,crew_id[y].indexOf("'"))+"'"+crew_id[y].substring(crew_id[y].indexOf("'"));	    		
                    
					sql = "SELECT DISTINCT ERN FROM ISDCREW.CREWDB_4_ALL "+
						  "WHERE UPPER(CREW_ID) ='" + crew_id[y].toUpperCase() + "'";
					rsx = stmtx.executeQuery(sql);
//					spileol added on 22/09/2016 for code remediation extra println
					System.out.println("The SQL is ----->" + sql);
					while (rsx.next()){
						ern_list[ern_list_cnt] = rsx.getString("ERN");
						ern_list_cnt++;	
					}									
				}
			}
			rsx.close();
			stmtx.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();
			// PBI#1906 - begin
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if  
			// PBI#1906 - end
		}	
	}
	
	//-------------------------------------------
	//get ERN by Random for input start_date and no. of consecutive day-off
	private void FindErnByRandom(String ern, String start_date, int day_num) {  
		
		String sql = new String("");
		String mycat = new String("");
		String sql_pre = new String("");
		String sql_end = new String("");
		String sql_main = new String("");
		String sql_ran_1 = new String("");
		String sql_ran_2 = new String("");

		try {	
			if (con == null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}
			
			//1.0 find my cate			           
			ResultSet rsx=null;
			Statement stmtx=null; 						
			ResultSet rsy=null;
			Statement stmty=null; 						
		
			sql = "SELECT DISTINCT CAT FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+ern+"'";			
			stmtx = con.createStatement();		
			rsx = stmtx.executeQuery(sql);
			while (rsx.next()){								
				mycat = rsx.getString("CAT" );										
			}		
			rsx.close();
			stmtx.close();
			
			//2.0 find ern Randomly by given max 9 staff for G, SB            			
			//Comment on 25 Oct 2006 : SQL Tuning
			//sql_ran_1 ="select ern from (select ern from ("; 
			sql_ran_1 ="SELECT /*+ PARALLEL(, 2) */ ERN FROM (SELECT /*+ PARALLEL(, 2) */ ERN FROM (";	
			
			if (day_num > 1) {
				for (int y = day_num-1; y >= 1; y--){
					//Comment on 25 Oct 2006 : SQL Tuning
				   	//sql_pre = sql_pre + "SELECT DISTINCT ERN FROM CREWDIR.V_ROSTER_PUBLIC WHERE DUTY IN ('G','SB') AND ROSTER_DATE =to_date('"+start_date+"','DD-MON-YY')+"+y+" AND ERN IN (" ;
				   	sql_pre = sql_pre + "SELECT /*+ PARALLEL(V_ROSTER_PUBLIC1, 2) */ DISTINCT ERN " +
				   	 		  "FROM CREWDIR.V_ROSTER_PUBLIC V_ROSTER_PUBLIC1 WHERE DUTY IN ('G','SB') " +
				   	 		  "AND ROSTER_DATE = TO_DATE('"+start_date+"','DD-MON-YY')+"+y+" AND ERN IN (" ;
				}
			}

			//Comment on 25 Oct 2006 : SQL Tuning
			//sql_main = "SELECT DISTINCT ERN FROM CREWDIR.V_ROSTER_PUBLIC WHERE DUTY IN ('G','SB') AND ROSTER_DATE =to_date('"+start_date+"','DD-MON-YY') AND" +
			//		   " ERN IN (SELECT DISTINCT ERN FROM ISDCREW.CREWDB_4_ALL WHERE CAT='"+mycat+"')";
					   
			sql_main = "SELECT /*+ PARALLEL(V_ROSTER_PUBLIC2, 2) */ DISTINCT ERN " +						"FROM CREWDIR.V_ROSTER_PUBLIC V_ROSTER_PUBLIC2 WHERE DUTY IN ('G','SB') " +
						"AND ROSTER_DATE = TO_DATE('"+start_date+"','DD-MON-YY') "+
						"AND ERN IN (SELECT /*+ PARALLEL(CREWDB_4_ALL, 2) */ DISTINCT ERN FROM ISDCREW.CREWDB_4_ALL "+
						"WHERE CAT = '"+mycat+"') GROUP BY ERN";
			if (day_num > 1){
				for (int y = day_num-1; y >= 1; y--){
					sql_end = sql_end + ")" ;   		
				}
			}
			
			//Comment on 25 Oct 2006 : SQL Tuning
			//sql_ran_2 = ") where ern like '%' order by dbms_random.value) where rownum <= 9";					 	  							 									 
			sql_ran_2 = ") WHERE ERN LIKE '%' ORDER BY DBMS_RANDOM.VALUE) WHERE ROWNUM <= 9";

			sql = sql_ran_1 + sql_pre+ sql_main + sql_end + sql_ran_2;

			stmty = con.createStatement();		
			rsy = stmty.executeQuery(sql);
			ern_list_cnt = 0;
			//add myself as 1st element
			ern_list[ern_list_cnt]= ern;
			ern_list_cnt++;			
			while (rsy.next()) {								
				ern_list[ern_list_cnt] = rsy.getString("ERN");
				ern_list_cnt++;								
			}							
			rsy.close();
			stmty.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if    			
							
		} catch (Exception ex) {
			ex.printStackTrace();
			// PBI#1906 - begin
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if  
			// PBI#1906 - end
		} 
	}

	//--------------------Get Roster Details
  	public othsRosterBean [] getRoster(String req_ern, String imonth, String iern) {
	  
	  	othsRosterBean[] rosters = new othsRosterBean[100];
//		spileol added on 22/09/2016 for code remediation extra print
		System.out.println("22222222");
		System.out.println("Can complete the getSwqpRestriction");
	        
	  	//get Swap Restriction informations	
	  	getSwapRestriction(iern);
		
		try {	
			boolean showRoster = true;			
		    ResultSet rs = null;			
		    Statement stmt = null;
		    ResultSet rsx = null;			
		    Statement stmtx = null;
		    String SQL = null;
		    lst_count = 0;		
			Date last_r_date = null;
		    String last_r_duty = null;
		    int last_r_date_cnt = 0;		  
		    boolean toSkip = false;				 			 				    		  			 			 		
						
		  	//1.0 find Crew_ID
			if (con == null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}
		
			showRoster = true;
	     	if (!req_ern.equals(iern)) {
				SQL = "SELECT DISTINCT x.CREW_ID as CREW_ID,'Monthly' AS COS, " +
					  "x.cat1 as cat1,x.cat as cat,x.cat2 cat2,'K' as PCOS,y.Roster_info as PROSTER " +
					  "FROM ISDCREW.CREWDB_4_ALL X, CREWDIR.KA_CREW_PROFILE Y " +
					  "WHERE X.ERN = '"+iern+"' AND X.ERN = Y.STAFFID";
//				spileol added on 22/09/2016 for code remediation extra println
				System.out.println("7777777---->" + SQL);
				stmt = con.createStatement();		
				rs = stmt.executeQuery(SQL);			
				while(rs.next()) {			  	  									
				  	crew_id[Cur_CNT] = rs.getString("CREW_ID");                  
                  	//--COS
	  			  	if (rs.getString("PCOS").equals("N")){
						crew_info[Cur_CNT] = "COS: Not Disclosed , CAT:"+rs.getString("CAT1")+"-"+rs.getString("CAT")+"-"+rs.getString("CAT2");   
					} else {
						crew_info[Cur_CNT] = "COS:"+rs.getString("COS")+", CAT:"+rs.getString("CAT1")+"-"+rs.getString("CAT")+"-"+rs.getString("CAT2");
				  	}

					//check disclosed infos
					if (rs.getString("PRoster").equals("N")){				  
				  		crew_info[Cur_CNT] = "Roster Not Disclosed";
				  		showRoster = false;
					} else {
				  		showRoster = true;
					}
				}
				rs.close();
				
	     	} else {
				crew_id[Cur_CNT] = "My Roster";
				crew_info[Cur_CNT] = "";
	     	}
	     	
			//2.0 get all roster details			
			if (showRoster){			
				SQL = "SELECT DISTINCT * " +
					  "FROM CREWDIR.V_ROSTER_PUBLIC "+
				  	  "WHERE STAFFID='"+iern+"' AND TO_CHAR(ROSTER_DATE,'MM') >= '"+imonth+"' "+
				  	  "ORDER BY ROSTER_DATE, SORT_ORDER";
			  	stmt = con.createStatement();		
			  	rs= stmt.executeQuery(SQL);
//			  	spileol added on 22/09/2016 for code remediation extra println
			  	System.out.println("88888888------>" + SQL);
			  	while(rs.next()){		
					String ern         = rs.getString("STAFFID");
					Date roster_date   = rs.getDate("ROSTER_DATE");
					String duty        = rs.getString("DUTY");						
					String sp_duty     = rs.getString("SP_DUTY");
					String ac_type     = rs.getString("AC_TYPE");
					String dep_time    = rs.getString("FLT_DEP");
					String arr_time    = rs.getString("FLT_ARR");
					String begin_time  = rs.getString("DUTY_START");
					String end_time    = rs.getString("DUTY_END");
					String from        = rs.getString("SECTOR_FROM");
					String to          = rs.getString("SECTOR_TO") ;
					String duty_time   = rs.getString("DUTY_TIME");
					String block_time  = rs.getString("BLOCK_TIME");
					String eswap = getSwapIndicator(roster_date,duty,sp_duty);
				
					//skip same day with blank line
					toSkip = false;
					if (last_r_date_cnt > 0) {
						if (roster_date.compareTo(last_r_date) == 0){
							if (last_r_duty.length() > 0 & duty.equals(" ")) {
								toSkip = true;
							}
						}
					}
					last_r_duty = duty;
					last_r_date = roster_date;
					last_r_date_cnt++;

					if (toSkip == false){
						othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty,ac_type,from,to,dep_time,arr_time,begin_time,end_time,duty_time,block_time,eswap);					
						rosters[lst_count] = myBean;
						lst_count++;
					}	
				}
				rs.close();
			}
			stmt.close();
	
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if    			
	
		} catch (Exception ex) {
			ex.printStackTrace();
			// PBI#1906 - begin
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if  
			// PBI#1906 - end
	  	} 

		return rosters;
	}

	//----------------------------------------------------------------------------------
	private String getSwapIndicator(Date irdate, String iDuty, String iSP){

		String myReturn = "Y";
		/*
		//0.0 user self blocked roster date
		if (r_BlockDate_cnt > 0){
			for (int x=0;x<r_BlockDate_cnt;x++) {
			  if (irdate.compareTo(rBlockDate[x].getBlockDate()) == 0){				    	 
					 myReturn = "B";
					 break;				   		
			  }
		  }
		} //0.0


		//1.0 (no swap period blocked)
		if (r_Period_cnt > 0){
			  for (int x=0;x<r_Period_cnt;x++) {
				  if (irdate.compareTo(rPeriod[x].getStart_date()) >= 0){				    	 
					  if (irdate.compareTo(rPeriod[x].getEnd_date()) <= 0){
						 myReturn = "N";
						 break;
					  }   		
				  }
			  }
		  } //1.0

		 //2.0 except duty (G,SB,R,RY,O)
	 	 if (!(iDuty.equals("G") ||iDuty.substring(0,1).equals("O") ||
				iDuty.equals("TG")  ||iDuty.substring(0,1).equals("N")||
				iDuty.equals("SB") ||iDuty.substring(0,1).equals("R")) ){		
	*/

		//2.1 added on 1 Aug 2005, standby duty('N', 'R') usually ends with different pattern code 
		//only read the first 3 chars to identify the duty code
		if (iDuty.trim().length() >= 3 && (iDuty.startsWith("N") || iDuty.startsWith("R"))) {
			iDuty = iDuty.substring(0, 3);
		}
				
		//2.2 duty code (no flight)	find excluded duty	  		
		if (isFlightDuty(iDuty)==false) {
			myReturn = "N";						
			if (r_Duty_cnt > 0){				
				for (int y = 0; y < r_Duty_cnt; y++) {
					if (rDuty[y].getR_type().equals("EX_DUTY")) {
						if (rDuty[y].getCode().equals(iDuty)) {
							myReturn = "Y";
							break;	
						}
					}						
				}//for
			}	
		}		
	
		//2.2 sp_duty  find exclued sp_duty
		if (myReturn.equals("Y")) {		
			if (!iSP.equals(" ")) {
				myReturn = "N";
				if (r_Duty_cnt > 0) {				
					for (int y = 0; y < r_Duty_cnt; y++) {
						if (rDuty[y].getR_type().equals("EX_SP")) {
							if (rDuty[y].getCode().equals(iSP)) {
								myReturn = "Y";
								break;	
							}
						}						
					}//for				
				} 
			}			
		}//myReturn			
			
		//moved on 1 Aug 05, the "RED" roster block indicator override the "GREY" roster block (EX_DUTY/EX_SP_DUTY) 
		//2.8 user self blocked roster date
	 	if (r_BlockDate_cnt > 0) {
			for (int x = 0; x < r_BlockDate_cnt; x++) {
				if (irdate.compareTo(rBlockDate[x].getBlockDate()) == 0) {				    	 
					myReturn = "B";
					break;				   		
				}
			}
		} //2.8

	 	//moved on 1 Aug 05, the "RED" roster block indicator override the "GREY" roster block (EX_DUTY/EX_SP_DUTY) 
	 	//2.9 (no swap period blocked)
	 	if (r_Period_cnt > 0) {
		 	for (int x = 0; x < r_Period_cnt; x++) {
				if (irdate.compareTo(rPeriod[x].getStart_date()) >= 0) {				    	 
					if (irdate.compareTo(rPeriod[x].getEnd_date()) <= 0) {
						myReturn = "N";
						break;
				 	}
			 	}
		 	}
	 	} //2.9
	 
	 	//3.0 (admin approved date action allow)	
	 	if (r_RosterDate_cnt > 0) {
		  	for (int z = 0; z < r_RosterDate_cnt; z++) {
				if (rRosterDate[z].getR_date().compareTo(irdate) == 0) {
					myReturn = rRosterDate[z].getAction_type();
					break; 		
			  	}
		  	}
	 	}
		
	  	///4.0 set return	
	  	return myReturn;
  	}

	//----------------------------------------------------------------------------------     
  	public void getSwapRestriction(String iern) {
	  	
		try {
//			 added on 22/09/2016 for code remediation extra println
			System.out.println("333333");
			if (con == null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			ResultSet rs = null;			
		  	Statement stmt = con.createStatement();
		  	String SQL = null;
			 			 		
		  	//1.1 (no swap period)
		  	r_Period_cnt=0;
		  	SQL = "SELECT to_date(start_date,'dd-mon-yy') as start_date,to_date(end_date,'dd-mon-yy') as end_date,reason,ern " +
		  		  "FROM CREWDIR.SW_R_RESTRICT_PERIOD WHERE ERN='"+iern+"'";						   							  
		  	rs = stmt.executeQuery(SQL);		
//		  	spileol added on 22/09/2016 for code remediation extra println
	        System.out.println("44444444----->" + SQL);
		  	while(rs.next()) {										
				String ern = rs.getString("ERN");
			  	Date startdate = rs.getDate("START_DATE");
			  	Date enddate = rs.getDate("END_DATE");
			  	String reason = rs.getString("REASON");
			  	sw_r_PeriodBean sw_crew = new sw_r_PeriodBean(ern,startdate,enddate,reason);
			  	rPeriod [r_Period_cnt] = sw_crew;
			  	r_Period_cnt++;
		  	}
          	rs.close();
            
		  	//1.2 (duty code)
		  	r_Duty_cnt = 0;
		  	SQL = "SELECT * FROM CREWDIR.SW_R_DUTY "; 				   						   					
		  	rs = stmt.executeQuery(SQL);
//		  	spileol added on 22/09/2016 for code remediation extra println
		  	System.out.println("555555555----->" + SQL);
		  	while(rs.next()) {										
				String rtype = rs.getString("R_TYPE");
			  	String code = rs.getString("CODE");
			  	sw_r_DutyBean  sw_duty = new sw_r_DutyBean(rtype,code);
			  	rDuty [r_Duty_cnt] = sw_duty;
			  	r_Duty_cnt++;
		  	}
		  	rs.close();
		  
		  	//1.3 (admin approved date)
		  	r_RosterDate_cnt = 0;
		  	SQL = "SELECT * FROM CREWDIR.SW_R_ROSTER_DATE " +
				  "WHERE ERN='"+iern+"' ORDER BY R_DATE";						   			
		  	rs = stmt.executeQuery(SQL);
//		  	spileol added on 22/09/2016 for code remediation extra println
		  	System.out.println("666666666----->" + SQL);
		  	while(rs.next()){										
			  	String ern = rs.getString("ERN");
			  	Date rdate = rs.getDate("R_DATE");
			  	String actiontype = rs.getString("SWAP");
			  	String reason = rs.getString("REASON");  
			  	sw_r_RosterDateBean sw_rdate = new sw_r_RosterDateBean(ern,rdate,actiontype,reason);
			  	rRosterDate [r_RosterDate_cnt] = sw_rdate;
			  	r_RosterDate_cnt++;
		  	}
		  	rs.close();
		  
		  	//1.4 user blocked roster date
		  	r_BlockDate_cnt=0;
		  	SQL = "SELECT * FROM CREWDIR.SW_R_BLOCK_ROSTER " +
		  	      "WHERE ERN='"+iern+"' ORDER BY B_DATE";						   			
		  	rs = stmt.executeQuery(SQL);			
		  	while(rs.next()){										
				Date bdate = rs.getDate("B_DATE");
				sw_r_BlockRosterBean sw_bdate = new sw_r_BlockRosterBean(bdate);
				rBlockDate [r_BlockDate_cnt] = sw_bdate;
				r_BlockDate_cnt++;
  		  	}
		  	rs.close();
		  
		  	stmt.close();
		  									        
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} //if    			

	  	} catch (Exception ex) {
			ex.printStackTrace();		    			
	  	}
	}
	
	//----------------------------------------------------------------------------------
  	private boolean isFlightDuty(String duty){
		boolean myreturn = true;
	  	int num;
    	
		if (!duty.equals(" ")){    	
			for (int x = 0; x < duty.length(); x++) {    		
				try { 
					num = Integer.parseInt(duty.substring(x,x+1)); 
				} catch (NumberFormatException nfe) {
					myreturn = false;
					break; 
				}
			}
		}
		return myreturn;
	}
	
	//----------------------------------------------------------------------------------    
	/**
	 * @return
	 */
	public String[] getCrew_id() {
//        spileol added on 22/09/2016 for code remediation extra println
		System.out.println("getcrew_id not null" + crew_id);
		return crew_id;
	}

	/**
	 * @return
	 */
	public String[] getCrew_info() {
//        spileol added on 22/09/2016 for code remediation extra println
		System.out.println("getCrew_info not null" + crew_info);
		return crew_info;
	}

	/**
	 * @return
	 */
	public String[] getErn_list() {
//        spileol added on 22/09/2016 for code remediation extra println
		System.out.println("getErn_list not null" + ern_list);
		return ern_list;
	}

	/**
	 * @return
	 */
	public int getErn_list_cnt() {
//		spileol added on 22/09/2016 for code remediation extra println
        System.out.println("getErn_list_cnt not null" + ern_list_cnt);
		return ern_list_cnt;
	}

	/**
	 * @return
	 */
	public othsRosterBean[][] getERNS() {
		return ERNS;
	}

	/**
	 * @return
	 */
	public int getMaxListCount() {
		return maxListCount;
	}

	/**
	 * @return
	 */
	public int[] getERNS_CNT() {
		return ERNS_CNT;
	}
}
