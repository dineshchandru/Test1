/*
 * Created on Jun 23, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.roster;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;


public class rstChangeDropList {
	private Connection con=null;
	
	private rstChangeDropListBean [] ack_lst =  new rstChangeDropListBean [100];
	private int ack_lst_cnt = 0;

	public rstChangeDropList() {
		super();
	}

	public rstChangeDropList(String iStaffID) {
			
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
	    
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 		

 			//remark by vicki for KACCD staging 17.4.2008
			String SQL =  "SELECT DISTINCT ACK_TIMESTAMP,ACK_TIME,ROSTER_FROM_MQ_PKEY " +
						  "FROM V_CREW_NOTE WHERE STAFFID ='" + iStaffID + "' "+
						  "ORDER BY ACK_TIMESTAMP DESC";
			
			/*String SQL =  	"SELECT DISTINCT ACK_TIMESTAMP,ACK_TIME,ROSTER_FROM_MQ_PKEY " +
			  				"FROM V_CREW_NOTE WHERE STAFFID ='1234' "+
							"ORDER BY ACK_TIMESTAMP DESC";*/
			stmt = con.createStatement();		
			
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				String ack_key = rs.getString("ROSTER_FROM_MQ_PKEY");				
				String ack_time = rs.getString("ACK_TIME");
				ack_lst [ack_lst_cnt] = new rstChangeDropListBean(ack_key,ack_time);
				ack_lst_cnt++; 							
			}									        
			rs.close();
			stmt.close();		
		  
			//set return data			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 						
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  	
	}
	


	/**
	 * @return
	 */
	public rstChangeDropListBean[] getAck_lst() {
		return ack_lst;
	}

	/**
	 * @return
	 */
	public int getAck_lst_cnt() {
		return ack_lst_cnt;
	}

}
