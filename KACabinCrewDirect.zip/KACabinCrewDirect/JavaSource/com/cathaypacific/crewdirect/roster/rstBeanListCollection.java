package com.cathaypacific.crewdirect.roster;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import com.cathaypacific.crewdirect.databeans.dbconnect;
//----------

public class rstBeanListCollection {
	private Connection con=null;	
	private int recordCount;
	private int maxListCount =0; 


	private String []M = new String[12];
	private String []M_Info = new String[12];


    private int [] lst_count = new int [12];
    private rstBean[][] monthRosters =  new rstBean [12][200];  //12 months each max 200 records
	
	public rstBeanListCollection() {
		super();
	}


	public void getRosterData(String iStaffID){
		try{	
			//connect to db
			dbconnect db = new dbconnect();
			con = db.getConn();	        
			ResultSet rsMonth=null;
			ResultSet rs=null;			
			String sql =null;
			String crewid=null;
			Statement stmtx = con.createStatement();
			Date last_r_date = null;
			String last_r_duty = null;
			int last_r_date_cnt = 0;
			
			boolean toSkip = false;
			//0.0 get crew_id
			/*sql = "SELECT DISTINCT CREW_ID "+
						 "FROM ISDCREW.CREWDB_4_ALL " +
						 "WHERE ERN='"+iern+"'" ;		


			rs = stmtx.executeQuery(sql);			

			while (rs.next()){				
				crewid = rs.getString("crew_id" );
				break;
			}*/					

			//rs.close();
			
			//1.0 get months list, then put data into arraylist month by month
			//remarked by vicki for KACCD 17.4.2008
			sql = 		"SELECT DISTINCT TO_CHAR(ROSTER_DATE,'Mon YY') AS month_lst,to_char(sysdate,'dd/mm/yy hh24:mi') as mydate, " +
						"TO_CHAR(ROSTER_DATE,'mmyy') AS month_ord " +
						"FROM V_ROSTER_MASTER " +
						"WHERE STAFFID='" + iStaffID + "' AND TO_CHAR(ROSTER_DATE,'Mon YY') is not null " +
						"ORDER BY month_ord";	
			
			/*sql = 		"SELECT DISTINCT TO_CHAR(ROSTER_DATE,'Mon YY') AS month_lst,to_char(sysdate,'dd/mm/yy hh24:mi') as mydate, " +
						"TO_CHAR(ROSTER_DATE,'mmyy') AS month_ord " +
						"FROM V_ROSTER_MASTER " +
						"WHERE STAFFID='1234' AND TO_CHAR(ROSTER_DATE,'Mon YY') is not null " +
						"ORDER BY month_ord";*/
			
			stmtx = con.createStatement();		
			rsMonth = stmtx.executeQuery(sql);
			recordCount = 0;

			while (rsMonth.next()){				
				M[recordCount] = rsMonth.getString("month_lst" );
				//remark for interface comment 31.7.2008
				//M_Info[recordCount] = rsMonth.getString("month_lst" ) + " Roster of "+ iStaffID + " @ "+ rsMonth.getString("mydate");
				M_Info[recordCount] = rsMonth.getString("month_lst" ) + " @ "+ rsMonth.getString("mydate");
				recordCount++;
			}		
			rsMonth.close();
						
			//2.0 get roster by month
			maxListCount = 0;			
			for (int m=0;m<recordCount;m++){
				lst_count[m] = 0;
				
				//PAX0884 start				
				//remarked by vicki for KACCD 17.4.2008
				/*
				sql =	"SELECT DISTINCT * " + 
						"FROM V_ROSTER_MASTER "+
						"WHERE STAFFID='" + iStaffID +"' AND " +
						"TO_CHAR(ROSTER_DATE,'Mon YY')='"+M[m]+"' "+
						"ORDER BY ROSTER_DATE,SORT_ORDER";
				*/
				sql =	"SELECT DISTINCT v.*, CASE WHEN k.STAFF_ID IS NOT NULL THEN 'Y' ELSE 'N' END AS ROSTER_UPDATED " + 
						"FROM V_ROSTER_MASTER v "+
						"LEFT OUTER JOIN KA_DC_DELTA k ON v.STAFFID = k.STAFF_ID AND v.ROSTER_DATE = k.ROSTER_DATE_W_DELTA " +
						"WHERE STAFFID='" + iStaffID +"' AND " +
						"TO_CHAR(ROSTER_DATE,'Mon YY')='"+M[m]+"' "+
						"ORDER BY ROSTER_DATE,SORT_ORDER";
				//PAX0884 end
				
				/*sql =	"SELECT DISTINCT * " + 
						"FROM V_ROSTER_MASTER "+
						"WHERE STAFFID='1234' AND " +
						"TO_CHAR(ROSTER_DATE,'Mon YY')='"+M[m]+"' "+
						"ORDER BY ROSTER_DATE,SORT_ORDER";*/
			
				rs= stmtx.executeQuery(sql);

				//-----------SPILIUZ---------------------
				//-----------PAX1153---------------------
				String SQL="select * from crewdir.SW_R_RESTRICT_PERIOD where ERN='"+iStaffID+"' ";
				Statement stmtx2 = con.createStatement();
				ResultSet rs2=stmtx2.executeQuery(SQL);
				ArrayList swaprestrict=new ArrayList();
				while(rs2.next()){
					Date []temp=new Date[2];
					temp[0]=rs2.getDate("START_DATE");
					temp[1]=rs2.getDate("END_DATE");
					swaprestrict.add(temp);
				}
				stmtx2.close();
				rs2.close();
				//-----------END---------------------
				
				while(rs.next()){													
					String ern     = rs.getString("STAFFID");
					Date roster_date   = rs.getDate("ROSTER_DATE");
					String duty        = rs.getString("DUTY");						
					String sp_duty     = rs.getString("SP_DUTY");
					String ac_type     = rs.getString("AC_TYPE");
					String dep_time    = rs.getString("FLT_DEP");
					String arr_time    = rs.getString("FLT_ARR");
					String begin_time  = rs.getString("DUTY_START");
					String end_time    = rs.getString("DUTY_END");
					String from        = rs.getString("SECTOR_FROM");
					String to          = rs.getString("SECTOR_TO") ;
					String duty_time   = rs.getString("DUTY_TIME");
					String block_time  = rs.getString("BLOCK_TIME");
					//PAX0884 start
					String roster_updated  = rs.getString("ROSTER_UPDATED");
					String ishighlight="0";
					//PAX0884 end
					
					//-----------SPILIUZ---------------------
					//-----------PAX1153---------------------
					Iterator iterator=swaprestrict.iterator();
					while(iterator.hasNext()){
						Date[]mydate=(Date[])iterator.next();
						if(roster_date.equals(mydate[1])||roster_date.equals(mydate[0])||(roster_date.after(mydate[0])&&roster_date.before(mydate[1]))){
							ishighlight="1";
							break;
						}
					}
					//-----------END---------------------
					
					
					
					
					
					//skip same day with blank line
					toSkip = false;
					if (last_r_date_cnt > 0) {
						if (roster_date.compareTo(last_r_date) == 0){
							if (last_r_duty.length() > 0 & duty.equals(" ") ){
								toSkip = true;
							}
						}
					}
				    last_r_duty = duty;
					last_r_date = roster_date;
					last_r_date_cnt++;
				
					if (toSkip==false){													
						//PAX0884 start
					    //rstBean myBean = new rstBean(ern,roster_date,duty,sp_duty,ac_type,from,to,dep_time,arr_time,begin_time,end_time,duty_time,block_time);
					    rstBean myBean = new rstBean(ern,roster_date,duty,sp_duty,ac_type,from,to,dep_time,arr_time,begin_time,end_time,duty_time,block_time,roster_updated,ishighlight);
						//PAX0884 end
						monthRosters[m][lst_count[m]] = myBean;
						lst_count[m]++;
					}	
				}									        

				rs.close();				 
				//find max list count
				if (lst_count[m] > maxListCount){
					maxListCount = lst_count[m];
				}
  
			}
			stmtx.close();
						
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try

	}


	/**
	 * @return
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param i
	 */
	public void setRecordCount(int i) {
		recordCount = i;
	}

	/**
	 * @return
	 */
	public int getMaxListCount() {
		return maxListCount;
	}

	/**
	 * @param i
	 */
	public void setMaxListCount(int i) {
		maxListCount = i;
	}

/**
 * @return
 */
public String[] getM() {
	return M;
}

/**
 * @param strings
 */
public void setM(String[] strings) {
	M = strings;
}

	/**
	 * @return
	 */
	public String[] getM_Info() {
		return M_Info;
	}

	/**
	 * @param strings
	 */
	public void setM_Info(String[] strings) {
		M_Info = strings;
	}

/**
 * @return
 */
public int[] getLst_count() {
	return lst_count;
}

/**
 * @return
 */
public rstBean[][] getMonthRosters() {
	return monthRosters;
}

}
