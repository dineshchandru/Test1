
package com.cathaypacific.crewdirect.roster;

import java.text.SimpleDateFormat;
import java.util.Date;

public class rstBean {
		
	private String ern;
	private String duty;
	private String roster_date;
	private String sp_duty;
    private String ac_type;
    private String from;
    private String to;
    private String dep_time;
    private String arr_time;
    private String begin_time;
    private String end_time;
    private String duty_time;
	private String roster_week_day;
	private String block_time;
	private String ishighlight;
	//PAX0884 start
	private String roster_updated;
	
	//public rstBean(String ern,Date roster_date,String duty,String sp_duty,String ac_type,String from,String to,String dep_time,String arr_time,String begin_time,String end_time,String duty_time,String block_time) {
	public rstBean(String ern,Date roster_date,String duty,
			String sp_duty,String ac_type,String from,
			String to,String dep_time,String arr_time,
			String begin_time,String end_time,String duty_time,
			String block_time,String roster_updated,String ishighlight) {
    //PAX0884 end
	    this.ern = ern;
		this.roster_date =Date2String(roster_date);
		this.duty = duty;
		this.sp_duty = sp_duty;
		this.ac_type = ac_type;
		this.from = from;
		this.to = to;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		this.begin_time = begin_time;
		this.end_time = end_time;
		this.duty_time = duty_time;
		this.block_time = block_time;
		this.roster_week_day = Date2WeekString(roster_date);
		//PAX0884 start
		this.roster_updated = roster_updated;
		//PAX0884 end
		this.ishighlight=ishighlight;
	}

	public rstBean() {
		super();	
	}

	private String Date2String(Date myDate){
		String str=null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
		str = formatter.format(myDate);
		return str;
	}

	private String Date2WeekString(Date myDate){
		String str=null;
		SimpleDateFormat formatter = new SimpleDateFormat("E");				
		str = formatter.format(myDate).substring(0,1);
		return str;
	}
		
		
	/**
	 * @return
	 */
	public String getDuty() {
		return duty;
	}

	/**
	 * @return
	 */
	public String getERN() {
		return ern;
	}

	/**
	 * @return
	 */
	public String getRoster_date() {
		return roster_date;
	}

	/**
	 * @return
	 */
	public String getSp_duty() {
		return sp_duty;
	}

	/**
	 * @param string
	 */
	public void setDuty(String string) {
		duty = string;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param string
	 */
	public void setRoster_date(String string) {
		roster_date = string;
	}

	/**
	 * @param string
	 */
	public void setSp_duty(String string) {
		sp_duty = string;
	}

	/**
	 * @return
	 */
	public String getAc_type() {
		return ac_type;
	}

	/**
	 * @return
	 */
	public String getArr_time() {
		return arr_time;
	}

	/**
	 * @return
	 */
	public String getDep_time() {
		return dep_time;
	}

	/**
	 * @param string
	 */
	public void setAc_type(String string) {
		ac_type = string;
	}

	/**
	 * @param string
	 */
	public void setArr_time(String string) {
		arr_time = string;
	}

	/**
	 * @param string
	 */
	public void setDep_time(String string) {
		dep_time = string;
	}

	/**
	 * @return
	 */
	public String getBegin_time() {
		return begin_time;
	}

	/**
	 * @return
	 */
	public String getEnd_time() {
		return end_time;
	}

	/**
	 * @param string
	 */
	public void setBegin_time(String string) {
		begin_time = string;
	}

	/**
	 * @param string
	 */
	public void setEnd_time(String string) {
		end_time = string;
	}


	/**
	 * @return
	 */
	public String getFrom() {
		return from;
	}

	/**
	 * @return
	 */
	public String getTo() {
		return to;
	}

	/**
	 * @param string
	 */
	public void setFrom(String string) {
		from = string;
	}

	/**
	 * @param string
	 */
	public void setTo(String string) {
		to = string;
	}

	/**
	 * @return
	 */
	public String getDuty_time() {
		return duty_time;
	}

	/**
	 * @param string
	 */
	public void setDuty_time(String string) {
		duty_time = string;
	}

	/**
	 * @return
	 */
	public String getRoster_week_day() {
		return roster_week_day;
	}

	/**
	 * @param string
	 */
	public void setRoster_week_day(String string) {
		roster_week_day = string;
	}

	/**
	 * @return
	 */
	public String getBlock_time() {
		return block_time;
	}

	/**
	 * @param string
	 */
	public void setBlock_time(String string) {
		block_time = string;
	}

    /**
     * @return Returns the roster_updated.
     */
    public String getRoster_updated() {
        return roster_updated;
    }
    
    /**
     * @param roster_updated The roster_updated to set.
     */
    public void setRoster_updated(String roster_updated) {
        this.roster_updated = roster_updated;
    }

	public String getIshighlight() {
		return ishighlight;
	}

	public void setIshighlight(String ishighlight) {
		this.ishighlight = ishighlight;
	}
    
    
}
