/*
 * Created on Jun 22, 2010
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.common;

/**
 * @author CPPBIL
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GenericCrewDirect {
	
	private static Log logger = Log.getInstance();
	private static PropertiesBean prop = PropertiesBean.getInstance();
	
	public static void writeDebugLog(String pLog)
    {
    	logger.writeDebugLog(pLog);
    }

	public static void writeInfoLog(String pLog)
    {
    	logger.writeInfoLog(pLog);
    }

	public static void writeErrorLog(String pLog)
    {
    	logger.writeErrorLog(pLog);
    }
	
	public static String getProperty(String key)
    {
    	return prop.getProperty(key);
    }	

}
