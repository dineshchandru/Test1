/*
 * Created on Jun 25, 2010
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.common;

/**
 * @author CPPBIL
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/*
 * Created on Jun 25, 2010
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.MissingResourceException;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;


public class PropertiesBean 
{
	
	private static PropertiesBean instance;
	/** The propertyFile is file contained the properties. */
	// give default value...
//	private static String thisResourceLoc = "";
	private static String thisResourceLoc = "repos.prop.ccd.ccd";	
//	private static String thisFileLoc = "";
	private static String thisFileLoc = "/repos/prop/ccd/ccd.properties";
	
	public static PropertiesBean getInstance() 
	{
		if (instance == null) {
			instance = new PropertiesBean();
		}
		return instance;
	}

	public static PropertiesBean getInstance(String pResLoc, String pFileLoc) 
	{
		if (instance == null) {
			instance = new PropertiesBean();
			loadProperty();
			loadProperty(pResLoc, pFileLoc);
		}
		return instance;
	}

	/** The prop is for storing property retrieved from the property file. */
	private static Properties prop = new Properties();
	

	/**
     * Load the property object with the key/value in the property file.
     */
     
	private static void loadProperty() throws java.util.MissingResourceException
	{
		loadProperty(thisResourceLoc, thisFileLoc);
	}
	
	private static void loadProperty(String pResLoc, String pFileLoc) throws java.util.MissingResourceException
	{
        FileInputStream fileInput = null;
        ResourceBundle bundle = null;
        try {
			System.out.println("PropertiesBean>loading Property..." + pFileLoc);
//			System.out.println("pFileLoc: " + pFileLoc);
        	fileInput = new FileInputStream(pFileLoc);
			bundle = new PropertyResourceBundle(fileInput);
			
		}  catch (Throwable t) {
//			System.out.println("pResourceLoc: " + pResourceLoc);
			bundle = ResourceBundle.getBundle(pResLoc);
		} finally {
           	if(fileInput != null) {
               	try {
                   	fileInput.close();
				} catch (Throwable t){
				}
			}
		}
		if (null!=bundle) {
			try {
				for (Enumeration e = bundle.getKeys(); e.hasMoreElements();)
				{
					String keys = e.nextElement().toString();
					prop.put(keys, new String(bundle.getString(keys).getBytes(), "UTF8"));
				}
			} catch (UnsupportedEncodingException e) {
			}
		} else {
			System.out.println("Property file " + pFileLoc + " not found!");	
		}
	}
	
	/**
     * Returns the values of the keys in the property file. 
     *
     * @return  the Enumeration of key names exist
     *          in the property file.
     */
	
	protected final static Enumeration getNames() {
		return prop.propertyNames();
	}

    /**
     * Returns the value of matched with the provided "key". 
     *
     * @param   key   a <code>String</code>.
     * @return  if the argument is <code>null</code>, then an
     *          empty string; otherwise, the value of
     *          matched key is returned.
     */
     
	public final static String getProperty(String key) throws java.util.MissingResourceException
	{
		if (isNotPropertyAvail())
			loadProperty();

		String propertyValue = "NOT FOUND";
		if (key != null && !key.trim().equals("")) {
			try {
				propertyValue = prop.getProperty(key);
			} catch (MissingResourceException mre) {
				throw new java.util.MissingResourceException("The property key: "+key+" is not available", "PropertyWrapper", key);
			}
		}
			
		return propertyValue;
	}
	
	public final static String getProperty(String key, String pType) throws java.util.MissingResourceException
	{
		return getProperty(key);
	}

	/**
     * Test whether the Property object prop has been set with 
     * the values contained in the parameter file
     *
     * @return  <code>true</code> if and only if Property object prop
     *          has been set;
     *          <code>false</code> otherwise
     */
     
	private final static boolean isNotPropertyAvail() {
		return (prop.isEmpty());
	}

	public final static void refresh() {
		instance = new PropertiesBean();
		loadProperty();
	}

	public final static void refresh(String pResLoc, String pFileLoc) {
		prop = new Properties();
		refresh();
		loadProperty(pResLoc, pFileLoc);
	}
}

