/*
 * Created on Jun 22, 2010
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.common;

import com.cathaypacific.utility.Logger;

/**
 * @author CPPBIL
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
/**
 * Common logger used by ammember
 * 
 */
public class Log
{  	
	private static Logger LogInstance;
	private static Log instance;
	
	public static Log getInstance() 
	{
		instance.getLogger();
		System.out.println("logger name getInstance(): " + instance.getLoggerName());
		return instance;
	}	

	public static Logger getLogger()        
    {
		if (LogInstance == null) {
			LogInstance = Logger.getLogger("KACCD");
		}
		return LogInstance;
	} // end of getLogger

	public static void setLogger(String pLoggerName)        
	{
		LogInstance = Logger.getLogger(pLoggerName);
	}

	public static String getLoggerName()        
	{
		return LogInstance.getName();
	} // end of getLoggerName

	/**
	* Write log in debug level
	* 
	*/
	public static void writeDebugLog(String pLog)
	{
	//	if ("local".equals(PropertiesBean.getProperty("ENV"))) 
	//		System.out.println(pLog);
		getLogger().debug(pLog);
	}

	/**
	* Write log in info level
	* 
	*/
	public static void writeInfoLog(String pLog)
	{
	//	if ("local".equals(PropertiesBean.getProperty("ENV"))) 
	//		System.out.println(pLog);
		getLogger().info(pLog);
	}

	/**
	* Write log in error level
	* 
	*/
	public static void writeErrorLog(String pLog)
	{
	//	if ("local".equals(PropertiesBean.getProperty("ENV"))) 
	//		System.out.println(pLog);
		getLogger().error(pLog);
	}

}
