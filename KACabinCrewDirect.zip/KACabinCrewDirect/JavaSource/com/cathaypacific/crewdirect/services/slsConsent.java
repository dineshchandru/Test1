/*
 * Created on 06 Apr, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTMMN
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsConsent {
	
	private Connection con = null;
	private int sql_commit = 0 ;
	private String err_msg = "no_err";
	private String display_start = new String("");
	private String display_end = new String("");
	private String sls_details = new String("");
	private String consent_date = new String("");
	private String required_days = new String("");
	
	public slsConsent() {
		super();
	}
	
	public String get_consent_period() {

		String rtn_period_status = new String("INACTIVE");
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
	
			String strsql = "";
			double start_count = 0;
			double end_count = 0;
			
			//Get the valid consent period
			strsql = "SELECT (CONSENT_START - SYSDATE) AS START_COUNT, (CONSENT_END - SYSDATE) AS END_COUNT, " +
					"TO_CHAR(DISPLAY_START, 'dd Mon yyyy hh24:mi') AS DISPLAY_START, " +
					"TO_CHAR(DISPLAY_END, 'dd Mon yyyy hh24:mi') AS DISPLAY_END, SLS_DETAILS " +
					"FROM CREWDIR.KA_SLS_CONTROL";
			rs = stmt.executeQuery(strsql);
			
			while (rs.next()) {
				start_count = rs.getDouble("START_COUNT");
				end_count = rs.getDouble("END_COUNT");
				display_start = rs.getString("DISPLAY_START");
				display_end = rs.getString("DISPLAY_END");
				sls_details = rs.getString("SLS_DETAILS");
			}
			rs.close();
			stmt.close();		
			con.close();

			//Valid consent period
			if (start_count < 0 && end_count > 0) {
				rtn_period_status = "ACTIVE";
            //Consent period expired
			} else if (start_count < 0 && end_count < 0) {
				rtn_period_status = "EXPIRED";
		    //Consent period not started yet
			} else if (start_count > 0 && end_count > 0) {
				rtn_period_status = "INACTIVE";
			} 

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
		return rtn_period_status;
	}
	
	public String get_consent_status(String ern) {
		
		String rtn_consent_status = "N";
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
	
			String strsql = "";
			double start_count = 0;
			double end_count = 0;
			
			//Get the Consent status of the crew
			strsql = "SELECT CONSENT, TO_CHAR(CONSENT_DATE, 'dd Mon yyyy hh24:mi') AS CONSENT_DATE, REQUIRED_DAYS " +
					"FROM CREWDIR.KA_SLS_CONSENT WHERE ERN = '" + ern + "'";
			rs = stmt.executeQuery(strsql);
			
			while (rs.next()) {
				rtn_consent_status = rs.getString("CONSENT");
				required_days = rs.getString("REQUIRED_DAYS");

				if (rtn_consent_status.equals("Y")) {
					consent_date = rs.getString("CONSENT_DATE");
				} else {
					consent_date = "";
				}
			}
			rs.close();
			stmt.close();		
			con.close();

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
		return rtn_consent_status;
	}
	
	public void updateConsent(String ern) {

//		String success_msg = new String("");
		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();     
			Statement stmt = null;	
			stmt = con.createStatement();
			String strsql = "";
			
			con.setAutoCommit(false); 	// not commit the data automatically
			
			//delete application record : status = 'A'
			strsql = 	"UPDATE CREWDIR.KA_SLS_CONSENT SET CONSENT = 'Y', CONSENT_DATE = SYSDATE, UPDATE_BY = '" + ern + "' " +
						"WHERE ERN = '" + ern + "'";
			sql_commit = stmt.executeUpdate(strsql);
			
			if (sql_commit <= 0) {
				con.rollback() ; 	//if not inserted, rollback the delete action
			} else { 
				con.commit() ;		//if inserted successfully, commit the changes			   
			}
/*			
			if (sql_commit > 0) {
			   success_msg = new String("Your SLS Consent form submitted successfully.");
			} else {
			   success_msg = new String("Your SLS Consent form submitted unsuccessfully.");
			}
	*/
			con.setAutoCommit(true); //set the commit action to auto again
			stmt.close();		
			con.close();

		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "SLS Consent : Cannot Update Record. " + sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch (SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{
			if (con != null) {	
			   try {
					 con.close();
			   } catch (SQLException e){
				  e.printStackTrace();
			   }	
			} //if  
		}//catch/try
//		return success_msg;
	}
	
	/**
	 * @return Returns the err_msg.
	 */
	public String getErr_msg() {
		return err_msg;
	}
	/**
	 * @return Returns the consent_end.
	 */
	public String getDisplay_end() {
		return display_end;
	}
	/**
	 * @return Returns the consent_start.
	 */
	public String getDisplay_start() {
		return display_start;
	}
	/**
	 * @return Returns the consent_date.
	 */
	public String getConsent_date() {
		return consent_date;
	}
	/**
	 * @return Returns the required_days.
	 */
	public String getRequired_days() {
		return required_days;
	}
	/**
	 * @return Returns the sls_details.
	 */
	public String getSls_details() {
		return sls_details;
	}
}
