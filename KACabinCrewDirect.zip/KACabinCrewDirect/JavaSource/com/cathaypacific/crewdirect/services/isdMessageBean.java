/*
 * Created on Aug 18, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.services;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class isdMessageBean {

	private String msg_id="";
	private String ern="";
	private String msg_type="";
	private String message="";
	private String msg_from="";	
	private String upd_by="";
	private String last_upd="";
	private String ack_time="";
	
		
	public isdMessageBean() {
		super();		
	}

	public isdMessageBean(String msg_id,String msg_type,String message,String msg_from,String last_upd) {
		this.msg_type = msg_type;
		this.message =message;
		this.msg_id = msg_id;
		this.msg_from = msg_from;
		this.last_upd = last_upd;		
	}

	public isdMessageBean(String msg_id,String msg_type,String message,String msg_from,String last_upd,String ack_time) {
		this.msg_type = msg_type;
		this.message =message;
		this.msg_id = msg_id;
		this.msg_from = msg_from;
		this.last_upd = last_upd;	
		this.ack_time = ack_time;	
	}

	/**
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @return
	 */
	public String getMsg_id() {
		return msg_id;
	}

	/**
	 * @return
	 */
	public String getUpd_by() {
		return upd_by;
	}


	/**
	 * @param string
	 */
	public void setMessage(String string) {
		message = string;
	}

	/**
	 * @param string
	 */
	public void setMsg_id(String string) {
		msg_id = string;
	}

	/**
	 * @param string
	 */
	public void setUpd_by(String string) {
		upd_by = string;
	}


	/**
	 * @return
	 */
	public String getAck_time() {
		return ack_time;
	}

	/**
	 * @param string
	 */
	public void setAck_time(String string) {
		ack_time = string;
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	/**
	 * @return
	 */
	public String getLast_upd() {
		return last_upd;
	}

	/**
	 * @return
	 */
	public String getMsg_from() {
		return msg_from;
	}

	/**
	 * @return
	 */
	public String getMsg_type() {
		return msg_type;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param string
	 */
	public void setLast_upd(String string) {
		last_upd = string;
	}

	/**
	 * @param string
	 */
	public void setMsg_from(String string) {
		msg_from = string;
	}

	/**
	 * @param string
	 */
	public void setMsg_type(String string) {
		msg_type = string;
	}

}
