/*
 * Created on Jul 19, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.services;
/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class number2alpha {

	private String myReturn;
	/**
	 * 
	 */
	public number2alpha() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String genAlphaNumber(String s){		
		int cur_num=Integer.parseInt(s);
		int reminder=0;
		String myNumber="";
		int divider = 36;
				
		do{
		   reminder = cur_num % divider ; //find reminder
		   myNumber = decode(reminder) + myNumber;   
		   cur_num = (cur_num - reminder)/divider ;	
		   if (cur_num<divider ){  //last char
			myNumber = decode(cur_num) + myNumber;
			break;	   
		   }
		} while (cur_num > 0);
		
 		return myNumber;		
	}	

    //-----------------------------------------
	private String decode(int num){
		String rtn="";
		switch (num){
			case 0:
			   rtn="0";
			   break;			   
			case 1:
			   rtn="1";
			   break;			   
			case 2:
			   rtn="2";
			   break;			   
			case 3:
			   rtn="3";
			   break;			   
			case 4:
			   rtn="4";
			   break;			   
			case 5:
			   rtn="5";
			   break;			   
			case 6:
			   rtn="6";
			   break;			   
			case 7:
			   rtn="7";
			   break;			   
			case 8:
			   rtn="8";
			   break;			   
			case 9:
			   rtn="9";
			   break;			   
			case 10:
			   rtn="A";
			   break;			   
			case 11:
			   rtn="B";
			   break;			   
			case 12:
			   rtn="C";
			   break;			   
			case 13:
			   rtn="D";
			   break;			   
			case 14:
			   rtn="E";
			   break;			   
			case 15:
			   rtn="F";
			   break;			   
			case 16:
			   rtn="G";
			   break;			   
			case 17:
			   rtn="H";
			   break;			   
			case 18:
			   rtn="I";
			   break;			   
			case 19:
			   rtn="J";
			   break;			   
			case 20:
			   rtn="K";
			   break;			   
			case 21:
			   rtn="L";
			   break;			   
			case 22:
			   rtn="M";
			   break;			   
			case 23:
			   rtn="N";
			   break;			   
			case 24:
			   rtn="O";
			   break;			   
			case 25:
			   rtn="P";
			   break;			   
			case 26:
			   rtn="Q";
			   break;			   
			case 27:
			   rtn="R";
			   break;			   
			case 28:
			   rtn="S";
			   break;			   
			case 29:
			   rtn="T";
			   break;			   
			case 30:
			   rtn="U";
			   break;			   
			case 31:
			   rtn="V";
			   break;			   
			case 32:
			   rtn="W";
			   break;			   
			case 33:
			   rtn="X";
			   break;			   
			case 34:
			   rtn="Y";
			   break;			   			   
			case 35:
			   rtn="Z";
			   break;			   			   

			default:
			   rtn="";
			   break;   	
		}
		return rtn;
	}
	//-----------------------------------------
}
