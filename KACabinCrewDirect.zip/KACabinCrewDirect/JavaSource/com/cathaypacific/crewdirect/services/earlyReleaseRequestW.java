package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class earlyReleaseRequestW {
	
	private String startDateONT = "";
	private Connection con = null;
	private String start_Date = "";
	private String end_Date = "";
	private String last_update = "";
	private String update_by="";
	private String status="";
	private String err_msg = "no_err";
	int id = 0;
	private boolean valid = true;
	

	
	public earlyReleaseRequestW(String ern)
	{
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";

			sql = " SELECT nvl(to_char(ROSTER_START, 'dd-Mon-yyyy'),'') as START_DATE, " + 
            " nvl(to_char(ROSTER_END, 'dd-Mon-yyyy'),'') as END_DATE, " +
            " nvl(to_char(LAST_UPDATE, 'dd-Mon-yyyy'),'') as LAST_UPDATE, " +
            " UPDATE_BY,STATUS,ID as APP_ID " +   
            " FROM QUOTA_FOR_ERRQ " +
            " WHERE ROWNUM = 1 and STATUS='ACTIVE' and sysdate between PERIOD_START and PERIOD_END order by PERIOD_START";
	
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{	
				if (rs.getString("START_DATE") != null)
				{
					setStart_Date(rs.getString("START_DATE"));
				}
				if (rs.getString("END_DATE") != null)
				{
					setEnd_Date(rs.getString("END_DATE"));
				}
				if (rs.getString("LAST_UPDATE") != null)
				{
					setLastUpdate_Date(rs.getString("LAST_UPDATE"));
				}
				if (rs.getString("UPDATE_BY") != null)
				{
					setUpdate_by(rs.getString("UPDATE_BY"));
				}
				if (rs.getString("STATUS") != null)
				{
					setStatus(rs.getString("STATUS"));
				}
				if (rs.getInt("APP_ID") != 0)
				{
					setId(rs.getInt("APP_ID"));
				}
				break;
			}	
			
		sql= " select * from CREWDIR.early_release_request " +
			 " where" +
				" ERN= '"+ern+"'" +
				" and START_DATE= '"+this.start_Date+"'" +
				" and END_DATE= '"+this.end_Date+"'" +
				" and STATUS= '"+this.status+"'" +
				" and APP_ID= '"+this.id+"'";
		
		 rs = stmt.executeQuery(sql);
		
		if(rs.next()){
			valid =false;
		}
			
			rs.close();
			stmt.close();		
			con.close();
	
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			   err_msg = sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}
	
	public String earlyReleaseWithdrawn(String ern,String start_Date,String end_Date,String last_Update,String update_by,String status,int id)
	{	
		String sql = "";
		try{
		dbconnect db = new dbconnect();
		Connection con = db.getConn(); 
		ResultSet rs = null;			
		Statement stmt = null;			 			 					 			 		
		stmt = con.createStatement();
	
			
		sql = " update early_release_request " +
              " set status = 'Withdrawn' " +
              " where ern = '" + ern +"' " +
              " and start_date = '" + start_Date + "'" + 
              " and end_date = '" + end_Date + "'" +
              " and status='InProgress'  ";
	
		rs = stmt.executeQuery(sql);

			rs.close();
			stmt.close();		
			con.close();
	
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			   err_msg = sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
		return sql;
	}
	
	
	public void setStart_Date(String start_Date)
	{
		this.start_Date = start_Date;
	}
	public String getStart_Date()
	{
		return start_Date;
	}
	public String getEnd_Date()
	{
		return end_Date;
	}
	public void setEnd_Date(String end_Date)
	{
		this.end_Date = end_Date;
	}
	public String getLastUpdate_Date()
	{
		return last_update;
	}
	public void setLastUpdate_Date(String last_update)
	{
		this.last_update = last_update;
	}
	public String getUpdate_by()
	{
		return update_by;
	}
	public void setUpdate_by(String update_by)
	{
		this.update_by = update_by;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getONTWithdrawDate()
	{
		return startDateONT;
	}
	
	public void setONTWithdrawDate(String startDateONT)
	{
		this.startDateONT = startDateONT;
	}
	public String getErr_msg() {
		return err_msg;
	}
	public boolean isValid()
	{
		return valid;
	}
	
}
