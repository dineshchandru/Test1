package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class highFlyingHoursRequestW {

	private String startDateONT = "";
	private Connection con = null;
	private String start_Date = "";
	private String end_Date = "";
	private String last_update = "";
	private String update_by = "";
	private String status = "";
	private int id = 0;
	private String err_msg = "no_err";
	private boolean valid = true;

	public highFlyingHoursRequestW(String ern) {
		try {

			dbconnect db = new dbconnect();
			Connection con = db.getConn();

			ResultSet rs = null;
			Statement stmt = null;
			stmt = con.createStatement();
			String sql = "";

			sql = " select ID, " + " nvl(to_char(roster_start, 'dd-Mon-yyyy'),'') as START_DATE, "
					+ " nvl(to_char(roster_end, 'dd-Mon-yyyy'),'') as END_DATE, "
					+ " nvl(to_char(last_update, 'dd-Mon-yyyy'),'') as LAST_UPDATE, " + " UPDATE_BY, " + " STATUS, "
					+ " ID AS APP_ID " + " from QUOTA_FOR_HFHR "
					+ " where rownum =1 and STATUS='ACTIVE' and sysdate between PERIOD_START and PERIOD_END order by PERIOD_START";

			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				if (rs.getString("START_DATE") != null) {
					setStart_Date(rs.getString("START_DATE"));
				}
				if (rs.getString("END_DATE") != null) {
					setEnd_Date(rs.getString("END_DATE"));
				}
				if (rs.getString("LAST_UPDATE") != null) {
					setLastUpdate_Date(rs.getString("LAST_UPDATE"));
				}
				if (rs.getString("UPDATE_BY") != null) {
					setUpdate_By(rs.getString("UPDATE_BY"));
				}
				if (rs.getString("STATUS") != null) {
					setStatus(rs.getString("STATUS"));
				}
				if (rs.getInt("APP_ID") != 0) {
					setId(rs.getInt("APP_ID"));
				}
				break;
			}

			sql = " select * from CREWDIR.HIGH_FLYING_HOUR_REQUEST " + " where" + " ERN= '" + ern + "'"
					+ " and START_DATE= '" + this.start_Date + "'" + " and END_DATE= '" + this.end_Date + "'"
					+ " and STATUS= '" + this.status + "'" + " and APP_ID= '" + this.id + "'";

			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				valid = true;
			}
			rs.close();
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = sqlex.getMessage();
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} // if

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {

			if (con != null) {

				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

			} // if

		} // catch/try

	}

	public String highFlyingHoursUpdateWithdrawn(String ern, String start_Date, String end_Date, String last_Update,
			String update_by, String status, int id) {
		String sql = "";
		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = con.createStatement();

			sql = " update HIGH_FLYING_HOUR_REQUEST " + " set status = 'Withdrawn' " + " where ern = '" + ern + "' "
					+ " and start_date = '" + start_Date + "'" + " and end_date = '" + end_Date + "'"
					+ " and status='InProgress'  ";

			rs = stmt.executeQuery(sql);

			// spileol added on 22/09/2016 for code remediation extra SQL found
			sql = " update HIGH_FLYING_HOUR_REQUEST  set last_update = sysdate where ern = '" + ern + "' "
					+ " and start_date = '" + start_Date + "'" + " and end_date = '" + end_Date + "'"
					+ " and status='Withdrawn'  ";
			rs = stmt.executeQuery(sql);
			rs.close();
			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = sqlex.getMessage();
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} // if

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {

			if (con != null) {

				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

			} // if

		} // catch/try
		return sql;
	}

	public void setStart_Date(String start_Date) {
		this.start_Date = start_Date;
	}

	public String getStart_Date() {
		return start_Date;
	}

	public String getEnd_Date() {
		return end_Date;
	}

	public void setEnd_Date(String end_Date) {
		this.end_Date = end_Date;
	}

	public void setLastUpdate_Date(String last_update) {
		this.last_update = last_update;

	}

	public String getLastUpdate_Date() {
		return last_update;

	}

	public String getUpdate_By() {
		return update_by;
	}

	public void setUpdate_By(String update_by) {
		this.update_by = update_by;

	}

	public void setStatus(String status) {
		this.status = status;

	}

	public String getStatus() {
		return status;

	}

	public void setId(int id) {
		this.id = id;

	}

	public int getId() {
		return id;

	}

	public String getONTWithdrawDate() {
		return startDateONT;
	}

	public void setONTWithdrawDate(String startDateONT) {
		this.startDateONT = startDateONT;
	}

	public String getErr_msg() {
		return err_msg;
	}

	public boolean isValid() {
		return valid;
	}
}
