/*
 * Created on Mar 24, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.Vector;

import com.cathaypacific.crewdirect.databeans.agqDetail;
import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java Code Style - Code Templates
 */
public class agqRequest {
	
	private Connection con = null;
	private int sql_commit = 0 ;

	private String err_msg = "no_err";
	private String ern = "";
	private String success_msg = new String("");
	private String withdraw_date = new String("");
	
	int total_quota = 0;
	Vector agqResultVector = new Vector();
	Vector agqActiveDetailVector = new Vector();
	Vector agqPeriodVector = new Vector();
	
	public agqRequest() {
		super();
	}
	
	public agqRequest(String ern, String roster_year)
	{
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			int record_count = 0;
			
			int total_period = 0;
			int total_entitlement = 0;
			int total_approved = 0 ;
			int total_request = 0;

			//Get the available request date excluded the black-out date
			total_period = get_period_list(con, roster_year);

			//Get the AGQ year entitlement of the crew
			sql = "SELECT COUNT(*) AS RTN_COUNT FROM CREWDIR.KA_AGQ_MASTER WHERE ERN = '" + ern + "' AND ROSTER_YEAR = '" + roster_year + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				record_count = rs.getInt("RTN_COUNT");
			}
			if (record_count > 0) {
				sql = 	"SELECT ERN, ROSTER_YEAR, AGQ_ENTITLEMENT, AGQ_USED FROM CREWDIR.KA_AGQ_MASTER WHERE ERN = '" + ern + "' and ROSTER_YEAR ='" + roster_year + "'";
				rs = stmt.executeQuery(sql);
		
				while (rs.next()) {
					total_entitlement = rs.getInt("AGQ_ENTITLEMENT");
				}
			}
			
			//Get the AGQ request of the crew
			sql = "SELECT COUNT(*) AS RTN_COUNT FROM CREWDIR.KA_AGQ_REQUEST WHERE ERN = '" + ern + "' AND ROSTER_YEAR = '" + roster_year + "'";
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				total_request = rs.getInt("RTN_COUNT");
			}

			if (total_request > 0) {
				sql = 	"SELECT ERN, ROSTER_YEAR, NVL(to_char(AGQ_DATE, 'dd-Mon-yyyy'),'') as AGQ_DATE, STATUS, UPDATE_BY, NVL(to_char(LAST_UPDATE, 'dd-Mon-yy hh24:mi'),'') as LAST_UPDATE " +
						"FROM CREWDIR.KA_AGQ_REQUEST WHERE ERN = '" + ern + "' and ROSTER_YEAR ='" + roster_year + "' ORDER BY STATUS, TO_DATE(AGQ_DATE)";
				rs = stmt.executeQuery(sql);
		
				while (rs.next()) {
					agqDetail tempDetail = new agqDetail();
					String request_status = rs.getString("STATUS") ;
					tempDetail.setERN(rs.getString("ERN"));
					tempDetail.setRoster_year(rs.getString("ROSTER_YEAR"));
					tempDetail.setStart_Date(rs.getString("AGQ_DATE"));
					tempDetail.setRecord_status(rs.getString("STATUS"));
					tempDetail.setLast_Update_User(rs.getString("UPDATE_BY"));
					tempDetail.setLast_Update_Date(rs.getString("LAST_UPDATE"));
					agqResultVector.add(tempDetail);
					
					if (request_status.equals("Application")) {
						agqActiveDetailVector.add(tempDetail);
					}
					if (request_status.equals("Pending") || request_status.equals("Approved")) {
						total_approved = total_approved + 1;
					} 
				}
			}
			total_quota = total_entitlement - total_approved;
			if (total_quota < 0) {
				total_quota = 0;
			}

			//get last withdraw date
			sql = "SELECT to_char(last_update, 'dd-Mon-yy hh24:mi') as last_update " +
				  "FROM CREWDIR.KA_AGQ_REQUEST WHERE ERN = '" + ern + "' and ROSTER_YEAR ='" + roster_year + "' " +
				  "AND STATUS = 'Withdrawn' order by last_update desc";	
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				withdraw_date = rs.getString("last_update");
				break;
			}
			rs.close();
			stmt.close();		
			con.close();
			
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}

	public String update_request(String web_action, String ern, String roster_year, String insert_start) {

		String commit_msg = new String("");
		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();     
			Statement stmt = null;	
			stmt = con.createStatement();
			
			String record_status = "Application";
			String strsql = new String("");
			con.setAutoCommit(false); 	// not commit the data automatically
			
			//insert or update the records 
			if (web_action.equals("INSERT_DATA")) 
			{			
				//Delete the existing record of the specified roster year and status = 'Application'
				strsql = "DELETE CREWDIR.KA_AGQ_REQUEST WHERE ERN = '" + ern + "' and roster_year ='"+roster_year+"' and status = '"+record_status+"'";
				stmt.executeUpdate(strsql);
    
				//split the chain of string which separated by delimiter
				Vector vlist = getSplitField(insert_start, ",");

				//update the priority days-off request by each splitted date
				for (int i = 0 ; i < vlist.size() ; i++) {
					String roster_date = vlist.elementAt(i).toString();
					// Insert the GDay off request data into DB, return with 0 or 1
					strsql = "INSERT INTO CREWDIR.KA_AGQ_REQUEST (ROSTER_YEAR, ERN, AGQ_DATE, STATUS, UPDATE_BY, LAST_UPDATE) " +
							 "VALUES('" + roster_year + "', '"+ ern +"', '" + roster_date + "', '"+record_status+"', '" + ern + "', sysdate)";
					sql_commit = stmt.executeUpdate(strsql);
				}

				if (sql_commit <= 0) {
					con.rollback() ; 	//if not inserted, rollback the delete action
				} else { 
					con.commit() ;		//if inserted successfully, commit the changes			   
				}

				if (sql_commit > 0) {
					commit_msg = new String("Your Priority G Day Request of "+insert_start+" submitted successfully.");
				} else {
					commit_msg = new String("Your Priority G Day Request of "+insert_start+" submitted unsuccessfully.");
				}   

			}
			//Withdraw the application
			else if (web_action.equals("WITHDRAW_DATA")) {
				strsql = 	"UPDATE CREWDIR.KA_AGQ_REQUEST SET STATUS = 'Withdrawn', " +
							"UPDATE_BY = '" + ern + "', LAST_UPDATE = sysdate " + 
							"WHERE ERN = '" + ern + "' and roster_year ='"+roster_year+"' " +
							"AND STATUS = '"+record_status+"'";
				sql_commit = stmt.executeUpdate(strsql);

				if (sql_commit <= 0) {
					con.rollback() ; 	//if not inserted, rollback the delete action
				} else { 
					con.commit() ;		//if inserted successfully, commit the changes			   
				}
				if (sql_commit >0) {
					commit_msg = new String("Your Priority G Day Request of "+insert_start+" withdrawn successfully.");
				} else {
					commit_msg = new String("Your Priority G Day Request of "+insert_start+" withdrawn unsuccessfully.");
				}
			}

			con.setAutoCommit(true); //set the commit action to auto again
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "AGQ Request : Cannot Update Record. " + sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch (SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch (SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
		return commit_msg;
	}

	/**
	* @see 		Get the period list for the drop-down menu
	*/
	private int get_period_list(Connection con, String roster_year) {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMM");
		Calendar rightNow = Calendar.getInstance();
	    rightNow.add(Calendar.MONTH, 2);
	    java.util.Date temp = rightNow.getTime();
		String available_period = formatter.format(temp);

		int total_period = 0;
		try { 	
			Vector vlist = new Vector();
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			
			//Get the AGQ available period list in Vector for drop-down selection
			sql = "SELECT COUNT(*) AS RTN_COUNT FROM CREWDIR.KA_AGQ_QUOTA where (quota - quota_used) > 0 and roster_year= '"+roster_year+"' and to_char(roster_date, 'yyyymm') >= '"+available_period+"'" ;
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				total_period = rs.getInt("RTN_COUNT");
			}

			if (total_period > 0) {
				sql = "select NVL(to_char(ROSTER_DATE, 'dd-Mon-yyyy'),'') as ROSTER_DATE FROM CREWDIR.KA_AGQ_QUOTA where (quota - quota_used) > 0 and roster_year= '"+roster_year+"' and to_char(roster_date, 'yyyymm') >= '"+available_period+"' order by to_date(roster_date)" ;
				rs = stmt.executeQuery(sql);		
				while (rs.next()) {
					String period_list = rs.getString("roster_date");
					vlist.addElement(period_list);
				}
			}
			rs.close();
			stmt.close();
			vlist.trimToSize();
			this.setAgqPeriodVector(vlist);
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			err_msg = "Error found in module [agqRequest.get_period_list]<br><br>" + sqlex.getMessage();

		} catch (NullPointerException nullex) {
			nullex.printStackTrace();
			err_msg = "Error found in module [agqRequest.get_period_list]<br>Your session has been timeout.<br><br>Please close all the browser and try again.<br>" + nullex.getMessage();
		}
		return total_period;
	}
	
	public static Vector getSplitField(String split_list, String delimiter) {

		Vector split_result = new Vector();
		try {
			//Split the input string with specified delimiter (e.g. "," or ";")
			if (split_list.length() != 0) {
				StringTokenizer t = new StringTokenizer(split_list, delimiter);
				while (t.hasMoreTokens()) {
					split_result.addElement(t.nextToken().trim());
				}
			}
			split_result.trimToSize();

		} catch (NoSuchElementException e) {      //nextToken Exception
			System.err.println("Error found in module [agqRequest.getSplitField]<br><br>No next element : " + e.getMessage());
		}
		return split_result;
	}

	public String getErr_msg() {
		return err_msg;
	}
	
	public int getSql_commit() 
	{
		return sql_commit;
	}
	
	public String getWithdraw_Date() 
	{
		return withdraw_date;
	}
	
	public Vector getAGQResultVector()
	{
		return agqResultVector;
	}

	public Vector getAGQActiveDetailVector() {
		return agqActiveDetailVector;
	}

	public Vector getAGQPeriodVector() 
	{
		return agqPeriodVector;
	}
	
	public void setAgqPeriodVector(Vector agqPeriodVector) 
	{
		this.agqPeriodVector = agqPeriodVector;
	}

	public int getTotal_quota() {
		return total_quota;
	}

	public String getSuccess_msg() {
		return success_msg;
	}

	public void setSuccess_msg(String success_msg) {
		this.success_msg = success_msg;
	}
}
