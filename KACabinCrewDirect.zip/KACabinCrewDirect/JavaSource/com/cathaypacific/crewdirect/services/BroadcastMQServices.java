package com.cathaypacific.crewdirect.services;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

import com.cathaypacific.crewdirect.common.GenericCrewDirect;

public class BroadcastMQServices {

	private MQQueueManager qMgr;
	private byte MsgId[];	
		
	private String hostname;
	private String channel;
	private int port;
	private String userID;
	private String RemoteQR;
	private String LocalQL;	
	private String mq_rtn_txt = new String();
	private String mq_ask_txt = new String();
	
	private String QueueManagerName;

	private String mq_err_code="";
    private String err_msg; 

	
	public BroadcastMQServices() {	
		hostname = "clkmwux01";
		channel = "MQSD.KAENII";		
		port = 1414;
		userID = "ccd";
		LocalQL   =  "CCS.KAENII.POSDUTPT";
		RemoteQR   =  "KAENII.CCS.POSDUTPT";					
	}
	
	public BroadcastMQServices(String user) {	

		hostname = GenericCrewDirect.getProperty("BROADCAST_MQHOSTNAME");
		channel = GenericCrewDirect.getProperty("BROADCAST_MQCHANNEL");
		port = Integer.valueOf(GenericCrewDirect.getProperty("BROADCAST_PORT")).intValue();
		userID = GenericCrewDirect.getProperty("BROADCAST_USERID");
		QueueManagerName = GenericCrewDirect.getProperty("BROADCAST_QMANAGERNAME");
		
		GenericCrewDirect.writeInfoLog("BROADCAST_MQHOSTNAME - "+hostname);
		GenericCrewDirect.writeInfoLog("BROADCAST_MQCHANNEL - "+channel);
		GenericCrewDirect.writeInfoLog("BROADCAST_PORT - "+port);
		GenericCrewDirect.writeInfoLog("BROADCAST_USERID - "+userID);
		GenericCrewDirect.writeInfoLog("BROADCAST_QMANAGERNAME - "+QueueManagerName);
				
		//KAD13/KAD14 - Get outstanding broadcast message indicator
        //KAD15/KAD16 - Get broadcast message content to the crew member AND acknowledge the broadcast message stored in CCS.
		if (user.equals("ack") || user.equals("getBCMsg")) {								
			
			LocalQL = "CCS.KAENII.POSDUTPT";
			RemoteQR = "KAENII.CCS.POSDUTPT";
			
			System.out.println("BROADCAST LocalQL - "+LocalQL);
			System.out.println("BROADCAST RemoteQR - "+RemoteQR);
			
		}				 		
	} 
		
	public BroadcastMQServices(String hostname,String channel,int port,String userid,String QP,String QL,String QR){
		this.hostname = hostname;
		this.channel = channel;
		this.port = port;
		this.userID = userid;
		this.RemoteQR = QR;
		this.LocalQL = QL;
	}
	
	public boolean call_mq(int waitInterval) {
		
		boolean myreturn = true;
		
		try {
		    String qManager = " ";                // define name of queue manager object to connect to.
		            
	        qManager = "";
			
			MQEnvironment.hostname = hostname ;	    
			MQEnvironment.channel = channel;
			MQEnvironment.port = port ;
			MQEnvironment.userID = userID;
			
			MQQueue q_put;						// queue 1 for put
			MQMessage q_put_msg;		    	// the put message
			MQPutMessageOptions q_put_option;	// put message options

			MQQueue q_get;		    			// put 2 for get
			MQMessage q_get_msg;		    	// the get message
			MQGetMessageOptions q_get_option;	// get message options
			
			qMgr = new MQQueueManager(qManager);
						
			// Set up the options on the queue to open
			int openOptions = MQC.MQOO_OUTPUT;
			q_put = qMgr.accessQueue(RemoteQR, openOptions, null, null, null);
			
			q_put_msg = new MQMessage();
			q_put_msg.expiry = 3000; // this is indicating the msg will be expired for 5 mins (interval in tenths of a second)
 
			q_put_msg.writeString(mq_ask_txt);

			q_put_msg.messageType = MQC.MQMT_REQUEST;
			q_put_msg.report = MQC.MQRO_EXCEPTION_WITH_DATA + MQC.MQRO_PASS_MSG_ID;
			q_put_msg.format = MQC.MQFMT_STRING;

	     	q_put_msg.replyToQueueName = LocalQL;     	
	     	q_put_msg.replyToQueueManagerName = QueueManagerName;
			
			// Specify the msg options
			q_put_option = new MQPutMessageOptions();	// accept the defaults, same as MQq_put_option_DEFAULT constant
			q_put.put(q_put_msg, q_put_option);		
			MsgId = q_put_msg.messageId;
			q_put.close();

			// get the reply msg
			// Define a MQ message buffer to receive the message into
			// Set up the options on the queue we wish to open
			
			//MQ change on 06 Nov 2005
		  	openOptions = MQC.MQOO_INPUT_AS_Q_DEF; 
			
			//Specify the queue we wish to open and the open options
			q_get = qMgr.accessQueue(LocalQL, openOptions, null, null, null);
			q_get_msg = new MQMessage();
			q_get_msg.messageId = MsgId;            // Set MsgId to put value
			q_get_msg.expiry = 600 ;				// Set expiry time to 1 min of the queue

			// Set the get msg options
			q_get_option = new MQGetMessageOptions();     // accept the defaults

			//MQ change on 06 Nov 2005
			q_get_option.options = MQC.MQGMO_WAIT + MQC.MQGMO_CONVERT + MQC.MQGMO_ACCEPT_TRUNCATED_MSG + MQC.MQGMO_FAIL_IF_QUIESCING ;
            
			q_get_option.waitInterval = 60000;            // set wait to 30 sec
			if (waitInterval != 0) {
			    q_get_option.waitInterval = waitInterval * 1000;
			}

			// get the msg off the queue
			q_get.get(q_get_msg,q_get_option,40000);        // max message size = 2000
			mq_rtn_txt = q_get_msg.readLine();
			
			// Close the queue
			q_get.close();
			qMgr.disconnect();
			
		} catch (MQException ex) {	
			System.out.println("MQException : " + ex.getMessage());	
			try {				
				qMgr.disconnect();
			} catch (MQException mex){
				mex.printStackTrace();
			}			

			myreturn = false;
			err_msg = "An MQ error occured: Completion code " + ex.completionCode + "; Reason Code" + ex.reasonCode ;
			mq_err_code = Integer.toString(ex.reasonCode);
			System.out.println(err_msg);
			ex.printStackTrace(); 
						
		} catch (java.io.IOException ex) {		
			System.out.println("IOException : " + ex.getMessage());
			try {				
				qMgr.disconnect();
			} catch(MQException mex){
				mex.printStackTrace();
			}			

			myreturn = false;
			err_msg = "An error occurred whilst writing to the message buffer: " + ex;
			System.out.println(err_msg);
			ex.printStackTrace();
						  
		} catch (Exception x){
			System.out.println("Exception : " + x.getMessage());
			try {				
				qMgr.disconnect();
			} catch (MQException mex) {
				mex.printStackTrace();
			}			

			myreturn = false;
			err_msg = "An MQ error occured: Completion code " + x;
			System.out.println(err_msg);
			x.printStackTrace(); 			
		}
		return myreturn;
	}
		
	/**
	 * @return
	 */
	public String getMq_rtn_txt() {
		return mq_rtn_txt;
	}

	/**
	 * @param string
	 */
	public void setMq_ask_txt(String string) {
		mq_ask_txt = string;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String getMq_err_code() {
		return mq_err_code;
	}
}
