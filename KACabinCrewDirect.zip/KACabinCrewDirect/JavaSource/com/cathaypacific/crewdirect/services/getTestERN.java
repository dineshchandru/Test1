/*
 * Created on May 7, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.services;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class getTestERN {

	private String ern;
	private Connection con=null;
	/**
	 * 
	 */
	public getTestERN() {
		getData();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	public void getData(){
		String SQL;		
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			//find last status & associated info
			ResultSet rs=null;			
			Statement stmt=null;
			//random select ern
			SQL = "select staffid from (select distinct staffid from v_roster_master where staffid like '%' order by dbms_random.value) where rownum <=1";		 			 					 			 		
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				this.ern = rs.getString("staffid");
			}									        
			rs.close();
			stmt.close(); 
		
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
	}
    

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

}
