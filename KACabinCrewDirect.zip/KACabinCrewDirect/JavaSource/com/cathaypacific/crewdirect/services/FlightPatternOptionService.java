package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class FlightPatternOptionService {
	private FlightPatternOption[] FlightPatternOptions1;
	private FlightPatternOption[] FlightPatternOptions2;
	private String cat;
	private String err_msg;
	private int canCommit = -1;
	private String optMsg;
	private int requestLimit = 99;
	private int batchCnt=0;

	public int getRequestLimit() {
		return requestLimit;
	}

	public void setRequestLimit(int requestLimit) {
		this.requestLimit = requestLimit;
	}

	public String getOptMsg() {
		return optMsg;
	}

	public void setOptMsg(String optMsg) {
		this.optMsg = optMsg;
	}

	public List getExistingFlightRequestList() {
		return existingFlightRequestList;
	}

	public void setExistingFlightRequestList(List existingFlightRequestList) {
		this.existingFlightRequestList = existingFlightRequestList;
	}

	private String ern;
	private List existingFlightRequestList;

	public FlightPatternOptionService(String ern) {
		this.ern = ern;
		Connection con = null;
		try {
			dbconnect db = new dbconnect();
			con = db.getConn();
			getCrewCategory(con);
			getRequestLimit(con);
			this.existingFlightRequestList = this.getFlightPatternRequest(con);
			List r1 = getFlightPatternWithRequestLimit(con);
			List t1 = processFlightPatternList(r1);
			FlightPatternOptions1 = new FlightPatternOption[t1.size()];
			t1.toArray(FlightPatternOptions1);

			List r2 = getFlightPatternWithoutRequestLimit(con);
			List t2 = processFlightPatternList(r2);
			FlightPatternOptions2 = new FlightPatternOption[t2.size()];
			t2.toArray(FlightPatternOptions2);
			err_msg = "no_err";

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = sqlex.getMessage();

			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} // if

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {

			if (con != null) {

				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

			} // if

		}// catch/try

	}

	private void getRequestLimit(Connection con) throws SQLException {
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "select t.* from admin_parameter t where params= 'FLIGHT_PATERN_REQUEST_LIMIT' ";
		rs = stmt.executeQuery(sql);

		if (rs.next()) {
			this.requestLimit = rs.getInt("params_value");
		}
		rs.close();
		stmt.close();

	}

	public FlightPatternOptionService(String ern, List fltPatternRequestList2,
			String action) {

		this.ern = ern;
		Connection con = null;
		List fltPatternRequestList = null;
		
		boolean limitCheckedPass=true;
		try {
			dbconnect db = new dbconnect();
			con = db.getConn();
			if ("I".equals(action)) {
				this.getRequestLimit(con);
				int cnt = this
						.getFlightPatternRequestCountWithRequestLimit(con);
				boolean ifCheck=needRequestLimitCheck(fltPatternRequestList2);
				if (ifCheck&&(cnt+this.batchCnt) > this.requestLimit) {
					
					//optMsg = "The number of request is exceeding the request limit.";
					optMsg = "The number of requests submitted have exceeded the limit.";
					limitCheckedPass=false;
				} else {
					this.canCommit = -1;
					fltPatternRequestList = fltPatternRequestList2;
				}
			} else if ("W".equals(action)) {
				this.canCommit = -1;
				fltPatternRequestList = fltPatternRequestList2;
			}
			if (fltPatternRequestList != null
					&& fltPatternRequestList.size() > 0) {
				this.canCommit = 0;
				con.setAutoCommit(false);

				Iterator i = fltPatternRequestList.iterator();
				while (i.hasNext()) {
					FlightPatternOption o = (FlightPatternOption) i.next();
					if ("I".equals(action)) {
						this.insert(o, con);
					} else if ("W".equals(action)) {
						this.withdraw(o, con);
					}
				}
				this.canCommit = 1;
				if (this.canCommit == 1) {
					try {
						con.commit();
						con.setAutoCommit(true);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else if (this.canCommit == 0) {
					try {
						con.rollback();
						con.setAutoCommit(true);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if ("I".equals(action)) {
					optMsg = "Flight Pattern Request(s) is(are) created successfully.";
				} else if ("W".equals(action)) {
					optMsg = "The Flight Pattern Request(s) is(are) withdrawn successfully.";
				}

			} else {
				if(limitCheckedPass){
				if ("I".equals(action)) {
					//optMsg = "Please select at least one Flight Pattern & Desired Period to perform required action .";
					optMsg = "Please select your desired period for each Flight Pattern Request.";
				} else if ("W".equals(action)) {
					optMsg = "Please select at least one pattern code to perform withdraw action.";
				}
				}

			}
			err_msg = "no_err";

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			this.canCommit = 0;
			err_msg = sqlex.getMessage();

			if (con != null) {
				try {
					con.rollback();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} // if

		} catch (Exception ex) {
			ex.printStackTrace();
			if (con != null) {
				try {
					con.rollback();
					con.setAutoCommit(true);
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		} finally {

			if (con != null) {

				try {

					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

			} // if

		}// catch/try
	}

	private boolean needRequestLimitCheck(List fltPatternRequestList2) {
		this.batchCnt=0;
		boolean ret=false;
		if(fltPatternRequestList2!=null&fltPatternRequestList2.size()>0){
			Iterator i=fltPatternRequestList2.iterator();
			while(i.hasNext()){
				FlightPatternOption t=(FlightPatternOption)i.next();
				if("W".equals(t.getType())){
					ret= true;
					batchCnt++;
				}
			}
		}
		// TODO Auto-generated method stub
		return ret;
	}

	public FlightPatternOption[] getFlightPatternOptions1() {
		return FlightPatternOptions1;
	}

	public void setFlightPatternOptions1(
			FlightPatternOption[] flightPatternOptions1) {
		FlightPatternOptions1 = flightPatternOptions1;
	}

	public FlightPatternOption[] getFlightPatternOptions2() {
		return FlightPatternOptions2;
	}

	public void setFlightPatternOptions2(
			FlightPatternOption[] flightPatternOptions2) {
		FlightPatternOptions2 = flightPatternOptions2;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getErr_msg() {
		return err_msg;
	}

	public void setErr_msg(String err_msg) {
		this.err_msg = err_msg;
	}

	public String getErn() {
		return ern;
	}

	public void setErn(String ern) {
		this.ern = ern;
	}

	private List processFlightPatternList(List r1) {
		List tmp = new ArrayList();
		Iterator i1 = r1.iterator();
		while (i1.hasNext()) {
			FlightPatternOption flt = (FlightPatternOption) i1.next();
			if (this.doubleCheckCategory(flt)) {
				processMonthList(flt);
				tmp.add(flt);
			}
		}
		return tmp;
	}

	private void processMonthList(FlightPatternOption flt) {
		String monStr = flt.getPeriod();
		String[] monArr = monStr.split(",");
		List monListTmp = Arrays.asList(monArr);
		Calendar rightNow = Calendar.getInstance();
		SimpleDateFormat ddmm_format = new SimpleDateFormat("dd-MMM-yy");
		SimpleDateFormat mm_format = new SimpleDateFormat("MM");
		java.util.Date temp = rightNow.getTime();
		rightNow.add(Calendar.MONTH, 2);
		List monList = new ArrayList();
		for (int i = 1; i <= 12; i++) {

			rightNow.set(Calendar.DAY_OF_MONTH,
					rightNow.getActualMaximum(Calendar.DAY_OF_MONTH));
			temp = rightNow.getTime();
			String im = mm_format.format(temp);
			String o = ddmm_format.format(temp);
			if ("all".equalsIgnoreCase(monStr) || monListTmp.contains(im)) {

				monList.add(new String[] { o, o, "" });
			}
			rightNow.add(Calendar.MONTH, 1);
		}
		flt.setMonthList(monList);

	}

	private List getFlightPatternWithRequestLimit(Connection con)
			throws SQLException {
		List ret = new ArrayList();
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "select * from ka_flt_pat_detail t where t.flt_pat_cat like'%"
				+ cat + "%' and t.flt_pat_type='W' and t.FLT_PAT_STATUS='1' order by t.flt_pat_code";
		rs = stmt.executeQuery(sql);

		while (rs.next()) {
			FlightPatternOption a = new FlightPatternOption();
			a.setFlightPatternCode(rs.getString("FLT_PAT_CODE"));
			a.setCat(rs.getString("FLT_PAT_CAT"));
			a.setDesc(rs.getString("FLT_PAT_DESC"));
			a.setPeriod(rs.getString("AVA_PERIOD"));
			a.setStatus(rs.getString("FLT_PAT_STATUS"));
			a.setType(rs.getString("FLT_PAT_TYPE"));
			a.setRequestLimit(rs.getString("FLT_R_LIMIT"));
			a.setLastUpdateBy(rs.getString("LAST_UPDATE_BY"));
			a.setLastUpdateDate(rs.getDate("LAST_UPDATE_DATE"));
			ret.add(a);
		}
		return ret;
	}

	private List getFlightPatternWithoutRequestLimit(Connection con)
			throws SQLException {
		List ret = new ArrayList();
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "select * from ka_flt_pat_detail t where t.flt_pat_cat like'%"
				+ cat + "%' and t.flt_pat_type='N' and t.FLT_PAT_STATUS='1'  order by t.flt_pat_code";
		rs = stmt.executeQuery(sql);

		while (rs.next()) {
			FlightPatternOption a = new FlightPatternOption();
			a.setFlightPatternCode(rs.getString("FLT_PAT_CODE"));
			a.setCat(rs.getString("FLT_PAT_CAT"));
			a.setDesc(rs.getString("FLT_PAT_DESC"));
			a.setPeriod(rs.getString("AVA_PERIOD"));
			a.setStatus(rs.getString("FLT_PAT_STATUS"));
			a.setType(rs.getString("FLT_PAT_TYPE"));
			a.setRequestLimit(rs.getString("FLT_R_LIMIT"));
			a.setLastUpdateBy(rs.getString("LAST_UPDATE_BY"));
			a.setLastUpdateDate(rs.getDate("LAST_UPDATE_DATE"));
			ret.add(a);
		}
		return ret;
	}

	private void getCrewCategory(Connection con) throws SQLException {
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "SELECT DISTINCT * FROM ISDCREW.CREW_INFO WHERE STAFFID = '"
				+ this.ern + "' ";
		rs = stmt.executeQuery(sql);

		if (rs.next()) {
			this.cat = rs.getString("CATEGORY");
		}
		rs.close();
		stmt.close();
	}

	private boolean doubleCheckCategory(FlightPatternOption dto) {
		String catstr = dto.getCat();
		if (catstr != null) {
			String[] cats = catstr.split(",");
			List s = Arrays.asList(cats);
			if (s.contains(this.cat)) {
				return true;
			}
		}
		return false;
	}

	private List getFlightPatternRequest(Connection con) throws SQLException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yyyy");
		List r = new ArrayList();
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "select * from crewdir.ka_flt_pat_request WHERE STAFFID = '"
				+ this.ern
				+ "' and status='A' and FLT_PATTERN_CODE!='ONT'  order by FLT_PATTERN_CODE asc, end_date desc";
		rs = stmt.executeQuery(sql);

		while (rs.next()) {
			Map ret = new HashMap();
			ret.put("FLT_PATTERN_CODE", rs.getString("FLT_PATTERN_CODE"));
			Date d1 = rs.getDate("END_DATE");
			ret.put("END_DATE", d1 == null ? "" : format1.format(d1));

			ret.put("LAST_UPDATE_USER", rs.getString("LAST_UPDATE_USER"));

			Date d2 = rs.getDate("LAST_UPDATE_DATE");
			ret.put("LAST_UPDATE_DATE", d2 == null ? "" : format2.format(d2));

			r.add(ret);
		}
		rs.close();
		stmt.close();
		return r;
	}

	private int getFlightPatternRequestCountWithRequestLimit(Connection con)
			throws SQLException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yyyy");
		List r = new ArrayList();
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "select count(*) as cnt from crewdir.ka_flt_pat_request t1 ,crewdir.ka_flt_pat_detail t2 WHERE t1.STAFFID = '"
				+ this.ern
				+ "' and t1.status='A' and t1.FLT_PATTERN_CODE!='ONT' and t1.FLT_PATTERN_CODE=t2.flt_pat_code and t2.flt_pat_type='W'  ";
		rs = stmt.executeQuery(sql);
		int cnt = 0;
		if (rs.next()) {
			cnt = rs.getInt("cnt");
		}
		rs.close();
		stmt.close();
		return cnt;
	}

	public void insert(FlightPatternOption dto, Connection con)
			throws SQLException {
		Statement stmt = null;
		try {
			this.getSeq(dto, con);

			String sql1 = "INSERT INTO KA_FLT_PAT_REQUEST "
					+ "(STAFFID, FLT_PATTERN_CODE, START_DATE, END_DATE, LAST_UPDATE_DATE, LAST_UPDATE_USER, SEQ, STATUS) VALUES "
					+ "('"
					+ ern
					+ "',"
					+ "'"
					+ dto.getFlightPatternCode()
					+ "', "
					+ "to_char(sysdate, 'dd Mon yyyy'), "
					+ "'"
					+ dto.getSelectedMonth()
					+ "', "
					+ "sysdate, "
					+ "'"
					+ ern
					+ "', "
					+ ""
					+ (Integer.parseInt(dto.getSeq() == null
							|| "".equals(dto.getSeq()) ? "0" : dto.getSeq()) + 1)
					+ "," + "'A' )";

			String sql2 = "UPDATE KA_FLT_PAT_REQUEST SET "
					+ "STATUS = 'I' , "
					+ "LAST_UPDATE_DATE = sysdate WHERE "
					+ "STAFFID = '"
					+ this.ern
					+ "' AND "
					+ "FLT_PATTERN_CODE = '"
					+ dto.getFlightPatternCode()
					+ "' AND "
					+ "STATUS = 'A' AND "
					+ (dto.getSeq() == null || "".equals(dto.getSeq()) ? " seq is null "
							: "SEQ = " + dto.getSeq());

			stmt = con.createStatement();
			int affectedrows = stmt.executeUpdate(sql1);
			if (affectedrows == 1) {
				stmt.executeUpdate(sql2);

			} else {
				this.canCommit = 0;
			}
		} finally {
			if (stmt != null)
				stmt.close();
		}

	}

	public void withdraw(FlightPatternOption dto, Connection con)
			throws SQLException {
		Statement stmt = null;
		try {
			this.getSeq(dto, con);

			String sql = "UPDATE KA_FLT_PAT_REQUEST SET "
					+ "STATUS = 'W', "
					+ "LAST_UPDATE_USER = '"
					+ ern
					+ "', "
					+ "LAST_UPDATE_DATE = sysdate "
					+ "WHERE FLT_PATTERN_CODE = '"
					+ dto.getFlightPatternCode()
					+ "' "
					+ "AND STAFFID = '"
					+ ern
					+ "' and "
					+ (dto.getSeq() == null || "".equals(dto.getSeq()) ? " seq is null "
							: " SEQ = " + dto.getSeq()) + " AND STATUS = 'A' ";
			System.out.println(sql);
			stmt = con.createStatement();
			stmt.executeUpdate(sql);

		} finally {
			if (stmt != null)
				stmt.close();
		}

	}

	private void getSeq(FlightPatternOption dto, Connection con)
			throws SQLException {
		ResultSet rs = null;
		Statement stmt = null;
		stmt = con.createStatement();
		String sql = "SELECT DISTINCT * FROM KA_FLT_PAT_REQUEST "
				+ "WHERE STAFFID = '" + ern + "' AND FLT_PATTERN_CODE = '"
				+ dto.getFlightPatternCode() + "' "
				+ "AND STATUS = 'A' ORDER BY SEQ desc";
		rs = stmt.executeQuery(sql);
		int ret = 0;
		if (rs.next()) {
			dto.setSeq(rs.getString("SEQ"));

		}

		rs.close();
		stmt.close();

	}

}
