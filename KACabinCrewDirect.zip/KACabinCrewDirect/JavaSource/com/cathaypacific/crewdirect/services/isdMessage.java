package com.cathaypacific.crewdirect.services;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cathaypacific.crewdirect.databeans.dbconnect;

public class isdMessage {
	
	private Connection con=null;
	private String iern;
	
	private String err_code="";
	private isdMessageBean isdmsg [] = new isdMessageBean[50];
	private int isdmsg_cnt =0;
	private boolean haveMessage = false; 
	
	
	public isdMessage() {
		super();		
	}


    //---------------------------------------
	public isdMessage(String ern,String req_type) {
		this.iern = ern;				
		
		if (req_type.equals("checkmsg" ))
			CheckMsg();

		if (req_type.equals("ackmsg" ))
			AckMessage();

		if (req_type.equals("showall" ))
		    getAllMessages();
		    
	}

	//---------------------------------
	public void CheckMsg(){
		String [] ids = new String [20];
		String SQL;		
		try{	
						
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			//find last status & associated info
			ResultSet rs=null;			
			Statement stmt=null;			 			 			
			SQL = "select msg_id from CREWDIR.KA_ADMIN_MESSAGE where acked <> 'Y' and staffID ='" + iern +"'";
			//System.out.println("isdMessage CheckMsg: " + SQL);
			
			stmt = con.createStatement();		
			
			rs= stmt.executeQuery(SQL);		
			haveMessage = false;
			while(rs.next()){
				haveMessage = true;
				break;
			}									        
			rs.close();


			//1.0 get those unacked message id						 			 					 			 	
			SQL = "select distinct msg_id,msg_type,message,msg_from,to_char(last_upd,'DD-MON-YY HH24:MI') as last_update,last_upd " +
				  "from CREWDIR.KA_ADMIN_MESSAGE where acked <> 'Y' and staffID ='"+ iern + "' order by last_upd desc"; 								
			
			//System.out.println("isdMessage CheckMsg : " + SQL);
			rs= stmt.executeQuery(SQL);
			
			isdmsg_cnt =0;
			while(rs.next()){		
				String msg_id = rs.getString("MSG_ID" );
				String msg_type = rs.getString("MSG_TYPE" );
				ids[isdmsg_cnt] = rs.getString("MSG_ID" );															
				String message  = rs.getString("MESSAGE");
				String msg_from  = rs.getString("MSG_FROM");	
				String last_upd  = rs.getString("LAST_UPDATE");
				isdmsg [isdmsg_cnt] = new isdMessageBean(msg_id,msg_type,message,msg_from,last_upd);				
				isdmsg_cnt++; 
			}									        
			rs.close();
			stmt.close();


						 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();
			  err_code = "isdMessage sqlerr : " + sqlex.toString();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();
			err_code = "isdMessage err: " + ex.toString();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
				
	}
	
	

	//---------------------------------	
	public void getAllMessages(){
		String SQL;		
		try{	
						
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			//find last status & associated info
			ResultSet rs=null;			
			Statement stmt=null;	
			
			//remarked by vicki for KACCD 17.4.2008
			SQL = "select distinct msg_id,msg_type,message,msg_from,upd_by,to_char(last_upd,'DD-MON-YY HH24:MI') as last_update,to_char(ack_time,'DD-MON-YY HH24:MI') as ack_time,ack_time as ord,last_upd as ord1 " +			  	"from KA_ADMIN_MESSAGE where acked='Y' and staffID ='"+ iern + "' " +			  	"order by ord1 desc,ord desc  " ;	
			
			/*SQL = 	"select distinct msg_id,msg_type,message,msg_from,upd_by,to_char(last_upd,'DD-MON-YY HH24:MI') as last_update,to_char(ack_time,'DD-MON-YY HH24:MI') as ack_time,ack_time as ord,last_upd as ord1 " +
				  	"from KA_ADMIN_MESSAGE where acked='Y' and staffID ='6100' " +
				  	"order by ord1 desc,ord desc  " ;*/
		
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);
			isdmsg_cnt=0;		
			while(rs.next()){		
				String msg_id = rs.getString("MSG_ID" );	
				String msg_type = rs.getString("MSG_TYPE" );															
				String message  = rs.getString("MESSAGE");
				String msg_from  = rs.getString("msg_from");	
				String last_upd  = rs.getString("LAST_UPDATE");
				String ack_time =  rs.getString("ACK_TIME");							
				isdmsg [isdmsg_cnt] = new isdMessageBean(msg_id,msg_type,message,msg_from,last_upd,ack_time);				
				isdmsg_cnt++; 
			}									        
			rs.close();
			stmt.close();
			
			 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();
			  err_code = sqlex.toString();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();
			err_code = ex.toString();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						

	}
	
	
	
    //----------------------------------
	public void AckMessage(){
		String [] ids = new String [20];
		int cnt=0;
		int row=0; 	
		String SQL;		
		try{	
			//try to conect if no connection
									
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			
						
			ResultSet rs=null;			
			Statement stmt=con.createStatement();			 			 					 			 		

            //1.0 get those unacked message id						 			 					 			 	
			SQL = "select distinct msg_id "+				  "from KA_ADMIN_MESSAGE where acked <> 'Y' and staffID ='"+ iern +"'"; 			
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			isdmsg_cnt =0;
			while(rs.next()){		
				ids[isdmsg_cnt] = rs.getString("MSG_ID" );															
				isdmsg_cnt++; 
			}									        
			rs.close();
            
            con.setAutoCommit(false);
			//2.0 update those message status			
			for (int x=0;x<isdmsg_cnt;x++){
				SQL = "UPDATE KA_ADMIN_MESSAGE SET ACKED='Y' , ACK_TIME=SYSDATE " +
					  "WHERE MSG_ID='"+ids[x]+"' and STAFFID ='" + iern + "'"; 						 	
				row = stmt.executeUpdate(SQL);
				cnt = cnt+row;						
			}			
			stmt.close(); 
			
			if (cnt != isdmsg_cnt){
				err_code = "Sytem cannot acknowledge your ISD message, Pls try to login again.";
				con.rollback();
			}else{
				con.commit();
			}
			   				
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();
			  err_code = sqlex.toString();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();
			err_code = ex.toString();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  

		}//catch/try						
		
	}
    //---------------------------------- 
    
	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

	/**
	 * @return
	 */
	public isdMessageBean[] getIsdmsg() {
		return isdmsg;
	}

	/**
	 * @return
	 */
	public int getIsdmsg_cnt() {
		return isdmsg_cnt;
	}

	/**
	 * @return
	 */
	public boolean isHaveMessage() {
		return haveMessage;
	}

}
