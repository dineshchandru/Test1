/*
 * Created on Apr 1, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.databeans.*;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsRequest {
	
	private Connection con = null;
	private int sql_commit = 0 ;
	private String err_msg = "no_err";
	private String ern = "";
	private String success_msg = new String("");
	private String withdraw_date = new String("");
	private int required_days = 0;
	private int odd_days = 0;
	private int remain_days = 0;
	private String sls_start_date = "";
	private String sls_end_date = "";
	private String req_details = "";
	private String exp_details = "";
	Vector slsRequestVector = new Vector();
	Vector slsPreferenceResultVector = new Vector();
	Vector slsControlVector = new Vector();
	Vector slsQuotaChartVector = new Vector();
	
	public slsRequest() {
		super();
	}
	
	public slsRequest(String ern)
	{
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			String start_date = "";
			String end_date = "";
			String base_port = "";
			String rank = "";
			
			//get Control Data
			sql = 	"SELECT nvl(to_char(SLS_START, 'dd-Mon-yyyy'),'') as SLS_START, " +
					"nvl(to_char(SLS_END, 'dd-Mon-yyyy'),'') as SLS_END, " +
					"nvl(REQ_DETAILS, '') as REQ_DETAILS, nvl(EXP_DETAILS, '') as EXP_DETAILS " +
					"FROM CREWDIR.KA_SLS_CONTROL " ;
			
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				sls_start_date = rs.getString("SLS_START");
				sls_end_date = rs.getString("SLS_END");
				if (rs.getString("REQ_DETAILS") != null)
					req_details = rs.getString("REQ_DETAILS");
				if (rs.getString("EXP_DETAILS") != null)
					exp_details = rs.getString("EXP_DETAILS");
			}
			
			//get Base Port 
			sql = "SELECT BASE_PORT, CATEGORY FROM ISDCREW.CREW_INFO WHERE STAFFID = '" + ern + "' ";
			rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				base_port = rs.getString("BASE_PORT");
				rank = rs.getString("CATEGORY");
			}
			
			sql = 	"SELECT ERN, SEQ, " +
					"nvl(to_char(START_DATE, 'dd-Mon-yy'),'') as START_DATE, " +
					"START_DATE AS START_DATE_ORDER, " + 
					"nvl(to_char(END_DATE, 'dd-Mon-yy'),'') as END_DATE, " +
					"DAYS, " +
					"nvl(to_char(ODD_START_DATE, 'dd-Mon-yy'),'') as ODD_START_DATE, " +
					"ODD_DAYS, " +
					"STATUS, " +
					"LAST_UPDATE_USER, nvl(to_char(LAST_UPDATE_DATE, 'dd-Mon-yyyy'),'') as LAST_UPDATE_DATE " +
					"FROM CREWDIR.KA_SLS_REQUEST " +
					"WHERE ERN = '" +  ern + "' AND UPPER(STATUS) = 'APPLICATION' " +
					"ORDER BY START_DATE_ORDER ASC ";
	
			System.out.println("SLSRequest sql : " + sql);
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				slsRequestBean tempRequest = new slsRequestBean();
				if (rs.getString("ERN") != null)
					tempRequest.setERN(rs.getString("ERN"));
				tempRequest.setSeq(rs.getInt("SEQ"));
				if (rs.getString("START_DATE") != null)
					tempRequest.setStart_Date(rs.getString("START_DATE"));
				if (rs.getString("END_DATE") != null)
					tempRequest.setEnd_Date(rs.getString("END_DATE"));
				if (rs.getString("ODD_START_DATE") != null)
					tempRequest.setOdd_Start_Date(rs.getString("ODD_START_DATE"));
				if (rs.getString("STATUS") != null)
					tempRequest.setStatus(rs.getString("STATUS"));
				tempRequest.setDay(rs.getInt("DAYS"));
				tempRequest.setOdd_Day(rs.getInt("ODD_DAYS"));
				slsRequestVector.add(tempRequest);
			}
			
			//getSLS Preference Result Vector
			sql = 	"SELECT ERN, SEQ, " +
					"nvl(to_char(START_DATE, 'dd-Mon-yy'),'') as START_DATE, " +
					"START_DATE AS START_DATE_ORDER, " + 
					"nvl(to_char(END_DATE, 'dd-Mon-yy'),'') as END_DATE, " +
					"DAYS, " +
					"nvl(to_char(ODD_START_DATE, 'dd-Mon-yy'),'') as ODD_START_DATE, " +
					"ODD_DAYS, " +
					"STATUS, " +
					"LAST_UPDATE_USER, nvl(to_char(LAST_UPDATE_DATE, 'dd-Mon-yyyy'),'') as LAST_UPDATE_DATE " +
					"FROM CREWDIR.KA_SLS_REQUEST " +
					"WHERE ERN = '" +  ern + "' AND " +
					"(UPPER(STATUS) = 'APPROVED' OR UPPER(STATUS) = 'DISAPPROVED' OR UPPER(STATUS) = 'ASSIGNED') " +
					"ORDER BY START_DATE_ORDER ASC ";

			System.out.println("SLSRequest preference sql : " + sql);
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				slsRequestBean tempRequest = new slsRequestBean();
				if (rs.getString("ERN") != null)
					tempRequest.setERN(rs.getString("ERN"));
				tempRequest.setSeq(rs.getInt("SEQ"));
				if (rs.getString("START_DATE") != null)
					tempRequest.setStart_Date(rs.getString("START_DATE"));
				if (rs.getString("END_DATE") != null)
					tempRequest.setEnd_Date(rs.getString("END_DATE"));
				tempRequest.setDay(rs.getInt("DAYS"));
				if (rs.getString("ODD_START_DATE") != null)
					tempRequest.setOdd_Start_Date(rs.getString("ODD_START_DATE"));
				tempRequest.setOdd_Day(rs.getInt("ODD_DAYS"));
				if (rs.getString("STATUS") != null)
					tempRequest.setStatus(rs.getString("STATUS"));
				if (rs.getString("LAST_UPDATE_USER") != null)
					tempRequest.setLast_Update_User(rs.getString("LAST_UPDATE_USER"));
				if (rs.getString("LAST_UPDATE_DATE") != null)
					tempRequest.setLast_Update_Date(rs.getString("LAST_UPDATE_DATE"));
				slsPreferenceResultVector.add(tempRequest);
			}

			
			//getSLS Quota Chart
			sql = 	"SELECT nvl(to_char(SLS_START_DATE, 'dd-Mon-yy'),'') as START_DATE, SLS_START_DATE AS START_DATE_ORDER, QUOTA " +
					"FROM CREWDIR.KA_SLS_QUOTA_CHART " +
					"WHERE BASE_PORT = '" + base_port + "' " +  
					"AND CATEGORY = '" + rank + "' " +  
					"AND QUOTA > 0 " +
					"ORDER BY START_DATE_ORDER ASC ";
			System.out.println("getSLS Quota Chart :" + sql);
			rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				slsQuotaChart tempChart = new slsQuotaChart();
				if (rs.getString("START_DATE") != null)
					tempChart.setSLS_Start_Date(rs.getString("START_DATE"));
				tempChart.setQuota(rs.getInt("QUOTA"));
				slsQuotaChartVector.add(tempChart);
			}
			
			//get SLS Control Data - Required Days and Odd Days
			sql = "SELECT REQUIRED_DAYS, ODD_DAYS, REMAIN_DAYS FROM CREWDIR.KA_SLS_CONSENT WHERE ERN = '" + ern + "' ";
			rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				required_days = rs.getInt("REQUIRED_DAYS");
				odd_days = rs.getInt("ODD_DAYS");
				remain_days = rs.getInt("REMAIN_DAYS");
				break;
			}
			
			rs.close();
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}
	
	public slsRequest(String action, String ern, Vector updateSLSRequest) {

		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();     
			Statement stmt = null;	
			stmt = con.createStatement();
			String strsql = "";
			String start_date = "";
			String end_date = "";
			int day = 0;
			String odd_start_date = "";
			int odd_day = 0;
			int seq = 0;
			
			con.setAutoCommit(false); 	// not commit the data automatically
			
			//delete application record : status = 'A'
			strsql = 	"DELETE FROM CREWDIR.KA_SLS_REQUEST WHERE " +
						"ERN = '" + ern + "' AND " + 
						"UPPER(STATUS) = 'APPLICATION' "; //A = Application
			
			System.out.println("SLSRequest update : strsql " + strsql);
			stmt.executeUpdate(strsql);
			
			if (updateSLSRequest != null)
			{
				if (updateSLSRequest.size() > 0)
				{
					for (int i=0; i<updateSLSRequest.size(); i++)
					{
						slsRequestBean tempRequest = new slsRequestBean();
						tempRequest = (slsRequestBean) updateSLSRequest.get(i);
						seq = tempRequest.getSeq();
						start_date = tempRequest.getStart_Date();
						end_date = tempRequest.getEnd_Date();
						day = tempRequest.getDay();
						odd_start_date = tempRequest.getOdd_Start_Date();
						odd_day = tempRequest.getOdd_Day();						
						
						if ((!start_date.equals("")) && (!end_date.equals("")))
						{
							strsql = 	"INSERT INTO CREWDIR.KA_SLS_REQUEST " +
										"(ERN, SEQ, START_DATE, END_DATE, DAYS, ODD_START_DATE, ODD_DAYS, STATUS, LAST_UPDATE_USER, LAST_UPDATE_DATE)" + 
										"VALUES " +
										"('" + ern + "', " +
										seq + ", " +
										"'" + start_date + "', " +
										"'" + end_date + "', " +
										"" + day + ", " +
										"'" + odd_start_date + "', " +
										"" + odd_day + ", " +
										"'APPLICATION', " +
										"'" + ern + "', " +
										"sysdate) ";
							System.out.println("SLSRequest update : insert strsql " + strsql);
							sql_commit = stmt.executeUpdate(strsql);
						}						
					}
				}
			}
			
			if (sql_commit <= 0) {
				con.rollback() ; 	//if not inserted, rollback the delete action
			} else { 
				con.commit() ;		//if inserted successfully, commit the changes			   
			}
			if (sql_commit >0) {
			   success_msg = new String("Your SLS Request submitted successfully.");
			} else {
			   success_msg = new String("Your SLS Request submitted unsuccessfully.");
			}
			
			con.setAutoCommit(true); //set the commit action to auto again
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "SLS Request : Cannot Update Record. " + sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch (SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch (SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	}
	
	
	public Vector getSLSRequestVector()
	{
		return slsRequestVector;
	}
	
	public Vector getSLSPreferenceResultVector()
	{
		return slsPreferenceResultVector;
	}
	
	public Vector getSLSControlVector()
	{
		return slsControlVector;
	}
	
	public Vector getSLSQuotaChartVector()
	{
		return slsQuotaChartVector;
	}
	
	public String getErr_msg() {
		return err_msg;
	}
	
	public String getSuccess_msg()
	{
		return success_msg;
	}
	
	public int getSql_commit() 
	{
		return sql_commit;
	}
	
	public String getWithdraw_Date() 
	{
		return withdraw_date;
	}
	
	public int getRequiredDays()
	{
		return required_days;
	}
	
	public int getOdd_Days()
	{
		return odd_days;
	}
	
	public int getRemain_Days()
	{
		return remain_days;
	}
	
	public String getSLS_Start_Date()
	{
		return sls_start_date;
	}
	
	public String getSLS_End_Date()
	{
		return sls_end_date;
	}
	
	public String getReq_Details()
	{
		return req_details;
	}
	
	public String getExp_Details()
	{
		return exp_details;
	}

}
