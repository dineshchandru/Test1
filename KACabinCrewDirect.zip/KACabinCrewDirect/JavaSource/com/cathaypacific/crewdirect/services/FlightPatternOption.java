package com.cathaypacific.crewdirect.services;


import java.util.Date;
import java.util.List;


public class FlightPatternOption {
	
	private String flightPatternCode;
	private String type;
	private String desc;
	private String cat;
	private String period;
	private String status;
	/* requestLimit is not used currently*/
	private String requestLimit;
	private Date lastUpdateDate;
	private String checked;
	private List monthList;
	private String selectedMonth;
	private String seq;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getSelectedMonth() {
		return selectedMonth;
	}

	public void setSelectedMonth(String selectedMonth) {
		this.selectedMonth = selectedMonth;
	}

	public List getMonthList() {
		return monthList;
	}

	public void setMonthList(List monthList) {
		this.monthList = monthList;
	}

	public String getChecked() {
		return checked;
	}

	public void setChecked(String checked) {
		this.checked = checked;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	private String lastUpdateBy;
	
	public String getRequestLimit() {
		return requestLimit;
	}

	public void setRequestLimit(String requestLimit) {
		this.requestLimit = requestLimit;
	}

	public String getFlightPatternCode() {
		return flightPatternCode;
	}

	public void setFlightPatternCode(String flightPatternCode) {
		this.flightPatternCode = flightPatternCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getStatusStr(){
		return "1".equals(status)?"Valid":"Invalid";
	}

}

