/*
 * Created on May 17, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class LoginTimeStamp {
	
	private String ern;
	private Connection con;
	public LoginTimeStamp() {
		super();
	}

	public LoginTimeStamp(String ern) {
		this.ern = ern;
	}


	public boolean setTimeStamp(String ip,String host,String ack) {
		boolean myreturn;		
		String SQL;
		int rows = 0;
				
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			Statement stmt=null;			 			 					 			 		
        	
        	con.setAutoCommit(false);
        	    			
			//1.0 insert into login timestamp
			stmt = con.createStatement();
			SQL = "INSERT INTO LOGIN(STAFFID,LOGIN_TIME,IP,HOST,ACK) VALUES " +
				  " ('" + ern + "',sysdate,'"+ip+"','"+host+"','"+ack+"')";
			//System.out.println("LoginTimeStamp : insert login timestamp: " + SQL);
			rows = stmt.executeUpdate(SQL);						
			
			if (rows >=1) {
				myreturn = true;
			} else {
				myreturn = false;
			}
			
			stmt.close();			
			con.commit();
			
			try{
				stmt = con.createStatement();
				
				//2.0 doing trigger actions (delete public insert master)
				SQL = "DELETE FROM CREWDIR.ROSTER_PUBLIC WHERE StaffID ='"+ ern +"'";
				System.out.println("LoginTimeStamp : delete from roster_public :" + SQL);
				rows = stmt.executeUpdate(SQL);
				SQL = "INSERT INTO CREWDIR.ROSTER_PUBLIC SELECT * FROM CREWDIR.KA_ROSTER_MASTER WHERE STAFFID ='"+ ern +"'";
				//System.out.println("LoginTimeStamp : insert " + SQL);
				rows = stmt.executeUpdate(SQL);						
			
				stmt.close();
				con.commit();
				
			}catch (SQLException sqlexs) {
				sqlexs.printStackTrace();
				System.out.println("KA CCD " + ern +" T rollbacked");				 
				con.rollback();
			}

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 myreturn = false;
		}catch (Exception ex) {
			ex.printStackTrace();
			myreturn = false;		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try								


		return myreturn;
	}

//////////////////////////////////////////////////////
	public String  getTimeStamp() {
		//return today - 45 days
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar cl = Calendar.getInstance(); 
		cl.add(Calendar.DATE,-5);
		String myreturn  = formatter.format(cl.getTime());		
		return myreturn;
	}


//	////////////////////////////////////////////////////
	public String  getTimeStamp(String myERN) {
		String myreturn = new String();		
		String SQL;
		try{	

			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt=null;

			
			SQL = "SELECT DISTINCT TO_CHAR(LOGIN_TIME,'yyyymmddhh24miss') AS TM " +				  "FROM CREWDIR.LOGIN "+
				  "WHERE STAFFID ='" + ern + "' and LOGIN_TIME=(SELECT DISTINCT MAX(LOGIN_TIME) FROM CREWDIR.LOGIN " +				  "WHERE STAFFID ='" + ern + "')";
				  			 		
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				myreturn = rs.getString("TM") + "0";				
			}									        
			rs.close();
			stmt.close(); 
			}catch (SQLException sqlex) {
				  sqlex.printStackTrace();	
				  if (con!=null) {
						try {
						   con.close();
						}catch( SQLException e){
						   e.printStackTrace();
						}		   	  
				  } //if    			
				myreturn ="";
			}catch (Exception ex) {
				ex.printStackTrace();
				myreturn = "";		    			
			} finally{
				if (con!=null) {
				   try {
						 con.close();
				   }catch( SQLException e){
					  e.printStackTrace();
				   }
				} //if  
			}//catch/try						

		
		return myreturn;
	}


}
