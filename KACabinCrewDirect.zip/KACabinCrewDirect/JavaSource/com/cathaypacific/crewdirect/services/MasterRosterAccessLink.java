/*
 * Created on Nov 4, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MasterRosterAccessLink 
{
	private Connection con = null;
	private int sql_commit = 0 ;
	private String link = "";
	
	public MasterRosterAccessLink()
	{
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			
			sql = "SELECT LINK FROM CREWDIR.MASTER_ROSTER_LINK ";
				
			//System.out.println("MasterRosterAccesslink sql : " + sql);
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				link = rs.getString("LINK");
				break;
			}
			
			rs.close();
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}
	
	public String getLink ()
	{
		return link;
	}
			

}
