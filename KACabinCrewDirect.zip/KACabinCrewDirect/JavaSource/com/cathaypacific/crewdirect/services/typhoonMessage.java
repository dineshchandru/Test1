package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class typhoonMessage {
	
	private Connection con=null;	
	private String message="";
	private String type="";	
	
	public typhoonMessage() {
		super();
		getData();		
	}


	public void getData(){
		String SQL;		
		try{	
						
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			//find last status & associated info
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 		
			SQL = "select distinct TYPE,MESSAGE from crewdir.admin_typhoon where ACTIVATED='Y' and TYPE NOT IN ('NIL','nil')"; 			
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);				
			while(rs.next()){										
				message  = rs.getString("message");
				type  = rs.getString("type");								
			}									        
			rs.close();
			stmt.close(); 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						

	}


	/**
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @return
	 */
	public String getType() {
		return type;
	}

}
