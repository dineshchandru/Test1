/** [Mantis:0000438]
 *  author: SPIBAW
 *  time : 20170512
 *  Function : used to earch staff fdp count 
 */
package com.cathaypacific.crewdirect.services;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.databeans.minusCrewBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class minusCrewSevices {
	private Connection con = null;
	public minusCrewBean[] minuscrew;
	public int lst_count;
	private String ERN;
	private String From_year;
	private String To_year;
	private String From_mth;
	private String To_mth;
	public String TOTIME;

	public minusCrewSevices() {
	}

	public minusCrewSevices(String iern, String ifromyear, String itoyear,
			String ifrommth, String itomth) throws SQLException {
		this.ERN = iern;
		this.From_year = ifromyear;
		this.To_year = itoyear;
		this.From_mth = ifrommth;
		this.To_mth = itomth;

		getMinusCrewList();

		this.TOTIME = secToTime();
	}

	public void getMinusCrewList() throws SQLException {
		this.minuscrew = new minusCrewBean[100];

		dbconnect db = new dbconnect();
		Connection con = db.getConn();
		Statement stmt = con.createStatement();
		try {
			String sql = "select ERN,TO_CHAR(FLTDATE,'DD/MM/YYYY') AS FLTDATE,FLTNO,CREWOB,SHORTAGE,FDPSHARE,TO_CHAR(PAYDATE,'Mon YYYY') as PAYDATE from (select * from CREWDIR.minuscrew  where ERN='"
					+ this.ERN
					+ "'and PayDate between to_date('01-"
					+ this.From_mth
					+ "-"
					+ this.From_year
					+ "','dd-Mon-yyyy')  And  add_months( to_date('01-"
					+ this.To_mth
					+ "-"
					+ this.To_year
					+ "','dd-Mon-yyyy') ,1 )-1   order by PAYDATE,FLTDATE) ";
			// System.out.println("KA CCD display"+sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				String ERN = rs.getString("ERN");
				String FLTDATE = rs.getString("FLTDATE");
				String FLTNO = rs.getString("FLTNO");
				String CREWOB = rs.getString("CREWOB");
				String SHORTAGE = rs.getString("SHORTAGE");
				String FDPSHARE = rs.getString("FDPSHARE");
				String PAYDATE = rs.getString("PAYDATE");

				FDPSHARE = FDPSHARE.substring(11, 19);
				minusCrewBean myBean = new minusCrewBean(ERN, FLTDATE, FLTNO,
						CREWOB, SHORTAGE, FDPSHARE, PAYDATE);
				this.minuscrew[this.lst_count] = myBean;
				this.lst_count += 1;
			}
			rs.close();
			stmt.close();
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}

			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		} catch (Exception ex) {
			ex.printStackTrace();

			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	public String secToTime() throws SQLException {
		int Second = 0;
		String Time = null;
		dbconnect db = new dbconnect();
		Connection con = db.getConn();
		Statement stmt = con.createStatement();
		try {
			String sql2 = "SELECT SUM(SUBSTR(TO_CHAR(FDPSHARE,'hh24:mi:ss'), 1, 2))*3600+ SUM(SUBSTR(TO_CHAR(FDPSHARE,'hh24:mi:ss'), 4, 2))*60+SUM(SUBSTR(TO_CHAR(FDPSHARE,'hh24:mi:ss'), 7, 2)) as TOTIME  from CREWDIR.minuscrew where ern='"
					+ this.ERN
					+ "' and  PayDate between to_date('01-"
					+ this.From_mth
					+ "-"
					+ this.From_year
					+ "','dd-Mon-yyyy')  And add_months(  to_date('01-"
					+ this.To_mth
					+ "-"
					+ this.To_year
					+ "','dd-Mon-yyyy'),1 )-1    ";

			ResultSet rs2 = stmt.executeQuery(sql2);
			while (rs2.next()) {
				Time = rs2.getString("TOTIME");
			}
			Second = Integer.valueOf(Time).intValue();
			rs2.close();
			stmt.close();
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}

			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		} catch (Exception ex) {
			ex.printStackTrace();

			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}

		}

		String timeStr = null;
		int hour = 0;
		int minute = 0;
		int second = 0;
		if (Second <= 0) {
			return "00:00:00";
		}
		minute = Second / 60;
		if (minute < 60) {
			second = Second % 60;
			timeStr = unitFormat(hour) + ":" + unitFormat(minute) + ":"
					+ unitFormat(second);
		} else {
			hour = minute / 60;
			if (hour > 99)
				return "99:59:59";
			minute %= 60;
			second = Second - hour * 3600 - minute * 60;

			timeStr = unitFormat(hour) + ":" + unitFormat(minute) + ":"
					+ unitFormat(second);
		}

		return timeStr;
	}

	public static String unitFormat(int i) {
		String retStr = null;
		if (i >= 0 && i < 10)
			retStr = "0" + Integer.toString(i);
		else
			retStr = "" + i;
		return retStr;
	}

	public String getTotal_time() {
		return this.TOTIME;
	}

	public int getLst_count() {
		return this.lst_count;
	}

	public minusCrewBean[] getQuotaLists() {
		return this.minuscrew;
	}
}