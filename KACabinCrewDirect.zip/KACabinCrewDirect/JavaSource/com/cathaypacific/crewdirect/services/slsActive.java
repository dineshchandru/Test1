/*
 * Created on Apr 9, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsActive {
	
	private Connection con = null;
	private int sql_commit = 0 ;
	private String err_msg = "no_err";
	private String base_port;
	private String port_status;
	private boolean active = false;
	
	public slsActive() {
		super();
	}
	
	public boolean getActiveStatus(String ern) {
		
		
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String crew_base_port = "";
	
			String strsql = "";
			double start_count = 0;
			double end_count = 0;
			
			//Get the crew base port
			strsql = 	"select rownum from isdcrew.crew_info a, crewdir.ka_sls_active_port b " +
						"where a.staffid = '" + ern + "' and a.base_port = b.base_port and b.active = 'Y' ";
			rs = stmt.executeQuery(strsql);
			
			while (rs.next()) {
				active = true;
			}
			
			if (!active)
			{
				err_msg = "You are NOT REQUIRE to submit SLS Preference Request.";
			}
			
			
			rs.close();
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "KACCD getActive Status error :" + sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
		
		return active;
	
		
	}
	
	public boolean isActive() {
		return active;
	}

	public String getErr_msg() {
		return err_msg;
	}

}
