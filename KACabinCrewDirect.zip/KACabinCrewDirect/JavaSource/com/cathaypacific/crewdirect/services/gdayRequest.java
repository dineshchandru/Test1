/****************************************************************************
 * Name : gdayRequest.java
 * Date : 26 Aug 2004 
 * Desc : Retrieve the G-Day off request data and update the request records
 ****************************************************************************/
package com.cathaypacific.crewdirect.services;
import com.cathaypacific.crewdirect.databeans.dbconnect;
import java.sql.*;

public class gdayRequest {
	
	private Connection con = null;
	private int sql_commit = 0 ;
	private String err_msg = "no_err";
	private String start_date = new String("");
	private String end_date = new String("");
	private String seq_no = new String("");
	private String last_update = new String("");
	private String withdraw_date = new String("");
	private String success_msg = new String("");
	private String confirm_start_date = new String("");
	private String confirm_end_date = new String("");

	public gdayRequest() {
		super();
	}

	/**
	 * Retrieve the applied G Days Request from DB
	 * Parameter : ERN, ROSTER_MONTH
	 */		
	public gdayRequest(String ern, String roster_month) {
	
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			
			//Get the normal day-off request monthly
			String strsql = "SELECT nvl(to_char(start_date, 'dd-Mon-yy'),'') as start_date, nvl(to_char(end_date, 'dd-Mon-yy'),'') as end_date, " +
							"update_by, to_char(last_update, 'dd-Mon-yy hh24:mi') as last_update, seq " +
							"FROM KA_GDAY_OFF_REQUEST WHERE STAFFID= '" + ern + "' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' "+
							"and status = 'A' " + 
							"order by start_date,end_date";	
			rs = stmt.executeQuery(strsql);
			
			int CNT = 0;
			while(rs.next()){	
				
				if (CNT > 0) {
				   if (rs.getString("start_date") != null)  start_date  = start_date+"|"+rs.getString("start_date");
				   if (rs.getString("end_date") != null)    end_date    = end_date+"|"+rs.getString("end_date");                    
				   if (rs.getString("last_update") != null) last_update = rs.getString("last_update");
				   seq_no = seq_no + "|" + rs.getInt("seq");
				} else {
				   start_date = rs.getString("start_date");				   
				   end_date = rs.getString("end_date");    
				   last_update = rs.getString("last_update");
				   seq_no = rs.getInt("seq") + "";
				}				
				CNT++;
			}
			rs.close();
			
			if (start_date == null) { start_date = ""; }
			if (end_date == null) { end_date = ""; }
			if (last_update == null) { last_update = ""; }
			if (seq_no == null) {seq_no = "";}
			
			//get last withdraw date
			strsql = 	"SELECT to_char(last_update, 'dd-Mon-yy hh24:mi') as last_update " +
						"FROM KA_GDAY_OFF_REQUEST WHERE STAFFID= '" + ern + "' and to_char(roster_month, 'Mon yyyy') = '"+roster_month+"' "+
						"and status = 'W' " + 
						"order by last_update desc ";	
			rs = stmt.executeQuery(strsql);
			
			while (rs.next()) {
				withdraw_date = rs.getString("last_update");
				break;
			}
			stmt.close();		
			con.close();
			
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	}

	/**
	 * Insert the G Days Request Records
	 * Parameter : ERN, ROSTER_MONTH, START_DATE, END_DATE
	 */		
	public gdayRequest(String ern, String roster_month, String insert_start, String insert_end) {

		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();     
			Statement stmt = null;	
			stmt = con.createStatement();
			
			con.setAutoCommit(false); 	// not commit the data automatically
				
			// Delete the existing record of the specified roster month
			String strsql = "DELETE KA_GDAY_OFF_REQUEST WHERE STAFFID = '" + ern + "' and to_char(roster_month, 'Mon yyyy') ='"+roster_month+"' and status = 'A' ";
			stmt.executeUpdate(strsql);
		    String[] i_start = new String[3];
		    String[] i_end   = new String[3];
    
		    for (int idx=0;idx<3;idx++) {
		    	i_start[idx] = "";
		    	i_end[idx]   = "";
		    }
		    
			if (insert_start.length()>0) {
			   if (insert_start.length()==9) {
			      i_start[0] = insert_start;
			   } else {			      
			      i_start[0] = insert_start.substring(0,9);			      
 			      if (insert_start.length()<=20) { 
 			      	 if (insert_start.length()==19 || insert_start.length()==20) {
 			      	 	i_start[1] = insert_start.substring(10,19);
 			      	 } else {
 			      	    i_start[1] = "";
 			      	 }
				     i_start[2] = "";
 			      } else {
 			      	i_start[1] = insert_start.substring(10,19);
 			      	i_start[2] = insert_start.substring(20,29);
				  };			      
			   };   
			}
			
			if (insert_end.length()>0) {
				   if (insert_end.length()==9) {
				      i_end[0] = insert_end;
				   } else {
				      i_end[0] = insert_end.substring(0,9);				      
	 			      if (insert_end.length()<=20) {
	 			      	if (insert_end.length()==19 || insert_end.length()==20) { 
	 			      		i_end[1] = insert_end.substring(10,19);
	 			      	} else {
	 			      		i_end[1] = "";	
	 			      	}
					    i_end[2] = "";
	 			      } else {   
	 			      	 i_end[1] = insert_end.substring(10,19);
	 			      	 i_end[2] = insert_end.substring(20,29);
	 			      };			      
				   };   
				}

			int insert_cnt = 0;
			for (int i = 0; i < 3; i++) {
				if (i_start[i].length()==9) {
				   // Insert the GDay off request data into DB, return with 0 or 1
  			       strsql = "INSERT INTO KA_GDAY_OFF_REQUEST (STAFFID, ROSTER_MONTH, START_DATE, END_DATE, UPDATE_BY, LAST_UPDATE, SEQ, STATUS) " +
				   			"VALUES('"+ ern +"', '1 "+roster_month+"', '" + i_start[i]+"', '"+i_end[i]+"', '" + ern + "', sysdate,'"+(i+1)+"', 'A')";
			       sql_commit = stmt.executeUpdate(strsql);
	  			   if (sql_commit > 0) {
	  				  insert_cnt++;
	  			   };	  			   
				};				
			}			
			sql_commit = insert_cnt;			
		    if (sql_commit <= 0) {
			   con.rollback() ; 	//if not inserted, rollback the delete action
		    } else { 
			   con.commit() ;		//if inserted successfully, commit the changes			   
		    };			
			if (sql_commit > 0) {
			   success_msg = new String("Your days-off request of "+roster_month+" submitted successfully.");
			   confirm_start_date = new String(insert_start);
			   confirm_end_date = new String (insert_end);
			} else {
			   success_msg = new String("Your days-off request of "+roster_month+" submitted unsuccessfully.");
			   confirm_start_date = new String(insert_start);
			   confirm_end_date = new String (insert_end);
			}   
			con.setAutoCommit(true); //set the commit action to auto again
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "Cannot Insert Record. " + sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch (SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			   try {
					 con.close();
			
			   } catch (SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	}
	
	//withdraw request
	public gdayRequest(String ern, String roster_month, String insert_start, String insert_end, String seq_no, String action) {

		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();     
			Statement stmt = null;	
			stmt = con.createStatement();
			
			con.setAutoCommit(false); 	// not commit the data automatically
				
			String[] i_start = new String[3];
		    String[] i_end   = new String[3];
		    String[] i_seq_no = new String[3];
		    String strsql = "";
	    
		    for (int idx=0;idx<3;idx++) {
		    	i_start[idx] = "";
		    	i_end[idx]   = "";
		    	i_seq_no[idx] = "";
		    }
		    
			if (insert_start.length()>0) {
			   if (insert_start.length()==9) {
			      i_start[0] = insert_start;
			   } else {			      
			      i_start[0] = insert_start.substring(0,9);			      
 			      if (insert_start.length()<=20) { 
 			      	 if (insert_start.length()==19 || insert_start.length()==20) {
 			      	 	i_start[1] = insert_start.substring(10,19);
 			      	 } else {
 			      	    i_start[1] = "";
 			      	 }
				     i_start[2] = "";
 			      } else {
 			      	i_start[1] = insert_start.substring(10,19);
 			      	i_start[2] = insert_start.substring(20,29);
				  };			      
			   };   
			}
			
			if (insert_end.length()>0) {
				   if (insert_end.length()==9) {
				      i_end[0] = insert_end;
				   } else {
				      i_end[0] = insert_end.substring(0,9);				      
	 			      if (insert_end.length()<=20) {
	 			      	if (insert_end.length()==19 || insert_end.length()==20) { 
	 			      		i_end[1] = insert_end.substring(10,19);
	 			      	} else {
	 			      		i_end[1] = "";	
	 			      	}
					    i_end[2] = "";
	 			      } else {   
	 			      	 i_end[1] = insert_end.substring(10,19);
	 			      	 i_end[2] = insert_end.substring(20,29);
	 			      };			      
				   };   
				}
			
			if (seq_no.length() > 0)
			{
				if (seq_no.length() <= 2)
				{
					i_seq_no[0] = seq_no;
				}else
				{
					i_seq_no[0] = seq_no.substring(0,1);
					if (seq_no.length() <= 4)
					{
						if ((seq_no.length() == 3) || (seq_no.length() == 4))
						{
							i_seq_no[1] = seq_no.substring(2,3);
						}else
						{
							i_seq_no[1] = "";
						}
						i_seq_no[2] = "";
					}else
					{
						i_seq_no[1] = seq_no.substring(2,3);
						i_seq_no[2] = seq_no.substring(4,5);
					}
				}
			}

			int insert_cnt = 0;
			if (action.equals("withdraw"))
			{
				for (int i = 0; i<3; i++) {
					if (i_seq_no.length > 0) {
						
					   // Insert the GDay off request data into DB, return with 0 or 1
	  			       //strsql = "INSERT INTO KA_GDAY_OFF_REQUEST (STAFFID, ROSTER_MONTH, START_DATE, END_DATE, UPDATE_BY, LAST_UPDATE, SEQ, STATUS) " +
					   //			"VALUES('"+ ern +"', '1 "+roster_month+"', '" + i_start[i]+"', '"+i_end[i]+"', '" + ern + "', sysdate,'"+(i+1)+"', 'A')";
	  			       
						if (!i_seq_no[i].equals(""))
						{
							strsql = 	"UPDATE KA_GDAY_OFF_REQUEST " +
										"SET STATUS = 'W', " +
										"UPDATE_BY = '" + ern + "', " +
										"LAST_UPDATE = sysdate " + 
										"WHERE STAFFID = '" + ern + "' AND " +
										"nvl(to_char(ROSTER_MONTH, 'Mon yyyy'),'') = '" + roster_month + "' AND " +
										"SEQ = " + Integer.parseInt(i_seq_no[i]) + " AND " +
										"STATUS = 'A' ";
							//System.out.println("withdraw strsql : " + strsql);
							sql_commit = stmt.executeUpdate(strsql);
						}
		  			   
				       if (sql_commit > 0) {
		  				  insert_cnt++;
		  			   };	  			   
					};				
				}			
				sql_commit = insert_cnt;	
			}
			
			//System.out.println("sql_commit : " + sql_commit);
		    if (sql_commit <= 0) {
			   con.rollback() ; 	//if not inserted, rollback the delete action
		    } else { 
			   con.commit() ;		//if inserted successfully, commit the changes			   
		    };			
			if (sql_commit >0) {
			   success_msg = new String("Your days-off request withdraw of "+roster_month+" submitted successfully.");
			   confirm_start_date = new String(insert_start);
			   confirm_end_date = new String (insert_end);
			} else {
			   success_msg = new String("Your days-off request withdraw of "+roster_month+" submitted unsuccessfully.");
			   confirm_start_date = new String(insert_start);
			   confirm_end_date = new String (insert_end);
			}   
			con.setAutoCommit(true); //set the commit action to auto again
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = "Cannot Withdraw Record. " + sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch (SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch (SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	}

	/**
	 * @return
	 */
	public String getStart_date() {
		return start_date;
	}

	/**
	 * @return
	 */
	public String getEnd_date() {
		return end_date;
	}
	
	public String getSeq_No() {
		return seq_no;
	}

	/**
	 * @return
	 */
	public String getLast_update() {
		return last_update;
	}
	
	public String getWithdraw_Date() {
		return withdraw_date;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public int getSql_commit() {
		return sql_commit;
	}
	
	/**
	 * @return
	 */
	public String getSuccess_msg() {
		return success_msg;
	}
	
	public String getConfirm_Start_Date() {
		return confirm_start_date;
	}
	
	public String getConfirm_End_Date() {
		return confirm_end_date;
	}

}
