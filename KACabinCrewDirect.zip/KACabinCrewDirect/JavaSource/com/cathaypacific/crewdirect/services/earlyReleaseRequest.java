package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class earlyReleaseRequest {
	
	private String startDateONT = "";
	private Connection con = null;
	private String start_Date = "";
	private String end_Date = "";
	private String err_msg = "no_err";
	private String last_update = "";
	private String update_by = "";
	private String status = "";
	private String PID = "";
	private int id = 0;
	private boolean valid = true;
	private boolean eligiable = false;
	public earlyReleaseRequest(String ern)
	{
		String sql = "";
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			
			
			sql = " SELECT nvl(to_char(ROSTER_START, 'dd-Mon-yyyy'),'') as START_DATE, " + 
            " nvl(to_char(ROSTER_END, 'dd-Mon-yyyy'),'') as END_DATE, " +
            " nvl(to_char(LAST_UPDATE, 'dd-Mon-yyyy'),'') as LAST_UPDATE, " +
            " UPDATE_BY,STATUS,ID as APP_ID " +   
            " FROM QUOTA_FOR_ERRQ  " +
            " WHERE ROWNUM = 1 and STATUS='ACTIVE'and sysdate between PERIOD_START and PERIOD_END order by PERIOD_START ";
	
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{	
				if (rs.getString("START_DATE") != null)
				{
					setStart_Date(rs.getString("START_DATE"));
				}
				if (rs.getString("END_DATE") != null)
				{
					setEnd_Date(rs.getString("END_DATE"));
				}
				if (rs.getString("LAST_UPDATE") != null)
				{
					setLastUpdate_Date(rs.getString("LAST_UPDATE"));
				}
				if (rs.getString("UPDATE_BY") != null)
				{
					setUpdate_by(rs.getString("UPDATE_BY"));
				}
				if (rs.getString("STATUS") != null)
				{
					setStatus(rs.getString("STATUS"));
				}
				if (rs.getInt("APP_ID") != 0)
				{
					setId(rs.getInt("APP_ID"));
				}
				break;
			}
			sql = "select PID from isdcrew.crew_basic where ern = '" + ern + "'";
	        rs = stmt.executeQuery(sql);
	        if(rs.next()){
	            setPID(rs.getString("PID"));
	        }
			
			sql="select * from CREWDIR.early_release_request where ERN= '"+ern+"'and status='InProgress'  ";
			rs = stmt.executeQuery(sql);
			if(rs.next()){
				valid = false;
			}
			
			sql= " SELECT * FROM ISDCREW.crew_basic WHERE sysdate > = add_monthS( date_join ,6) AND ERN = '"+ern+"'";
			rs = stmt.executeQuery(sql);
			if(rs.next()){
				eligiable = true;
			}
			else{
				eligiable = false;
			}
			
			if(eligiable==true){
				
//			sql=" select * from isdcrew.staff_category where to_char(sysdate, 'dd-Mon-yyyy') between " +
//				" to_char(effective_Date, 'dd-Mon-yyyy') " +
//				" and add_monthS(effective_Date,3) and ern = '"+ern+"' ";
				
			sql="select CATEGORY, CATEGORY_GROUP, min(EFFECTIVE_DATE) from isdcrew.staff_category " +
				"where ern = '"+ern+"' " +
				"group by CATEGORY, CATEGORY_GROUP " +
				"having sysdate between  trunc( min(EFFECTIVE_DATE))  " +
				"and trunc(add_monthS( min(EFFECTIVE_DATE),3))";
			rs = stmt.executeQuery(sql);
			
			if(rs.next()){
				eligiable = false;
			}else{
				eligiable = true;
			}
			}
			rs.close();
			stmt.close();		
			con.close();
	
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			   err_msg = sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}
	
	public String earlyReleaseInsert(String ern, String start_Date, String end_Date, String last_Update, String update_by, String status, int id)
	{
		String sql = "";
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			
			
	    	sql = " insert into CREWDIR.early_release_request (ERN,START_DATE,END_DATE,LAST_UPDATE,UPDATE_BY,STATUS,APP_ID)"+			      
	          " values('"+ern+"','"+start_Date+"','"+end_Date+"','"+last_Update+"','"+ern+"','InProgress','"+id+"')" ;
		
			rs = stmt.executeQuery(sql);
			
			rs.close();
			stmt.close();		
			con.close();
	
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			   err_msg = sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
			
		}//catch/try
		return sql;

	}
	
	public boolean CheckRequestType(String ern)
	{
		String sql = "";
		valid = false;
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			
			sql="select * from CREWDIR.early_release_request where ERN= '"+ern+"'and status='InProgress'  ";
    		rs = stmt.executeQuery(sql);
    		
    		if(rs.next())
    		{
    			valid = true;
    		}
			
			rs.close();
			stmt.close();		
			con.close();
	
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			   err_msg = sqlex.getMessage();
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
			
			
		
		
		}//catch/try
		
		return valid;

		
	}
	
	public void setStart_Date(String start_Date)
	{
		this.start_Date = start_Date;
	}
	public String getStart_Date()
	{
		return start_Date;
	}
	public String getEnd_Date()
	{
		return end_Date;
	}
	public void setEnd_Date(String end_Date)
	{
		this.end_Date = end_Date;
	}
	public String getLastUpdate_Date()
	{
		return last_update;
	}
	public void setLastUpdate_Date(String last_update)
	{
		this.last_update  = last_update;
	}
	public String getUpdate_by()
	{
		return update_by; 
	}
	public void setUpdate_by(String update_by)
	{
		this.update_by = update_by;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getPID()
    {
        return PID;
    }

    public void setPID(String PID)
    {
        this.PID = PID;
    }

	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
		
	}
	public String getONTWithdrawDate()
	{
		return startDateONT;
	}
	
	public void setONTWithdrawDate(String startDateONT)
	{
		this.startDateONT = startDateONT;
	}
	public String getErr_msg() {
		return err_msg;
	}
	public boolean isValid(){
		return valid;
	}

	public boolean isEligible() {
		
		return eligiable;
	}
}
