/*
 * Created on Apr 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class flightPatternRequest {
	
	private Connection con = null;
	private int sql_commit = 0 ;
	private String err_msg = "no_err";
	private String ern = "";
	private String flightPatternDAC = "";
	private String flightPatternKTM = "";
	private String flightPatternONT = "";
	private String flightPatternBLR = "";
	private String start_Date = "";
	private String end_Date = "";
	private String startDateONT = "";
	private String endDateONT = "";
	private String lastUpdateDate = "";
	private String lastUpdateUser = "";
	private int seqDAC= 0;
	private int seqKTM = 0;
	private int seqONT = 0;
	private int seqBLR = 0;
	private String statusDAC = "";
	private String statusKTM = "";
	private String statusONT = "";
	private String statusBLR = "";
	private String success_msg = "";
	private String confirm_DAC_msg = "";
	private String confirm_KTM_msg = "";
	private String confirm_ONT_msg = "";
	private String confirm_BLR_msg = "";
	private String confirm_period_msg = "";
	private String flt_pattern_last_update_date = "";
	private String ont_last_update_date = "";
	private String flt_pattern_withdraw_date = "";
	private String ont_withdraw_date = "";
	
	public flightPatternRequest() {
		super();
	}
	
	public flightPatternRequest(String ern)
	{
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			
			sql = 	"SELECT STAFFID, FLT_PATTERN_CODE," +
					"nvl(to_char(START_DATE, 'dd-Mon-yyyy'),'') as START_DATE, nvl(to_char(END_DATE, 'dd-Mon-yyyy'),'') as END_DATE, " +
					"to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, LAST_UPDATE_USER, " +
					"SEQ, STATUS " +
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND FLT_PATTERN_CODE = 'DAC' " +
					"AND STATUS = 'A' ORDER BY SEQ DESC";
			
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setERN (rs.getString("STAFFID"));
				setFlightPatternDAC (rs.getString("FLT_PATTERN_CODE"));
				
				if (rs.getString("START_DATE") != null)
				{
					start_Date = rs.getString("START_DATE");
				}
				if (rs.getString("END_DATE") != null)
				{
					end_Date = rs.getString("END_DATE");
				}
				
				setSeqDAC (rs.getInt("SEQ"));
				setStatusDAC (rs.getString("STATUS"));
				flt_pattern_last_update_date = (rs.getString("LAST_UPDATE_DATE"));
							
				break;
			}
			
			//BLR
			sql = 	"SELECT STAFFID, FLT_PATTERN_CODE," +
					"nvl(to_char(START_DATE, 'dd-Mon-yyyy'),'') as START_DATE, nvl(to_char(END_DATE, 'dd-Mon-yyyy'),'') as END_DATE, " +
					"to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, LAST_UPDATE_USER, " +
					"SEQ, STATUS " +
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND FLT_PATTERN_CODE = 'BLR' " +
					"AND STATUS = 'A' ORDER BY SEQ DESC";
			
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setERN (rs.getString("STAFFID"));
				setFlightPatternBLR (rs.getString("FLT_PATTERN_CODE"));
		
				if (rs.getString("START_DATE") != null)
				{
					start_Date = rs.getString("START_DATE");
				}
				if (rs.getString("END_DATE") != null)
				{
					end_Date = rs.getString("END_DATE");
				}
				
				setSeqBLR (rs.getInt("SEQ"));
				setStatusBLR (rs.getString("STATUS"));
				flt_pattern_last_update_date = (rs.getString("LAST_UPDATE_DATE"));
				break;
			}
			
			
			
			sql = 	"SELECT STAFFID, FLT_PATTERN_CODE," +
					"nvl(to_char(START_DATE, 'dd-Mon-yyyy'),'') as START_DATE, nvl(to_char(END_DATE, 'dd-Mon-yyyy'),'') as END_DATE, " +
					"to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, LAST_UPDATE_USER, " +
					"SEQ, STATUS " +
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND FLT_PATTERN_CODE = 'KTM' " +
					"AND STATUS = 'A' ORDER BY SEQ DESC";
				
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setERN (rs.getString("STAFFID"));
				setFlightPatternKTM (rs.getString("FLT_PATTERN_CODE"));

				if (rs.getString("START_DATE") != null)
				{
					start_Date = rs.getString("START_DATE");
				}
				if (rs.getString("END_DATE") != null)
				{
					end_Date = rs.getString("END_DATE");
				}
				
				setSeqKTM (rs.getInt("SEQ"));
				setStatusKTM (rs.getString("STATUS"));
				flt_pattern_last_update_date = (rs.getString("LAST_UPDATE_DATE"));
				
				break;
			}
			
			//get last withdraw date
			sql = 	"SELECT to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, " +
					"LAST_UPDATE_DATE AS LAST_UPDATE_DATE_ORDER " + 
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND " +
					"(FLT_PATTERN_CODE = 'DAC' OR FLT_PATTERN_CODE = 'KTM' OR FLT_PATTERN_CODE = 'BLR') " +
					"AND STATUS = 'W' ORDER BY LAST_UPDATE_DATE_ORDER DESC ";
			
			//System.out.println("getLastWithdrawDate : " + sql);
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setFltPatternWithdrawDate(rs.getString("LAST_UPDATE_DATE"));
				break;
			}
			
			
			sql = 	"SELECT STAFFID, FLT_PATTERN_CODE," +
					"nvl(to_char(START_DATE, 'dd-Mon-yyyy'),'') as START_DATE, nvl(to_char(END_DATE, 'dd-Mon-yyyy'),'') as END_DATE, " +
					"to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, LAST_UPDATE_USER, " +
					"SEQ, STATUS " +
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND FLT_PATTERN_CODE = 'ONT' " +
					"AND STATUS = 'A' ORDER BY SEQ DESC";
			
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setERN(rs.getString("STAFFID"));
				setFlightPatternONT (rs.getString("FLT_PATTERN_CODE"));
		
				if (rs.getString("START_DATE") != null)
				{
					startDateONT = rs.getString("START_DATE");
				}
				if (rs.getString("END_DATE") != null)
				{
					endDateONT = rs.getString("END_DATE");
				}
				
				setSeqONT (rs.getInt("SEQ"));
				setStatusONT (rs.getString("STATUS"));
				ont_last_update_date = (rs.getString("LAST_UPDATE_DATE"));
							
				break;
			}
			
			//get last withdraw date ONT
			sql = 	"SELECT to_char(LAST_UPDATE_DATE, 'dd-Mon-yy hh24:mi') AS LAST_UPDATE_DATE, " +
					"LAST_UPDATE_DATE AS LAST_UPDATE_DATE_ORDER " +
					"FROM KA_FLT_PAT_REQUEST " +
					"WHERE STAFFID = '" + ern + "' AND " +
					"FLT_PATTERN_CODE = 'ONT' " +
					"AND STATUS = 'W' ORDER BY LAST_UPDATE_DATE_ORDER DESC ";
			
			//System.out.println("overnight pattern last withdraw date : " + sql);
			rs = stmt.executeQuery(sql);
			
			while (rs.next())
			{
				setONTWithdrawDate(rs.getString("LAST_UPDATE_DATE"));
				break;
			}			
	
			rs.close();
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}

	public flightPatternRequest(String ern, String DACFlightPattern,
								String KTMFlightPattern, String ONTFlightPattern, 
								String BLRFlightPattern,
								String endDate, String DAC_Seq, 
								String KTM_Seq, String ONT_Seq,
								String BLR_Seq)
	{
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
			stmt = con.createStatement();
			String sql = "";
			
			if ((DACFlightPattern.equals("DAC")) && (ONTFlightPattern.equals("-1")))
			{
				sql = 	"INSERT INTO KA_FLT_PAT_REQUEST " +
						"(STAFFID, FLT_PATTERN_CODE, START_DATE, END_DATE, LAST_UPDATE_DATE, LAST_UPDATE_USER, SEQ, STATUS) VALUES " +
						"('" + ern + "'," +
						"'" + DACFlightPattern + "', " +
						"to_char(sysdate, 'dd Mon yyyy'), " +
						"'" + endDate + "', " +
						"sysdate, " +
						"'" + ern + "', " +
						"" + (Integer.parseInt(DAC_Seq) + 1) + "," +
						"'A' )";
				
			
				sql_commit = stmt.executeUpdate(sql);
				
				if (sql_commit > 0)
				{
					if (Integer.parseInt(DAC_Seq) > 0)
					{
						sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
								"STATUS = 'I' , " +
								"LAST_UPDATE_DATE = sysdate WHERE " +
								"STAFFID = '" + ern + "' AND " + 
								"FLT_PATTERN_CODE = 'DAC' AND " +
								"STATUS = 'A' AND " +
								"SEQ = " + DAC_Seq ;
						
						sql_commit = stmt.executeUpdate(sql);
					}
				}
				
				confirm_DAC_msg = "DAC";
				
			}else if ((DACFlightPattern.equals("")) && (ONTFlightPattern.equals("-1")))
			{
				if (Integer.parseInt(DAC_Seq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'I' , " +
							"LAST_UPDATE_DATE = sysdate WHERE " +
							"STAFFID = '" + ern + "' AND " + 
							"FLT_PATTERN_CODE = 'DAC' AND " +
							"STATUS = 'A' AND " +
							"SEQ = " + DAC_Seq ;
					
					sql_commit = stmt.executeUpdate(sql);
				}
			
			}
			
			if ((KTMFlightPattern.equals("KTM"))&& (ONTFlightPattern.equals("-1")))
			{
				sql = 	"INSERT INTO KA_FLT_PAT_REQUEST " +
						"(STAFFID, FLT_PATTERN_CODE, START_DATE, END_DATE, LAST_UPDATE_DATE, LAST_UPDATE_USER, SEQ, STATUS) VALUES " +
						"('" + ern + "'," +
						"'" + KTMFlightPattern + "', " +
						"to_char(sysdate, 'dd Mon yyyy'), " +
						"'" + endDate + "', " +
						"sysdate, " +
						"'" + ern + "', " +
						"" + (Integer.parseInt(KTM_Seq) + 1) + "," +
						"'A' )";
				
				
				sql_commit = stmt.executeUpdate(sql);
				
				if (sql_commit > 0)
				{
					if (Integer.parseInt(KTM_Seq) > 0)
					{
						sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
								"STATUS = 'I' , " +
								"LAST_UPDATE_DATE = sysdate WHERE " +
								"STAFFID = '" + ern + "' AND " + 
								"FLT_PATTERN_CODE = 'KTM' AND " +
								"STATUS = 'A' AND " +
								"SEQ = " + KTM_Seq ;
						
						sql_commit = stmt.executeUpdate(sql);
					}
				}
				
				confirm_KTM_msg = "KTM";
				
			}else if ((KTMFlightPattern.equals("")) && (ONTFlightPattern.equals("-1")))
			{
				if (Integer.parseInt(KTM_Seq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'I' , " +
							"LAST_UPDATE_DATE = sysdate WHERE " +
							"STAFFID = '" + ern + "' AND " + 
							"FLT_PATTERN_CODE = 'KTM' AND " +
							"STATUS = 'A' AND " +
							"SEQ = " + KTM_Seq ;
					
					sql_commit = stmt.executeUpdate(sql);
				}
			}
			
			if ((BLRFlightPattern.equals("BLR"))&& (ONTFlightPattern.equals("-1")))
			{
				sql = 	"INSERT INTO KA_FLT_PAT_REQUEST " +
						"(STAFFID, FLT_PATTERN_CODE, START_DATE, END_DATE, LAST_UPDATE_DATE, LAST_UPDATE_USER, SEQ, STATUS) VALUES " +
						"('" + ern + "'," +
						"'" + BLRFlightPattern + "', " +
						"to_char(sysdate, 'dd Mon yyyy'), " +
						"'" + endDate + "', " +
						"sysdate, " +
						"'" + ern + "', " +
						"" + (Integer.parseInt(BLR_Seq) + 1) + "," +
						"'A' )";
				
				
				sql_commit = stmt.executeUpdate(sql);
				
				if (sql_commit > 0)
				{
					if (Integer.parseInt(BLR_Seq) > 0)
					{
						sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
								"STATUS = 'I' , " +
								"LAST_UPDATE_DATE = sysdate WHERE " +
								"STAFFID = '" + ern + "' AND " + 
								"FLT_PATTERN_CODE = 'BLR' AND " +
								"STATUS = 'A' AND " +
								"SEQ = " + BLR_Seq ;
						
						sql_commit = stmt.executeUpdate(sql);
					}
				}
				
				confirm_BLR_msg = "BLR";
				
			}else if ((BLRFlightPattern.equals("")) && (ONTFlightPattern.equals("-1")))
			{
				if (Integer.parseInt(BLR_Seq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'I' , " +
							"LAST_UPDATE_DATE = sysdate WHERE " +
							"STAFFID = '" + ern + "' AND " + 
							"FLT_PATTERN_CODE = 'BLR' AND " +
							"STATUS = 'A' AND " +
							"SEQ = " + BLR_Seq ;
					
					sql_commit = stmt.executeUpdate(sql);
				}
			}
			
			
			if 	(	(ONTFlightPattern.equals("ONT")) &&
					(DACFlightPattern.equals("-1")) && 
					(KTMFlightPattern.equals("-1")))
			{
				sql = 	"INSERT INTO KA_FLT_PAT_REQUEST " +
						"(STAFFID, FLT_PATTERN_CODE, START_DATE, END_DATE, LAST_UPDATE_DATE, LAST_UPDATE_USER, SEQ, STATUS) VALUES " +
						"('" + ern + "'," +
						"'" + ONTFlightPattern + "', " +
						"to_char(sysdate, 'dd Mon yyyy'), " +
						"'" + endDate + "', " +
						"sysdate, " +
						"'" + ern + "', " +
						"" + (Integer.parseInt(ONT_Seq) + 1) + "," +
						"'A' )";
							
				sql_commit = stmt.executeUpdate(sql);
				
				if (sql_commit > 0)
				{
					if (Integer.parseInt(ONT_Seq) > 0)
					{
						sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
								"STATUS = 'I' , " +
								"LAST_UPDATE_DATE = sysdate WHERE " +
								"STAFFID = '" + ern + "' AND " + 
								"FLT_PATTERN_CODE = 'ONT' AND " +
								"STATUS = 'A' AND " +
								"SEQ = " + ONT_Seq ;
						sql_commit = stmt.executeUpdate(sql);
					}
				}
				confirm_ONT_msg = "ONT";
			}else if (	(ONTFlightPattern.equals("")) && 
						(DACFlightPattern.equals("-1")) && 
						(KTMFlightPattern.equals("-1")))
			{
				if (Integer.parseInt(ONT_Seq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'I' , " +
							"LAST_UPDATE_DATE = sysdate WHERE " +
							"STAFFID = '" + ern + "' AND " + 
							"FLT_PATTERN_CODE = 'ONT' AND " +
							"STATUS = 'A' AND " +
							"SEQ = " + ONT_Seq ;
					
					sql_commit = stmt.executeUpdate(sql);
				}
			}
			
		    if (sql_commit <= 0) {
		    	con.rollback() ; 	//if not inserted, rollback the delete action
			} else { 
				con.commit() ;		//if inserted successfully, commit the changes			   
			};			
			
			if (sql_commit >0) {
				if (ONTFlightPattern.equals("-1"))
				{
					success_msg = new String("Your Additional Flight Pattern request submitted successfully.");   
					confirm_period_msg = endDate;
				}else
				{
					success_msg = new String("Your Overnight Pattern request submitted successfully.");
					confirm_period_msg = endDate;
				}
			} else {
				if (ONTFlightPattern.equals("-1"))
				{
				   	success_msg = new String("Your Additional Flight Pattern request submitted unsuccessfully.");
				}else
				{
					success_msg = new String("Your Overnight Pattern request submitted unsuccessfully.");
				}
			}   
			con.setAutoCommit(true); //set the commit action to auto again
			
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  	
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try

	}
	
	public flightPatternRequest(String ern, String patternRequest, String action,
								String DACSeq,	String KTMSeq, String ONTSeq, String BLRSeq)
	{
		try{	
		dbconnect db = new dbconnect();
		Connection con = db.getConn(); 
		
		ResultSet rs = null;			
		Statement stmt = null;			 			 					 			 		
		stmt = con.createStatement();
		String sql = "";
		con.setAutoCommit(false);
		
		if (action.equals("withdraw"))
		{
			if (patternRequest.equals("FLT_PATTERN"))
			{
				if (Integer.parseInt(DACSeq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'W', " +
							"LAST_UPDATE_USER = '" + ern + "', " +
							"LAST_UPDATE_DATE = sysdate " +
							"WHERE FLT_PATTERN_CODE = 'DAC' " +
							"AND STAFFID = '" + ern + "' " +
							"AND SEQ = " + DACSeq + " " +
							"AND STATUS = 'A' ";
					//System.out.println("withdraw DAC sql : " + sql);
					sql_commit = stmt.executeUpdate(sql);
				}
				
				if (Integer.parseInt(KTMSeq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'W', " +
							"LAST_UPDATE_USER = '" + ern + "', " +
							"LAST_UPDATE_DATE = sysdate " +
							"WHERE FLT_PATTERN_CODE = 'KTM' " +
							"AND STAFFID = '" + ern + "' " +
							"AND SEQ = " + KTMSeq + " " +
							"AND STATUS = 'A' ";
					//System.out.println("withdraw KTM sql : " + sql);
					sql_commit = stmt.executeUpdate(sql);
				}
				
				if (Integer.parseInt(BLRSeq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'W', " +
							"LAST_UPDATE_USER = '" + ern + "', " +
							"LAST_UPDATE_DATE = sysdate " +
							"WHERE FLT_PATTERN_CODE = 'BLR' " +
							"AND STAFFID = '" + ern + "' " +
							"AND SEQ = " + BLRSeq + " " +
							"AND STATUS = 'A' ";
					//System.out.println("withdraw BLR sql : " + sql);
					sql_commit = stmt.executeUpdate(sql);
				}
				
			}else if (patternRequest.equals("ONT_PATTERN"))
			{
				if (Integer.parseInt(ONTSeq) > 0)
				{
					sql = 	"UPDATE KA_FLT_PAT_REQUEST SET " +
							"STATUS = 'W', " +
							"LAST_UPDATE_USER = '" + ern + "', " +
							"LAST_UPDATE_DATE = sysdate " +
							"WHERE FLT_PATTERN_CODE = 'ONT' " +
							"AND STAFFID = '" + ern + "' " +
							"AND SEQ = " + ONTSeq + " " +
							"AND STATUS = 'A' ";
				}
				//System.out.println("withdraw ONT sql : " + sql);
				sql_commit = stmt.executeUpdate(sql);
			}
			
			
			//System.out.println("sql_commit : " + sql_commit);
			 if (sql_commit <= 0) {
		    	con.rollback() ; 	//if not inserted, rollback the delete action
			} else { 
				con.commit() ;		//if inserted successfully, commit the changes			   
			};			
			
			if (sql_commit >0) {
				if (patternRequest.equals("FLT_PATTERN"))
				{
					success_msg = new String("Your Flight Pattern Request withdraw submitted successfully.");   
					
				}else if (patternRequest.equals("ONT_PATTERN"))
				{
					success_msg = new String("Your Overnight Pattern Request withdraw submitted successfully.");
				}
			} else {
				if (patternRequest.equals("FLT_PATTERN"))
				{
				   	success_msg = new String("Your Flight Pattern Request withdraw submitted unsuccessfully.");
				}else if (patternRequest.equals("ONT_PATTERN"))
				{
					success_msg = new String("Your Overnight Pattern Request withdraw submitted unsuccessfully.");
				}
			}   
			con.setAutoCommit(true); //set the commit action to auto again
			
		}
		
		
		stmt.close();		
		con.close();
		
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  err_msg = sqlex.getMessage();
			  
			  if (con != null) {
					try {
					   con.close();
					} catch(SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if  
			    						
		} catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{
	
			if (con != null) {
			
			   try {
					 con.close();
			
			   } catch(SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	
	}
	public String getERN()
	{
		return ern;
	}
	
	public void setERN(String ern)
	{
		this.ern = ern;
	}
	
	public String getFlightPatternDAC()
	{
		return flightPatternDAC;
	}
	
	public void setFlightPatternDAC(String flightPatternDAC)
	{
		this.flightPatternDAC = flightPatternDAC;
	}
	
	public String getFlightPatternKTM()
	{
		return flightPatternKTM;
	}
	
	public void setFlightPatternKTM (String flightPatternKTM)
	{
		this.flightPatternKTM = flightPatternKTM;
	}
	
	public String getFlightPatternONT()
	{
		return flightPatternONT;
	}
	
	public void setFlightPatternONT (String flightPatternONT)
	{
		this.flightPatternONT = flightPatternONT;
	}
	
	public String getFlightPatternBLR()
	{
		return flightPatternBLR;
	}
	
	public void setFlightPatternBLR (String flightPatternBLR)
	{
		this.flightPatternBLR = flightPatternBLR;
	}
	
	public String getStart_Date()
	{
		return start_Date;
	}
	
	public String getEnd_Date()
	{
		return end_Date;
	}
	
	public String getStartDateONT()
	{
		return startDateONT;
	}
	
	public void setStartDateONT(String startDateONT)
	{
		this.startDateONT = startDateONT;
	}
	
	public String getEndDateONT()
	{
		return endDateONT;
	}
	
	public void setEndDateONT(String endDateONT)
	{
		this.endDateONT = endDateONT;
	}
	
	public String getLastUpdateDate()
	{
		return lastUpdateDate;
	}
	
	public String getLastUpdateUser()
	{
		return lastUpdateUser;
	}
	
	public String getFltPatternLastUpdateDate()
	{
		return flt_pattern_last_update_date;
	}
	
	public void setFltPatternLastUpdateDate(String flt_pattern_last_update_date)
	{
		this.flt_pattern_last_update_date = flt_pattern_last_update_date;
	}
	
	public String getONTLastUpdateDate()
	{
		return ont_last_update_date;
	}
	
	public void setONTLastUpdateDate(String ont_last_update_date)
	{
		this.ont_last_update_date = ont_last_update_date;
	}
	
	public String getFltPatternWithdrawDate()
	{
		return flt_pattern_withdraw_date;
	}
	
	public void setFltPatternWithdrawDate(String flt_pattern_withdraw_date)
	{
		this.flt_pattern_withdraw_date = flt_pattern_withdraw_date;
	}
	
	public String getONTWithdrawDate()
	{
		return ont_withdraw_date;
	}
	
	public void setONTWithdrawDate(String ont_withdraw_date)
	{
		this.ont_withdraw_date = ont_withdraw_date;
	}
	
	public int getSeqDAC()
	{
		return seqDAC;		
	}
	
	public void setSeqDAC (int seqDAC)
	{
		this.seqDAC = seqDAC;
	}
	
	public int getSeqKTM()
	{
		return seqKTM;		
	}
	
	public void setSeqKTM (int seqKTM)
	{
		this.seqKTM = seqKTM;
	}
	
	public int getSeqONT()
	{
		return seqONT;		
	}
	
	public void setSeqONT (int seqONT)
	{
		this.seqONT = seqONT;
	}
	
	public int getSeqBLR()
	{
		return seqBLR;		
	}
	
	public void setSeqBLR (int seqBLR)
	{
		this.seqBLR = seqBLR;
	}
	
	public String getStatusDAC()
	{
		return statusDAC;
	}
	
	public void setStatusDAC (String statusDAC)
	{
		this.statusDAC = statusDAC;
	}
	
	public String getStatusKTM()
	{
		return statusKTM;
	}
	
	public void setStatusKTM (String statusKTM)
	{
		this.statusKTM = statusKTM;
	}
	
	public String getStatusONT()
	{
		return statusONT;
	}
	
	public void setStatusONT (String statusONT)
	{
		this.statusONT = statusONT;
	}
	
	public String getStatusBLR()
	{
		return statusBLR;
	}
	
	public void setStatusBLR (String statusBLR)
	{
		this.statusBLR = statusBLR;
	}
	
	public int getSql_commit() {
		return sql_commit;
	}
	
	public String getErr_msg() {
		return err_msg;
	}
	
	public String getSuccess_msg() {
		return success_msg;
	}
	
	public String getConfirm_DAC_msg()
	{
		return confirm_DAC_msg;
	}
	
	public String getConfirm_KTM_msg()
	{
		return confirm_KTM_msg;
	}
	
	public String getConfirm_ONT_msg()
	{
		return confirm_ONT_msg;
	}
	
	public String getConfirm_BLR_msg()
	{
		return confirm_BLR_msg;
	}
	
	public String getConfirm_Period_msg()
	{
		return confirm_period_msg;
	}
	
	

	
}
