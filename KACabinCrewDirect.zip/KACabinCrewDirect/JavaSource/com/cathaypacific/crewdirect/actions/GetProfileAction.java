package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.profileBeanList;

/**
 * @version 	1.0
 * @author
 */
public class GetProfileAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

/*	remarks on 13.02.2009 for second prod launch	
 		try {
			HttpSession session = request.getSession();			 
			String ern = ""; 
			ern = (String) session.getAttribute("MyERN");			
			
			//added on 16.01.09 for KACCD first prod launch
			checkAccessRight myAccess = new checkAccessRight(ern);
	            
	        if (!myAccess.isValid()){
	        	request.setAttribute("err_msg",myAccess.getErr_msg());
	        	forward = mapping.findForward("no_access");
					
	        }else{	
			//added on 16.01.09 for KACCD first prod launch
				if (ern.length()!=4) {			
					errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
				}else{			
					profileBeanList profile = new profileBeanList(ern);			
					if (profile != null){
						session.setAttribute("profile",profile );
						forward = mapping.findForward("success");	
					}
				}
	        }
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}
*/
		try {
			HttpSession session = request.getSession();			 
			String ern = ""; 
			ern = (String) session.getAttribute("MyERN");			
			
			if (ern.length() < 4) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
			}else{			
				profileBeanList profile = new profileBeanList(ern);			
				if (profile != null){
					session.setAttribute("profile",profile );
					forward = mapping.findForward("success");	
				}
			}
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}
		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}
		// Write logic determining how the user should be forwarded.		
		

		// Finish with
		return (forward);

	}
}
