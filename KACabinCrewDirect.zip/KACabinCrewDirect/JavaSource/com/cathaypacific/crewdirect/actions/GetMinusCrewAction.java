/** [Mantis:0000438]
 *  author: SPIBAW
 *  time : 20170512
 *  Function : Go to search staff fdp count 
 */
package com.cathaypacific.crewdirect.actions;

import com.cathaypacific.crewdirect.services.minusCrewSevices;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class GetMinusCrewAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession();
		String ern = (String) session.getAttribute("MyERN");

		String From_year = request.getParameter("From_year");
		String To_year = request.getParameter("To_year");
		String From_mth = request.getParameter("From_mth");
		String To_mth = request.getParameter("To_mth");

		minusCrewSevices rst = new minusCrewSevices(ern, From_year, To_year,
				From_mth, To_mth);

		request.setAttribute("minuscrew_list", rst);
		request.setAttribute("From_year", From_year);
		request.setAttribute("To_year", To_year);
		request.setAttribute("From_mth", From_mth);
		request.setAttribute("To_mth", To_mth);

		return mapping.findForward("success");
	}
}