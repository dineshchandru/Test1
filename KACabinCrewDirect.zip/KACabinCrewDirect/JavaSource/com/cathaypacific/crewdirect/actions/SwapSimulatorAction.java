package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.swapRequestInfoBean;
import com.cathaypacific.crewdirect.swap.swapSimulateRoster;

/**
 * @version 	1.0
 * @author
 */
public class SwapSimulatorAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		String ern ="";
		String s_date="";
		String e_date="";
		String erns ="";
		String crewid="";
		String day_offset="10";
		String other_erns[]= new String [10];
		String other_crewid[]= new String [10];		
		String action_type="";
		// return value

		try {

			HttpSession session = request.getSession();			 
			ern = (String) session.getAttribute("MyERN");	
			s_date = request.getParameter("s_date").toUpperCase();
			e_date = request.getParameter("e_date").toUpperCase();
			day_offset = request.getParameter("day_offset");
			erns=request.getParameter("swap_ern");
			crewid=request.getParameter("swap_crew_id");
			
			
			other_erns = str2array(erns);
			other_crewid = str2array(crewid);			

			if (day_offset==null)
			   day_offset = "5";
			   
			swapSimulateRoster mySimulator = new swapSimulateRoster(ern,s_date,e_date,day_offset,other_erns);
			//set request info
			swapRequestInfoBean requstInfo = new swapRequestInfoBean(s_date,e_date,mySimulator.getErn_cnts(),other_erns,other_crewid);
			

			if (mySimulator!=null){				
				request.setAttribute("SimRoster",mySimulator);
				request.setAttribute("ReqInfo",requstInfo);
				forward = mapping.findForward("success");						
			}

			// do something here
			session.setAttribute("DateSwapFrom",s_date);						
			session.setAttribute("DateSwapTo",e_date);



		} catch (Exception e) {
			errors.add("name", new ActionError("id"));
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);

			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}
	
	public String [] str2array (String s) {
		String  temp[] = new String [10];
		int cnt=0;
		int pos_start=0;
		int pos_end =0;
		for (int x=0; x<s.length();x++ ){
			pos_end = s.indexOf(",",x);
			temp[cnt] = s.substring(pos_start,pos_end);
			cnt++;
			x = pos_end;
			pos_start = pos_end +1;
		}		
		
		//initial other elements
		for (int  y=cnt;y<10;y++){
			temp[y]="";
		}
			
		return temp; 
	}
	
}
