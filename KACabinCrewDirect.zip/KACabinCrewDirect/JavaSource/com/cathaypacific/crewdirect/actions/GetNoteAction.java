package com.cathaypacific.crewdirect.actions;

import java.sql.Connection;
 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.checkAccessRight;
import com.cathaypacific.crewdirect.databeans.checkAdminRight;

import com.cathaypacific.crewdirect.services.LoginTimeStamp;
import com.cathaypacific.crewdirect.services.MQServices;
import com.cathaypacific.crewdirect.services.getBasicInfo;
 
import com.cathaypacific.crewdirect.services.typhoonMessage;
import com.cathaypacific.crewdirect.utils.decode_mq_roster;

/**
 * @version 	1.0
 * @author
 */
public class GetNoteAction extends Action {
    private Connection con=null;
	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String myStatus="";
		String ask_txt="";
		String rtn_txt="";
		String rtn_status="";
		String ern = "";
		
		String TimeStamp = "";
		String [] myInfo = new String [4];
		String clientIP ="";
		String clientHost="";
		String AdmERN = "";
		String AdmID = "";
		String AdmPID = "";
		LoginTimeStamp myLogin;
		LoginTimeStamp AdmLogin;
		boolean LoginUpdated;
		boolean HaveErrorMQ ;
		String myErr = "Sorry, the system is busy at this moment (E001), the crew notification has not been acknowledged. Please login again. If the problem still exists, please call Crew Control at your earliest convenience.";
		String myErr1 = "The sytem is busy at this moment(E002), the roster is not updated. If the problem still exists, Please call Crew Control to reconfirm your duties.";

		//System.out.println("GetNoteAction");
		try {
			HttpSession session = request.getSession();
			
			//0.0 get typhoon message 
			typhoonMessage typ_msg = new typhoonMessage();			
			session.setAttribute("typ_type",typ_msg.getType());
			session.setAttribute("typ_msg",typ_msg.getMessage());

			//1.0 get ern 
			//String ern=request.getParameter("ern");			 
			
			ern = (String) session.getAttribute("MyERN");
			
			if (ern.equals("UAT")){  //uat
				//System.out.println("ERN = UAT");
				AdmERN = (String) session.getAttribute("AdmERN");
				AdmID  = (String) session.getAttribute("AdmID");
				AdmPID  =(String) session.getAttribute("AdmPID");
				//5.0 set logintime
				//clientIP = (String ) request.getRemoteAddr();
				//clientHost = (String ) request.getRemoteHost();
				//AdmLogin = new LoginTimeStamp(AdmERN);		
//System.out.println("ERN:" + AdmERN + "/ID:"+AdmID+ "/PID:"+AdmPID+"/staff:"+request.getParameter("staff"));
				checkAdminRight AdmAccess = new checkAdminRight(AdmPID);
				if (AdmAccess.isValid())
				{
					String type=request.getParameter("staff");				
					ern = type.toUpperCase();		
					//System.out.println("check 1");
					if (ern.substring(7).equals("X")){	
						//System.out.println("check X");
					   ern = ern.substring(0,7);
					   session.setAttribute("MyERN",ern); //block acess
					}else{								
					   ern = "12345678";
					}
				}else
				{
					myStatus = "no_access";
				}
	            /*if (!AdmAccess.isValid()){				
					LoginUpdated =AdmLogin.setTimeStamp(clientIP,clientHost,"F-"+ern );					
	            }else{	
				    LoginUpdated =AdmLogin.setTimeStamp(clientIP,clientHost,"S-"+ern );
	            };*/    
//System.out.println("ERN:" + ern+"/ip:"+clientIP+"/Host:"+clientHost);	            
			}
			
            //1.1 Check User Acess Right
            checkAccessRight myAccess = new checkAccessRight(ern);
            
            if (!myAccess.isValid()){
				request.setAttribute("err_msg",myAccess.getErr_msg());
				myStatus = "no_access";           	           
				
            }else{	
            	
            	getBasicInfo info = new getBasicInfo(ern);
            	
	            //2.0 set banner infomation 
				if (info!=null) {
					//HttpSession session = request.getSession();
					session.setAttribute("MyInfo",info.getMyInfo());
				}
				
				//added by vicki for testing of KACCD 10.4.2008
				//myStatus = "no_msg";
	  			//remarked by vicki for testing of KACCD 9.4.2008
				
	            //3.0 ask Facts of CrewNote by MQ
				//3.1 get timestamp
				//remarked for testing 22.5.2008
				myLogin = new LoginTimeStamp(ern);
				TimeStamp = myLogin.getTimeStamp(); 
								
				//3.2 get MQ
				MQServices CrewNoteMQ = new MQServices("getnote");
				//remark for UAT testing 14.5.2008
				//ask_txt = "KAD01" + ern + "   "+ TimeStamp;
				ask_txt = "KAD01" + ern + TimeStamp;
				//ask_txt = "KAD010072   200806220000000";
				CrewNoteMQ.setMq_ask_txt(ask_txt);
				
				//max try 3 time if mq error occured
				HaveErrorMQ = true;
				
				System.out.println("KA CCD "+ern +" a 0.0 ask mq");				
				System.out.println("KA CCD_LOG:MQ ask_txt"  + ask_txt);									
				if (CrewNoteMQ.call_mq()==true){
					rtn_txt = CrewNoteMQ.getMq_rtn_txt();
					
					//for testing only
					//rtn_txt = "KAD02  0028   200809030001000200809030002000Y";
					
					System.out.println("KA CCD "+ern +" a 0.0 end ask mq");					
					System.out.println("KA CCD_LOG:MQ rtn_txt"  + rtn_txt);

					if (rtn_txt.substring(5,7).equals("  " )){
						if (rtn_txt.substring(7,14).trim().equals(ern )){	 //same ern
							HaveErrorMQ = false;				
						}
					}else
					{
						//System.out.println("rtn_txt : " + rtn_txt.substring(5,7) + ".");
						if (rtn_txt.substring(5,7).equals("IC"))
						{
							myErr1 = "Your Staff ID could not be found. Please call Crew Control to confirm your duties.";
						}
					}
				}
				
				//System.out.println("getNoteAction HaveErrorMQ : " + HaveErrorMQ);
				//4.0 handle mq return								
				if (HaveErrorMQ){
					request.setAttribute("err_msg",myErr1);
					myStatus = "failure";						
				}else{					
					rtn_status = getNoteIndicator(rtn_txt);
					//System.out.println("getNoteAction rtn_status: " + rtn_status);
					//4.1 nothing happened
					if (rtn_status.equals("N")){					
						myStatus = "no_msg";
						
						//4.11 set forward to swap page
						/*if (session.getAttribute("from").equals("swap")){
							myStatus = "from_others";	//from e-team show swaps			
						}*/
												
					}
					//4.2 have crew notification
					if (rtn_status.equals("Y")){					
						//reset a wrong ern in session to prevent not ack the message
					  	session.setAttribute("ACKFLAG",ern); //block access
					  	session.setAttribute("MyERN","1234567"); //block acess 
												
						myStatus = "have_msg";
					}					
				    //4.3 no crewnote but have roster change				 
					if (rtn_status.equals("R")){ 
						//System.out.println("getNotAction rtn_status == R");
						decode_mq_roster mq =new decode_mq_roster(ern,rtn_txt,"RC");
						if (mq.isSuccess() == true) {
							  myStatus = "chg_roster";	
						 }else{
							  request.setAttribute("err_msg",myErr);
							  myStatus = "failure";
						 }
					}				 	   							
				}
	            
				//5.0 set logintime
				clientIP = (String ) request.getRemoteAddr();
				clientHost = (String ) request.getRemoteHost();
				LoginUpdated =myLogin.setTimeStamp(clientIP,clientHost,rtn_status);


				//6.0 set forward other default page
				if (!myStatus.equals("failure")){
					if (session.getAttribute("from").equals("others")){
						myStatus = "from_others";	//from e-team show swaps			
					}				
				}
				
			}//1.1 check access
			
			
		} catch (Exception e) {
			request.setAttribute("err_msg",myErr);
			errors.add("name", new ActionError("id"));			
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg",myErr);
			forward = mapping.findForward("failure");
		}else{

  		  forward = mapping.findForward(myStatus);
		}
		return (forward);

	}
	
	
	//return crew notification indicator (Y/N/R)
	String getNoteIndicator(String str){		
		return str.substring(44,45);
	}
}
