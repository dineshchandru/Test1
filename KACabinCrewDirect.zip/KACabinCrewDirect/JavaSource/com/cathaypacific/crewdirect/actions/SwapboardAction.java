package com.cathaypacific.crewdirect.actions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.catList;
import com.cathaypacific.crewdirect.swapboard.deleteMessage;
import com.cathaypacific.crewdirect.swapboard.postNewMessage;
import com.cathaypacific.crewdirect.swapboard.showMessage;

/**
 * @version 	1.0
 * @author
 */
public class SwapboardAction extends Action {

	public ActionForward execute(ActionMapping mapping,	ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		String ern=null;
		String mystatus = "success";
		// return value
		String s_date = new String("");
		String e_date = new String("");
		String cat = new String("");
		String lang = new String("");
		
		try {
			HttpSession session = request.getSession();			 
			ern = (String) session.getAttribute("MyERN");	

			String web_action = request.getParameter("web_action");
			String action_type = request.getParameter("action_type");
			if (web_action == null) {
				web_action = "";
			}
			if (action_type == null) {
				action_type = "";
			}
			s_date = request.getParameter("s_date");
			e_date = request.getParameter("e_date");
			cat = request.getParameter("cat");
			lang = request.getParameter("lang");

			//0.0 web start up from left menu link
			if (web_action.equals("menu_startup")) {
				showMessage all_msg = new showMessage();
				all_msg.StartShowMessage(ern);			
				request.setAttribute("bulletin_msg", all_msg);
				mystatus = "all_msg";				
				
			//1.0 show the post message page
			} else if (web_action.equals("menu_post") || action_type.equals("post_new")) {  //display correct pages
				
				//1.1 post new message actions
				if (action_type.equals("post_new")) {  //Send New Message
					String msg = request.getParameter("msg");
					
					postNewMessage nw_msg = new postNewMessage(ern, s_date, e_date, msg);
					if (nw_msg.getErr_msg().equals("no_err")) {
						showMessage my_msg = new showMessage(ern);				
						request.setAttribute("bulletin_msg", my_msg);
						mystatus = "my_msg";								
					} else {
						request.setAttribute("err_msg", nw_msg.getErr_msg()); 
						mystatus = "errors";
					}
				//1.1 show the blank message page
				} else {		
					mystatus = "post_new";
				}
				
	        //2.0 show my messages
			} else if (web_action.equals("menu_my") || action_type.equals("del_msg")) {  //display correct pages
							
				//2.1 delete msg   
				if (action_type.equals("del_msg")) {  //display correct pages
					String msg_id = request.getParameter("msg_id");
					
					deleteMessage del_msg = new deleteMessage(msg_id);
					if (del_msg.getErr_msg().equals("no_err")) {				
						showMessage my_msg = new showMessage(ern);				
						request.setAttribute("bulletin_msg", my_msg);
						mystatus = "my_msg";								
					} else {
						request.setAttribute("err_msg", del_msg.getErr_msg()); 
						mystatus = "errors";
					}											
			    //2.2 normal : show my messages
				} else {
					showMessage my_msg = new showMessage(ern);				
					request.setAttribute("bulletin_msg", my_msg);
					mystatus = "my_msg";				
				}

			//3.0 search the messages w/ period, category and language
			} else if (web_action.equals("search_msg")) {  //display correct pages						
				showMessage all_msg = new showMessage(s_date, e_date, cat, lang);				
				request.setAttribute("bulletin_msg", all_msg);
				mystatus = "all_msg";				
			}

            if (s_date == null) {
				Date date = new Date(); 
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
				Calendar cal = Calendar.getInstance(); 
 
				s_date = formatter.format(cal.getTime());
				cal.add(Calendar.DATE, 3);
				e_date = formatter.format(cal.getTime());            	
            }
            
			if (session.getAttribute("CATS") == null || cat == null){
				catList cats = new catList(ern);
				session.setAttribute("CATS", cats);
				cat = cats.getMycat(); 
				lang = cats.getMylang();
			}
            request.setAttribute("s_date", s_date);
			request.setAttribute("e_date", e_date);
			request.setAttribute("mycat", cat);
			request.setAttribute("mylang", lang);
			
			forward = mapping.findForward(mystatus);
			
		} catch (Exception e) {
			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {			
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}
		// Finish with
		return (forward);
	}
}
