package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.eswapRequestingSwap;
import com.cathaypacific.crewdirect.swap.setItemStatus;

/**
 * @version 	1.0
 * @author
 */
public class SetSwapItemAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		String ern;
		boolean swap_status;
		String err_msg;
		try {
			
			String action_type = request.getParameter("act_type");
			String swap_id = request.getParameter("req_id");
			String sw_type = request.getParameter("dep_sw_type");
			String sw_opt0 = request.getParameter("dep_sw_opt0");
			String sw_opt1 = request.getParameter("dep_sw_opt1");
			String sw_opt2 = request.getParameter("dep_sw_opt2");
						
			HttpSession session = request.getSession();			 
			ern = (String) session.getAttribute("MyERN");	
			
			//1.0 for requesting
			if (action_type.equals("Requesting")){
				if (!sw_type.equals("NONE" )){
					//1.1 dependant swap
					eswapRequestingSwap dep_sw = new eswapRequestingSwap(ern,sw_type,sw_opt0,sw_opt1,sw_opt2);
					swap_status = dep_sw.isSuccess() ;
					err_msg = dep_sw.getErr_code(); 
				}else{
					//1.2 single swap (add)
					eswapRequestingSwap dep_sw = new eswapRequestingSwap("ADD",ern,swap_id);					
					swap_status = dep_sw.isSuccess() ;
					err_msg = dep_sw.getErr_code();  
				}

			}else{
				if (action_type.equals("Send withdrawal request to ICM")){
					//2.0 send withdraw
					//1.2 single swap 
					eswapRequestingSwap dep_sw = new eswapRequestingSwap("DEL",ern,swap_id);					
					swap_status = dep_sw.isSuccess() ;
					err_msg = dep_sw.getErr_code();  
					
				}else{	
					//3.0 update the status only  
					setItemStatus sts = new setItemStatus(ern,action_type,swap_id);
					swap_status = sts.isSuccess();
					err_msg = sts.getErr_code();										
				}

			}
			
			if (swap_status){
				if (action_type.equals("Delete")){
					forward = mapping.findForward("delete");
				}else{
					forward = mapping.findForward("success");
				}
				 
			}else{
				request.setAttribute("err_msg",err_msg); 
				forward = mapping.findForward("errors");
			}
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);			
				forward = mapping.findForward("errors");
		}

		// Finish with
		return (forward);

	}
}
