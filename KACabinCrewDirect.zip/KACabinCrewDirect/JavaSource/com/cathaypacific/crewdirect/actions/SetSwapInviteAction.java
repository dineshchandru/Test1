package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.eswapLogicCheck;
import com.cathaypacific.crewdirect.swap.eswapLogicResultBean;
import com.cathaypacific.crewdirect.swap.setNewSwap;

/**
 * @version 	1.0
 * @author
 */
public class SetSwapInviteAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		
				
		String myern ="";
		String [] other_erns;
		String [] RequestSwapERN = new String [10];
		int ern_cnt=0;
		int req_cnt=0;
		String swapStart="";
		String swapEnd="";
		
		//String partners[] = new String[10];				
		//String Acp_ERN[] = new String [10];
		
		eswapLogicCheck chkEswap = null;
		eswapLogicResultBean [] mySwapResult ;						
		int inv_cnt =0;
		int p_cnt = 1;
		try {

			HttpSession session = request.getSession();			 
			myern = (String) session.getAttribute("MyERN");
			if (myern.length()!=7) {	
				request.setAttribute("err_msg","Cannot get your ERN");
				forward = mapping.findForward("errors");
			}else{
				//1.0 get input values
				swapStart=request.getParameter("PeriodStart");
				swapEnd=request.getParameter("PeriodEnd");
				String swapRemark=request.getParameter("req_remark");				
				String erns =request.getParameter("swap_ern");				
				other_erns = str2array(erns);
				for (int x=0;x<10;x++){
					if (other_erns[x].length()==7)
					   ern_cnt++;					   
				}

				session.setAttribute("DateSwapFrom",swapStart);						
				session.setAttribute("DateSwapTo",swapEnd);

												
				//2.0 check swap logic before sumbit swap
				chkEswap = new eswapLogicCheck(myern,other_erns,swapStart,swapEnd);
				mySwapResult = chkEswap.getCheckResult(); //element 0 is myern

				if (chkEswap.isAllowInvitation() == false) {
					request.setAttribute("MySwapResult",mySwapResult);
					forward = mapping.findForward("success");
				}else{														
					//3.0 request swap ern one by one
					//skip 1st element in the array cos it hold my info					
					for (int y=1;y<=ern_cnt;y++){
						if (mySwapResult[y].getHaveError().equals("N")){
							if (mySwapResult[y].getType().equals("ACP")){
								RequestSwapERN[req_cnt] = mySwapResult[y].getErn();
								req_cnt++;  								 
							}								
						}
						
					}

					//4.0 create swap records	
					if (req_cnt > 0){									
						setNewSwap swap = new setNewSwap(myern,RequestSwapERN,swapStart,swapEnd,swapRemark);	
						//merage  error message in swap result bean
						
						for (int x=0;x<req_cnt;x++){							
							for (int y=0;y<=ern_cnt;y++){															
								if (mySwapResult[y].getErn() == RequestSwapERN[x]){
									mySwapResult[y].setSwapnumber(swap.getSwapNumber()[x]);
									mySwapResult[y].setErr_msg(swap.getErr_code()[x]);									
								}
							}
						}						
						request.setAttribute("MySwapResult",mySwapResult);
						forward = mapping.findForward("success");									
					}else{
						forward = mapping.findForward("errors");
					}
				}			    					
			}
			

			
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}

	public String [] str2array (String s) {
		String  temp[] = new String [10];
		int cnt=0;
		int pos_start=0;
		int pos_end =0;
		for (int x=0; x<s.length();x++ ){
			pos_end = s.indexOf(",",x);
			temp[cnt] = s.substring(pos_start,pos_end);
			cnt++;
			x = pos_end;
			pos_start = pos_end +1;
		}		
		
		//initial other elements
		for (int  y=cnt;y<10;y++){
			temp[y]="";
		}
					
		return temp; 
	}

}
