/***************************************************
 * Name : GetDutySummaryAction.java
 * Date : 26 Aug 2004 
 * Desc : Redirect page and action
 ***************************************************/
package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.dutysummary.dutySummary;

/**
 * @version 	1.0
 * @author
 */
public class GetDutySummaryAction extends Action {

	public ActionForward execute(ActionMapping mapping,	ActionForm form,
		HttpServletRequest request,	HttpServletResponse response) throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");

			if (ern.length()!= 7) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));

			} else {	
				
				//Call dutySummary.java -> Retrieve duty summary data from DB			
				dutySummary dutyrecord = new dutySummary(ern);	
									
				//Record Found -> show the data in dutySummary.jsp
				if (dutyrecord.getErr_msg().equals("no_err")) {
					request.setAttribute("dutyDetails", dutyrecord);
					forward = mapping.findForward("success");					
				} else {
					String err_msg = dutyrecord.getErr_msg();
					request.setAttribute("err_msg" ,err_msg); 
					forward = mapping.findForward("errors");
				}

			}				
			
		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg", errors);		
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}
}
