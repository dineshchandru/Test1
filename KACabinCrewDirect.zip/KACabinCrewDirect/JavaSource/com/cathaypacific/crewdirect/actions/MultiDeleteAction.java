package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.setMultiDelete;

/**
 * @version 	1.0
 * @author
 */
public class MultiDeleteAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
			if (ern.length()!=7) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
			}else{
				String del_items = request.getParameter("del_items");				
				if (!del_items.equals("")){
					setMultiDelete mydel = new setMultiDelete(ern,del_items);
					if (mydel.getErr_code().equals("no_err")){ 
						forward = mapping.findForward("success");
					}else{
						request.setAttribute("err_msg",mydel.getErr_code());
						forward = mapping.findForward("failure");
					}
				}else{
					forward = mapping.findForward("success");
				}
			}
			
 
			// do something here

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			forward = mapping.findForward("error");						
		}
		
		return (forward);


	}
}
