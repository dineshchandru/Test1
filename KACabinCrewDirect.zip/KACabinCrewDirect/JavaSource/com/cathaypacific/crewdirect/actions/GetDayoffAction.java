/***************************************************
 * Name : GetDayoffAction.java
 * Date : 25 Jun 2009 
 * Desc : Redirect page and action
 ***************************************************/
package com.cathaypacific.crewdirect.actions;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.owasp.esapi.filters.SafeRequest;

import com.cathaypacific.crewdirect.services.agqRequest;
import com.cathaypacific.crewdirect.services.gdayRequest;

/**
 * @version 	1.0
 * @author
 */
public class GetDayoffAction extends Action {

	public ActionForward execute(ActionMapping mapping,	ActionForm form,
		HttpServletRequest request,	HttpServletResponse response) throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		


		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
						
			if (ern.length() < 7) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));

			} else {
				//2016
				System.out.println("ABCD"+ern);
				if (ern.equals("1234567")) {			
					String err_msg = "You have not yet acknowledged crew notification(s) / CCS broadcast message, please close the window and log in again. ";
					request.setAttribute("err_msg" ,err_msg); 
					forward = mapping.findForward("errors");
					return (forward);
				}
			
				//Get the input parameter from the user interface page
				String app_type = request.getParameter("app_type");
				String web_action = request.getParameter("web_action");

				// ******** Insert, Delete, Update action from Normal days-off request *******
				if (app_type.equals("MONTH_DAYOFF1")) {			
					
					//KA Security add
					System.out.println("GetDayoffAction debug : KA security started");
					SafeRequest newRequest = new SafeRequest(request);
					System.out.println("GetDayoffAction debug : new request initialized");
					
					Map unfilteredParameterMap = request.getParameterMap(); 
					System.out.println("GetDayoffAction debug : parametermap got");
					
					Map filteredParameterMap = newRequest.getParameterMap();
					System.out.println("GetDayoffAction debug : filtered parametermap got");
					
					System.out.println("GetDayoffAction debug : filteredParameterMap.size is "+filteredParameterMap.size() + "un filteredParameterMap.size is "+unfilteredParameterMap.size());
					System.out.println("GetDayoffAction debug : KA security determining"); 
					
					if(filteredParameterMap.size()<unfilteredParameterMap.size()){
						
						System.out.println("GetDayoffAction : KA security failed (set forward to error, error msg xssError ) ");
						forward = mapping.findForward("failure");
						String err_msg = null;
						err_msg = "XSSError";
						request.setAttribute("err_msg", err_msg);
//						errors.add("Error",	new org.apache.struts.action.ActionError(err_msg));
						System.out.println("GetDayoffAction: Invalid paramter map is as follow (XSS);");
						
						Set keySet = unfilteredParameterMap.keySet();
					     Iterator it = keySet.iterator();
					     while(it.hasNext()) {
					        Object key = it.next();
					        String[] value=(String[])(unfilteredParameterMap.get(key));
					        System.out.println("GetDayoffAction XSS Parameter : The input Key is-->"+key+" and "+"The Input value is-->"+value[0]);
					       // System.out.printf("XSS Paramter %-12s is %-20s \n" ,key,value[0]);
					     }
					     System.out.println("Isabel updated end");
						return forward;		
					}
					
					System.out.println("GetDayoffAction debug : KA security passed");
				
					String roster_month = request.getParameter("roster_month");					
					//String roster_month =validate( "roster_month",request.getParameter("roster_month"));										
					String roster_yy = request.getParameter("roster_yy");
					//String roster_yy =validate( "roster_yy",request.getParameter("roster_yy"));					
					String roster_mm = request.getParameter("roster_mm");
					//String roster_mm= validate( "roster_mm",request.getParameter("roster_mm"));
					request.setAttribute("roster_month", roster_month);
					request.setAttribute("roster_yy", roster_yy);
					request.setAttribute("roster_mm", roster_mm);
					
					//Call gdayRequest.java -> Retrieve day-off request of specified month from DB
					if (web_action.equals("GET_DATA")) {
						//modified by vicki for KACCD 1.4.2008								
						gdayRequest dayoffrecord = new gdayRequest(ern, roster_month);
						
						//Record Found -> show the data in gdayBody.jsp
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("GDayoff", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Days-off Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
					
					//Call gdayRequest.java -> Insert day-off request of specified month to DB
					}
					}
				
					if (app_type.equals("MONTH_DAYOFF")) {		
						
						String roster_month= request.getParameter("roster_month"); 
						
					if (web_action.equals("INSERT_DATA")) {
						String insert_start = request.getParameter("insert_start");
						String insert_end = request.getParameter("insert_end");    
						

						gdayRequest dayoffrecord = new gdayRequest(ern, roster_month, insert_start, insert_end) ;

						//Inserted successful -> return the successful message on the screen
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("GDayoff", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Days-off Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}

					} else if (web_action.equals("WITHDRAW_DATA")) {

						String insert_start = "";
						String insert_end = "";
						String seq_no = "";
						if (request.getParameter("insert_start") != null)
							insert_start = request.getParameter("insert_start");
						if (request.getParameter("insert_end") != null)
							insert_end = request.getParameter("insert_end");
						if (request.getParameter("seq_no") != null)
							seq_no = request.getParameter("seq_no");
						
						gdayRequest dayoffrecord = new gdayRequest(ern, roster_month, insert_start, insert_end, seq_no, "withdraw") ;

						//Inserted successful -> return the successful message on the screen
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("GDayoff", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Days-off Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
					}
				
				// ******** Insert, Delete, Update action from Priority G day Request (AGQ) ******* 
				} else if (app_type.equals("ANNUAL_DAYOFF")) {

					String roster_year = request.getParameter("roster_year");
					request.setAttribute("roster_year", roster_year);

					//Call agqRequest.java -> Retrieve day-off request of specified month from DB
					if (web_action.equals("GET_DATA")) {
						//modified by May Ng for KACCD 7 Jul 2009					
						agqRequest dayoffrecord = new agqRequest(ern, roster_year);
						
						//Record Found -> show the data in gdayAGQ.jsp
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("AGQRequest", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Priority G day Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
					
					//Call agqRequest.java -> Insert day-off request of specified month to DB
					} else if (web_action.equals("INSERT_DATA")) {
						String insert_start = request.getParameter("insert_start");
						String commit_msg = new String("");
						
   						agqRequest dayoffrecord = new agqRequest();
   						commit_msg = dayoffrecord.update_request(web_action, ern, roster_year, insert_start) ;
   						dayoffrecord = new agqRequest(ern, roster_year);
   						dayoffrecord.setSuccess_msg(commit_msg);

   						//Inserted successful -> return the successful message on the screen
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("AGQRequest", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Priority G day Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}

					} else if (web_action.equals("WITHDRAW_DATA")) {

						String insert_start = "";
						String commit_msg = new String("");

						if (request.getParameter("insert_start") != null)
							insert_start = request.getParameter("insert_start");

						agqRequest dayoffrecord = new agqRequest();
   						commit_msg = dayoffrecord.update_request(web_action, ern, roster_year, insert_start) ;
   						dayoffrecord = new agqRequest(ern, roster_year);
   						dayoffrecord.setSuccess_msg(commit_msg);

						//Inserted successful -> return the successful message on the screen
						if (dayoffrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("AGQRequest", dayoffrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Priority G day Request: "+dayoffrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
					}
					
				}
			}				
			
			
			
		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg", errors);		
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}

	
}
