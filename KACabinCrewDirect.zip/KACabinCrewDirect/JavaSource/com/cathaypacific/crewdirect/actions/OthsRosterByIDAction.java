package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.roster.othsRosterListCollection;


/**
 * @version 	1.0
 * @author
 */
public class OthsRosterByIDAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		String crew_id [] = new String [9];
		String id0="";
		String id1="";
		String id2="";
		String id3="";
		String id4="";
		String id5="";
		String id6="";
		String id7="";
		String id8="";		
		String imonth="";				
		try {
			//1.0 get current ERN
			HttpSession session = request.getSession();
			String ern = (String) session.getAttribute("MyERN");
			
			//get user inputs
			imonth = request.getParameter("imonth").trim() ;
			id0 = request.getParameter("id0").toUpperCase().trim() ;
			id1 = request.getParameter("id1").toUpperCase().trim() ;
			id2 = request.getParameter("id2").toUpperCase().trim() ;
			id3 = request.getParameter("id3").toUpperCase().trim() ;
			id4 = request.getParameter("id4").toUpperCase().trim() ;
			id5 = request.getParameter("id5").toUpperCase().trim() ;
			id6 = request.getParameter("id6").toUpperCase().trim() ;
			id7 = request.getParameter("id7").toUpperCase().trim() ;
			id8 = request.getParameter("id8").toUpperCase().trim() ;
			crew_id  = getCrewIDArray(id0,id1,id2,id3,id4,id5,id6,id7,id8);			
						
			//create crew-id array
			
			
			if (ern.length() == 7) {
				//pass,ern,month, crew_id arrary (max9)
				othsRosterListCollection othsRoster =  new othsRosterListCollection(ern,imonth,crew_id);
	
				if (othsRoster!=null){				
					request.setAttribute("OthsRosters",othsRoster );				
					forward = mapping.findForward("success");
				}
			}else{
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
				forward = mapping.findForward("failure");
			}


		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}
		return (forward);

	}

    private String [] getCrewIDArray(String s0,String s1,String s2,String s3,String s4,
    								 String s5,String s6,String s7,String s8){
    	
    	String temp[]= new String[9];
    	int cnt=0;
    	if (s0.length()>0){
			temp[cnt] = s0;
			cnt++;
    	}
		if (s1.length()>0){
			temp[cnt] = s1;
			cnt++;
		}
		if (s2.length()>0){
			temp[cnt] = s2;
			cnt++;
		}
		if (s3.length()>0){
			temp[cnt] = s3;
			cnt++;
		}
		if (s4.length()>0){
			temp[cnt] = s4;
			cnt++;
		}
		if (s5.length()>0){
			temp[cnt] = s5;
			cnt++;
		}
		if (s6.length()>0){
			temp[cnt] = s6;
			cnt++;
		}
		if (s7.length()>0){
			temp[cnt] = s7;
			cnt++;
		}
		if (s8.length()>0){
			temp[cnt] = s8;
			cnt++;
		}
    	return temp;
    }
}
