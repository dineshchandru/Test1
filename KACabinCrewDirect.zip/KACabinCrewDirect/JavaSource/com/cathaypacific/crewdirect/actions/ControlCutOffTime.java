package com.cathaypacific.crewdirect.actions;

import com.cathaypacific.crewdirect.databeans.StartAndEndData;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ControlCutOffTime extends Action
{
  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws Exception
  {
    String type = request.getParameter("type");

    StartAndEndData se = new StartAndEndData();
    Date end_date = se.getEnd_date(type);
    Date start_date = se.getStart_date(type);

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
    int year = Integer.parseInt(sdf.format(start_date));

    int a = 0;
    int b = 0;
    Date d = new Date();
    int today = d.getDate();

    if (end_date == null) {
      int month = start_date.getMonth() + 1;
      if ((month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12))
        b = 31;
      else if ((month == 4) || (month == 6) || (month == 9) || (month == 11))
        b = 30;
      else if (month == 2) {
        if (year % 4 == 0)
          b = 29;
        else {
          b = 28;
        }
      }
      a = start_date.getDate();
    } else {
      a = start_date.getDate();
      b = end_date.getDate();
    }

    if ((today >= a) && (today <= b)) {
      request.setAttribute("type", type);
      return mapping.findForward("timeisout");
    }

    HttpSession session = request.getSession();
    String ern = (String)session.getAttribute("MyERN");
    if (ern.equals("1234567")) {
      String err_msg = "You have not yet acknowledged crew notification(s) / CCS broadcast message, please close the window and log in again. ";
      request.setAttribute("err_msg", err_msg);

      return mapping.findForward("errors");
    }

    if ("DOR".equals(type))
      return mapping.findForward("Days");
    if ("FPR".equals(type)) {
      return mapping.findForward("Flight");
    }
    return mapping.findForward("overnight");
  }
}