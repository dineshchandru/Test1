package com.cathaypacific.crewdirect.actions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.owasp.esapi.filters.SafeRequest;

import com.cathaypacific.crewdirect.swap.MayFlyCrewList;
import com.cathaypacific.crewdirect.swap.MayFlySelect;

/**
 * @version 	1.0
 * @author
 */
public class GetMayFlyAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		MayFlySelect myflt;
		String start_date = "";		
		String temp_date ="";
		try {
			
			System.out.println("GetMayFlyAction debug : KA security started");
			SafeRequest newRequest = new SafeRequest(request);
			System.out.println("GetMayFlyAction debug : new request initialized");
			
			Map unfilteredParameterMap = request.getParameterMap(); 
			System.out.println("GetMayFlyAction debug : parametermap got");
			
			Map filteredParameterMap = newRequest.getParameterMap();
			System.out.println("GetMayFlyAction debug : filtered parametermap got");
			
			System.out.println("GetMayFlyAction debug : filteredParameterMap.size is "+filteredParameterMap.size() + "un filteredParameterMap.size is "+unfilteredParameterMap.size());
			System.out.println("GetMayFlyAction debug : KA security determining"); 
						
			if(filteredParameterMap.size()<unfilteredParameterMap.size()){
				
				System.out.println("GetMayFlyAction : KA security failed (set forward to error, error msg xssError ) ");
				forward = mapping.findForward("failure");
				String err_msg = null;
				err_msg = "XSSError";
				request.setAttribute("err_msg", err_msg);
//				errors.add("Error",	new org.apache.struts.action.ActionError(err_msg));
				System.out.println("GetMayFlyAction: Invalid paramter map is as follow (XSS) :");
				
				Set keySet = unfilteredParameterMap.keySet();
			     Iterator it = keySet.iterator();
			     while(it.hasNext()) {
			        Object key = it.next();
			        String[] value=(String[])(unfilteredParameterMap.get(key));
			        System.out.println("GetMayFlyAction XSS Parameter : The input Key is-->"+key+" and "+"The Input value is-->"+value[0]);
			       // System.out.printf("XSS Paramter %-12s is %-20s \n" ,key,value[0]);
			     }
				return forward;		
			}
			
			System.out.println("GetMayFlyAction debug : KA security passed");
			
			
			HttpSession session = request.getSession();
			String mytype = request.getParameter("web");
			 
			String ern = (String) session.getAttribute("MyERN");
			if (ern.equals("1234567")) {			
				String err_msg = "You have not yet acknowledged crew notification(s) / CCS broadcast message, please close the window and log in again. ";
				request.setAttribute("err_msg" ,err_msg); 
			 
				return mapping.findForward("errors");
			}
			
			
			//get date from sessions
			if (session.getAttribute("DateMayFly") == null || session.getAttribute("DateMayFly").equals("null")){
				//get today value
				Date date = new Date(); 
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
				Calendar cal = Calendar.getInstance();  
				start_date = formatter.format(cal.getTime());	
				session.setAttribute("DateMayFly", start_date);
				
			} else {
				start_date = (String) session.getAttribute("DateMayFly");
			}
		
			if (mytype.equals("req_crewlist")){
				//KA Security
				String flt_date = request.getParameter("flt_date").trim() ;
				String flt_no = request.getParameter("flt_no").trim() ;									
				String flt_port = request.getParameter("sector_from").toUpperCase().trim() ;
				MayFlyCrewList crewlist = new MayFlyCrewList(flt_date,flt_no,flt_port);						
			
				if (crewlist.getErr_msg().equals("no_err")){
					request.setAttribute("MayFlyCrwLst", crewlist);
					forward = mapping.findForward("success");					
				}else{
					String err_msg = "Crew List: "+crewlist.getErr_msg();
					request.setAttribute("err_msg",err_msg); 
					forward = mapping.findForward("errors");
				}			
				start_date = flt_date;
				
			} else {
				if (mytype.equals("req_flights")){
					String req_date = request.getParameter("req_date").trim() ;
					myflt = new MayFlySelect(req_date);
					session.setAttribute("MayFly", myflt);				
					start_date = req_date;		
				}
				forward = mapping.findForward("start");
			}
			
			session.setAttribute("DateMayFly", start_date);
			//set swap period				
			session.setAttribute("DateSwapFrom", start_date);						
			session.setAttribute("DateSwapTo", start_date);
			 	

		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);		
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}
}
