package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.BroadcastMQServices;
import com.cathaypacific.crewdirect.services.LoginTimeStamp;
import com.cathaypacific.crewdirect.utils.Decode_MQ_BCMsg;

/**
 * @version 	1.0
 * @author      Alvin
 */
public class BroadcastAcknowledgeAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String myStatus="success";
		String ask_txt="";
		String rtn_txt="";
		String ERN ="";
		LoginTimeStamp myLogin;
		String clientIP ="";
		String clientHost="";
		
		String myErr = "Sorry, the system is busy at this moment (E003), the crew broadcast message has not been acknowledged. Please login again. If the problem still exists, please call Crew Control at your earliest convenience.";
		String myErr1 = "The sytem is busy at this moment(E004), the broadcast message is not updated. If the problem still exists, Please call Crew Control to reconfirm your duties.";
		boolean HaveErrorMQ;
		try {
			
		    HttpSession session = request.getSession();
			
			//acked the messge,reset global ern					
			ERN = (String) session.getAttribute("ACKFLAG");//block acess
			session.setAttribute("MyERN",ERN); //block access
	
	
			ERN = (String) session.getAttribute("MyERN");	
			//1.0 get Last login time
			myLogin = new LoginTimeStamp(ERN);
			
			//2.0 MQ access                  
            BroadcastMQServices CrewAckMQ = new BroadcastMQServices("ack");                   
            ask_txt = "KAD15" + ERN;
            CrewAckMQ.setMq_ask_txt(ask_txt);  
            System.out.println("ask_txt : " + ask_txt);
            
            //3.1 loop max 3 time for getting correct MQ info
            HaveErrorMQ = true;
            for (int x=0;x<2;x++){                                    
                if (CrewAckMQ.call_mq(0)==true){
                    rtn_txt = CrewAckMQ.getMq_rtn_txt();

                    if (rtn_txt.substring(5,7).equals("  " )){   //no error code
                        if (rtn_txt.substring(57,64).trim().equals(ERN )){    //same ern
                            HaveErrorMQ = false;
                            break;
                        }
                    }
                }                   
            }
            
            // For decode MQ message test only
            //rtn_txt = "KAD16                                                    701065ETesting Broadcast Message                                                                                                                                                                               ";
            //HaveErrorMQ = false;           
            
            System.out.println("rtn_txt : " + rtn_txt);
            //4.0 handle MQ return status
            String bcMsg = rtn_txt.substring(64, 264);
            myStatus = "success";
            if (HaveErrorMQ){
                request.setAttribute("err_msg",myErr1);
                myStatus = "error";                                         
            }else{
                //4.1 Crew Note not acked 
                //update oracle db
                Decode_MQ_BCMsg mq_ack =new Decode_MQ_BCMsg(ERN, bcMsg.trim());
                if (mq_ack.isSuccess() == false) {                	
                   request.setAttribute("err_msg",myErr);            
                   myStatus = "error";
                }                                                        
            }

		    //5.0 set logintime for acknowlegement
		    clientIP = (String ) request.getRemoteAddr();
		    clientHost = (String ) request.getRemoteHost();
		    if (myStatus.equals("error"))
		        myLogin.setTimeStamp(clientIP,clientHost,"ACK_Er");
		    else
		        myLogin.setTimeStamp(clientIP,clientHost,"ACKED");	

		    if ("success".equals(myStatus)) {
		        request.setAttribute("BC_MSG", bcMsg);
		    }
		    forward = mapping.findForward(myStatus);		   

		} catch (Exception e) {
			request.setAttribute("err_msg",myErr);
			System.out.println("Exception : " + myErr);
			forward = mapping.findForward("error");
		}

		if (!errors.isEmpty()) {
			request.setAttribute("err_msg",myErr);
			forward = mapping.findForward("error");						
		}
		
		return (forward);

	}
}
