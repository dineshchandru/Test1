/*
 * Created on Apr 1, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.actions;

import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.slsActive;
import com.cathaypacific.crewdirect.services.slsRequest;
import com.cathaypacific.crewdirect.services.slsConsent;
import com.cathaypacific.crewdirect.databeans.slsRequestBean;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GetSLSRequestAction extends Action {
	
	public ActionForward execute(ActionMapping mapping,	ActionForm form,
			HttpServletRequest request,	HttpServletResponse response) throws Exception {

			ActionErrors errors = new ActionErrors();
			ActionForward forward = new ActionForward();
			// return value

			try {
				HttpSession session = request.getSession();			 
				String ern = (String) session.getAttribute("MyERN");
				String app_type = "GET_DATA";
				
				if (request.getParameter("app_type") != null)
					app_type = request.getParameter("app_type");
								
				if (ern.length() < 4) {			
					errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));

				} else {
					//Get the input parameter from the user interface page
					String roster_month = request.getParameter("roster_month");
					String roster_yy = request.getParameter("roster_yy");
					String roster_mm = request.getParameter("roster_mm");
					request.setAttribute("roster_month", roster_month);
					request.setAttribute("roster_yy", roster_yy);
					request.setAttribute("roster_mm", roster_mm);
					
					String start_date = "";
					String start_date1= "";
					String start_date2 = "";
					String start_date3 = "";
					
					String end_date = "";
					String end_date1 = "";
					String end_date2 = "";
					String end_date3 = "";
					
					String day = "0";
					String day1 = "0";
					String day2 = "0";
					String day3 = "0";
					
					String odd_start_date = "";
					String odd_day = "0";
					
					String consent_status = "";
					String consent_date = "";
					
					if (request.getParameter("cbStartDate") != null)
						start_date = request.getParameter("cbStartDate");
					
					if (request.getParameter("cbStartDate1") != null)
						start_date1 = request.getParameter("cbStartDate1");
					
					if (request.getParameter("cbStartDate2") != null)
						start_date2 = request.getParameter("cbStartDate2");
					
					if (request.getParameter("cbStartDate3") != null)
						start_date3 = request.getParameter("cbStartDate3");
					
					if (request.getParameter("cbEndDate") != null)
						end_date = request.getParameter("cbEndDate");
					
					if (request.getParameter("cbEndDate1") != null)
						end_date1 = request.getParameter("cbEndDate1");
					
					if (request.getParameter("cbEndDate2") != null)
						end_date2 = request.getParameter("cbEndDate2");
					
					if (request.getParameter("cbEndDate3") != null)
						end_date3 = request.getParameter("cbEndDate3");
					
					if (request.getParameter("day") != null)
						day = request.getParameter("day");
					
					if (request.getParameter("day1") != null)
						day1 = request.getParameter("day1");
					
					if (request.getParameter("day2") != null)
						day2 = request.getParameter("day2");
					
					if (request.getParameter("day3") != null)
						day3 = request.getParameter("day3");
					
					if (request.getParameter("cbOddStartDate") != null)
						odd_start_date = request.getParameter("cbOddStartDate");
					
					if (request.getParameter("oddDay") != null)
						odd_day = request.getParameter("oddDay");
					
					Vector updateSLSRequest = new Vector();
					int max_seq = 0;

					//Call gdayRequest.java -> Retrieve day-off request of specified month from DB
					if (app_type.equals("GET_DATA")) {
						
						slsActive activeRecord = new slsActive();
						
						if (activeRecord.getActiveStatus(ern))
						{
							slsConsent slsconsent = new slsConsent();
							consent_status = slsconsent.get_consent_status(ern);							
							
							if (consent_status.equals("R")) 
							{	
								forward = mapping.findForward("no_sls");
							}else if (consent_status.equals("N"))
							{
								forward = mapping.findForward("no_consent");
							}else if (consent_status.equals("Y"))
							{
								slsRequest slsrecord = new slsRequest(ern);
								//Record Found -> show the data in gdayBody.jsp
								if (slsrecord.getErr_msg().equals("no_err")) {
									request.setAttribute("SLSRequest", slsrecord);
									forward = mapping.findForward("success");					
								} else {
									String err_msg = "SLS Request: " + slsrecord.getErr_msg();
									request.setAttribute("err_msg" ,err_msg); 
									forward = mapping.findForward("errors");
								}
							}
						}else
						{
							String err_msg = "SLS Consent: " + activeRecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("no_sls");
						}
						//Call gdayRequest.java -> Insert day-off request of specified month to DB
					} else if (app_type.equals("INSERT_DATA")) {
						
						slsRequestBean tempRequest = new slsRequestBean();
						tempRequest.setERN(ern);
						tempRequest.setStart_Date(start_date);
						tempRequest.setEnd_Date(end_date);
						tempRequest.setDay(Integer.parseInt(day));
						if (start_date.equals(odd_start_date))
						{
							tempRequest.setOdd_Start_Date(odd_start_date);
							tempRequest.setOdd_Day(Integer.parseInt(odd_day));
						}
						tempRequest.setSeq(1);
						updateSLSRequest.add(tempRequest);
						
						tempRequest = new slsRequestBean();
						tempRequest.setERN(ern);
						tempRequest.setStart_Date(start_date1);
						tempRequest.setEnd_Date(end_date1);
						tempRequest.setDay(Integer.parseInt(day1));
						if (start_date1.equals(odd_start_date))
						{
							tempRequest.setOdd_Start_Date(odd_start_date);
							tempRequest.setOdd_Day(Integer.parseInt(odd_day));
						}
						tempRequest.setSeq(2);
						updateSLSRequest.add(tempRequest);
						
						tempRequest = new slsRequestBean();
						tempRequest.setERN(ern);
						tempRequest.setStart_Date(start_date2);
						tempRequest.setEnd_Date(end_date2);
						tempRequest.setDay(Integer.parseInt(day2));
						if (start_date2.equals(odd_start_date))
						{
							tempRequest.setOdd_Start_Date(odd_start_date);
							tempRequest.setOdd_Day(Integer.parseInt(odd_day));
						}
						tempRequest.setSeq(3);
						updateSLSRequest.add(tempRequest);						
						
						tempRequest = new slsRequestBean();
						tempRequest.setERN(ern);
						tempRequest.setStart_Date(start_date3);
						tempRequest.setEnd_Date(end_date3);
						tempRequest.setDay(Integer.parseInt(day3));
						if (start_date3.equals(odd_start_date))
						{
							tempRequest.setOdd_Start_Date(odd_start_date);
							tempRequest.setOdd_Day(Integer.parseInt(odd_day));
						}
						tempRequest.setSeq(4);
						updateSLSRequest.add(tempRequest);
						           
						slsRequest slsrecord = new slsRequest(app_type, ern, updateSLSRequest);
						
						//Inserted successful -> return the successful message on the screen
						if (slsrecord.getErr_msg().equals("no_err")) {
							request.setAttribute("SLSRequest", slsrecord);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "SLS Request: "+slsrecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
							
					}
				}				
				
			} catch (Exception e) {			
				errors.add("name", new ActionError("id"));
				request.setAttribute("err_msg", "Your session has been timeout.");
				forward = mapping.findForward("failure");
			}

			if (!errors.isEmpty()) {
				saveErrors(request, errors);
				request.setAttribute("err_msg", errors);		
				forward = mapping.findForward("failure");
			}

			// Finish with
			return (forward);
		}
	}