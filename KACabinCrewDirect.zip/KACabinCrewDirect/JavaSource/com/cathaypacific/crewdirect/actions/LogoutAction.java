package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import java.io.IOException;
import javax.servlet.ServletException;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
 

/**
 * @version 	1.0
 * @author
 */
public class LogoutAction extends Action

{

    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        ActionErrors errors = new ActionErrors();
        ActionForward forward = new ActionForward(); // return value

        try {
        	
            Cookie isuggestCookie = new Cookie("isuggest", null);
            isuggestCookie.setMaxAge(0);
            isuggestCookie.setPath("/");
            isuggestCookie.setDomain(".cathaypacific.com");
            response.addCookie(isuggestCookie);
            
            Cookie usergroupCookie = new Cookie("usergroup", null);
            usergroupCookie.setMaxAge(0);
            usergroupCookie.setPath("/");
            usergroupCookie.setDomain(".cathaypacific.com");
            response.addCookie(usergroupCookie);
            
            /*Cookie userdeptCookie = new Cookie(" userdept", null);
            userdeptCookie.setMaxAge(0);
            userdeptCookie.setPath("/");
            userdeptCookie.setDomain(".cathaypacific.com");
            response.addCookie(userdeptCookie); 
            response.sendRedirect(response.encodeRedirectURL(checkNullOrEmpty(request.getParameter("URL"), "")));
            */
        	
        } catch (Exception e) {

            // Report the error using the appropriate name and ID.
            errors.add("name", new ActionError("id"));
            System.out.println("Logout:"+e.getMessage());
        }

        // If a message is required, save the specified key(s)
        // into the request for use by the <struts:errors> tag.

        if (!errors.isEmpty()) {
            saveErrors(request, errors);

            // Forward control to the appropriate 'failure' URI (change name as desired)
            forward = mapping.findForward("failure");

        } else {

            // Forward control to the appropriate 'success' URI (change name as desired)
            forward = mapping.findForward("success");
        }
        // Finish with
        return (forward);

    }

    private String checkNullOrEmpty(String str, String defaultValue) {
        if(str == null || str.trim().length() <= 0)
            return defaultValue;
        else
            return str;
    }

    private void sendRedirect(String url, HttpServletResponse res) throws ServletException, IOException {
        res.sendRedirect(res.encodeRedirectURL(url));
    }    
}
