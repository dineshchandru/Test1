package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.profileBeanList;
import com.cathaypacific.crewdirect.forms.ProfileformBean;

/**
 * @version 	1.0
 * @author
 */
public class SetProfileAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		ProfileformBean ProfileformBean = (ProfileformBean) form;
		String [] arr_prof = new String [4]; 
		try {

			HttpSession session = request.getSession();			 
			String ern = "";
			ern = (String) session.getAttribute("MyERN");
			
			
			if (ern.length() < 4) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
				forward = mapping.findForward("failure");
			}else{
 			
				arr_prof[0] = ProfileformBean.getRoster_info() ;
				arr_prof[1] = ProfileformBean.getMail_box(); 
				arr_prof[2] = ProfileformBean.getEmail(); 
				arr_prof[3] = ProfileformBean.getBase_port(); 
				
				profileBeanList profile = new profileBeanList(ern,arr_prof);			
				if (profile.getStatus().equals("Y" )){				
					forward = mapping.findForward("success");	
				}
			}            
			// do something here

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}
		// Finish with
		return (forward);

	}
}
