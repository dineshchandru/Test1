package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.slsConsent;
import com.cathaypacific.crewdirect.services.slsActive;

/**
 * @version 	1.0
 * @author
 */
public class GetSLSConsentAction extends Action {

	public ActionForward execute(ActionMapping mapping,	ActionForm form,
		HttpServletRequest request,	HttpServletResponse response) throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
			String app_type = "GET_DATA";
				
			if (request.getParameter("app_type") != null)
				app_type = request.getParameter("app_type");
								
			if (ern.length() < 4) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));

			} else {
				
				slsActive activeRecord = new slsActive();
				
				if (activeRecord.getActiveStatus(ern))
				{
					slsConsent consentRecord = new slsConsent();
					
					//Update the Consent Status
					if (app_type.equals("INSERT_DATA")) {
						consentRecord.updateConsent(ern);
					}		
	
					//Get the Consent Period Details
					if (consentRecord.getErr_msg().equals("no_err")) {
						//Call slsConsent.java -> Retrieve consent status from DB
						String period_status = consentRecord.get_consent_period();
						String display_start = consentRecord.getDisplay_start();
						String display_end = consentRecord.getDisplay_end();
						String sls_details = consentRecord.getSls_details();
	
						//Record Found -> show the data in slsConsent.jsp
						if (consentRecord.getErr_msg().equals("no_err")) {					
							String consent_status = consentRecord.get_consent_status(ern);
							String consent_date = consentRecord.getConsent_date();
							String required_days = consentRecord.getRequired_days();
							
							if (consentRecord.getErr_msg().equals("no_err")) {
								
								if (consent_status.equals("R")) // no SLS required
								{
									forward = mapping.findForward("no_sls");
								}else
								{
									request.setAttribute("period_status", period_status);
									request.setAttribute("display_start", display_start);
									request.setAttribute("display_end", display_end);
									request.setAttribute("sls_details", sls_details);
									request.setAttribute("consent_status", consent_status);
									request.setAttribute("consent_date", consent_date);
									request.setAttribute("required_days", required_days);
									
									forward = mapping.findForward("success");
								}
							
							} else {
								String err_msg = "SLS Consent: " + consentRecord.getErr_msg();
								request.setAttribute("err_msg" ,err_msg); 
								forward = mapping.findForward("errors");
							}
						} else {
							String err_msg = "SLS Consent: " + consentRecord.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
						
					} else {
						String err_msg = "SLS Consent: " + consentRecord.getErr_msg();
						request.setAttribute("err_msg" ,err_msg); 
						forward = mapping.findForward("errors");
					}
				}else
				{
					String err_msg = "SLS Consent: " + activeRecord.getErr_msg();
					request.setAttribute("err_msg" ,err_msg); 
					forward = mapping.findForward("no_sls");
				}
			}

		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg", errors);		
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}
}
