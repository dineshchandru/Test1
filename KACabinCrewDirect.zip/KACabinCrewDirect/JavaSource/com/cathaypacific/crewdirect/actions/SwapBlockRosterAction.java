package com.cathaypacific.crewdirect.actions;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.owasp.esapi.filters.SafeRequest;

import com.cathaypacific.crewdirect.swap.swapBlockRoster;

/**
 * @version 	1.0
 * @author
 */
public class SwapBlockRosterAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String ern="";
	    
		try {
			
			System.out.println("SwapBlockRosterAction debug : KA security started");
			SafeRequest newRequest = new SafeRequest(request);
			System.out.println("SwapBlockRosterAction debug : new request initialized");
			
			Map unfilteredParameterMap = request.getParameterMap(); 
			System.out.println("SwapBlockRosterAction debug : parametermap got");
			
			Map filteredParameterMap = newRequest.getParameterMap();
			System.out.println("SwapBlockRosterAction debug : filtered parametermap got");
			
			System.out.println("SwapBlockRosterAction debug : filteredParameterMap.size is "+filteredParameterMap.size() + "un filteredParameterMap.size is "+unfilteredParameterMap.size());
			System.out.println("SwapBlockRosterAction debug : KA security determining"); 
						
			if(filteredParameterMap.size()<unfilteredParameterMap.size()){
				
				System.out.println("SwapBlockRosterAction : KA security failed (set forward to error, error msg xssError ) ");
				forward = mapping.findForward("failure");
				String err_msg = null;
				err_msg = "XSSError";
				request.setAttribute("err_msg", err_msg);
//				errors.add("Error",	new org.apache.struts.action.ActionError(err_msg));
				System.out.println("SwapBlockRosterAction: Invalid paramter map is as follow (XSS) :");
				
				Set keySet = unfilteredParameterMap.keySet();
			     Iterator it = keySet.iterator();
			     while(it.hasNext()) {
			        Object key = it.next();
			        String[] value=(String[])(unfilteredParameterMap.get(key));
			        System.out.println("SwapBlockRosterAction XSS Parameter : The input Key is-->"+key+" and "+"The Input value is-->"+value[0]);
			       // System.out.printf("XSS Paramter %-12s is %-20s \n" ,key,value[0]);
			     }
				return forward;		
			}
			
			System.out.println("SwapBlockRosterAction debug : KA security passed");
			
			
			HttpSession session = request.getSession();			 
			ern = (String) session.getAttribute("MyERN");
			
			String action_type = request.getParameter("web");
			if (action_type.equals("start")) {
				swapBlockRoster blk = new swapBlockRoster(ern);	
//				session.setAttribute("blockedMonth", blk.getStart_month());
				request.setAttribute("start_month", blk.getStart_month());
				request.setAttribute("end_month", blk.getEnd_month());
				request.setAttribute("block_roster", blk);
			}
/*
			if (action_type.equals("search")) {				
				String action_value = request.getParameter("action_value");
				session.setAttribute("blockedMonth",action_value);
				swapBlockRoster blk = new swapBlockRoster(ern,action_value);			
				request.setAttribute("block_roster",blk);								
			}
*/
			if (action_type.equals("SetBlock") || action_type.equals("ClearBlock")) {		
				//KA Security pay attentionx
				String action_value = request.getParameter("action_value");
				String start_month = request.getParameter("start_month");
				String end_month = request.getParameter("end_month");

				if (action_type.equals("ClearBlock")) {
					swapBlockRoster blk = new swapBlockRoster();
					blk.deleteMonth(ern, start_month, end_month);	
					request.setAttribute("block_roster", blk);
				} else {
					String [] myDates = str2array(action_value);
					swapBlockRoster blk = new swapBlockRoster(ern, myDates, start_month, end_month);			
					request.setAttribute("block_roster", blk);
				}
				
				/*if (action_value.length() < 1) {
					swapBlockRoster blk = new swapBlockRoster();
					blk.deleteMonth(ern,(String) session.getAttribute("blockedMonth"));	
					request.setAttribute("block_roster", blk);
				} else {
					String [] myDates = str2array(action_value);
					swapBlockRoster blk = new swapBlockRoster(ern, myDates, start_month, end_month);			
					request.setAttribute("block_roster", blk);
				}*/
			}
			forward = mapping.findForward("success");
			
		} catch (Exception e) {
			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.
		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}
		// Finish with
		return (forward);
	}

	//--------------------------------
	public String [] str2array (String s) {
		String  temp[] = new String [31];
		int cnt=0;
		int pos_start=0;
		int pos_end =0;
		for (int x = 0; x < s.length(); x++ ){
			pos_end = s.indexOf(",",x);
			temp[cnt] = s.substring(pos_start, pos_end);
			cnt++;
			x = pos_end;
			pos_start = pos_end +1;
		}
		return temp;		
	}
}
