package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.setItemReadStatus;
import com.cathaypacific.crewdirect.swap.setItemStatus;
import com.cathaypacific.crewdirect.swap.swapItemDetails;

/**
 * @version 	1.0
 * @author
 */
public class GetSwapDetailsAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		String req_id =null;
		String req_type = null;
		boolean swap_status;
		// return value
		
		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
			if (ern.length()!=7 | ern == null) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
				forward = mapping.findForward("failure");
			}else{
				
				req_id = request.getParameter("req_id");
				req_type = request.getParameter("req_type"); 
				if (req_type ==null)
				     req_type="";
				if (req_type.equals("delete")){
					setItemStatus sts = new setItemStatus(ern,"Delete",req_id);
					swap_status = sts.isSuccess();
					if (swap_status) 
						forward = mapping.findForward("show_start");
					else
					    forward = mapping.findForward("failure");																

				}else{
					//veiw details										
					setItemReadStatus read = new setItemReadStatus(ern,req_id); 
					if (read.isSuccess()){ 							
						swapItemDetails dts = new swapItemDetails(req_id,ern);
						if (dts!=null){
							request.setAttribute("swap_details",dts);	
							forward = mapping.findForward("success");							
						}else{
							forward = mapping.findForward("failure");
						}
					}				
				}
						
			}

			
			
			
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);			
				forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}
}
