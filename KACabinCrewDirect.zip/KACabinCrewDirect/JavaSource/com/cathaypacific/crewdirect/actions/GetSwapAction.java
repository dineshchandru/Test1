package com.cathaypacific.crewdirect.actions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.setItemStatus;
import com.cathaypacific.crewdirect.swap.swapEnquiryList;

public class GetSwapAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String myType="";
		String Start_Date="";
		String End_Date="";
		String iStatus="";

		try {
							
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
			if (ern.length()!=7 |ern==null ) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
			}else{		
				myType=request.getParameter("what");
				Start_Date=request.getParameter("s_date");
				End_Date=request.getParameter("e_date");
				iStatus=request.getParameter("istatus");
				
				//normal flow
				if (myType==null){
					//at begin of web
					swapEnquiryList lst = new swapEnquiryList(ern);
					if (lst!=null){
						request.setAttribute("swap_list",lst);
						forward = mapping.findForward("success");						
					}					
				}else{								
					if (myType.equals("RANGE" )){
						//by range
						swapEnquiryList lst = new swapEnquiryList(ern,Start_Date,End_Date,iStatus);
						if (lst!=null){
							request.setAttribute("swap_list",lst);
							forward = mapping.findForward("success");						
						}					
					}else{
						if(myType.equals("BATCH_DEL")){
							//this is batch delete function
							setItemStatus batchDel = new setItemStatus(ern,Start_Date,End_Date,iStatus);
							if (batchDel.getErr_code().equals("no_err")){
							
								//get the lsst again
								swapEnquiryList lstx = new swapEnquiryList(ern);
								if (lstx!=null){
									request.setAttribute("swap_list",lstx);
									forward = mapping.findForward("success");						
								}
							}else{			
								forward = mapping.findForward("failure");
							}
							
								
						}
						
					}
				}					
								
			}	
			
				
			//jsp default date range
			if (Start_Date ==null){
				//set start & end date
				Date date = new Date(); 
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
				Calendar cal = Calendar.getInstance();  
				Start_Date = formatter.format(cal.getTime());
				cal.add(Calendar.MONTH, 2);
				End_Date = formatter.format(cal.getTime());
				//------------------------------
			}

			request.setAttribute("s_date",Start_Date);
			request.setAttribute("e_date",End_Date);
			
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);

			
				forward = mapping.findForward("failure");

		}

		// Finish with
		return (forward);

	}
}
