package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.earlyReleaseRequestW;

public class GetEarlyReleaseActionW extends Action{
	public ActionForward execute(ActionMapping mapping,	ActionForm form,
			HttpServletRequest request,	HttpServletResponse response) throws Exception {

			ActionErrors errors = new ActionErrors();
			ActionForward forward = new ActionForward();
			// return value

			try {
				HttpSession session = request.getSession();			 
				String ern = (String) session.getAttribute("MyERN");
				String app_type = "ERR_WITHDRAWN";
				app_type = request.getParameter("app_type");
				if (app_type == null) {
					app_type = "";
				}
					if (app_type.equals("ERR_WITHDRAWN")) {
					
						//Get Flying Hours details
						earlyReleaseRequestW earlyRelease = new earlyReleaseRequestW(ern);
						if (earlyRelease.getErr_msg().equals("no_err")) {
							request.setAttribute("EearlyReleaseRecordWithdrawn", earlyRelease);
							forward = mapping.findForward("success");					
						} else {
							String err_msg = "Eearly Release Record Withdrawn: " + earlyRelease.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
						
					}

					
			} catch (Exception e) {			
				errors.add("name", new ActionError("id"));
				request.setAttribute("err_msg", "Your session has been timeout.");
				forward = mapping.findForward("failure");
			}
			// Finish with
			return (forward);
		}

}
