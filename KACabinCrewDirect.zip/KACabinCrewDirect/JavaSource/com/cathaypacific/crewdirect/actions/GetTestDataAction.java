package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.LoginTimeStamp;
import com.cathaypacific.crewdirect.services.MQServices;
import com.cathaypacific.crewdirect.services.getBasicInfo;
import com.cathaypacific.crewdirect.services.getTestERN;
//import com.cathaypacific.crewdirect.swap.eswapRequstingSwap;
import com.cathaypacific.crewdirect.services.typhoonMessage;

/**
 * @version 	1.0
 * @author
 */
public class GetTestDataAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String ern="";
		String myStatus=null;
		String ask_txt=null;
		String rtn_txt=null;
		String rtn_status=null;
		String TimeStamp = null;
		String [] myInfo = new String [4];
		LoginTimeStamp myLogin;
		boolean LoginUpdated;
		String myErr = "Sorry, due to problem 001, the crew notification has not been acknowledged. Please call Crew Control at your earliest convenience.";
		String myErr1 = "Due to problem 001, your roster has not been updated. Please reconfirm your roster with Crew Control.";

		
		try {
			
			HttpSession session = request.getSession();
			getTestERN test_ern = new getTestERN();
			String tern=request.getParameter("tern");
			ern = test_ern.getErn();
			if(tern!=null&&!tern.equals("")){
				ern=tern;
				
			}
			
			getBasicInfo info = new getBasicInfo(ern);
	             
			//2.0 set banner infomation 
			if (info!=null) {
				//HttpSession session = request.getSession();
				session.setAttribute("MyInfo",info.getMyInfo());			
				session.setAttribute("MyERN",ern);							
			}
	  
	  			
			//3.0 ask Facts of CrewNote by MQ
			//3.1 get timestamp
			myLogin = new LoginTimeStamp(ern);
			TimeStamp = myLogin.getTimeStamp(); 
System.out.println("KACCD "+ern +" T 0.0 ask mq");	
			//3.2 get MQ
			MQServices CrewNoteMQ = new MQServices("getnote");			
			ask_txt = "KAD01" + ern + TimeStamp;
System.out.println("KACCD_LOG:MQ TEST A/C "  + ask_txt);			
			CrewNoteMQ.setMq_ask_txt(ask_txt);
	            
			if (CrewNoteMQ.call_mq()==true){
				rtn_txt = CrewNoteMQ.getMq_rtn_txt();
System.out.println("KACCD "+ern +" T 0.0 end ask mq");
System.out.println("KACCD_LOG:MQ TEST A/C "  + rtn_txt);
				//check error code
				if (!rtn_txt.substring(5,7).equals("  " )){
					request.setAttribute("err_msg",myErr1);
					myStatus = "failure";						
				}else{								
					myStatus = "success";
				}
			}
			myStatus = "success";

			
			//0.0 get typhoon message 
			typhoonMessage typ_msg = new typhoonMessage();			
			session.setAttribute("typ_type",typ_msg.getType());
			session.setAttribute("typ_msg",typ_msg.getMessage());
			// do something here
			forward = mapping.findForward(myStatus);
			
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);

			// Forward control to the appropriate 'failure' URI (change name as desired)
				forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}
}
