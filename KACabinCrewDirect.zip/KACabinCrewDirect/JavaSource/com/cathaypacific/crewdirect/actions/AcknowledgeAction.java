package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.LoginTimeStamp;
import com.cathaypacific.crewdirect.services.MQServices;
import com.cathaypacific.crewdirect.utils.ComputeRosterDelta;
import com.cathaypacific.crewdirect.utils.decode_mq_roster;

/**
 * @version 	1.0
 * @author
 */
public class AcknowledgeAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String myStatus="success";
		String ask_txt="";
		String rtn_txt="";
		String rtn_status="";
		String ERN ="";
		String TimeStamp = "";
		LoginTimeStamp myLogin;
		boolean LoginUpdated;
		String clientIP ="";
		String clientHost="";
		
		String myErr = "Sorry, the system is busy at this moment (E003), the crew notification has not been acknowledged. Please login again. If the problem still exists, please call Crew Control at your earliest convenience.";
		String myErr1 = "The sytem is busy at this moment(E004), the roster is not updated. If the problem still exists, Please call Crew Control to reconfirm your duties.";
		boolean HaveErrorMQ;
		try {
			
			HttpSession session = request.getSession();			 
			
			
			//acked the messge,reset global ern					
			ERN = (String) session.getAttribute("ACKFLAG");//block acess
			session.setAttribute("MyERN",ERN); //block access
	
	
			ERN = (String) session.getAttribute("MyERN");	
			//1.0 get Last login time
			myLogin = new LoginTimeStamp(ERN);
			TimeStamp = myLogin.getTimeStamp(); 
			
			 //2.0 temporary have ignore button
			String type=request.getParameter("msg_type");
			if (type.equals("Acknowledge_it_later" )){
				myStatus = "ignore";
			}else{	
				
				//3.0 MQ access					
				MQServices CrewAckMQ = new MQServices("ack"); //get MQ ACD03 for ack message						
				//remark for UAT 14.5.2008
				//ask_txt = "KAD03" + ERN + "   " + TimeStamp;
				ask_txt = "KAD03" + ERN + TimeStamp;
				//ask_txt = "KAD030028   200806210000000";
				CrewAckMQ.setMq_ask_txt(ask_txt);	            
				
				//3.1 loop max 3 time for getting correct MQ info
				HaveErrorMQ = true;
				for (int x=0;x<2;x++){
					System.out.println("KA CCD "+ERN +" a 0.0 ask mq");				
					System.out.println("KA CCD_LOG:MQ "  + ask_txt);									
					if (CrewAckMQ.call_mq()==true){
						rtn_txt = CrewAckMQ.getMq_rtn_txt();
						System.out.println("KA CCD "+ERN +" a 0.0 end ask mq");					
						System.out.println("KA CCD_LOG:MQ "  + rtn_txt);

						if (rtn_txt.substring(5,7).equals("  " )){   //no error code
							if (rtn_txt.substring(7,14).trim().equals(ERN )){	 //same ern
								HaveErrorMQ = false;
								break;
							}
						}
					}					
				}
				
				//4.0 handle MQ return status	
				myStatus = "success";
				if (HaveErrorMQ){
					request.setAttribute("err_msg",myErr1);
					myStatus = "error";											
				}else{
					rtn_status = getIndicator(rtn_txt);
					//4.1 Crew Note not acked 
					if (rtn_status.equals("N")){   //Crew Note Not Acked		
						request.setAttribute("err_msg",myErr);
						myStatus = "error";
					}else{
						//Crew Note updated by Facts, so update oracle db
						if (rtn_status.equals("Y")){ 
						   decode_mq_roster mq_ack =new decode_mq_roster(ERN,rtn_txt,"CN");
						   if (mq_ack.isSuccess() == false) {
							  request.setAttribute("err_msg",myErr);			
							  myStatus = "error";
						   }
						   //PAX0884 start
						   else{
						       ComputeRosterDelta rosterDelta = new ComputeRosterDelta();
						       rosterDelta.recordChangedDelta(ERN);
						       
							   if (!rosterDelta.isSuccess()) {
								  request.setAttribute("err_msg",myErr);			
								  myStatus = "error";
							   }
						   }
						   //PAX0884 end
						}   
					}				 	  										
				}
		} //2.0

		//5.0 set logintime for acknowlegement
		clientIP = (String ) request.getRemoteAddr();
		clientHost = (String ) request.getRemoteHost();
		if (myStatus.equals("error"))
			LoginUpdated =myLogin.setTimeStamp(clientIP,clientHost,"ACK_Er");
		else
			LoginUpdated =myLogin.setTimeStamp(clientIP,clientHost,"ACKED");	

                    
		forward = mapping.findForward(myStatus);


		} catch (Exception e) {
			request.setAttribute("err_msg",myErr);
			forward = mapping.findForward("error");
		}

		if (!errors.isEmpty()) {
			request.setAttribute("err_msg",myErr);
			forward = mapping.findForward("error");						
		}
		
		return (forward);

	}


     
	//-------------return notification indicator (Y/N)
	String getIndicator(String str){		
		return str.substring(44,45);
	}

}
