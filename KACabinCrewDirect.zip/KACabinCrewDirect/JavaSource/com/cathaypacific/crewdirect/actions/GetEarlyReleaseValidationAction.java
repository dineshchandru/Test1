package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.common.Log;
import com.cathaypacific.crewdirect.services.earlyReleaseRequest;

public class GetEarlyReleaseValidationAction extends Action{
	public ActionForward execute(ActionMapping mapping,	ActionForm form,
			HttpServletRequest request,	HttpServletResponse response) throws Exception {

			ActionErrors errors = new ActionErrors();
			ActionForward forward = new ActionForward();
			
			// return val
			try {
				HttpSession session = request.getSession();			 

				String ern = (String) session.getAttribute("MyERN");
				String type = "NO";
				type = request.getParameter("type");
				if (type == null) {
					type = "";
				}
					if (type.equals("YES")) {
					 //Varify early release details
						earlyReleaseRequest earlyRelease = new earlyReleaseRequest(ern);
						if (earlyRelease.getErr_msg().equals("no_err")) {
							request.setAttribute("EarlyReleaseValidation", earlyRelease);	
							if(!earlyRelease.isValid()){
								request.setAttribute("err_msg", "Sorry,The table was already have the record in Early Request!");
				                forward = mapping.findForward("errors");								
							}else{
								if(earlyRelease.isEligible()){
								String start_Date = earlyRelease.getStart_Date();
								String end_Date = earlyRelease.getEnd_Date();
								String last_Update = earlyRelease.getLastUpdate_Date();
								String update_by = earlyRelease.getUpdate_by();
								String status = earlyRelease.getStatus();
								String pid = earlyRelease.getPID();
								int id = earlyRelease.getId();
								String sql = earlyRelease.earlyReleaseInsert(ern,start_Date,end_Date,last_Update,pid,status,id);
								request.setAttribute("msg", "You have successfully submitted the request for Early Release.");
								//request.setAttribute("msg", " ern = " + ern + "start_Date = " + start_Date + " end_Date = " + end_Date + " last_Update = " + last_Update + " update_by = " + update_by + " status = " + status + "\n " + " sql = " + sql);
    							forward = mapping.findForward("success");	
								}
								else{
									String err_msg = "Probation Crew is not eligible for submitting the request.";
									request.setAttribute("err_msg" ,err_msg); 
									forward = mapping.findForward("errors");
								}
								}				
						} else {
							String err_msg = "Early Release Validation: " + earlyRelease.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
						
					}

					
			} catch (Exception e) {			
				errors.add("name", new ActionError("id"));
				request.setAttribute("err_msg", "Your session has been timeout.");
				forward = mapping.findForward("failure");
			}
			// Finish with
			return (forward);
		}

}
