package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.roster.rstChangeBeanList;

/**
 * @version 	1.0
 * @author
 */
public class ShowNoteAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			String type=request.getParameter("ack_key");
			HttpSession session = request.getSession();			 
			String ern = ""; 
			ern = (String) session.getAttribute("MyERN");
            
			rstChangeBeanList rst;
			if (type.equals("recent" )){
				//System.out.println("ShowNoteAction recent");
				rst = new rstChangeBeanList(ern);  //show most recent ack contents				
			}else{
				//System.out.println("ShowNoteAction ! recent type: " + type);
				rst = new rstChangeBeanList(ern,type);
			}
					
			request.setAttribute("myRosterChg",rst );
			forward = mapping.findForward("success");
					

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}
}
