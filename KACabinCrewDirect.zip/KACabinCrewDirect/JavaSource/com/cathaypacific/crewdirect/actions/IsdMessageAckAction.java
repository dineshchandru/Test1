package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.services.isdMessage;

/**
 * @version 	1.0
 * @author
 */
public class IsdMessageAckAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String [] arr_msg = new String [10];  
		isdMessage isd ;
		try {
			//System.out.println("KACCD - IsdMessageAckAction");
			
			forward = mapping.findForward("no_ack_msg");  //set defaults
			
			HttpSession session = request.getSession();			 
			String ern = "";
			ern = (String) session.getAttribute("MyERN");	
			String myAction = request.getParameter("web") ;
						
			if (myAction.equals("check")){
				//System.out.println("KACCD - IsdMessageAckAction myAction = check");
				isd = new isdMessage(ern,"checkmsg");
				
				//remarked by vicki 2.5.2008
				if (isd.isHaveMessage()){
					//have message
					if (isd.getErr_code().length() == 0 ){
						
						//reset a wrong ern in session to prevent not ack the message
						session.setAttribute("ACKFLAG",ern); //block access
						//session.setAttribute("MyERN","1234567"); //block acess 
				
						request.setAttribute("isdmessage",isd);
						forward = mapping.findForward("show");						

					}else{
						request.setAttribute("err_msg",isd.getErr_code());
						forward = mapping.findForward("errors");
					}
				}else{
					//no_message
					forward = mapping.findForward("no_ack_msg");
				}				
				
			}

			
			if (myAction.equals("Acknowledge")){
				//acked the messge,reset global ern					
				ern = (String) session.getAttribute("ACKFLAG");//block acess

				isd = new isdMessage(ern,"ackmsg");
				if (isd.getErr_code().length() == 0 ){ 							
					//reset correct ern
					session.setAttribute("MyERN",ern); //block acess
					
					forward = mapping.findForward("acked");						
				}else{
					request.setAttribute("err_msg",isd.getErr_code());
					forward = mapping.findForward("errors");
				}
			}



			if (myAction.equals("showall" )){								
				isd = new isdMessage(ern ,"showall");				
				request.setAttribute("isdmessage",isd);
				forward = mapping.findForward("showall");						
			}



		} catch (Exception e) {	
			e.printStackTrace(); 		
			errors.add("name", new ActionError("id"));
		}


		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("errors");
		}

		// Finish with
		return (forward);

	}
}
