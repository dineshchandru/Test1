package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.common.Log;
import com.cathaypacific.crewdirect.services.highFlyingHoursRequestW;

public class GetHighFlyingHourWValidationAction extends Action{
	public ActionForward execute(ActionMapping mapping,	ActionForm form,
			HttpServletRequest request,	HttpServletResponse response) throws Exception {

			ActionErrors errors = new ActionErrors();
			ActionForward forward = new ActionForward();
			 forward = mapping.findForward("errors");	
			// return val
			try {
				HttpSession session = request.getSession();			 

				String ern = (String) session.getAttribute("MyERN");
				String type = "NO";
				type = request.getParameter("type");
				if (type == null) {
					type = "";
				}
				if ("YES".equals(type)) {
					 //Varify high Flying Hours withdrawn details
						highFlyingHoursRequestW highFlyingHoursW = new highFlyingHoursRequestW(ern);
						if (highFlyingHoursW.getErr_msg().equals("no_err")) {
							request.setAttribute("HighFlyingHoursWValidation", highFlyingHoursW);	
							if(!highFlyingHoursW.isValid()){
								request.setAttribute("err_msg", "Sorry,the record is not existed,unable to withdraw! Please check whether the record has been created.");
				                forward = mapping.findForward("errors");								
							}else{
								String start_Date = highFlyingHoursW.getStart_Date();
								String end_Date = highFlyingHoursW.getEnd_Date();
								String last_Update = highFlyingHoursW.getLastUpdate_Date();
								String update_by = highFlyingHoursW.getUpdate_By();
								String status = highFlyingHoursW.getStatus();
								int id = highFlyingHoursW.getId();
								String sql = highFlyingHoursW.highFlyingHoursUpdateWithdrawn(ern,start_Date,end_Date,last_Update,ern,status,id);
								request.setAttribute("msg", "You have successfully withdrawn from the request for High Flying Hours.");
								//request.setAttribute("msg", " ern = " + ern + "start_Date = " + start_Date + " end_Date = " + end_Date + " last_Update = " + last_Update + " update_by = " + update_by + " status = " + status + "\n " + " sql = " + sql);
   							forward = mapping.findForward("success");		
								}				
						} else {
							String err_msg = "Early Release Validation: " + highFlyingHoursW.getErr_msg();
							request.setAttribute("err_msg" ,err_msg); 
							forward = mapping.findForward("errors");
						}
						
					}

					
			} catch (Exception e) {			
				errors.add("name", new ActionError("id"));
				request.setAttribute("err_msg", "Your session has been timeout.");
				forward = mapping.findForward("failure");
			}
			// Finish with
			return (forward);
		}

}
