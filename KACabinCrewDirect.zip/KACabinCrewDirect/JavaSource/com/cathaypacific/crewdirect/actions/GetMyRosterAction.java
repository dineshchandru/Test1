package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.roster.rstBeanListCollection;


public class GetMyRosterAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		
		//System.out.println("GetMyRosterAction");
		try {
			
			String myType=request.getParameter("what");				 		    	 
			
			//1.0 get session values            
			HttpSession session = request.getSession();			 
            String ern = "";
            ern = (String) session.getAttribute("MyERN");            
                        
			if (ern.length() > 0 ) {
				// 2.0 access db bean     
				rstBeanListCollection  myRoster = new rstBeanListCollection ();
				myRoster.getRosterData(ern);			
	
				if (myRoster!=null){				
					request.setAttribute("MyRosters",myRoster );
					if (myType.equals("printing" )){											                
						forward = mapping.findForward("printing");						
					}else{
						forward = mapping.findForward("success");
					}						
				}
				
			}else{
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
				forward = mapping.findForward("failure");
			}
        
		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}

		return (forward);

	}
}
