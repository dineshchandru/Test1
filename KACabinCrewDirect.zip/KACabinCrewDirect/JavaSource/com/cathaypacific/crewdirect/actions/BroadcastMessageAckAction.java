package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.checkAccessRight;
import com.cathaypacific.crewdirect.databeans.checkAdminRight;
import com.cathaypacific.crewdirect.services.BroadcastMQServices;
import com.cathaypacific.crewdirect.services.LoginTimeStamp;
import com.cathaypacific.crewdirect.services.getBasicInfo;

/**
 * @version 	1.0
 * @author
 */
public class BroadcastMessageAckAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		String myStatus="";
		String ask_txt="";
		String rtn_txt="";
		String rtn_status="";
		String ern = "";
		String AdmERN = "";
		String AdmID = "";
		String AdmPID = "";		
		String clientIP ="";
		String clientHost="";
		LoginTimeStamp myLogin;
		LoginTimeStamp AdmLogin;
		boolean HaveErrorMQ ;
		boolean LoginUpdated;
		String myErr = "Sorry, the system is busy at this moment (E001), the crew broadcast message has not been acknowledged. Please login again. If the problem still exists, please call Crew Control at your earliest convenience.";
		String myErr1 = "The sytem is busy at this moment, CCS broadcast message cannot be delivered. Please call Crew Control to get the updated information.";

		try {
			HttpSession session = request.getSession();
			
			//1.0 get ern			
			ern = (String) session.getAttribute("MyERN");
			
			if (ern.equals("UAT")){  //uat
				//System.out.println("ERN = UAT");
				AdmERN = (String) session.getAttribute("AdmERN");
				AdmID  = (String) session.getAttribute("AdmID");
				AdmPID  =(String) session.getAttribute("AdmPID");
				//5.0 set logintime
				clientIP = (String ) request.getRemoteAddr();
				clientHost = (String ) request.getRemoteHost();
				AdmLogin = new LoginTimeStamp(AdmERN);		
				checkAdminRight AdmAccess = new checkAdminRight(AdmPID);
				if (AdmAccess.isValid())
				{
					String type=request.getParameter("staff");				
					ern = type.toUpperCase();		
					//System.out.println("check 1");			
					if (ern.substring(7).equals("X")){	
						//System.out.println("check X");
					   ern = ern.substring(0,7);
					   session.setAttribute("MyERN",ern); //block acess					   
					}else{								
					   ern = "12345678";
					}
				}else
				{
					myStatus = "no_access";
				}
	            if (!AdmAccess.isValid()){				
					LoginUpdated =AdmLogin.setTimeStamp(clientIP,clientHost,"F-"+ern );					
	            }else{	
				    LoginUpdated =AdmLogin.setTimeStamp(clientIP,clientHost,"S-"+ern );
	            };    
//System.out.println("ERN:" + ern+"/ip:"+clientIP+"/Host:"+clientHost);	            
			}			
			
			//1.0 get Last login time
            myLogin = new LoginTimeStamp(ern);
            
			
            //1.1 Check User Acess Right
            checkAccessRight myAccess = new checkAccessRight(ern);
            
            if (!myAccess.isValid()){
            //if (false){
				request.setAttribute("err_msg",myAccess.getErr_msg());
				myStatus = "no_access";           	           
				
            }else{	
            	
            	getBasicInfo info = new getBasicInfo(ern);
            	
	            //2.0 set banner infomation 
				if (info!=null) {
					//HttpSession session = request.getSession();
					session.setAttribute("MyInfo",info.getMyInfo());
				}
				
	            //3.0 ask Facts of CrewBCMsg by MQ
				//3.1 get MQ
				BroadcastMQServices CrewBCMsgMQ = new BroadcastMQServices("getBCMsg");
				ask_txt = "KAD13" + ern;
				CrewBCMsgMQ.setMq_ask_txt(ask_txt);
				System.out.println("ask_txt : " + ask_txt);
				
				//max try 3 time if mq error occured
				HaveErrorMQ = true;
				
				if (CrewBCMsgMQ.call_mq(0)==true){
					rtn_txt = CrewBCMsgMQ.getMq_rtn_txt();
					System.out.println("rtn_txt : " + rtn_txt);
					
					if (rtn_txt.substring(5,7).equals("  " )){
						if (rtn_txt.substring(57,64).trim().equals(ern )){	 //same ern
							HaveErrorMQ = false;				
						}
					} else {
						if (rtn_txt.substring(5,7).equals("IC")) {
							myErr1 = "Your Staff ID could not be found. Please call Crew Control to confirm your duties.";
						}
					}
				}		
				
				//HaveErrorMQ = false;
				//rtn_txt = "KAD14                                                    701065EY";				
				
				System.out.println("rtn_txt : " + rtn_txt);
				//4.0 handle mq return								
				if (HaveErrorMQ){
					request.setAttribute("err_msg",myErr1);
					myStatus = "failure";						
				}else{					
					rtn_status = getNoteIndicator(rtn_txt);
					//4.1 nothing happened				
					if (rtn_status.equals("N")){
						myStatus = "no_bc_msg";
						
					}
					//4.2 have crew broadcast message
					if (rtn_status.equals("Y")){										
						//reset a wrong ern in session to prevent not ack the message
					  	session.setAttribute("ACKFLAG",ern); //block access
					  	session.setAttribute("MyERN","1234567"); //block acess 
												
						myStatus = "have_bc_msg";
					}					
				}
	            
				//5.0 set logintime
				clientIP = (String ) request.getRemoteAddr();
				clientHost = (String ) request.getRemoteHost();
				myLogin.setTimeStamp(clientIP,clientHost,rtn_status);
				
			}//1.1 check access
			
			
		} catch (Exception e) {
			request.setAttribute("err_msg",myErr);
			errors.add("name", new ActionError("id"));
			System.out.println("Exception : " + e.getMessage());
		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg",myErr);
			forward = mapping.findForward("failure");
		}else{
		  System.out.println("myStatus : " + myStatus);
  		  forward = mapping.findForward(myStatus);
		}
		return (forward);

	}
	
	
	//return crew broadcast message indicator (Y/N)
	String getNoteIndicator(String str){		
		return str.substring(64,65);
	}
}
