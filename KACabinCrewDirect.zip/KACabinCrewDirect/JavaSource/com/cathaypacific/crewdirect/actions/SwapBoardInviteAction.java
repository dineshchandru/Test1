package com.cathaypacific.crewdirect.actions;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.swap.eswapLogicCheck;
import com.cathaypacific.crewdirect.swap.swapRequestInfoBean;
import com.cathaypacific.crewdirect.swap.swapSimulateRoster;
import com.cathaypacific.crewdirect.swapboard.swapBoardRequest;

/**
 * @version 	1.0
 * @author
 */
public class SwapBoardInviteAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
	  String partners[] = new String[10];				
	  String Acp_ERN[] = new String [10];
	  eswapLogicCheck chkEswap = null;
	  int inv_cnt =0;
	  int p_cnt = 1;
	  String msg_id=null;
	  String err_msg=null;
	  String other_erns[]= new String [10];
	  String other_crewid[]= new String [10];		
	  String ern ="";
	  String s_date="";
	  String e_date="";
	  String erns ="";
	  String crewid="";
	  String day_offset="10";

	  try {
	
		for (int t=0;t<10;t++){
			other_erns[t]="";
			other_crewid[t]="";
		}
		
		HttpSession session = request.getSession();			 
		ern = (String) session.getAttribute("MyERN");
		msg_id = request.getParameter("req_msg_id");
		
		
		if (ern.length()!=7) {			
			errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
		}else{

			//1.0 find partners
			swapBoardRequest req = new swapBoardRequest(msg_id);
			if (req.getErr_msg().equals("no_err" )){
								
				if (req.getPost_ern().equals(ern) ){	
					request.setAttribute("err_msg","You cannot make swap request to yourself.");		
					forward = mapping.findForward("failure");	
				}else{
					
					day_offset = "5";
					s_date = req.getPeriod_start() ;
					e_date = req.getPeriod_end();

					other_erns[0]=req.getOther_erns();  
					other_crewid[0]= req.getOther_crewid();		

					swapSimulateRoster mySimulator = new swapSimulateRoster(ern,s_date,e_date,day_offset,other_erns);
					//set request info
					swapRequestInfoBean requstInfo = new swapRequestInfoBean(s_date,e_date,mySimulator.getErn_cnts(),other_erns,other_crewid);
			   		 
					if (mySimulator!=null){				
						request.setAttribute("SimRoster",mySimulator);
						request.setAttribute("ReqInfo",requstInfo);
						forward = mapping.findForward("success");						
					}
				}
			}
		}
		
		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);

	}
}
