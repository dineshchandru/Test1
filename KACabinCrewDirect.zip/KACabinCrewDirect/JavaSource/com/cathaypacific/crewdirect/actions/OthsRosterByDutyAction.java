package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.roster.othsRosterListCollection;

/**
 * @version 	1.0
 * @author
 */
public class OthsRosterByDutyAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		
		try {

			HttpSession session = request.getSession();
			String ern = (String) session.getAttribute("MyERN");
			String start_date = request.getParameter("start_date").toUpperCase().trim() ;
			String day_num = request.getParameter("day_nums");			
			String imonth = request.getParameter("imonth").trim();			             
			othsRosterListCollection othsRoster = new othsRosterListCollection(ern,start_date,day_num,imonth);
			if (othsRoster!=null){				
				request.setAttribute("OthsRosters",othsRoster );				
				forward = mapping.findForward("success");
			}

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("name", new ActionError("id"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("failure");
		}

		return (forward);

	}
}
