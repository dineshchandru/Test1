/***************************************************
 * Name : GetFlightPatternAction.java
 * Date : 2 April 2008 
 * Desc : Redirect page and action
 ***************************************************/
package com.cathaypacific.crewdirect.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.owasp.esapi.filters.SafeRequest;

import com.cathaypacific.crewdirect.services.FlightPatternOption;
import com.cathaypacific.crewdirect.services.FlightPatternOptionService;
import com.cathaypacific.crewdirect.services.flightPatternRequest;

/**
 * @version 1.0
 * @author
 */
public class GetFlightPatternOptionAction extends Action {

	private List insertList;
	private List withdrawList;

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			System.out.println("GetFlightPatternOptionAction debug : KA security started");
			SafeRequest newRequest = new SafeRequest(request);
			System.out.println("GetFlightPatternOptionAction debug : new request initialized");
			
			Map unfilteredParameterMap = request.getParameterMap(); 
			System.out.println("GetFlightPatternOptionAction debug : parametermap got");
			
			Map filteredParameterMap = newRequest.getParameterMap();
			System.out.println("GetFlightPatternOptionAction debug : filtered parametermap got");
			
			System.out.println("GetFlightPatternOptionAction debug : filteredParameterMap.size is "+filteredParameterMap.size() + "un filteredParameterMap.size is "+unfilteredParameterMap.size());
			System.out.println("GetFlightPatternOptionAction debug : KA security determining"); 			
			if(filteredParameterMap.size()<unfilteredParameterMap.size()){
				
				System.out.println("GetFlightPatternOptionAction : KA security failed (set forward to error, error msg xssError ) ");
				forward = mapping.findForward("failure");
				String err_msg = null;
				err_msg = "XSSError";
				request.setAttribute("err_msg", err_msg);
//				errors.add("Error",	new org.apache.struts.action.ActionError(err_msg));
				System.out.println("GetFlightPatternOptionAction: Invalid paramter map is as follow (XSS) :");
				
				Set keySet = unfilteredParameterMap.keySet();
			     Iterator it = keySet.iterator();
			     while(it.hasNext()) {
			        Object key = it.next();
			        String[] value=(String[])(unfilteredParameterMap.get(key));
			        System.out.println("GetFlightPatternOptionAction XSS Parameter : The input Key is-->"+key+" and "+"The Input value is-->"+value[0]);
			       // System.out.printf("XSS Paramter %-12s is %-20s \n" ,key,value[0]);
			     }
				return forward;		
			}
			
			System.out.println("GetFlightPatternOptionAction debug : KA security passed");
			
			HttpSession session = request.getSession();
			String ern = (String) session.getAttribute("MyERN");
			String app_type = "GET_DATA";
			String insert_end = "";
			String flightPatternDAC = "";
			String flightPatternKTM = "";
			String flightPatternONT = "";
			String flightPatternBLR = "";
			String flightPatternPeriod = "";
			String DACSeq = "-1";
			String KTMSeq = "-1";
			String ONTSeq = "-1";
			String BLRSeq = "-1";
			String endMonth = "";
			String endDate = "";
			String patternRequest = "";

			if (request.getParameter("app_type") != null)
				app_type = request.getParameter("app_type");

			if (request.getParameter("FlightPatternDAC") != null)
				flightPatternDAC = request.getParameter("FlightPatternDAC");

			if (request.getParameter("FlightPatternKTM") != null)
				flightPatternKTM = request.getParameter("FlightPatternKTM");

			if (request.getParameter("FlightPatternONT") != null)
				flightPatternONT = request.getParameter("FlightPatternONT");

			if (request.getParameter("FlightPatternBLR") != null)
				flightPatternBLR = request.getParameter("FlightPatternBLR");

			if (request.getParameter("FlightPatternPeriod") != null)
				flightPatternPeriod = request
						.getParameter("FlightPatternPeriod");

			if (request.getParameter("DAC_seq") != null)
				DACSeq = request.getParameter("DAC_seq");

			if (request.getParameter("KTM_seq") != null)
				KTMSeq = request.getParameter("KTM_seq");

			if (request.getParameter("ONT_seq") != null)
				ONTSeq = request.getParameter("ONT_seq");

			if (request.getParameter("BLR_seq") != null)
				BLRSeq = request.getParameter("BLR_seq");

			if (request.getParameter("cbEndMonth") != null)
				endMonth = request.getParameter("cbEndMonth");

			if (flightPatternPeriod.equals("ALL")) {
				insert_end = "31-Dec-9999";
			} else if (flightPatternPeriod.equals("ByMonth")) {
				insert_end = endMonth;
			}

			if (request.getParameter("PatternRequest") != null)
				patternRequest = request.getParameter("PatternRequest");

			if (ern.length() < 4) {
				errors.add("ern", new org.apache.struts.action.ActionError(
						"error.ern.required"));

			} else {

				// Call flightPatterRequest.java -> Retrieve DAC/KTM Request
				// from DB
				if (app_type.equals("GET_DATA")) {

					forward = getData(mapping, request, ern);

					// Call flightPatternRequest.java -> Insert flightPattern to
					// DB
				} else if (app_type.equals("INSERT_DATA")) {

					prepareDataForInsert(request);
					
					FlightPatternOptionService flightPatternRecord = new FlightPatternOptionService(ern,this.insertList,"I");

					// Inserted successful -> return the successful message on
					// the screen
					if (flightPatternRecord.getErr_msg().equals("no_err")) {
						request.setAttribute("optMsg",
								flightPatternRecord.getOptMsg());
						getData(mapping, request, ern);
						forward = mapping.findForward("success");
					} else {
						String err_msg = "Error occurs when creating flight pattern request: "
								+ flightPatternRecord.getErr_msg();
						request.setAttribute("err_msg", err_msg);
						forward = mapping.findForward("errors");
					}
				} else if (app_type.equals("WITHDRAW_DATA")) {
					prepareDataForWithdraw(request);
					
					FlightPatternOptionService flightPatternRecord = new FlightPatternOptionService(ern,this.withdrawList,"W");

					// Inserted successful -> return the successful message on
					// the screen
					if (flightPatternRecord.getErr_msg().equals("no_err")) {
						request.setAttribute("optMsg",
								flightPatternRecord.getOptMsg());
						getData(mapping, request, ern);
						forward = mapping.findForward("success");
					} else {
						String err_msg = "Flight Pattern Record Request: "
								+ flightPatternRecord.getErr_msg();
						request.setAttribute("err_msg", err_msg);
						forward = mapping.findForward("errors");
					}
				}
			}

		} catch (Exception e) {
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg", errors);
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}

	private ActionForward getData(ActionMapping mapping,
			HttpServletRequest request, String ern) {
		ActionForward forward;
		// Get Flight Pattern details
		FlightPatternOptionService flightPatternRequest = new FlightPatternOptionService(
				ern);
		if (flightPatternRequest.getErr_msg().equals("no_err")) {
			request.setAttribute("flightPatternOptions1",
					flightPatternRequest.getFlightPatternOptions1());
			request.setAttribute("flightPatternOptions2",
					flightPatternRequest.getFlightPatternOptions2());
			request.setAttribute("existingFlightRequestList",
					flightPatternRequest
							.getExistingFlightRequestList());
			request.setAttribute("requestLimit",
					String.valueOf(flightPatternRequest.getRequestLimit()));
			forward = mapping.findForward("success");
		} else {
			String err_msg = "Flight Pattern Request: "
					+ flightPatternRequest.getErr_msg();
			request.setAttribute("err_msg", err_msg);
			forward = mapping.findForward("errors");
		}
		return forward;
	}

	private void prepareDataForInsert(HttpServletRequest request) {
		List l = new ArrayList();
		String[] c = request.getParameterValues("fltPatternCode");
		if(c!=null&&c.length>0){
			for(int i=0;i<c.length;i++){
				String s=request.getParameter("flightPatternPeriodFlag_"+c[i]);
				String stype=request.getParameter("flt_pat_type_"+c[i]);
				String selectedMonth="";
				if("all".equalsIgnoreCase(s)){
					selectedMonth="31-Dec-9999";
				}else{
					selectedMonth=request.getParameter("cbEndMonth_"+c[i]);
				}
				if(selectedMonth!=null&&!"".equals(selectedMonth)&&!"--".equals(selectedMonth)){
				FlightPatternOption o=new FlightPatternOption();
				o.setFlightPatternCode(c[i]);
				o.setSelectedMonth(selectedMonth);
				o.setType(stype);
				l.add(o);
				}
			}
		}
		this.insertList=l;

	}
	private void prepareDataForWithdraw(HttpServletRequest request) {
		List l = new ArrayList();
		String[] c = request.getParameterValues("fltPatternCode_withdraw");
		if(c!=null&&c.length>0){
			for(int i=0;i<c.length;i++){
			
				FlightPatternOption o=new FlightPatternOption();
				o.setFlightPatternCode(c[i]);
				
				l.add(o);
			}
		}
		this.withdrawList=l;

	}
}
