
/*************************************************************
 * Name : GetPreferentialCheckAction.java
 * Date : 08 Mar 2006 
 * Desc : Preferential Rostering - High Density Hour Scheme 
 *************************************************************/
package com.cathaypacific.crewdirect.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.preferentialList;
import com.cathaypacific.crewdirect.roster.preferInitCheck;
import com.cathaypacific.crewdirect.roster.preferRecord;
import com.cathaypacific.crewdirect.roster.preferRequest;

/**
 * @version 	1.0
 * @author
 */
public class GetPreferentialCheckAction extends Action {

	public ActionForward execute(ActionMapping mapping,	ActionForm form,
		HttpServletRequest request,	HttpServletResponse response) throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value

		try {
			HttpSession session = request.getSession();			 
			String ern = (String) session.getAttribute("MyERN");
			if (ern.length() != 7) {			
				errors.add("ern", new org.apache.struts.action.ActionError("error.ern.required"));
			} else {
				String web_action = request.getParameter("app_type");
				String err_msg = new String("");
				String tmpstr = new String("");
				String cat = new String("");
				String cos = new String("");
				//Initial Checking : must be HKG-Based, no MU/CA crew, BC, QBCNN
				preferInitCheck init_check = new preferInitCheck();

				//********* 1.0 Initial Checking (init_checking) ****************
				//Preliminary crew info checking - no MU/CA crew, exclude non-HKG based crew, and must be QBCNN
				if (web_action.equals("init_checking")) {
					err_msg = init_check.BasicInfoCheckbyERN(ern);
                              
					//Eligible crew -> show the roster month for selection, starting the application
					if (err_msg.equals("no_err")) {
						String link_terms = init_check.getFilePath("PREFERENTIAL_TERMS");
						session.setAttribute("link_terms", link_terms);
						cat = init_check.getCat(ern);
						cos = init_check.getCos(ern);
						session.setAttribute("crew_cat", cat);
						session.setAttribute("crew_cos", cos);
						forward = mapping.findForward("request_month");
					//Non-eligible crew -> show filter-out reasons
					} else {
						err_msg = "Preferential Rostering<br><br>You are not eligible for this scheme because : "+err_msg;
						request.setAttribute("err_msg", err_msg); 
						forward = mapping.findForward("errors");
					}

				//********* 2.0 Checking the selected month details (request_checking) ****************
				//Get the requester or invitation information of the specified roster month
				} else if (web_action.equals("request_checking")) {

					String req_status = new String("");
					int req_process_count = 0 ;
					int invited_count = 0 ;
					int invited_accept_count = 0 ;
             		int inactive_count = 0 ;

					String roster_month = request.getParameter("roster_month");

					preferRequest prefer_request = new preferRequest();
						
					// ********* Requester : Processing or Accepted ******************
					req_process_count = prefer_request.getRequesterApplication(ern, roster_month);
					req_status = prefer_request.getRequester_status();

					// ********* Receiver : status - Accepted  ******************
					invited_accept_count = prefer_request.getInvitedApplication(ern, roster_month, "'Accepted'");
					//No accepted application, then searching for the outstanding application
					if (invited_accept_count == 0) {
						//********* Receiver : status - Processing  ******************
						invited_count = prefer_request.getInvitedApplication(ern, roster_month, "'Processing'");
					}

					// ********* Receiver and Requester : status - Rejected or Withdraw  ******************
					//Application history shown on the input page (all the INACTIVE records)
					inactive_count = prefer_request.getInvitedApplication(ern, roster_month, "'Withdraw', 'Rejected'");

					//If the crew accepted the invitation, show view-only page
					//If invitation is processing, show the invitation page for the crew to choose one of the application	
					if (invited_accept_count > 0 || invited_count > 0) {
						//Status : Processing
						if (invited_count > 0) {						
							session.setAttribute("invited_list", prefer_request.getInvited_list());						
							forward = mapping.findForward("request_invitation");
						//Status : Accepted
						} else {
							request.setAttribute("view_role", "invited");
							request.setAttribute("view_list", prefer_request.getInvited_list());
							forward = mapping.findForward("request_view"); //View-only page - preferentialView.jsp
						}

					//Retrieve the requester application details
					} else {
						//Status : Accepted - not allow the requester to update the details, show view-only page					
						if (req_status.equals("Accepted")) {						
							request.setAttribute("view_role", "requester");
							request.setAttribute("view_list", prefer_request.getRequester_list());
							request.setAttribute("inactive_list", prefer_request.getInactive_list());
							forward = mapping.findForward("request_view"); //View-only page	- preferentialView.jsp										

						//Status : Processing  - allow the crew to update anytime except one of the buddy already accepted the invitation
						//       : New Request - show blank form 
						} else {
							request.setAttribute("prefer_daysoff", prefer_request.getVPreferDayoffList());
							request.setAttribute("prefer_flyhour", prefer_request.getVPreferFLyHourList());
							request.setAttribute("requester_list", prefer_request.getRequester_list());
							request.setAttribute("inactive_list", prefer_request.getInactive_list());
							forward = mapping.findForward("request_apply"); //Blank form - preferentialRequest.jsp
						}
					}

				//********* 3.0 Validate the details of the input fields (request_validation) ****************
				} else if (web_action.equals("request_validation")) {

					String roster_month = request.getParameter("roster_month");
					String req_id = request.getParameter("req_id");
					String days_off = request.getParameter("days_off");
					String fly_hour = request.getParameter("fly_hour");
					String dayoff_afterflt = request.getParameter("dayoff_afterflt");
					String ack_integrated = request.getParameter("ack_integrated");
					String ack_terms = request.getParameter("ack_terms");

					String buddy_flying = request.getParameter("buddy_flying");
					String buddy1_ern = new String("");
					String buddy1_crewid = request.getParameter("buddy1_crewid").trim();
					String buddy2_ern = new String("");	
					String buddy2_crewid = request.getParameter("buddy2_crewid").trim();
					boolean buddy_check = true;

					//Check the validity of the buddy Crew ID 
					if (buddy_flying.equals("Y")) {

						//Initial Checking : must be HKG-Based, no MU/CA crew, BC, QBCNN
						preferInitCheck initCheck = new preferInitCheck();

						if (!buddy1_crewid.equals("")) {
							//Get the ERN of the buddy (parameter : CREW ID)
							buddy1_ern = initCheck.getERN(buddy1_crewid);

							//Invalid ERN, go to error page
							if (buddy1_ern.equals("invalid_crewid")) {
								buddy_check = false ;
								err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Cannot find the Crew ID of your nominated buddy : "+buddy1_crewid;
								err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
								request.setAttribute("err_msg", err_msg); 								
								forward = mapping.findForward("errors");

							} else {
								//return error if the crew input his/her Crew ID in the buddy field
								if (buddy1_ern.equals(ern)) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>You cannot nominate yourself as buddy : "+buddy1_crewid;
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								} else {
									//Valid ERN, get the basic info the buddy for further checking
									//Non-eligible buddy -> show unsuccessful reasons
									err_msg = init_check.BasicInfoCheckbyERN(buddy1_ern);
									if (!err_msg.equals("no_err")) {
										buddy_check = false ;
										err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") is not eligible for this scheme because : "+err_msg;
										err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
										request.setAttribute("err_msg", err_msg); 								
										forward = mapping.findForward("errors");
									} else {	
									   err_msg = init_check.CrewCatCheck(ern,buddy1_ern);
										if (!err_msg.equals("no_err")) {
											buddy_check = false ;
											err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") is not eligible for this scheme because : "+err_msg;
											err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
											request.setAttribute("err_msg", err_msg); 								
											forward = mapping.findForward("errors");
										}	
								    }
									
								}
							}

							if (buddy_check == true) {
								//As requester : check whether the nominated buddy have submitted the application
								int requester_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								requester_count = prefer_request.getRequesterApplication(buddy1_ern, roster_month);
								if (requester_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") already submitted the application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";									
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}
							}
							
							if (buddy_check == true) {							
								//As accepter : check whether the nominated buddy have accepted other invitation
								int invited_accept_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								invited_accept_count = prefer_request.getInvitedApplication(buddy1_ern, roster_month, "'Accepted'");
								if (invited_accept_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") already accepted another application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}	
							}
						}
						
						if (buddy_check == true && (!buddy2_crewid.equals(""))) {
							//Get the ERN of the buddy (parameter : CREW ID)
							buddy2_ern = initCheck.getERN(buddy2_crewid);
							
							//Invalid ERN, go to error page
							if (buddy2_ern.equals("invalid_crewid")) {
								buddy_check = false;
								err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Cannot find the Crew ID of your nominated buddy : "+buddy2_crewid;
								err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
								request.setAttribute("err_msg", err_msg); 								
								forward = mapping.findForward("errors");

							} else {
								//return error if the crew input his/her Crew ID in the buddy field
								if (buddy2_ern.equals(ern)) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>You cannot nominate yourself as buddy : "+buddy2_crewid;
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								} else {
									//Valid ERN, get the basic info the buddy for further checking
									//Non-eligible buddy -> show unsuccessful reasons
									err_msg = init_check.BasicInfoCheckbyERN(buddy2_ern);
									if (!err_msg.equals("no_err")) {
										buddy_check = false;
										err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") is not eligible for this scheme because : "+err_msg;
										err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
										request.setAttribute("err_msg", err_msg); 								
										forward = mapping.findForward("errors");	
									} else {	
										   err_msg = init_check.CrewCatCheck(ern,buddy2_ern);
											if (!err_msg.equals("no_err")) {
												buddy_check = false ;
												err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") is not eligible for this scheme because : "+err_msg;
												err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
												request.setAttribute("err_msg", err_msg); 								
												forward = mapping.findForward("errors");
											}											
									}
								}
							}

							if (buddy_check == true) {
								//As requester : check whether the nominated buddy have submitted the application
								int requester_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								requester_count = prefer_request.getRequesterApplication(buddy2_ern, roster_month);
								if (requester_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") already submitted the application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}
							}

							if (buddy_check == true) {
								//As accepter : check whether the nominated buddy have accepted other invitation
								int invited_accept_count = 0 ;
								preferRequest prefer_request = new preferRequest();									
								invited_accept_count = prefer_request.getInvitedApplication(buddy2_ern, roster_month, "'Accepted'");
								if (invited_accept_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") already accepted another application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}	
							}
						}						
					}

					//Valid buddy crew id checking and no error found, go to the confirmation page
					if (buddy_check == true) {
						forward = mapping.findForward("request_confirm"); //Confirmation - preferentialConfirmation.jsp
					}

				//********* 4.0 Insert new request or Update existing records (request_insert, request_update) ****************
				//Insert or Update the preferential rostering application
				} else if (web_action.equals("request_insert") || web_action.equals("request_update")) {

					String roster_month = request.getParameter("roster_month");
					String days_off = request.getParameter("days_off");
					String fly_hour = request.getParameter("fly_hour");
					String dayoff_afterflt = request.getParameter("dayoff_afterflt");
					String ack_integrated = request.getParameter("ack_integrated");
					String ack_terms = request.getParameter("ack_terms");
					boolean buddy_check = true;
										
					//New Request : no req id, generate a new one for reference number
					//Update existing request : with req id
					String req_id = request.getParameter("req_id");
					if (req_id == null) {
						req_id = "";
					}

					if (web_action.equals("request_insert")) {
						//As requester : check whether the nominated buddy have submitted the application
						int requester_count = 0 ;
						preferRequest prefer_request = new preferRequest();	
						requester_count = prefer_request.getRequesterApplication(ern, roster_month);
						if (requester_count > 0) {
							buddy_check = false ;
							err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>You have already submitted the application for this month.";
							err_msg = err_msg + "<br><br>Please click 'Preferential Rostering' again and select the roster month for the details of the submitted application.";									
							request.setAttribute("err_msg", err_msg); 								
							forward = mapping.findForward("errors");	
						}
					}	
					
					String buddy_flying = request.getParameter("buddy_flying");
					String buddy1_ern = new String("");
					String buddy1_crewid = request.getParameter("buddy1_crewid").trim();
					String buddy1_status = request.getParameter("buddy1_status");
					String buddy2_ern = new String("");	
					String buddy2_crewid = request.getParameter("buddy2_crewid").trim();
					String buddy2_status = request.getParameter("buddy2_status");

					//Check the validity of the buddy Crew ID 
					if (buddy_flying.equals("Y")) {

						//Buddy 1
						preferInitCheck initCheck = new preferInitCheck();
						if (!buddy1_crewid.equals("")) {						
							buddy1_ern = initCheck.getERN(buddy1_crewid); //Get the ERN of the buddy (parameter : CREW ID)
							
							if (buddy_check == true && web_action.equals("request_insert")) {
								//As requester : check whether the nominated buddy have submitted the application
								int requester_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								requester_count = prefer_request.getRequesterApplication(buddy1_ern, roster_month);
								if (requester_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") already submitted the application for this month.";
									err_msg = err_msg + "<br><br>Please click 'Preferential Rostering' again and select the roster month for the details of the submitted application.";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}
							}				
							
							if (buddy_check == true && web_action.equals("request_insert")) {							
								//As accepter : check whether the nominated buddy have accepted other invitation
								int invited_accept_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								invited_accept_count = prefer_request.getInvitedApplication(buddy1_ern, roster_month, "'Accepted'");
								if (invited_accept_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy1_crewid+") already accepted another application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}	
							}
						}
						
						//Buddy 2
						if (!buddy2_crewid.equals("")) {
							buddy2_ern = initCheck.getERN(buddy2_crewid); //Get the ERN of the buddy (parameter : CREW ID)
							
							if (buddy_check == true && web_action.equals("request_insert")) {
								//As requester : check whether the nominated buddy have submitted the application
								int requester_count = 0 ;
								preferRequest prefer_request = new preferRequest();	
								requester_count = prefer_request.getRequesterApplication(buddy2_ern, roster_month);
								if (requester_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") already submitted the application for this month.";
									err_msg = err_msg + "<br><br>Please click 'Preferential Rostering' again and select the roster month for the details of the submitted application.";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}
							}

							if (buddy_check == true && web_action.equals("request_insert")) {
								//As accepter : check whether the nominated buddy have accepted other invitation
								int invited_accept_count = 0 ;
								preferRequest prefer_request = new preferRequest();									
								invited_accept_count = prefer_request.getInvitedApplication(buddy2_ern, roster_month, "'Accepted'");
								if (invited_accept_count > 0) {
									buddy_check = false ;
									err_msg = "Preferential Rostering - Your application cannot be proceeded due to : <br><br>Your nominated buddy ("+buddy2_crewid+") already accepted another application for this month.";
									err_msg = err_msg + "<br><br><input type='button' name='back' value='<- Back' style='font-family: verdana; font-weight: Bold;' onClick='javascript:history.go(-1);'>";
									request.setAttribute("err_msg", err_msg); 								
									forward = mapping.findForward("errors");	
								}	
							}
						}		
					}		

					//Requester, Buddy1, Buddy2 - no error and pass all the validation
					if (buddy_check == true) {
						preferRecord request_record = new preferRecord();
						//update existing records
						if (web_action.equals("request_update")) {
							err_msg = request_record.updateRecord(req_id, ern, roster_month, days_off, fly_hour, dayoff_afterflt, buddy_flying, buddy1_ern, buddy1_crewid, buddy1_status, buddy2_ern, buddy2_crewid, buddy2_status, ack_integrated, ack_terms);
						//insert a new request						
						} else {
							err_msg = request_record.insertRecord(req_id, ern, roster_month, days_off, fly_hour, dayoff_afterflt, buddy_flying, buddy1_ern, buddy1_crewid, buddy1_status, buddy2_ern, buddy2_crewid, buddy2_status, ack_integrated, ack_terms);
						}
					
						//No error found when updating/inserting, go to final view-only page
						if (err_msg.equals("no_err")) {
							//get the updated records from the DB for final display
							int req_process_count = 0 ;
							preferRequest prefer_request = new preferRequest();
							req_process_count = prefer_request.getRequesterApplication(ern, roster_month);
							if (req_process_count > 0) {
								request.setAttribute("view_role", "updated");
								request.setAttribute("view_list", prefer_request.getRequester_list());
								request.setAttribute("success_percent", request_record.getSuccess_percent());							
							}
							forward = mapping.findForward("request_view");	//View-only page - preferentialView.jsp
						//SQL error found
						} else {
							err_msg = "Preferential Rostering<br><br>Please copy this error message and email to ISD#DIAL for further investigation.<br>"+err_msg;
							request.setAttribute("err_msg", err_msg); 
							forward = mapping.findForward("errors");
						}			
					}
				
				//********* 5.0 Withdraw the preferential rostering application
				} else if (web_action.equals("request_withdraw")) {
					preferRecord request_record = new preferRecord();					
					String req_id = request.getParameter("req_id");
					String roster_month = request.getParameter("roster_month");

					err_msg = request_record.updateWithdraw(req_id, ern);
					//No error found when updating/inserting, go back to the month selection menu page
					if (err_msg.equals("no_err")) {
						err_msg = "You have withdrawn the application ("+roster_month+").<br>If you want to apply for this scheme, please select the roster month and fill in the form again.";
						request.setAttribute("update_msg", err_msg);
						forward = mapping.findForward("request_month");	//preferentialMenu.jsp
					//SQL error found
					} else {
						err_msg = "Preferential Rostering<br><br>Please copy this error message and email to ISD#DIAL for further investigation.<br>"+err_msg;
						request.setAttribute("err_msg", err_msg); 
						forward = mapping.findForward("errors");
					}
					
						
				//********* 6.0 Recevier : Insert or Update the preferential rostering invitation
				} else if (web_action.equals("invited_reject") || web_action.equals("invited_accept")) {
					preferRecord request_record = new preferRecord();
					preferentialList invited_list = (preferentialList) session.getAttribute("invited_list");
					String roster_month = request.getParameter("roster_month");
					
					//Reject all the invitation
					if (web_action.equals("invited_reject")) {
						err_msg = request_record.updateRejected(invited_list, ern);
						//No error found when updating/inserting, go back to the month selection menu page
						if (err_msg.equals("no_err")) {
							err_msg = "You have rejected all the invitation ("+roster_month+").<br>If you want to apply for this scheme, please select the roster month and fill in the form again.";
							request.setAttribute("update_msg", err_msg);
							forward = mapping.findForward("request_month"); //preferentialMenu.jsp
						//SQL error found
						} else {
							err_msg = "Preferential Rostering<br><br>Please copy this error message and email to ISD#DIAL for further investigation.<br>"+err_msg;
							request.setAttribute("err_msg", err_msg); 
							forward = mapping.findForward("errors");
						}

					//Accept one of the invitation, update rejected status of the others
					} else {
						String req_id = request.getParameter("req_id");
						err_msg = request_record.updateAccepted(invited_list, req_id, ern, roster_month);

						//No error found when updating/inserting, go back to the month selection menu page
						if (err_msg.equals("no_err")) {
							int invited_accept_count = 0 ;
							preferRequest prefer_request = new preferRequest();
							invited_accept_count = prefer_request.getInvitedApplication(ern, roster_month, "'Accepted'");
							if (invited_accept_count > 0) {
								request.setAttribute("view_role", "requester");
								request.setAttribute("view_list", prefer_request.getInvited_list());
							}					
							forward = mapping.findForward("request_view");	//View-only page - preferentialView.jsp
						//SQL error found
						} else {
							err_msg = "Preferential Rostering<br><br>Please copy this error message and email to ISD#DIAL for further investigation.<br>"+err_msg;
							request.setAttribute("err_msg", err_msg); 
							forward = mapping.findForward("errors");
						}
					}

				}
			}				
			
		} catch (Exception e) {			
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("failure");
		}

		if (!errors.isEmpty()) {
			saveErrors(request, errors);
			request.setAttribute("err_msg", errors);		
			forward = mapping.findForward("failure");
		}

		// Finish with
		return (forward);
	}
}
