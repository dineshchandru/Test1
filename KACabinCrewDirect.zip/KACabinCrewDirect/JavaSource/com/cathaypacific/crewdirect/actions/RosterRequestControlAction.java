package com.cathaypacific.crewdirect.actions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.dutysummary.dutySummary;
import com.cathaypacific.crewdirect.utils.DBUtils;

public class RosterRequestControlAction extends Action {

	public final static String HIGH_FLYING_HOUR = "highFlyingHour";
	public final static String EARLY_RELEASE = "earlyRelease";
	public final static String FLIGHT_PATTERN_REQUEST = "flightParrernRequest";
	public final static String ACTION_KEY = "action";
	public final static String HIGH_FLYING_HOUR_SUBMITTED_ROSTER_KEY = "hfhrSubmittedRoster";
	public final static String EARLY_RELEASE_SUBMITTED_ROSTER_KEY = "earrSubmittedRoster";
	public final static String FLIGHT_PATTERN_SUBMITTED_ROSTER_KEY = "flightParrernRoster";
	public final static String HIGH_FLYING_HOUR_IS_SUBMITED_KEY = "hfhrRosterSubmitted";
	public final static String EARLY_RELEASE_IS_SUBMITTED_KEY = "earrRosterSubmitted";
	public final static String FLIGHT_PATTERN_IS_SUBMITTED_KEY = "flightParrernSubmitted";
	public final static String REQUEST_CHECK_MAP_KEY = "reqCheckMap";
	public final static String EARLY_RELEASE_APPLICATION_ROSTER_KEY = "earrApplicationRoster";
	public final static String HIGH_FLYING_HOUR_APPLICATION_KEY = "hfhrApplicationRoster";
	public final static String HIGH_FLYING_HOUR_AVAILABLE_KEY = "hfhrAvailable";
	public final static String EARLY_RELEASE_AVAILABLE_KEY = "earrAvailable";
	public final static String FLIGHT_PATTERN_AVAILABLE_KEY = "flightParrernAvailable";
	public final static String MUTUAL_EXCLUSIVE_KEY = "mutualExclusive";
//	public final static String BLOCK_TYPE_KEY = "blockType";
	public final static String PROBATION_KEY = "probation";

//	public final static String EARLY_RELEASE_REQ_CHECK_SQL = 
//			"SELECT Count(1) as count "
//			+ "FROM EARLY_RELEASE_REQUEST  "
//			+ "Where ern = ? and status= 'InProgress' "
//			+ "and APP_ID in ( "
//			+ "select id from QUOTA_FOR_ERRQ "
//			+ "where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and "
//			+ "sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') )";
//	public final static String HIGH_FLYING_HOUR_REQ_CHECK_SQL = 
//			"SELECT Count(1) as count "
//			+ "FROM HIGH_FLYING_HOUR_REQUEST  "
//			+ "Where ern = ? and status= 'InProgress' "
//			+ "and APP_ID in ( "
//			+ "select id from QUOTA_FOR_HFHR "
//			+ "where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and "
//			+ "sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') )";
//	public final static String REQ_COUNT_CHECK_SQL = 
//			"SELECT Count(1)  as count,'ERR' as REQ_TYPE " +
//					"FROM EARLY_RELEASE_REQUEST " +
//					"Where ern = ? and status= 'InProgress' " +
//					"and APP_ID in ( " +
//					"select id from QUOTA_FOR_ERRQ  " +
//					"where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
//					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') ) " +
//					"UNION " +
//					"SELECT Count(1) as count,'HFHR'  as REQ_TYPE " +
//					"FROM HIGH_FLYING_HOUR_REQUEST " +
//					"Where ern = ? and status= 'InProgress' " +
//					"and APP_ID in ( " +
//					"select id from QUOTA_FOR_HFHR  " +
//					"where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
//					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') ) ";
	public final static String REQ_ROSTER_CHECK_SQL =
			"Select 'EARR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END, " +
					"CASE WHEN status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') THEN 'Y' ELSE 'N' end as InApplication " +
					"from QUOTA_FOR_ERRQ  " +
					"where to_date(to_char(add_months( ROSTER_END, 1),'YYYYMM') || '01','YYYYMMDD') > sysdate " +
					"and ID in ( " +
					"select APP_ID " +
					"from EARLY_RELEASE_REQUEST " +
					"where ern = ? and status in ('InProgress') " +
					") " +
					"union " +
					"Select 'HFHR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END, " +
					"CASE WHEN status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD') THEN 'Y' ELSE 'N' end as InApplication " +
					"from QUOTA_FOR_HFHR  " +
					"where to_date(to_char(add_months( ROSTER_END, 1),'YYYYMM') || '01','YYYYMMDD') > sysdate " +
					"and ID in ( " +
					"select APP_ID " +
					"from HIGH_FLYING_HOUR_REQUEST " +
					"where ern = ? and status= ('InProgress') " +
					") " +
					"union " +
					"select " +
					"'FLTPAT' as REQ_TYPE, " +
					"to_number( to_char(START_DATE,'yyyymm')) as ROSTER_START, " +
					"to_number( to_char(END_DATE,'yyyymm')) as ROSTER_END, " +
					"'Y' as InApplication " +
					"from KA_FLT_PAT_REQUEST " +
					"where STATUS = 'A' and FLT_PATTERN_CODE != 'ONT' and END_DATE >= sysdate and STAFFID = ? ";
					
	
	public final static String APPLICATION_ROSTER_SQL = 
			"select 'EARR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END  " +
					"from QUOTA_FOR_ERRQ  " +
					"where status = 'ACTIVE' and sysdate >= PERIOD_START and  " +
					"sysdate < PERIOD_END + 1  " +
					"union " +
					"select 'HFHR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END  " +
					"from QUOTA_FOR_HFHR  " +
					"where status = 'ACTIVE' and sysdate >= PERIOD_START and  " +
					"sysdate < PERIOD_END + 1  ";
//			"select 'EARR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END  " +
//					"from QUOTA_FOR_ERRQ  " +
//					"where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
//					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD')  " +
//					"union " +
//					"select 'HFHR' as REQ_TYPE, to_number( to_char(ROSTER_START,'yyyymm')) as ROSTER_START, to_number( to_char(ROSTER_END,'yyyymm')) as ROSTER_END  " +
//					"from QUOTA_FOR_HFHR  " +
//					"where status = 'ACTIVE' and sysdate >= to_date( to_char(PERIOD_START,'yyyyMM') || '01'  ,'yyyyMMdd') and  " +
//					"sysdate < to_date(to_char(add_months( PERIOD_END, 1),'YYYYMM') || '01','YYYYMMDD')  ";
//	
	public final static String BLOCK_PAGE_SQL = 
			"select START_DATE, END_DATE " +
					"from REQUEST_CUT_OFF_CONTROL " +
					"where TYPE = 'LSS'"	;
	
	public final static String MUTUAL_EXCLUSIVE_SQL =
			"select PARAMS_VALUE from ADMIN_PARAMETER " +
					"where PARAMS = 'ON_MUTUAL_EXCLUSIVE' and PARAMS_ENABLE = 'Y'";
	
	public final static String CREW_INFO_SQL = 
			"select ern, base_port, RESIGNED, " +
					"case when add_months( DATE_JOIN, 6) > sysdate then 'Y' else 'N' end as DOJ_PROBATION, " +
					"'N' as PROMO_PROBATION " +
					"from ISDCREW.CREW_BASIC where ern = ? ";
//	"select ern, base_port, RESIGNED, " +
//	"case when add_months( DATE_JOIN, 6) > sysdate then 'Y' else 'N' end as DOJ_PROBATION, " +
//	"case when " +
//	"add_months(  " +
//	"( " +
//	"select decode( MIN(EFFECTIVE_DATE),null,to_date('31-12-2999','dd-mm-yyyy'),MIN(EFFECTIVE_DATE))  from ISDCREW.STAFF_CATEGORY  s " +
//	"      where ern =CREW_BASIC.ern and category = ( " +
//	"      select CATEGORY " +
//	"      from ISDCREW.STAFF_CATEGORY " +
//	"      where ern =CREW_BASIC.ern and sysdate between EFFECTIVE_DATE and EXPIRY_DATE " + 
//	"      ) " +
//	"),3) > sysdate then 'Y' else 'N' end as PROMO_PROBATION " +
//	"from ISDCREW.CREW_BASIC where ern = ? ";
			
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = null;

		String action = request.getParameter(ACTION_KEY);
		String ern = null;

		response.setHeader("Cache-control", "no-cache, no-store");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "-1");
		
		try {
			HttpSession session = request.getSession();
			ern = (String) session.getAttribute("MyERN");

		    if (ern.equals("1234567")) {
		        String err_msg = "You have not yet acknowledged crew notification(s) / CCS broadcast message, please close the window and log in again. ";
		        request.setAttribute("err_msg", err_msg);

		        return mapping.findForward("errors");
		      }
			
			
			if (ern.length() != 7) {
				errors.add("ern", new org.apache.struts.action.ActionError(
						"error.ern.required"));

			} else {

//				// Call dutySummary.java -> Retrieve duty summary data from DB
//				dutySummary dutyrecord = new dutySummary(ern);
//
//				// Record Found -> show the data in dutySummary.jsp
//				if (dutyrecord.getErr_msg().equals("no_err")) {
//					request.setAttribute("dutyDetails", dutyrecord);
//					forward = mapping.findForward("success");
//				} else {
//					String err_msg = dutyrecord.getErr_msg();
//					request.setAttribute("err_msg", err_msg);
//					forward = mapping.findForward("errors");
//				}

			}

		} catch (Exception e) {
			errors.add("name", new ActionError("id"));
			request.setAttribute("err_msg", "Your session has been timeout.");
			forward = mapping.findForward("errors");
			return forward;
		}

		dbconnect db = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Exception tempE = null;

		
		
		int parameterIndex = 1;
		int hfhrCount = 0;
		int errCount = 0;
		
		HashMap reqCheckMap = new HashMap();
		
		List hfhrSubmittedRosterList = new ArrayList();
		List earrSubmittedRosterList = new ArrayList();
		List flightPatternSubmittedRosterList = new ArrayList();
		List hfhrApplicationRosterList = new ArrayList();
		List earrApplicationRosterList = new ArrayList();
		//List blockTypeList = new ArrayList();
		
		reqCheckMap.put(HIGH_FLYING_HOUR_SUBMITTED_ROSTER_KEY, hfhrSubmittedRosterList);
		reqCheckMap.put(EARLY_RELEASE_SUBMITTED_ROSTER_KEY, earrSubmittedRosterList);
		reqCheckMap.put(FLIGHT_PATTERN_SUBMITTED_ROSTER_KEY, flightPatternSubmittedRosterList);
		reqCheckMap.put(HIGH_FLYING_HOUR_APPLICATION_KEY, hfhrApplicationRosterList);
		reqCheckMap.put(EARLY_RELEASE_APPLICATION_ROSTER_KEY, earrApplicationRosterList);
		reqCheckMap.put(HIGH_FLYING_HOUR_IS_SUBMITED_KEY, "N");
		reqCheckMap.put(EARLY_RELEASE_IS_SUBMITTED_KEY, "N");
		reqCheckMap.put(FLIGHT_PATTERN_IS_SUBMITTED_KEY, "N");
//		reqCheckMap.put(PROBATION_KEY, "Y");
		
		//reqCheckMap.put(BLOCK_TYPE_KEY,blockTypeList);
		int rosterStart = 0;
		int rosterEnd = 0;
		
		int blockCount = 0;
		String mutualExclusiveValue = null;
		String basePort = null;
		String dojProbation = null;
		String promoProbation = null;
		String isResigned = null;
		Date blockStart = null;
		Date blockEnd = null;
		int blockDayStart = 0;
		int blockDayEnd = 0;
		
		try {
			
			 
			
			
			db = new dbconnect();
			conn = db.getConn();
			
			///Check Crew must be HKG base and not in Probation period ( doj > 6 months, new rank > 3 months)
			
			parameterIndex = 1;
			pstmt = conn.prepareStatement(CREW_INFO_SQL);
			pstmt.setString(parameterIndex++, ern);
			rs = pstmt.executeQuery();
			if (rs.next()){
				basePort = rs.getString("base_port");
				dojProbation = rs.getString("DOJ_PROBATION");
				promoProbation = rs.getString("PROMO_PROBATION");
				isResigned =  rs.getString("RESIGNED");
			}
			DBUtils.closeResultSet(rs);
			DBUtils.closeStatment(pstmt);
			
			///Check Crew must be HKG base
			if ("Y".equalsIgnoreCase(isResigned)){
				DBUtils.closeConnextion(conn);
				request.setAttribute("err_msg", "This function is not applicable for resigned crew." );
				forward = mapping.findForward("errors");
				return forward;
			}
			else if (!"HKG".equalsIgnoreCase(basePort)){
				DBUtils.closeConnextion(conn);
				request.setAttribute("err_msg", "This function is applicable to HKG based crew only." );
				forward = mapping.findForward("errors");
				return forward;
			}
			///Check not in Probation period ( doj > 6 months, new rank > 3 months)
			if ("Y".equalsIgnoreCase(dojProbation) || "Y".equalsIgnoreCase(promoProbation)  ){
				reqCheckMap.put(PROBATION_KEY, "Y");
			}
			
			///Go to block page from 27th to end of month
			Calendar cal = Calendar.getInstance();
//			if ( cal.get(Calendar.DAY_OF_MONTH) > 26 ){
//				DBUtils.closeConnextion(conn);
//				forward = mapping.findForward("block");
//				return forward;
//			}
			
			
			pstmt = conn.prepareStatement(BLOCK_PAGE_SQL);
			rs = pstmt.executeQuery();
			if (rs.next()){
				//blockTypeList.add( rs.getString("TYPE"));
				blockStart = rs.getDate("START_DATE");
				blockEnd = rs.getDate("END_DATE");
			}
			DBUtils.closeResultSet(rs);
			DBUtils.closeStatment(pstmt);
			
			Calendar tempCal = Calendar.getInstance();
			
			if (blockStart != null){
				tempCal.setTime(blockStart) ;
				blockDayStart = tempCal.get(Calendar.DAY_OF_MONTH);
			}
			if (blockEnd != null){
				tempCal.setTime(blockEnd);
				blockDayEnd = tempCal.get(Calendar.DAY_OF_MONTH);
			}
			else{
				blockDayEnd = 31;
			}
			
			
			if ( cal.get(Calendar.DAY_OF_MONTH) >= blockDayStart && cal.get(Calendar.DAY_OF_MONTH) <= blockDayEnd   ){
				DBUtils.closeConnextion(conn);
				forward = mapping.findForward("block");
				return forward;
			}
			
			pstmt = conn.prepareStatement(MUTUAL_EXCLUSIVE_SQL);
			rs = pstmt.executeQuery();
			if (rs.next()){
				mutualExclusiveValue = rs.getString("PARAMS_VALUE");
			}
			reqCheckMap.put(MUTUAL_EXCLUSIVE_KEY,mutualExclusiveValue);
			
			parameterIndex = 1;
			pstmt = conn.prepareStatement(REQ_ROSTER_CHECK_SQL);
			pstmt.setString(parameterIndex++, ern);
			pstmt.setString(parameterIndex++, ern);
			pstmt.setString(parameterIndex++, ern);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if ( "EARR".equals(rs.getString("REQ_TYPE")) ){
					if ("Y".equals(rs.getString("InApplication"))){
						reqCheckMap.put(EARLY_RELEASE_IS_SUBMITTED_KEY, "Y");
					}
					rosterStart = rs.getInt("ROSTER_START");
					rosterEnd = rs.getInt("ROSTER_END");
					
					for (int rosterYYYYMM = rosterStart; rosterYYYYMM <= rosterEnd; rosterYYYYMM++){
						earrSubmittedRosterList.add( new Integer(rosterYYYYMM) );
					}
					
					
				}
				else if ( "HFHR".equals(rs.getString("REQ_TYPE")) ){
					if ("Y".equals(rs.getString("InApplication"))){
						reqCheckMap.put(HIGH_FLYING_HOUR_IS_SUBMITED_KEY, "Y");
					}
					rosterStart = rs.getInt("ROSTER_START");
					rosterEnd = rs.getInt("ROSTER_END");
					
					for (int rosterYYYYMM = rosterStart; rosterYYYYMM <= rosterEnd; rosterYYYYMM++){
						hfhrSubmittedRosterList.add( new Integer(rosterYYYYMM) );
					}
				}
				else if ( "FLTPAT".equals(rs.getString("REQ_TYPE")) ){
					if ("Y".equals(rs.getString("InApplication"))){
						reqCheckMap.put(FLIGHT_PATTERN_IS_SUBMITTED_KEY, "Y");
					}
					rosterStart = rs.getInt("ROSTER_START");
					rosterEnd = rs.getInt("ROSTER_END");
					
					if (rosterEnd != 999912){
						for (int rosterYYYYMM = rosterStart; rosterYYYYMM <= rosterEnd; rosterYYYYMM++){
							flightPatternSubmittedRosterList.add( new Integer(rosterYYYYMM) );
						}
					}
					else{
						flightPatternSubmittedRosterList.add( new Integer(rosterEnd) );
					}
						
				}
			}
			
			DBUtils.closeResultSet(rs);
			DBUtils.closeStatment(pstmt);
			
			pstmt = conn.prepareStatement(APPLICATION_ROSTER_SQL);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if ( "EARR".equals(rs.getString("REQ_TYPE")) ){
					rosterStart = rs.getInt("ROSTER_START");
					rosterEnd = rs.getInt("ROSTER_END");
					
					for (int rosterYYYYMM = rosterStart; rosterYYYYMM <= rosterEnd; rosterYYYYMM++){
						earrApplicationRosterList.add( new Integer(rosterYYYYMM) );
					}
					
					
				}
				else if ( "HFHR".equals(rs.getString("REQ_TYPE")) ){
					rosterStart = rs.getInt("ROSTER_START");
					rosterEnd = rs.getInt("ROSTER_END");
					
					for (int rosterYYYYMM = rosterStart; rosterYYYYMM <= rosterEnd; rosterYYYYMM++){
						hfhrApplicationRosterList.add( new Integer(rosterYYYYMM) );
					}
				}
			}

		} catch (Exception e) {
			System.out.println("RosterRequestControlAction:highFlyingHoursFilter exception: " + e.getMessage());
			e.printStackTrace(System.out);
			tempE = e;
		}

		DBUtils.closeResultSet(rs);
		DBUtils.closeStatment(pstmt);
		DBUtils.closeConnextion(conn);
		
		
		if (tempE != null) {
			//saveErrors(request, errors);
			// request.setAttribute("err_msg", errors);
			request.setAttribute("err_msg", tempE.getMessage());
			forward = mapping.findForward("errors");
		} else {
			try {
				if (action == null) {
					System.out.println("case action is null");
					forward = displayMenu(reqCheckMap, mapping, form, request, response);
				} else if (HIGH_FLYING_HOUR.equals(action)) {
					System.out.println("case HIGH_FLYING_HOUR");
					forward = highFlyingHoursFilter(reqCheckMap,mapping, form, request,
							response);
				} else if (EARLY_RELEASE.equals(action)) {
					System.out.println("case EARLY_RELEASE");
					forward = earlyReleaseFilter(reqCheckMap, mapping, form, request,
							response);
				} else if (FLIGHT_PATTERN_REQUEST.equals(action)) {
					System.out.println("case FLIGHT_PATTERN_REQUEST");
					forward = flightPatternFilter(reqCheckMap,mapping, form, request,
							response);
				} else {
					System.out.println("case else");
					forward = displayMenu(reqCheckMap, mapping, form, request, response);
				}
			} catch (Exception e) {
				request.setAttribute("err_msg", e.getMessage());
				forward = mapping.findForward("failure");
			}
		}

		return forward;

	}

	private ActionForward displayMenu(HashMap reqCheckMap,ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		
		request.setAttribute(HIGH_FLYING_HOUR_AVAILABLE_KEY, new Boolean( isHighFlyingHoursAvailble(reqCheckMap)));
		request.setAttribute(EARLY_RELEASE_AVAILABLE_KEY, new Boolean( isEarlyReleaseAvailble(reqCheckMap)));
		request.setAttribute(FLIGHT_PATTERN_AVAILABLE_KEY, new Boolean( isFlightPatternAvailble(reqCheckMap)));
		request.setAttribute(HIGH_FLYING_HOUR_IS_SUBMITED_KEY, reqCheckMap.get(HIGH_FLYING_HOUR_IS_SUBMITED_KEY));
		request.setAttribute(EARLY_RELEASE_IS_SUBMITTED_KEY, reqCheckMap.get(EARLY_RELEASE_IS_SUBMITTED_KEY));
		
		forward = mapping.findForward("menu");
		return forward;
	}

	private ActionForward highFlyingHoursFilter(HashMap reqCheckMap,ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		
				
		if (isHighFlyingHoursAvailble(reqCheckMap)){
			forward = mapping.findForward("high_hour");
		} else {
			forward = displayMenu(reqCheckMap,mapping, form, request,response);
		} 
		
//		else if ("Y".equals(reqCheckMap.get(HIGH_FLYING_HOUR_IS_SUBMITED_KEY) )) {
//			forward = mapping.findForward("high_hour_withdraw");
//		} else {
//			request.setAttribute("err_msg", "unknow error");
//			forward = mapping.findForward("failure");
//		}

		return forward;
	}

	private ActionForward earlyReleaseFilter(HashMap reqCheckMap, ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();

		if (isEarlyReleaseAvailble(reqCheckMap) ){
			forward = mapping.findForward("early_release");
		} else {
			forward = displayMenu(reqCheckMap,mapping, form, request,response);
		} 
//		else if (errCount > 0) {
//			forward = mapping.findForward("early_release_withdraw");
//		} else {
//			request.setAttribute("err_msg", "unknow error");
//			forward = mapping.findForward("failure");
//		}

		return forward;
	}

	private ActionForward flightPatternFilter(HashMap reqCheckMap,ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		
		
		if ( isFlightPatternAvailble(reqCheckMap) ){
			
			forward = mapping.findForward("flight_pattern");
		}
		else{
			forward = displayMenu(reqCheckMap,mapping, form, request,response);
		}
		return forward;
	}
	private boolean isHighFlyingHoursAvailble(HashMap reqCheckMap){
//		String mutualExclusiveVlaue = (String) reqCheckMap.get(MUTUAL_EXCLUSIVE_KEY);
//		if ("2".equals(mutualExclusiveVlaue)){
//			return true;
//		}
		
		List hfhrApplicationList = (List) reqCheckMap.get(HIGH_FLYING_HOUR_APPLICATION_KEY);
		List earrSubmittedRosterList =(List) reqCheckMap.get(EARLY_RELEASE_SUBMITTED_ROSTER_KEY);
//		List blockTypeList = (List) reqCheckMap.get(BLOCK_TYPE_KEY);
		String isProbation = (String) reqCheckMap.get(PROBATION_KEY);
		
		///remove probation checking for high flying hour
		//if (blockTypeList.contains("HFH") || "Y".equals(isProbation) ){
//		if (blockTypeList.contains("HFH")){
//			return false;
//		}
		
		if (hfhrApplicationList.size() == 0) {
			return false;
		}
		
		boolean returnValue = true;
		
		Iterator iter = hfhrApplicationList.iterator();
		while (iter.hasNext()){
			if (earrSubmittedRosterList.contains(iter.next())){
				returnValue = false;
				break;
			}
		}
		return returnValue;
	}
	private boolean isEarlyReleaseAvailble(HashMap reqCheckMap){
//		String mutualExclusiveVlaue = (String) reqCheckMap.get(MUTUAL_EXCLUSIVE_KEY);
//		if ("2".equals(mutualExclusiveVlaue)){
//			return true;
//		}
		List earrApplicationRosterList = (List) reqCheckMap.get(EARLY_RELEASE_APPLICATION_ROSTER_KEY);
		List hfhrSubmittedRosterList = (List) reqCheckMap.get(HIGH_FLYING_HOUR_SUBMITTED_ROSTER_KEY);
//		List blockTypeList = (List) reqCheckMap.get(BLOCK_TYPE_KEY);
		String isProbation = (String) reqCheckMap.get(PROBATION_KEY);
		
		if ( "Y".equals(isProbation)){
			return false;
		}
		if (earrApplicationRosterList.size() == 0) {
			return false;
		}
		
		boolean returnValue = true;
		
		Iterator iter = earrApplicationRosterList.iterator();
		while (iter.hasNext()){
			if (hfhrSubmittedRosterList.contains(iter.next())){
				returnValue = false;
				break;
			}
		}
		return returnValue;
	}
	private boolean isFlightPatternAvailble(HashMap reqCheckMap){
		///return true for turn off the checking
		return true;
		
		///remark the logic for turn off the checking
		
//		String mutualExclusiveVlaue = (String) reqCheckMap.get(MUTUAL_EXCLUSIVE_KEY);
//		if ("2".equals(mutualExclusiveVlaue)){
//			return true;
//		}
//		List hfhrSubmittedRosterList = (List) reqCheckMap.get(HIGH_FLYING_HOUR_SUBMITTED_ROSTER_KEY);
//		List earrSubmittedRosterList =(List) reqCheckMap.get(EARLY_RELEASE_SUBMITTED_ROSTER_KEY);
//		List flightPatternSubmittedRosterList =(List) reqCheckMap.get(FLIGHT_PATTERN_SUBMITTED_ROSTER_KEY);
//		
//		System.out.println(hfhrSubmittedRosterList);
//		System.out.println(earrSubmittedRosterList);
//		System.out.println(flightPatternSubmittedRosterList);
//		
//		if (flightPatternSubmittedRosterList.size() == 0){
//			return true;
//			
//		}
//		else if (  ((Integer)flightPatternSubmittedRosterList.get(0)).intValue() == 999912){
//			if (hfhrSubmittedRosterList.size()> 0 ||  earrSubmittedRosterList.size() > 0){
//				return false;
//			}
//			else{
//				return true;
//			}
//			
//		}else
//		{
//			boolean returnValue = true;
//			
//			Iterator iter = hfhrSubmittedRosterList.iterator();
//			while (iter.hasNext()){
//				if (flightPatternSubmittedRosterList.contains(iter.next())){
//					returnValue = false;
//					break;
//				}
//			}
//			if (!returnValue){
//				return returnValue;
//			}
//			iter = earrSubmittedRosterList.iterator();
//			while (iter.hasNext()){
//				if (flightPatternSubmittedRosterList.contains(iter.next())){
//					returnValue = false;
//					break;
//				}
//			}
//			
//			return returnValue;
//		}
		
		
		
		
	}
}
