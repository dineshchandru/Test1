package com.cathaypacific.crewdirect.forms;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 2 fields on this form:
 * <ul>
 * <li>hidden_items - [your comment here]
 * <li>type - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class SetHiddenformBean extends ActionForm {

	private String hidden_items = null;
	private String action_type = null;

	/**
	 * Get hidden_items
	 * @return String
	 */
	public String getHidden_items() {
		return hidden_items;
	}

	/**
	 * Set hidden_items
	 * @param <code>String</code>
	 */
	public void setHidden_items(String h) {
		this.hidden_items = h;
	}


	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {
	    ArrayList toHideItems = new ArrayList();
		int spos =0;
		int epos =0;
		String tmp = null;
		ActionErrors errors = new ActionErrors();
		
		if (hidden_items.equals("SHOW_ALL" )){
			action_type="SHOW_ALL";
		}else{
			action_type="hidden";							 
		}
		
		return errors;

	}
	/**
	 * @return
	 */
	public String getAction_type() {
		return action_type;
	}

	/**
	 * @param string
	 */
	public void setAction_type(String string) {
		action_type = string;
	}

}
