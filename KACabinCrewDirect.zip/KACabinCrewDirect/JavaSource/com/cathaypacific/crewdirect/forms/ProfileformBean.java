package com.cathaypacific.crewdirect.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 5 fields on this form:
 * <ul>
 * <li>roster_info - [your comment here]
 * <li>s_phone - [your comment here]
 * <li>p_phone - [your comment here]
 * <li>gala_id - [your comment here]
 * <li>mailbox - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class ProfileformBean extends ActionForm {

	private String roster_info = "";
	private String email = "";
	private String mail_box = "";
	private String base_port = "";
	

	

	
	
	
	/**
	 * Get roster_info
	 * @return String
	 */
	public String getRoster_info() {
		return roster_info;
	}
	
	public String getEmail ()
	{
		return email;
	}
	
	public String getMail_box()
	{
		return mail_box;
	}
	
	public String getBase_port()
	{
		return base_port;
	}
	
	/**
	 * Set roster_info
	 * @param <code>String</code>
	 */
	public void setRoster_info(String r) {
		this.roster_info = r;
	}
	
	public void setEmail (String email)
	{
		this.email = email;
	}
	
	public void setMail_box (String mail_box)
	{
		this.mail_box = mail_box;
	}
	
	public void setBase_port (String base_port)
	{
		this.base_port = base_port;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request) {

		// Reset values are provided as samples only. Change as appropriate.

		roster_info = "";
		email = "";
		mail_box = "";
		base_port = "";
		
	}

//	public ActionErrors validate(
//		ActionMapping mapping,
//		HttpServletRequest request) {
//
//		ActionErrors errors = new ActionErrors();
//		// Validate the fields in your form, adding
//		// adding each error to this.errors as found, e.g.
//
//		// if ((field == null) || (field.length() == 0)) {
//		//   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
//		// }
//		return errors;
//
//	}

}
