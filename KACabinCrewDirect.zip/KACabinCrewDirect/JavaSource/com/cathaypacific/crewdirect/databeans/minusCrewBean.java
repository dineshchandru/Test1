/** [Mantis:0000438]
 *  author: SPIBAW
 *  time : 20170512
 *  Function : minuscrew databean
 */
package com.cathaypacific.crewdirect.databeans;

public class minusCrewBean {
	private String ern;
	private String fltdate;
	private String fltno;
	private String crewob;
	private String shortage;
	private String fdpshare;
	private String paydate;

	public minusCrewBean() {
	}

	public minusCrewBean(String ern, String fltdate, String fltno,
			String crewob, String shortage, String fdpshare, String paydate) {
		this.ern = ern;
		this.fltdate = fltdate;
		this.fltno = fltno;
		this.crewob = crewob;
		this.shortage = shortage;
		this.fdpshare = fdpshare;
		this.paydate = paydate;
	}

	public String getErn() {
		return this.ern;
	}

	public void setErn(String ern) {
		this.ern = ern;
	}

	public String getFltdate() {
		return this.fltdate;
	}

	public void setFltdate(String fltdate) {
		this.fltdate = fltdate;
	}

	public String getFltno() {
		return this.fltno;
	}

	public void setFltno(String fltno) {
		this.fltno = fltno;
	}

	public String getCrewob() {
		return this.crewob;
	}

	public void setCrewob(String crewob) {
		this.crewob = crewob;
	}

	public String getShortage() {
		return this.shortage;
	}

	public void setShortage(String shortage) {
		this.shortage = shortage;
	}

	public String getFdpshare() {
		return this.fdpshare;
	}

	public void setFdpshare(String fdpshare) {
		this.fdpshare = fdpshare;
	}

	public String getPaydate() {
		return this.paydate;
	}

	public void setPaydate(String paydate) {
		this.paydate = paydate;
	}
}