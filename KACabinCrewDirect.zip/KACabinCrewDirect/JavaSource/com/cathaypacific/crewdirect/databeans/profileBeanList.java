package com.cathaypacific.crewdirect.databeans;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class profileBeanList {	

	private Connection con=null;
	private String ern;		
	private profileBean [] privacy_list = new profileBean[4];	
	private String arr_profile [][] = new String [4][4];
	
	private String arr_insrtProf [] = new String[6];
	private String status;
	 			
	public profileBeanList() {		
		super();		
	}

	public profileBeanList(String ern) {
		this.ern = ern;		
		genPrivacyList();
	}

	public profileBeanList(String ern,String [] insertProfile) {
		this.ern = ern;
		this.arr_insrtProf = insertProfile;
		setProfile();
	}

	public void setProfile() {
		try{				
			//connect to db and put data by month into list
			
			dbconnect db = new dbconnect();
			con = db.getConn();
			Statement stmt = con.createStatement();		        			 			 					 			 		
			String SQL = "UPDATE KA_CREW_PROFILE SET ROSTER_INFO = '" + arr_insrtProf[0] + "'," +
						 "MAIL_BOX ='"+ arr_insrtProf[1] + "'," +
						 "EMAIL ='"+ arr_insrtProf[2] + "'," +
						 "BASE_PORT ='"+ arr_insrtProf[3] + "' " +
						 " WHERE STAFFID = '" + ern + "' ";					 				

			int rows = stmt.executeUpdate(SQL);
			
			if (rows == 1){
				status="Y";
			}else{			
				status="N";	
			}
	
			stmt.close(); 
			
			//set return data			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try

		
	}


	public void genPrivacyList() {				
		try{				
			
			dbconnect db = new dbconnect();
			con = db.getConn();	        
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 		
			String SQL;
			/*String crew_id   = null;
			String mail_box = null;
			String p_phone =  null;
			String s_phone =  null;
			String galacxy_id = null;
			String cos = null;*/
																												
			String iStaffID = "";
			String first_name = "";
			String sur_name = "";
			String badge_name = "";
			String category = "";
			String mail_box = "";
			String email = "";
			String base_port = "";
			
            //1.0 get info
			/*SQL =   "SELECT DISTINCT * " +
					"FROM ISDCREW.CREWDB_4_ALL_CONTACT WHERE ERN='"+ern+"'";					 

			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);
			while(rs.next()){																	
				crew_id   = rs.getString("CREW_ID");
				mail_box = rs.getString("MAIL_BOX");
				p_phone =  rs.getString("P_PHONE");
				s_phone =  rs.getString("S_PHONE");
				galacxy_id = rs.getString("PID");																									
				cos = rs.getString("COS");
				break;
			}	
			rs.close(); */
			
			SQL = "SELECT DISTINCT * FROM ISDCREW.CREW_INFO WHERE STAFFID = '" + ern + "' and RESIGNED = 'N' ";
			
			stmt = con.createStatement();
			rs = stmt.executeQuery(SQL);
			while (rs.next())
			{
				ern =  rs.getString("STAFFID");
				sur_name = rs.getString("SUR_NAME");
				first_name = rs.getString("FIRST_NAME");
				badge_name = rs.getString("BADGE_NAME");
				category = rs.getString("CATEGORY");
				mail_box = rs.getString("MAIL_BOX");
				email = rs.getString("EMAIL");
				base_port = rs.getString("BASE_PORT");
			}
			rs.close();

			//2.0 get profile setting
			SQL = "SELECT DISTINCT * FROM KA_CREW_PROFILE WHERE STAFFID = '" + ern + "' ";
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){				
				//-------------------				                
				arr_profile [0][0] = "roster_info";
				arr_profile [0][1] = "Roster Information";
				arr_profile [0][2] = "&nbsp;";
				arr_profile [0][3] = rs.getString("ROSTER_INFO");
				//-------------------								
				arr_profile [1][0] = "mail_box";
				arr_profile [1][1] = "Mail Box";
				if (mail_box.equals(""))
				{
					arr_profile [1][2] = "&nbsp;";
				}else
				{
					arr_profile [1][2] = mail_box;
				}
				arr_profile [1][3] = rs.getString("MAIL_BOX");
				//-------------------								
				arr_profile [2][0] = "email";
				arr_profile [2][1] = "Email";
				if (email.equals(""))
				{
					arr_profile [2][2] = "&nbsp;";
				}else
				{
					arr_profile [2][2] = email;
				}
				arr_profile [2][3] = rs.getString("EMAIL");
				//-------------------								
				arr_profile [3][0] = "base_port";
				arr_profile [3][1] = "Base Port";
				if (base_port.equals(""))
				{
					arr_profile [3][2] = "&nbsp;";
				}else
				{
					arr_profile [3][2] = base_port;
				}
				arr_profile [3][3] = rs.getString("BASE_PORT");
				//-------------------		
				/*arr_profile [4][0] = "crew_name";										
				arr_profile [4][1] = "Crew Name";
				arr_profile [4][2] = sur_name + "&nbsp" + first_name;
				arr_profile [4][3] = rs.getString("SUR_NAME") + "&nbsp" + rs.getString("FIRST_NAME");
				//-------------------		
				arr_profile [5][0] = "cos";										
				arr_profile [5][1] = "COS";
				arr_profile [5][2] = cos;
				arr_profile [5][3] = rs.getString("COS");	*/			
			}									        
			rs.close();
			stmt.close(); 
			
			//set return data			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 						
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  
		
		//put array bean
		for (int x=0;x<4;x++) {
			profileBean myprofile = new profileBean(arr_profile[x][0],arr_profile[x][1],arr_profile[x][2],arr_profile[x][3]);
			privacy_list[x] = myprofile;
		}
		 			
	}


		/**
		 * @return
		 */
		public String getERN() {
			return ern;
		}
		
		
		/**
		 * @param string
		 */
		public void setERN(String string) {
			ern = string;
		}


	/**
	 * @return
	 */
	public profileBean[] getPrivacy_list() {
		return privacy_list;
	}

	/**
	 * @param beans
	 */
	public void setPrivacy_list(profileBean[] beans) {
		privacy_list = beans;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param string
	 */
	public void setStatus(String string) {
		status = string;
	}

}
