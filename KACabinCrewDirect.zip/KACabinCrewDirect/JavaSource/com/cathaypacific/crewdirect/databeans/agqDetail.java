/*
 * Created on Mar 30, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class agqDetail {
	
	private String ern;
	private String roster_year;
	private String roster_month;
	private String start_date;
	private String record_status;
	private String last_update_user;
	private String last_update_date;
	
	public agqDetail() {
		ern = "";
		roster_year = "";
		roster_month = "";
		start_date = "";
		record_status = "";
		last_update_user = "";
		last_update_date = "";
	}
	
	public String getERN() {
		return ern;
	}
	
	public void setERN (String ern)	{
		this.ern = ern;
	}

	public String getRoster_year() {
		return roster_year;
	}

	public void setRoster_year(String roster_year) {
		this.roster_year = roster_year;
	}
	
	public String getRoster_Month()	{
		return roster_month;
	}

	public void setRoster_Month(String roster_month) {
		this.roster_month = roster_month;
	}
		
	public String getStart_Date() {
		return start_date;
	}
	
	public void setStart_Date(String start_date) {
		this.start_date = start_date;
	}
	
	public String getLast_Update_User()	{
		return last_update_user;
	}
	
	public void setLast_Update_User(String last_update_user) {
		this.last_update_user = last_update_user;
	}
	
	public String getLast_Update_Date()	{
		return last_update_date;
	}
	
	public void setLast_Update_Date(String last_update_date) {
		this.last_update_date = last_update_date;
	}

	public String getRecord_status() {
		return record_status;
	}

	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
}