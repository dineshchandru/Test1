package com.cathaypacific.crewdirect.databeans;

import java.text.SimpleDateFormat;
import java.util.Date;

public class noteBean {
	private String msg_type;
	private String note_details;
	private String ack_time;
	
	public noteBean(String msg_type,String note_details,String ack_time) {
		this.msg_type = msg_type;
		this.note_details = note_details;
		this.ack_time = ack_time;
	}

	public noteBean() {
		super();
	}

	private String Date2String(Date myDate){
		String str=null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
		str = formatter.format(myDate);
		return str;
	}

	/**
	 * @return
	 */
	public String getAck_time() {
		return ack_time;
	}

	/**
	 * @return
	 */
	public String getNote_details() {
		return note_details;
	}


	/**
	 * @param string
	 */
	public void setAck_time(String string) {
		ack_time = string;
	}

	/**
	 * @param string
	 */
	public void setNote_details(String string) {
		note_details = string;
	}


	/**
	 * @return
	 */
	public String getMsg_type() {
		return msg_type;
	}

	/**
	 * @param string
	 */
	public void setMsg_type(String string) {
		msg_type = string;
	}

}
