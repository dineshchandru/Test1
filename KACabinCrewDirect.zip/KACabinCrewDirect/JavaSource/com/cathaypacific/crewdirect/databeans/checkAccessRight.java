package com.cathaypacific.crewdirect.databeans;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class checkAccessRight {

	private boolean valid;
	private String ern;
	private String err_msg = "checkAccessRight_no_err";	
	Connection con = null;
	ResultSet rs = null;
	Statement stmt = null;

	public checkAccessRight() {
		super();		
	}

	public checkAccessRight(String ern) {

		this.ern = ern;
		try {				
			dbconnect db = new dbconnect();
			con = db.getConn();
			if (con != null)
			{
				stmt=con.createStatement();			 	
				//edit on 16.01.09 for new crew basic table to containt staff info
				//String SQL =  "SELECT * FROM ISDCREW.KA_USER_PID WHERE STAFFID ='" + ern + "'";
				String SQL =  "SELECT * FROM ISDCREW.CREW_INFO WHERE STAFFID = '" + ern + "' ";
				rs= stmt.executeQuery(SQL);
				
				valid = false;	
				
				while(rs.next()){				
					valid = true;  //have record
					break;
				}			
				
			}else
			{
				err_msg = "checkAccessRight Err in connection";
			}

			if (!valid)						        
				err_msg = "Your Staff ID :("+ern+") does not have access right to Cabin Crew Direct.";

			rs.close();
			stmt.close(); 

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			err_msg = "checkAccessRight sqlerr : " + sqlex.getMessage();
			if (con != null) {
				try {
				   con.close();
				} catch (SQLException e){
					e.printStackTrace();
				}		   	  
			  } //if

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = "checkAccessRight err : E00-Oracle DataBase (KACCD) Error.";
			valid = false;

		} finally {
			if (con != null) {
				try {
					con.close();
				} catch( SQLException e){
					valid = false;
					err_msg = "E00-Oracle DataBase (KACCD) Error.";
					e.printStackTrace();
				}
			} //if  
		}//catch/try		 
	}

	/**
	 * @return
	 */
	public boolean isValid() {
		return valid;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

}
