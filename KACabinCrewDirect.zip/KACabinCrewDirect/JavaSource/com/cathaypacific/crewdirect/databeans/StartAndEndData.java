package com.cathaypacific.crewdirect.databeans;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class StartAndEndData
{
  private Connection con = null;
  private Date start_date = null;
  private Date end_date = null;

  public Date getStart_date(String type)
  {
    dbconnect db;
    try
    {
      db = new dbconnect();
      Connection con = db.getConn();
      Statement stmt = con.createStatement();
      String sql = "select start_date,end_date from CREWDIR.request_cut_off_control where TYPE='" + type + "'";
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()) {
        this.start_date = rs.getDate("start_date");
        this.end_date = rs.getDate("end_date");
      }
      rs.close();
    } catch (Exception e) {
      if (this.con != null)
        try {
          this.con.close();
        } catch (Exception e1) {
          System.out.println(e.getMessage());
        }
    }

    return this.start_date;
  }

  public Date getEnd_date(String type)
  {
    dbconnect db;
    try {
      db = new dbconnect();
      Connection con = db.getConn();
      Statement stmt = con.createStatement();
      String sql = "select start_date,end_date from CREWDIR.request_cut_off_control where TYPE='" + type + "'";
      ResultSet rs = stmt.executeQuery(sql);
      while (rs.next()) {
        this.start_date = rs.getDate("start_date");
        this.end_date = rs.getDate("end_date");
      }
      rs.close();
    } catch (Exception e) {
      if (this.con != null)
        try {
          this.con.close();
        } catch (Exception e1) {
          System.out.println(e.getMessage());
        }
    }

    return this.end_date;
  }
}