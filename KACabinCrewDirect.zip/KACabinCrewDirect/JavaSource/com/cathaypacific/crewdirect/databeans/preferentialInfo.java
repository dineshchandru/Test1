package com.cathaypacific.crewdirect.databeans;

import java.io.Serializable;

/**
 * @version 	1.0
 * @author
 */
public class preferentialInfo implements Serializable {

	private String req_id = new String("");
	private String requester_ern = new String("");
	private String requester_crewid = new String("");
	private String roster_month = new String("");
	private String days_off = new String("");
	private String flying_hours = new String("");
	private String dayoff_after_flight = new String("");
	private String buddy_flying = new String("");
	private String buddy1_ern = new String("");
	private String buddy1_crewid = new String("");
	private String buddy1_status = new String("");
	private String buddy2_ern = new String("");	
	private String buddy2_crewid = new String("");
	private String buddy2_status = new String("");
	private String ack_integrated = new String("");
	private String ack_terms = new String("");
	private String last_status = new String("");
	private String last_update = new String("");
	private boolean allow_amend = false ;

	/**
	 * @return
	 */
	public preferentialInfo() {
		super();
	}
/*
	public preferentialInfo (String req_id, String requester_ern, String requester_crewid, String roster_month, String days_off, String flying_hours, String dayoff_after_flight, String buddy_flying, String buddy1_ern, String buddy1_crewid, String buddy1_status, String buddy2_ern, String buddy2_crewid, String buddy2_status, String ack_integrated, String ack_terms){
		this.req_id = req_id;
		this.requester_ern = requester_ern;
		this.requester_crewid = requester_crewid;
		this.roster_month = roster_month;
		this.days_off = days_off;
		this.flying_hours = flying_hours;
		this.dayoff_after_flight =dayoff_after_flight;
		this.buddy_flying = buddy_flying;
		this.buddy1_ern = buddy1_ern;
		this.buddy1_crewid = buddy1_crewid;
		this.buddy1_status = buddy1_status;
		this.buddy2_ern = buddy2_ern;	
		this.buddy2_crewid = buddy2_crewid;
		this.buddy2_status = buddy2_status;
		this.ack_integrated = ack_integrated;
		this.ack_terms = ack_terms;
		//this.last_status = last_status;
	}
	*/
	/**
	 * @return
	 */
	public String getAck_integrated() {
		return ack_integrated;
	}

	/**
	 * @return
	 */
	public String getAck_terms() {
		return ack_terms;
	}

	/**
	 * @return
	 */
	public String getBuddy_flying() {
		return buddy_flying;
	}

	/**
	 * @return
	 */
	public String getBuddy1_crewid() {
		return buddy1_crewid;
	}

	/**
	 * @return
	 */
	public String getBuddy1_ern() {
		return buddy1_ern;
	}

	/**
	 * @return
	 */
	public String getBuddy1_status() {
		return buddy1_status;
	}

	/**
	 * @return
	 */
	public String getBuddy2_crewid() {
		return buddy2_crewid;
	}

	/**
	 * @return
	 */
	public String getBuddy2_ern() {
		return buddy2_ern;
	}

	/**
	 * @return
	 */
	public String getBuddy2_status() {
		return buddy2_status;
	}

	/**
	 * @return
	 */
	public String getDayoff_after_flight() {
		return dayoff_after_flight;
	}

	/**
	 * @return
	 */
	public String getDays_off() {
		return days_off;
	}

	/**
	 * @return
	 */
	public String getFlying_hours() {
		return flying_hours;
	}

	/**
	 * @return
	 */
	public String getLast_status() {
		return last_status;
	}

	/**
	 * @return
	 */
	public String getLast_update() {
		return last_update;
	}

	/**
	 * @return
	 */
	public String getReq_id() {
		return req_id;
	}

	/**
	 * @return
	 */
	public String getRequester_crewid() {
		return requester_crewid;
	}

	/**
	 * @return
	 */
	public String getRequester_ern() {
		return requester_ern;
	}

	/**
	 * @return
	 */
	public String getRoster_month() {
		return roster_month;
	}

	/**
	 * @param string
	 */
	public void setAck_integrated(String string) {
		ack_integrated = string;
	}

	/**
	 * @param string
	 */
	public void setAck_terms(String string) {
		ack_terms = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy_flying(String string) {
		buddy_flying = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy1_crewid(String string) {
		buddy1_crewid = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy1_ern(String string) {
		buddy1_ern = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy1_status(String string) {
		buddy1_status = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy2_crewid(String string) {
		buddy2_crewid = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy2_ern(String string) {
		buddy2_ern = string;
	}

	/**
	 * @param string
	 */
	public void setBuddy2_status(String string) {
		buddy2_status = string;
	}

	/**
	 * @param string
	 */
	public void setDayoff_after_flight(String string) {
		dayoff_after_flight = string;
	}

	/**
	 * @param string
	 */
	public void setDays_off(String string) {
		days_off = string;
	}

	/**
	 * @param string
	 */
	public void setFlying_hours(String string) {
		flying_hours = string;
	}

	/**
	 * @param string
	 */
	public void setLast_status(String string) {
		last_status = string;
	}

	/**
	 * @param string
	 */
	public void setLast_update(String string) {
		last_update = string;
	}

	/**
	 * @param string
	 */
	public void setReq_id(String string) {
		req_id = string;
	}

	/**
	 * @param string
	 */
	public void setRequester_crewid(String string) {
		requester_crewid = string;
	}

	/**
	 * @param string
	 */
	public void setRequester_ern(String string) {
		requester_ern = string;
	}

	/**
	 * @param string
	 */
	public void setRoster_month(String string) {
		roster_month = string;
	}

	/**
	 * @return
	 */
	public boolean isAllow_amend() {
		return allow_amend;
	}

	/**
	 * @param b
	 */
	public void setAllow_amend(boolean b) {
		allow_amend = b;
	}

}
