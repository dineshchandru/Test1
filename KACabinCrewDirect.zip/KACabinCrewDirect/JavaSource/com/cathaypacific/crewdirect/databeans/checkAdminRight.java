package com.cathaypacific.crewdirect.databeans;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class checkAdminRight {

	private boolean valid;
	private String pid;
	private String err_msg = "no_err";
	Connection con = null;

	public checkAdminRight() {
		super();		
	}

	public checkAdminRight(String pid) {

		this.pid = pid;
		try {				
			dbconnect db = new dbconnect();
			con = db.getConn();
			Statement stmt=con.createStatement();			 			 					 			 		 		
			String SQL =  "SELECT rownum FROM crewdir.ka_admin_control WHERE userid ='"+pid+"'";
			ResultSet rs= stmt.executeQuery(SQL);
			valid = false;	
			
			while(rs.next()){				
				valid = true;  //have record
				break;
			}			
			
			if (!valid)						        
				err_msg = "Your ID:( "+pid+" ) does not have access right to KA Cabin Crew Direct Admin Page.";
			   
			rs.close();
			stmt.close(); 

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
				   con.close();
				} catch (SQLException e){
					e.printStackTrace();
				}		   	  
			  } //if

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = "E00-Oracle DataBase (ISDDB) Error.";
			valid = false;

		} finally {
			if (con != null) {
				try {
					con.close();
				} catch( SQLException e){
					valid = false;
					err_msg = "E00-Oracle DataBase (ISDDB) Error.";
					e.printStackTrace();
				}
			} //if  
		}//catch/try		 
	}

	/**
	 * @return
	 */
	public boolean isValid() {
		return valid;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

}
