/*
 * Created on Apr 1, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsRequestBean {
	
	private String ern;
	private int seq;
	private String start_date;
	private String end_date;
	private int day;
	private String odd_start_date;
	private int odd_day;
	private String status;
	private String last_update_user;
	private String last_update_date;
	
	public slsRequestBean()
	{
		ern = "";
		seq = 0;
		start_date = "";
		end_date = "";
		day = 0;
		odd_start_date = "";
		odd_day = 0;
		status = "";
		last_update_user = "";
		last_update_date = "";		
	}
	
	public String getERN()
	{
		return ern;
	}
	
	public void setERN(String ern)
	{
		this.ern = ern;
	}
	
	public int getSeq()
	{
		return seq;
	}
	
	public void setSeq(int seq)
	{
		this.seq = seq;
	}
	
	public String getStart_Date()
	{
		return start_date;
	}
	
	public void setStart_Date(String start_date)
	{
		this.start_date = start_date;
	}
	
	public String getEnd_Date()
	{
		return end_date;
	}
	
	public void setEnd_Date(String end_date)
	{
		this.end_date = end_date;
	}
	
	public int getDay()
	{
		return day;
	}
	
	public void setDay(int day)
	{
		this.day = day;
	}
	
	public String getOdd_Start_Date()
	{
		return odd_start_date;
	}
	
	public void setOdd_Start_Date(String odd_start_date)
	{
		this.odd_start_date = odd_start_date;
	}
	
	public int getOdd_Day()
	{
		return odd_day;
	}
	
	public void setOdd_Day(int odd_day)
	{
		this.odd_day = odd_day;
	}
	
	public String getStatus()
	{
		return status;
	}
	
	public void setStatus(String status)
	{
		this.status = status;
	}
	
	public String getLast_Update_User()
	{
		return last_update_user;
	}
	
	public void setLast_Update_User(String last_update_user)
	{
		this.last_update_user = last_update_user;
	}
	
	public String getLast_Update_Date()
	{
		return last_update_date;
	}
	
	public void setLast_Update_Date(String last_update_date)
	{
		this.last_update_date = last_update_date;
	}
	
	

}
