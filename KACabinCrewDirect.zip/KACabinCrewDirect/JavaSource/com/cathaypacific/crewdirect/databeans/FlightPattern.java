/*
 * Created on Apr 2, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FlightPattern {
	
	private String ern;
	private String flightPattern;
	private String startDate;
	private String endDate;
	private String lastUpdateDate;
	private String lastUpdateUser;
	private int seq;
	private String status;
	
	public FlightPattern()
	{
		ern = "";
		flightPattern = "";
		startDate = "";
		endDate = "";
		lastUpdateDate = "";
		lastUpdateUser = "";
		seq = 0;
		status = "I";	//A: active; I: inactive
	}
	
	public String getERN()
	{
		return ern;
	}
	
	public String getFlightPattern()
	{
		return flightPattern;
	}
	
	public String getStartDate()
	{
		return startDate;
	}
	
	public String getEndDate()
	{
		return endDate;
	}
	
	public String getLastUpdateDate()
	{
		return lastUpdateDate;
	}
	
	public String getLastUpdateUser()
	{
		return lastUpdateUser;
	}
	
	public int getSeq()
	{
		return seq;
	}
	
	public String getStatus()
	{
		return status;
	}
	
	public void setERN(String ern)
	{
		this.ern = ern;
	}
	
	public void setFlightPattern (String flightPattern)
	{
		this.flightPattern = flightPattern;
	}
	
	public void setStartDate (String startDate)
	{
		this.startDate = startDate;
	}
	
	public void setEndDate (String endDate)
	{
		this.endDate = endDate;
	}
	
	public void setLastUpdateDate (String lastUpdateDate)
	{
		this.lastUpdateDate = lastUpdateDate;
	}
	
	public void setLastUpdateUser (String lastUpdateUser)
	{
		this.lastUpdateUser = lastUpdateUser;
	}
	
	public void setSeq (int seq)
	{
		this.seq = seq;
	}
	
	public void setStatus (String status)
	{
		this.status = status;
	}

}
