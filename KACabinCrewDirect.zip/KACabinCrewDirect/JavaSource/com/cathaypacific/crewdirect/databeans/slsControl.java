/*
 * Created on Apr 6, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsControl {
	
	private String consent_start_date;
	private String consent_end_date;
	private String sls_start_date;
	private String sls_end_date;	
	
	public slsControl()
	{
		consent_start_date = "";
		consent_end_date = "";
		sls_start_date = "";
		sls_end_date = "";
	}
	
	public String getConsent_Start_Date()
	{
		return consent_start_date;
	}
	
	public void setConsent_Start_Date(String consent_start_date)
	{
		this.consent_start_date = consent_start_date;
	}
	
	public String getConsent_End_Date()
	{
		return consent_end_date;
	}
	
	public void setConsent_End_Date(String consent_end_date)
	{
		this.consent_end_date = consent_end_date;
	}
	
	public String getSLS_Start_Date()
	{
		return sls_start_date;
	}
	
	public void setSLS_Start_Date(String sls_start_date)
	{
		this.sls_start_date = sls_start_date;
	}
	
	public String getSLS_End_Date()
	{
		return sls_end_date;
	}
	
	public void setSLS_End_Date(String sls_end_date)
	{
		this.sls_end_date = sls_end_date;
	}

}
