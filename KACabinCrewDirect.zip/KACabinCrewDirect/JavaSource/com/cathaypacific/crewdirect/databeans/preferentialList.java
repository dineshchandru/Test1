package com.cathaypacific.crewdirect.databeans;

import java.io.Serializable;
import java.util.Vector;

/**
 * @version 	1.0
 * @author
 */
public class preferentialList implements Serializable {

	private Vector preferential_list = new Vector() ;

	/**
	 * @return
	 */
	public preferentialList() {
		super();
	}


	/**
	 * @return
	 */
	public Vector getPreferential_list() {
		return preferential_list;
	}

	/**
	 * @param vector
	 */
	public void setPreferential_list(Vector vector) {
		preferential_list = vector;
	}

}

