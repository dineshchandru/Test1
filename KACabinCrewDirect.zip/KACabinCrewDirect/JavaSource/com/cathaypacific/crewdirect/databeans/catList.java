package com.cathaypacific.crewdirect.databeans;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class catList {

    private Connection con=null;
	private ArrayList arr_cat;
	private String ary_cat [] = new String [20]; 
	private int ary_cat_cnt = 0;
	
	private String ary_lang [] = new String [50];
	private int ary_lang_cnt = 0;
	
	private String mycat=" ";
	private String mylang=" ";
	
	public catList() {		
		super();		
	}

	public catList(String ern) {		
		genList(ern);		
	}

	public void genList(String ern) {
	ArrayList list= new ArrayList();	
	try {	
	    dbconnect db = new dbconnect();
	    Connection con = db.getConn(); 
		String SQL;	    
		String cat;
		String lang;
		ResultSet rs=null;			
		Statement stmt= con.createStatement();	 			 					 			 		
        //find all cats 			
		SQL =  "SELECT DISTINCT NVL(CAT,' ') as CAT " +
				"FROM ISDCREW.CREWDB_4_ALL WHERE CAT IS NOT NULL "+
				"ORDER BY CAT";				
		rs= stmt.executeQuery(SQL);		
		while(rs.next()){										
			cat = rs.getString("CAT");
			list.add(new catBean(cat));
			ary_cat[ary_cat_cnt]= cat;
			ary_cat_cnt++;
		}									        
		rs.close();

        //find all languages
		SQL =  "SELECT DISTINCT NVL(LANG_1,' ') as LANG_1 " +
				"FROM ISDCREW.CREWDB_4_ALL WHERE LANG_1 IS NOT NULL "+
				"ORDER BY LANG_1";				
		rs= stmt.executeQuery(SQL);		
		while(rs.next()){										
			lang = rs.getString("LANG_1");				
			list.add(new langBean(lang));
			ary_lang[ ary_lang_cnt]= lang;
			ary_lang_cnt++;			
		}									        
		rs.close();
		
		//find my cat
		SQL =  "SELECT DISTINCT CAT,LANG_1 FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+ern+"'";					  
		stmt = con.createStatement();		
		rs= stmt.executeQuery(SQL);		
		while(rs.next()){										
			mycat = rs.getString("CAT");
			mylang= rs.getString("LANG_1");
			break;				
		}									        
		rs.close();
		stmt.close();		
		  
		//set return data			
	} catch (SQLException sqlex) {
		  sqlex.printStackTrace();	
		  if (con != null) {
				try {
				   con.close();
				} catch (SQLException e) {
				   e.printStackTrace();
				}		   	  
		  } //if
		  
	} catch (Exception ex) {
		ex.printStackTrace();

	} finally {
		if (con != null) {
			try {
		   		con.close();
			} catch (SQLException e) {
		   		e.printStackTrace();
			}
		} //if  
	}//catch/try
	this.setArr_cat(list);
}


/**
 * @return
 */
public ArrayList getArr_cat() {
	return arr_cat;
}

/**
 * @param list
 */
public void setArr_cat(ArrayList list) {
	arr_cat = list;
}


	/**
	 * @return
	 */
	public String[] getAry_cat() {
		return ary_cat;
	}

	/**
	 * @return
	 */
	public int getAry_cat_cnt() {
		return ary_cat_cnt;
	}

	/**
	 * @return
	 */
	public String getMycat() {
		return mycat;
	}

	/**
	 * @return
	 */
	public String[] getAry_lang() {
		return ary_lang;
	}

	/**
	 * @return
	 */
	public int getAry_lang_cnt() {
		return ary_lang_cnt;
	}

	/**
	 * @return
	 */
	public String getMylang() {
		return mylang;
	}

	/**
	 * @param strings
	 */
	public void setAry_lang(String[] strings) {
		ary_lang = strings;
	}

	/**
	 * @param string
	 */
	public void setMylang(String string) {
		mylang = string;
	}

}
