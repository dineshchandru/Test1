/*
 * Created on Apr 29, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class langBean {
	private String lang;
	/**
	 * 
	 */
	public langBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public langBean(String lang) {
		this.lang = lang;
	}
	/**
	 * @return
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * @param string
	 */
	public void setLang(String string) {
		lang = string;
	}

}
