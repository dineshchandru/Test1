package com.cathaypacific.crewdirect.databeans;

public class catBean {

	private String cat;
		
	public catBean() {
		super();
	}

	public catBean(String cat) {
		this.cat = cat;
	}
	
	/**
	 * @return
	 */
	public String getCat() {
		return cat;
	}

	/**
	 * @param string
	 */
	public void setCat(String string) {
		cat = string;
	}
	
}
