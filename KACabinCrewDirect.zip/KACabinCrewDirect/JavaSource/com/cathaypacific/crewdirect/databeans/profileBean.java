package com.cathaypacific.crewdirect.databeans;

public class profileBean {

	private String field;
	private String desc;
	private String label;
	private String value;

	public profileBean() {
		super();
	}

	public profileBean(String field,String desc,String label,String value) {
		this.field = field;
		this.desc  = desc;
		this.label = label;
		this.value = value;			
	}

	/**
	 * @return
	 */
	public String getField() {
		return field;
	}

	/**
	 * @return
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @return
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param string
	 */
	public void setField(String string) {
		field = string;
	}

	/**
	 * @param string
	 */
	public void setLabel(String string) {
		label = string;
	}

	/**
	 * @param string
	 */
	public void setValue(String string) {
		value = string;
	}

	/**
	 * @return
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param string
	 */
	public void setDesc(String string) {
		desc = string;
	}

}
