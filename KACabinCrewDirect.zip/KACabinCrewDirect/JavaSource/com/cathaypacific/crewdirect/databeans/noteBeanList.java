package com.cathaypacific.crewdirect.databeans;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class noteBeanList {
	
    private Connection con=null;
	private String ern;	
	private ArrayList note_list;
	
	public noteBeanList() {		
		super();		
	}

	public noteBeanList(String ern) {
		this.ern=ern;				
		genList();		
	}


	public void genList() {
	ArrayList list= new ArrayList();	
	try{	
			

		dbconnect db = new dbconnect();
		con = db.getConn();
			        
		
		ResultSet rs=null;			
		Statement stmt=null;			 			 					 			 		
 		String SQL;
		
		SQL =  "SELECT DISTINCT MSG_TYPE," +			                   "TO_CHAR(START_DATE,'DD-MON-YY')||' TO '||TO_CHAR(END_DATE,'DD-MON-YY') DATE_RANGE," +			                   "ACK_TIMESTAMP,ACK_TIME "+
			  "FROM CREWDIR.V_CREW_NOTE "+
			  "WHERE ERN='"+ern+"' " +			  "ORDER BY ACK_TIMESTAMP DESC";
 			
		stmt = con.createStatement();		
		rs= stmt.executeQuery(SQL);		
		while(rs.next()){
			String msg_type = rs.getString("MSG_TYPE");
			String note_details = rs.getString("DATE_RANGE");
			String ack_time = rs.getString("ack_time");
			list.add(new noteBean(msg_type,note_details,ack_time));			
		}									        
		rs.close();
		stmt.close(); 
		
		//set return data			
	}catch (SQLException sqlex) {
		  sqlex.printStackTrace();	
		  if (con!=null) {
				try {
				   con.close();
				}catch( SQLException e){
				   e.printStackTrace();
				}		   	  
		  } //if    			

	}catch (Exception ex) {
		ex.printStackTrace();		    			
	} finally{
		if (con!=null) {
		   try {
				 con.close();
		   }catch( SQLException e){
			  e.printStackTrace();
		   }
		} //if  
	}//catch/try
	//set return  
	this.setNote_list(list);
}



/**
 * @return
 */
public ArrayList getNote_list() {
	return note_list;
}

/**
 * @param list
 */
public void setNote_list(ArrayList list) {
	note_list = list;
}


}
