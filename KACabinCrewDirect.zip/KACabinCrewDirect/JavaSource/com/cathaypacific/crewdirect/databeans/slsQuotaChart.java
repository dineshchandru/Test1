/*
 * Created on Apr 6, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cathaypacific.crewdirect.databeans;

/**
 * @author IMTVWW
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class slsQuotaChart {
	
	private String sls_start_date;
	private int quota;
	
	public slsQuotaChart()
	{
		sls_start_date = "";
		quota = 0;
	}
	
	public String getSLS_Start_Date()
	{
		return sls_start_date;
	}
	
	public void setSLS_Start_Date(String sls_start_date)
	{
		this.sls_start_date = sls_start_date;
	}
	
	public int getQuota()
	{
		return quota;
	}
	
	public void setQuota(int quota)
	{
		this.quota = quota;
	}

}
