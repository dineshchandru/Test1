/*
 * Created on Jul 12, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swapboard;


import com.cathaypacific.crewdirect.databeans.dbconnect;
import oracle.sql.*;
import java.sql.*;

public class swapBoardRequest {
	
	private Connection con;
	private String period_start;
	private String period_end;
	private String post_ern;
	private String err_msg;
	private String other_erns;
	private String other_crewid;		
	/**
	 * 
	 */
	public swapBoardRequest() {
		super();		
	}

	public swapBoardRequest(String msg_id) {
		err_msg = "no_err";
		try{	
			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs=null;			
			Statement stmt = con.createStatement();

			String SQL = "SELECT distinct ern as ern,to_char(start_date,'DD-MON-YY') as start_date, " +
						  "to_char(end_date,'DD-MON-YY') as end_date,crew_id FROM swap_msg_board "+ 
						  "WHERE msg_id='"+msg_id+"'";										
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){				
				post_ern = rs.getString("ern");
				other_erns = rs.getString("ern");
				other_crewid = rs.getString("crew_id");
				period_start = rs.getString("start_date" );
				period_end  = rs.getString("end_date" );
			}									        
			rs.close();
			stmt.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			 err_msg = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  err_msg = e.toString();
			   }
			} //if  
		}//catch/try						    	    	

				
	}


	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String getPeriod_end() {
		return period_end;
	}

	/**
	 * @return
	 */
	public String getPeriod_start() {
		return period_start;
	}

	/**
	 * @return
	 */
	public String getPost_ern() {
		return post_ern;
	}


	/**
	 * @return
	 */
	public String getOther_crewid() {
		return other_crewid;
	}

	/**
	 * @return
	 */
	public String getOther_erns() {
		return other_erns;
	}

}
