/*
 * Created on Jul 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swapboard;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class showMessage {

	private String err_msg;
	
	private msgBean [] arr_msg = new msgBean[5000]; 
	private int arr_msg_cnt = 0;
	private Connection con = null;
	
	public showMessage() {
		super();	
	}

    //only display my messages - "menu_my"
	public showMessage(String iern) {

		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs = null;			
			Statement stmt = con.createStatement();
			String SQL = new String("");
			SQL = "SELECT msg_id, ern, crew_id, cat, nvl(lang,' ') as lang, msg_type, message, to_char(start_date, 'dd Mon') as start_date, " +				  "to_char(end_date,'dd Mon') as end_date, duty, to_char(time_stamp, 'dd Mon yyyy hh24:mi') as time_log, " +				  "start_date AS ORD1, end_date as ORD2, day1, nvl(day2,' ') as day2, memo FROM swap_msg_board "+ 
				  "WHERE ERN='"+iern+"' ORDER BY ORD1, ORD2, lang";
			rs= stmt.executeQuery(SQL);		
			while(rs.next()) {
				String msg_id = rs.getString("msg_id");
				String ern = rs.getString("ern");
				String crew_id = rs.getString("crew_id");
				String cat = rs.getString("cat");
				String lang = rs.getString("lang");
				String msg_type = rs.getString("msg_type");
				String message = rs.getString("message");
				String start_date = rs.getString("start_date");
				String end_date = rs.getString("end_date");
				String duty = rs.getString("duty");
				String time_stamp = rs.getString("time_log");	   
				String period = rs.getString("start_date")+"-"+rs.getString("end_date");
				String day1 = rs.getString("day1");
				String day2 = rs.getString("day2");				
				String memo = rs.getString("memo");
				arr_msg[arr_msg_cnt] = new msgBean(msg_id,ern,crew_id,cat,lang,msg_type,message,
												   start_date,end_date,duty,time_stamp,day1,day2,memo);
				arr_msg[arr_msg_cnt].setCnt(arr_msg_cnt);
				arr_msg[arr_msg_cnt].setPeriod(period);													
				arr_msg_cnt++;																	
			}									        
			rs.close();
			stmt.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			if (con != null) {
				try {
					con.close();
				} catch( SQLException e) {
					e.printStackTrace();
				}
			} //if    			
			err_msg = sqlex.toString();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString();

		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
					err_msg = e.toString();
				}
			} //if  
		}//catch/try						    	    	
	}

//web startup page
  public void StartShowMessage(String iern) {
  	
	  try {	
		  dbconnect db = new dbconnect();
		  con = db.getConn();
		  ResultSet rs = null;			
		  Statement stmt = con.createStatement();
		  String SQL = null;
		  String mycat = "";
		  String mylang = "";
		  
		  SQL = "SELECT DISTINCT NVL(LANG_1, ' ') LANG_1, CATEGORY AS CAT FROM ISDCREW.CREW_INFO WHERE STAFFID = '"+iern+"'";
		  rs= stmt.executeQuery(SQL);		
		  while(rs.next()) {
		  	mycat  = rs.getString("CAT");
		  	mylang = rs.getString("LANG_1");
			break;		  
		  }									        
		  rs.close();

		  SQL = "SELECT MSG_ID, ERN, CREW_ID, CAT, NVL(LANG,' ') AS LANG, MSG_TYPE, MESSAGE, TO_CHAR(START_DATE, 'dd Mon') as start_date, " +
				"TO_CHAR(END_DATE, 'dd Mon') as end_date, duty, to_char(time_stamp, 'dd Mon yyyy hh24:mi') as time_log, " +
				"START_DATE AS ORD1, END_DATE AS ORD2, nvl(day1, ' ') as day1, nvl(day2,' ') as day2, memo FROM swap_msg_board "+ 
				"WHERE START_DATE >= sysdate AND END_DATE <= (sysdate + 5) "+				  
				"AND CAT = '"+mycat+"'  AND LANG LIKE '"+mylang+"%' ORDER BY ORD1, ORD2, lang";
		  rs= stmt.executeQuery(SQL);		
		  while(rs.next()) {
			  String msg_id = rs.getString("msg_id");
			  String ern = rs.getString("ern");
			  String crew_id = rs.getString("crew_id");
			  String cat = rs.getString("cat");
			  String lang = rs.getString("lang");
			  String msg_type = rs.getString("msg_type");
			  String message = rs.getString("message");
			  String start_date = rs.getString("start_date");
			  String end_date = rs.getString("end_date");
			  String duty = rs.getString("duty");
			  String time_stamp = rs.getString("time_log");	   
			  String period = rs.getString("start_date")+"-"+rs.getString("end_date");
			  String day1 = rs.getString("day1");
			  String day2 = rs.getString("day2");	
			  String memo = rs.getString("memo");			
			  arr_msg[arr_msg_cnt] = new msgBean(msg_id,ern,crew_id,cat,lang,msg_type,message,
												 start_date,end_date,duty,time_stamp,day1,day2,memo);
			  arr_msg[arr_msg_cnt].setCnt(arr_msg_cnt);
			  arr_msg[arr_msg_cnt].setPeriod(period);																	
			  arr_msg_cnt++;																	
		  }									        
		  rs.close();
		  stmt.close();
		  
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			if (con != null) {
				try {
					con.close();
				} catch( SQLException e) {
					e.printStackTrace();
				}
			} //if    			
			err_msg = sqlex.toString();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString();

		} finally {
			
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
					err_msg = e.toString();
				}
			} //if  
		}//catch/try						    	    	
	}
	
//----------------------------------------------------   
	public showMessage(String istart_date,String iend_date,String icat,String ilang) {

		try{	
			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs = null;			
			Statement stmt = con.createStatement();
			String SQL = null;

			if (ilang.equals("ALL")) {
				//show all languages						
				SQL = "SELECT msg_id, ern, crew_id, cat, nvl(lang,' ') as lang, msg_type, message, to_char(start_date, 'dd Mon') as start_date, " +
					  "to_char(end_date, 'dd Mon') as end_date, duty, to_char(time_stamp, 'dd Mon yyyy hh24:mi') as time_log, " +
					  "START_DATE AS ORD1, END_DATE AS ORD2, nvl(day1,' ') as day1, nvl(day2,' ') as day2, memo FROM swap_msg_board "+ 
					  "WHERE START_DATE >= '"+istart_date+"' AND END_DATE <= '"+iend_date+"' AND CAT = '"+icat+"' "+						  
					  "ORDER BY ORD1, ORD2, lang";
			} else {
				//show specificed language only						
				SQL = "SELECT msg_id, ern, crew_id, cat, nvl(lang,' ') as lang, msg_type, message, to_char(start_date, 'dd Mon') as start_date, " +
					  "to_char(end_date,'dd Mon') as end_date, duty, to_char(time_stamp, 'dd Mon yyyy hh24:mi') as time_log, " +
					  "START_DATE AS ORD1, END_DATE AS ORD2, nvl(day1,' ') as day1, nvl(day2,' ') as day2, memo FROM swap_msg_board "+ 
					  "WHERE START_DATE >= '"+istart_date+"' AND END_DATE <= '"+iend_date+"' "+				  
					  "AND CAT = '"+icat+"' AND LANG LIKE '"+ilang+"%' "+
				      "ORDER BY ORD1,ORD2,lang";
			}
			rs= stmt.executeQuery(SQL);		
			while(rs.next()) {
				String msg_id = rs.getString("msg_id");
				String ern = rs.getString("ern");
				String crew_id = rs.getString("crew_id");
				String cat = rs.getString("cat");
				String lang = rs.getString("lang");
				String msg_type = rs.getString("msg_type");
				String message = rs.getString("message");
				String start_date = rs.getString("start_date");
				String end_date = rs.getString("end_date");
				String duty = rs.getString("duty");
				String time_stamp = rs.getString("time_log");	   
				String period = rs.getString("start_date")+"-"+rs.getString("end_date");
				String day1 = rs.getString("day1");
				String day2 = rs.getString("day2");	
				String memo = rs.getString("memo");			
				arr_msg[arr_msg_cnt] = new msgBean(msg_id,ern,crew_id,cat,lang,msg_type,message,
												   start_date,end_date,duty,time_stamp,day1,day2,memo);
				arr_msg[arr_msg_cnt].setCnt(arr_msg_cnt);
				arr_msg[arr_msg_cnt].setPeriod(period);																	
				arr_msg_cnt++;																	
			}									        
			rs.close();
            stmt.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			if (con != null) {
				try {
					con.close();
				} catch( SQLException e) {
					e.printStackTrace();
				}
			} //if    			
			err_msg = sqlex.toString();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString();

		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
					err_msg = e.toString();
				}
			} //if  
		}//catch/try						    	    	
	}

	/**
	 * @return
	 */
	public msgBean[] getArr_msg() {
		return arr_msg;
	}

	/**
	 * @return
	 */
	public int getArr_msg_cnt() {
		return arr_msg_cnt;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}
}