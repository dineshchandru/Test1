/*
 * Created on Jul 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swapboard;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class postNewMessage {

	private String err_msg;
	
	public postNewMessage() {
		super();
	}

	public postNewMessage(String ern,String start_date,String end_date,String msg) {
		
		Connection con = null;
		String SQL=null;
		String crew_id = null;
		String lang = null;
		String duty = null;
		String cat = null;
		String msg_type = "USER";
		String day1 = "";
		String day2 = "";
		String pid = "";
		String last_day = "";
		
		int cnt= 0;
		int day_cnt = 0;
		String msg_id = null;
		int row;
	    
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs = null;			
			Statement stmt = con.createStatement();
			Statement stmtx = con.createStatement();

			//1.0 find this staff infomation
			SQL = "SELECT DISTINCT CREW_ID, NVL(LANG_1, ' ') LANG, CATEGORY AS CAT, PID FROM ISDCREW.CREW_INFO " +				  "WHERE STAFFID = '"+ern+"'";										
			rs = stmt.executeQuery(SQL);		
			while(rs.next()) {
				crew_id = rs.getString("CREW_ID");
				lang = rs.getString("LANG");				
				cat = rs.getString("CAT");
				pid = rs.getString("PID");
				break;								
			}									        
			rs.close();

			//2.0 get Duty within this period
			SQL = "SELECT TO_CHAR(ROSTER_DATE,'DD') AS RDATE, DUTY, ROSTER_DATE, SORT_ORDER " +				  "FROM CREWDIR.V_ROSTER_MASTER " +				  
				  "WHERE STAFFID = '"+ern+"' AND ROSTER_DATE BETWEEN '"+start_date+"' AND '"+end_date+"' " +				  "ORDER BY ROSTER_DATE, SORT_ORDER";				  	     										
			rs= stmt.executeQuery(SQL);
			duty = "";	
			cnt=0;
			
			while(rs.next()) {
				if (cnt == 0) {
					day1 = rs.getString("DUTY");
					last_day = rs.getString("RDATE");
					day_cnt++;
				} else {
					if (!last_day.equals(rs.getString("RDATE"))) {
						if (day_cnt == 1){
							day2 = rs.getString("DUTY");
							day_cnt++;
						}						
					}
				}
				duty = duty+"["+ rs.getString("RDATE")+"]"+rs.getString("DUTY") +" ";
				cnt++; 
			}									        
			rs.close();
				
			//3.0 get swap_board_msg_key
			SQL = "select swap_board_msg_key.nextval as msg_id from dual"; 			
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				msg_id = rs.getString("msg_id");							
			}									        
			rs.close();

			if (crew_id.indexOf("'") > 0)  //elimate double quote
				crew_id = crew_id.substring(0,crew_id.indexOf("'"))+"'"+crew_id.substring(crew_id.indexOf("'"));	    		
									
			//4.0 insert records						
			SQL ="INSERT INTO swap_msg_board " +			     "(msg_id,ern,crew_id,lang,memo,cat,msg_type,start_date,end_date,message,duty,time_stamp,day1,day2) " +			     "VALUES ('"+msg_id+"','"+ern+"','"+crew_id+"','"+lang+"','"+pid+"','"+cat+"','"+msg_type+"','"+
			 	          start_date+"','"+end_date+"','"+format_msg(msg)+"','"+duty+"',sysdate,'"+day1+"','"+day2+"')";
			row = stmtx.executeUpdate(SQL);
			if (row > 0) {
				err_msg = "no_err";		
			} else {
				err_msg = "Fail to post the new message!";
			}
			stmt.close();
			stmtx.close();

		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con != null) {
					try {
					   con.close();
					} catch( SQLException e) {
					   e.printStackTrace();
					}		   	  
			  } //if   			
			err_msg = sqlex.toString();
			
		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString();
			
		} finally {
			if (con != null) {
			   try {
			   		con.close();
			   } catch(SQLException e) {
			   		e.printStackTrace();
			   		err_msg = e.toString();
			   }
			} //if  
		}//catch/try						    	    	
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	private String format_msg(String str) {
	   String myRtn="";
	   for(int x=0; x < str.length(); x++) {
	   	  if (str.substring(x,x+1).equals("'")) {
	   	  	 myRtn = myRtn + str.substring(x,x+1)+"'";
	   	  } else {
			myRtn = myRtn + str.substring(x,x+1);
	   	  }
	   }
	   return myRtn;
	}
}