/*
 * Created on Jul 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swapboard;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;


public class deleteMessage {

	private String err_msg;

	public deleteMessage() {
		super();
	}

	public deleteMessage(String msg_id) {

		Connection con = null;
		int row;
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs=null;			
			Statement stmt = con.createStatement();
						
			String SQL ="DELETE FROM swap_msg_board WHERE msg_id='" +msg_id+"'";
			row = stmt.executeUpdate(SQL);
			if (row > 0) {
				err_msg = "no_err";		
			} else {
				err_msg = "Fail to delete the message!";
			}
			stmt.close();
			
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();
			  if (con!=null) {
					try {
						con.close();
					} catch( SQLException e) {
						e.printStackTrace();
					}	   	  
			  } //if

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 		    			
		
		} finally {
			if (con!=null) {
				try {
					con.close();
			   } catch(SQLException e) {
			   		e.printStackTrace();
			   		err_msg = e.toString();
			   }
			} //if  
		}//catch/try						    	    	
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}
}