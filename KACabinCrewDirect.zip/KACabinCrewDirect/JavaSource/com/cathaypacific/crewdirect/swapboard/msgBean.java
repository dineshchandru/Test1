/*
 * Created on Jul 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swapboard;

public class msgBean {
	private String msg_id;
	private String ern;
	private String crew_id;
	private String cat;
	private String lang;
	private String msg_type;
	private String message;
	private String start_date;
	private String end_date;
	private String duty;
	private String time_stamp;	 
	private String period; 
	private String day1;
	private String day2; 
	private String memo;

	private int cnt;

	public msgBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public msgBean(String msg_id,String ern,String crew_id,String cat,String lang,
				   String msg_type,String message,String start_date,String end_date,
				   String duty,String time_stamp,String day1,String day2,String pid) {
		this.msg_id = msg_id;
		this.ern =ern;
		this.cat =cat;
		this.crew_id = crew_id;
		this.lang = lang;
		this.msg_type = msg_type;
		this.message = message;
		this.start_date = start_date;
		this.end_date = end_date;
		this.duty = duty;
		this.time_stamp = time_stamp;
		this.day1 = day1;
		this.day2 = day2; 
		this.memo = pid;
	}

	/**
	 * @return
	 */
	public String getCat() {
		return cat;
	}

	/**
	 * @return
	 */
	public String getCrew_id() {
		return crew_id;
	}

	/**
	 * @return
	 */
	public String getDuty() {
		return duty;
	}

	/**
	 * @return
	 */
	public String getEnd_date() {
		return end_date;
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	/**
	 * @return
	 */
	public String getLang() {
		return lang;
	}

	/**
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @return
	 */
	public String getMsg_type() {
		return msg_type;
	}

	/**
	 * @return
	 */
	public String getStart_date() {
		return start_date;
	}

	/**
	 * @return
	 */
	public String getTime_stamp() {
		return time_stamp;
	}

	/**
	 * @param string
	 */
	public void setCat(String string) {
		cat = string;
	}

	/**
	 * @param string
	 */
	public void setCrew_id(String string) {
		crew_id = string;
	}

	/**
	 * @param string
	 */
	public void setDuty(String string) {
		duty = string;
	}

	/**
	 * @param string
	 */
	public void setEnd_date(String string) {
		end_date = string;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param string
	 */
	public void setLang(String string) {
		lang = string;
	}

	/**
	 * @param string
	 */
	public void setMessage(String string) {
		message = string;
	}

	/**
	 * @param string
	 */
	public void setMsg_type(String string) {
		msg_type = string;
	}

	/**
	 * @param string
	 */
	public void setStart_date(String string) {
		start_date = string;
	}

	/**
	 * @param string
	 */
	public void setTime_stamp(String string) {
		time_stamp = string;
	}

	/**
	 * @return
	 */
	public int getCnt() {
		return cnt;
	}

	/**
	 * @param i
	 */
	public void setCnt(int i) {
		cnt = i;
	}

	/**
	 * @return
	 */
	public String getMsg_id() {
		return msg_id;
	}

	/**
	 * @param string
	 */
	public void setMsg_id(String string) {
		msg_id = string;
	}

	/**
	 * @return
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param string
	 */
	public void setPeriod(String string) {
		period = string;
	}

	/**
	 * @return
	 */
	public String getDay1() {
		return day1;
	}

	/**
	 * @return
	 */
	public String getDay2() {
		return day2;
	}

	/**
	 * @param string
	 */
	public void setDay1(String string) {
		day1 = string;
	}

	/**
	 * @param string
	 */
	public void setDay2(String string) {
		day2 = string;
	}

	/**
	 * @return
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * @param string
	 */
	public void setMemo(String string) {
		memo = string;
	}

}
