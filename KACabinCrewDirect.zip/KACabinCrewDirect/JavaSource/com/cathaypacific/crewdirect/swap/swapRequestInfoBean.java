/*
 * Created on Jul 29, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class swapRequestInfoBean {

	private String SwapStartDate;
	private String SwapEndDate;
	private String [] crew_id ;
	private String [] erns ;
	private int erns_cnt;
	
	
	/**
	 * 
	 */
	public swapRequestInfoBean() {
		super();
	}


	public swapRequestInfoBean(String s_date,String e_date,int erns_cnt,String [] ern,String []crew_id) {
		this.SwapStartDate = s_date;		
		this.SwapEndDate = e_date;
		this.crew_id = crew_id;
		this.erns = ern;
		this.erns_cnt = erns_cnt;		
	}

	/**
	 * @return
	 */
	public String[] getCrew_id() {
		return crew_id;
	}

	/**
	 * @return
	 */
	public String[] getErns() {
		return erns;
	}

	/**
	 * @return
	 */
	public int getErns_cnt() {
		return erns_cnt;
	}

	/**
	 * @return
	 */
	public String getSwapEndDate() {
		return SwapEndDate;
	}

	/**
	 * @return
	 */
	public String getSwapStartDate() {
		return SwapStartDate;
	}

	/**
	 * @param strings
	 */
	public void setCrew_id(String[] strings) {
		crew_id = strings;
	}

	/**
	 * @param strings
	 */
	public void setErns(String[] strings) {
		erns = strings;
	}

	/**
	 * @param i
	 */
	public void setErns_cnt(int i) {
		erns_cnt = i;
	}

	/**
	 * @param string
	 */
	public void setSwapEndDate(String string) {
		SwapEndDate = string;
	}

	/**
	 * @param string
	 */
	public void setSwapStartDate(String string) {
		SwapStartDate = string;
	}

}
