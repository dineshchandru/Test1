
package com.cathaypacific.crewdirect.swap;

import java.util.Date;

public class sw_r_RosterDateBean {
	private String ern;
	private Date r_date;
	private String action_type;
	private String reason;
	
	public sw_r_RosterDateBean(String ern,Date r_date,String action_type,String reason) {
		this.ern =ern;
		this.r_date = r_date;
		this.action_type = action_type;
		this.reason = reason;
	}
	
	public sw_r_RosterDateBean() {
		super();
	}

	/**
	 * @return
	 */
	public String getAction_type() {
		return action_type;
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	/**
	 * @return
	 */
	public Date getR_date() {
		return r_date;
	}

	/**
	 * @return
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param string
	 */
	public void setAction_type(String string) {
		action_type = string;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param date
	 */
	public void setR_date(Date date) {
		r_date = date;
	}

	/**
	 * @param string
	 */
	public void setReason(String string) {
		reason = string;
	}

}
