/*
 * Created on Jun 3, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

public class eswapLogicResultBean {

	String ern;
	String type;
	String haveError;
	String err_msg="";
	String success;
	String crew_id;
	String swapnumber="";
	
	public eswapLogicResultBean(String ern,String crew_id,String type,String haveError,String err_msg) {
		this.ern = ern;
		this.crew_id = crew_id;
		this.type = type;
		this.err_msg = err_msg;
		this.haveError = haveError;
		if (haveError.equals("Y" )){
			success = "Failed";
		}else{
			success = "Success";
		}		
	}

	public eswapLogicResultBean(String ern,String crew_id,String type,String haveError) {
		this.ern = ern;
		this.crew_id = crew_id;
		this.type = type;
		this.haveError = haveError;		
		if (haveError.equals("Y" )){
			success = "Failed";
		}else{
			success = "Success";
		}
	
	}

	
	public eswapLogicResultBean() {
		super();
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String getHaveError() {
		return haveError;
	}

	/**
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param string
	 */
	public void setErr_msg(String string) {
		err_msg = string;
	}

	/**
	 * @param string
	 */
	public void setHaveError(String string) {
		haveError = string;
	}

	/**
	 * @param string
	 */
	public void setType(String string) {
		type = string;
	}

	/**
	 * @return
	 */
	public String getSuccess() {
		return success;
	}

	/**
	 * @param string
	 */
	public void setSuccess(String string) {
		success = string;
	}

	/**
	 * @return
	 */
	public String getCrew_id() {
		return crew_id;
	}

	/**
	 * @param string
	 */
	public void setCrew_id(String string) {
		crew_id = string;
	}

	/**
	 * @return
	 */
	public String getSwapnumber() {
		return swapnumber;
	}

	/**
	 * @param string
	 */
	public void setSwapnumber(String string) {
		swapnumber = string;
	}

}
