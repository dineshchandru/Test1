/*
 * Created on Sep 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.roster.othsRosterBean;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class eswapRequestingRosterCheck {
	private Connection con=null;
	
	private String err_msg = "no_err";
	
	private othsRosterBean[] rosters_req_cur = new othsRosterBean[100];
	private othsRosterBean[] rosters_req_save = new othsRosterBean[100];
	int req_cur_cnt =0;
	int req_save_cnt =0;	
	private othsRosterBean[] rosters_acp_cur = new othsRosterBean[100];
	private othsRosterBean[] rosters_acp_save = new othsRosterBean[100];
	int acp_cur_cnt =0;
	int acp_save_cnt =0;
			
	public eswapRequestingRosterCheck() {
		super();
	}

	public eswapRequestingRosterCheck(String SwapNo ) {
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt=con.createStatement();
		    String SQL;
		    String req_ern="";
		    String acp_ern="";
		    String sw_start ="";
		    String sw_end ="";
		    
		
		    //1.0 get swap details
			SQL = "select req_key,last_status,req_id,acp_id," +
				  "to_char(period_start,'DD-MON-YY') as s_date,to_char(period_end,'DD-MON-YY') as e_date " +
				  "from crewdir.swap_req where req_key = '"+SwapNo+"'"; 			 		
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				req_ern = rs.getString("req_id");
				acp_ern = rs.getString("acp_id");
				sw_start = rs.getString("s_date");
				sw_end = rs.getString("e_date");
			}
			rs.close();
		
	        //2.0 get current roster of request party
			SQL =  "SELECT DISTINCT * " +
				   "FROM CREWDIR.V_ROSTER_MASTER "+
				   "WHERE STAFFID='"+req_ern+"' AND ROSTER_DATE BETWEEN '"+sw_start+"' AND '"+sw_end+"'" +
				   "ORDER BY ROSTER_DATE,sort_order";				   
					
			rs= stmt.executeQuery(SQL);
			req_cur_cnt=0;			
			while(rs.next()){										
				String ern         = rs.getString("STAFFID");
				Date roster_date   = rs.getDate("ROSTER_DATE");
				String duty        = rs.getString("DUTY");						
				String sp_duty     = rs.getString("SP_DUTY");					 		
				othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty," ");
				rosters_req_cur[req_cur_cnt] = myBean;
				req_cur_cnt++;
			}
			rs.close();

          
            //2.1 get save roster while create invitation
			SQL =  "SELECT DISTINCT * " +
				   "FROM CREWDIR.SWAP_REQ_ROSTER "+
			        "WHERE REQ_KEY = '"+SwapNo+"' AND ERN='"+req_ern+"'"+				   
				   "ORDER BY ROSTER_DATE,sort_order";				   
					
			rs= stmt.executeQuery(SQL);
			req_save_cnt=0;			
			while(rs.next()){										
				String ern         = rs.getString("ERN");
				Date roster_date   = rs.getDate("ROSTER_DATE");
				String duty        = rs.getString("DUTY");						
				String sp_duty     = rs.getString("SP_DUTY");					 		
				othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty," ");
				rosters_req_save[req_save_cnt] = myBean;
				req_save_cnt++;
			}
			rs.close();
            
            
            //2.2 compare rosters
            if (req_cur_cnt != req_save_cnt){
				err_msg ="#"+ SwapNo + " inviter roster has changed.";
            }else{
            	//2.2.1 put okay mark 
				for (int x=0;x<req_cur_cnt;x++)
            	     for (int y=0;y<req_save_cnt;y++)
            	     	if (rosters_req_cur[x].getRoster_date().equals(rosters_req_save[y].getRoster_date()))
            	     	   if (rosters_req_cur[x].getDuty().equals(rosters_req_save[y].getDuty()) )
            	     	       rosters_req_cur[x].setEswap("OK"); 
				
				//2.2.2 check okay mark
				for (int z=0;z<req_cur_cnt;z++)
					if (!rosters_req_cur[z].getEswap().equals("OK") )
					    err_msg = "#"+SwapNo + " inviter roster on ["+rosters_req_cur[z].getRoster_date()+"] has changed.";					
								
            }
                
			if (err_msg.equals( "no_err")){			
				//3.0 get current roster of accepted party
				SQL =  "SELECT DISTINCT * " +
					   "FROM CREWDIR.V_ROSTER_MASTER "+
					   "WHERE STAFFID='"+acp_ern+"' AND ROSTER_DATE BETWEEN '"+sw_start+"' AND '"+sw_end+"'" +
					   "ORDER BY ROSTER_DATE,sort_order";				   
						
				rs= stmt.executeQuery(SQL);
				acp_cur_cnt=0;			
				while(rs.next()){										
					String ern         = rs.getString("STAFFID");
					Date roster_date   = rs.getDate("ROSTER_DATE");
					String duty        = rs.getString("DUTY");						
					String sp_duty     = rs.getString("SP_DUTY");					 		
					othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty," ");
					rosters_acp_cur[acp_cur_cnt] = myBean;
					acp_cur_cnt++;
				}
				rs.close();
	
	          
				//3.1 get save roster while create invitation
				SQL =  "SELECT DISTINCT * " +
					   "FROM CREWDIR.SWAP_REQ_ROSTER "+
						"WHERE REQ_KEY = '"+SwapNo+"' AND ERN='"+acp_ern+"'"+					   
					   "ORDER BY ROSTER_DATE,sort_order";				   
						
				rs= stmt.executeQuery(SQL);
				acp_save_cnt=0;			
				while(rs.next()){										
					String ern         = rs.getString("ERN");
					Date roster_date   = rs.getDate("ROSTER_DATE");
					String duty        = rs.getString("DUTY");						
					String sp_duty     = rs.getString("SP_DUTY");					 		
					othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty," ");
					rosters_acp_save[acp_save_cnt] = myBean;
					acp_save_cnt++;
				}
				rs.close();
	            
	            
				//3.2 compare rosters
				if (acp_cur_cnt != acp_save_cnt){
					err_msg = "#"+ SwapNo + " receiver roster has changed.";
				}else{
					//3.2.1 put okay mark 
					for (int x=0;x<acp_cur_cnt;x++)
						 for (int y=0;y<acp_save_cnt;y++)
							if (rosters_acp_cur[x].getRoster_date().equals(rosters_acp_save[y].getRoster_date()))
							   if (rosters_acp_cur[x].getDuty().equals(rosters_acp_save[y].getDuty()))
								   rosters_acp_cur[x].setEswap("OK"); 
					
					//3.2.2 check okay mark
					for (int z=0;z<acp_cur_cnt;z++)
						if (!rosters_acp_cur[z].getEswap().equals("OK"))
							err_msg = "#"+ SwapNo + " receiver roster on ["+rosters_acp_cur[z].getRoster_date()+"] has changed.";														
				}
			
			}//3.0
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_msg = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString() ;		    			
		} finally{
			if (con!=null) {
				  try {
					 con.close();
				  }catch( SQLException e){
					 e.printStackTrace();
				  }		   	  
			} //if    			

		}//catch/try
										
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

}
