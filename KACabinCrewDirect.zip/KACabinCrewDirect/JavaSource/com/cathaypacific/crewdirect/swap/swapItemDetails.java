package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class swapItemDetails {
	
	private Connection con=null;
	
	private swapItemHistoryBean [] hist_lst = new swapItemHistoryBean[50];
	private int hist_lst_cnt=0;

	private swapPartnerInfoBean partner_info = new swapPartnerInfoBean();

	private String [][] req_roster = new String [100][2];
	private String [][] req_roster_save = new String [100][2];
	private int req_roster_cnt=0;
	private int req_roster_save_cnt=0;
	
	private String [][] acp_roster  = new String [100][2];
	private String [][] acp_roster_save  = new String [100][2];
	private int acp_roster_cnt=0;
	private int acp_roster_save_cnt=0;

	private String [] action_lst = new String [100];
	private int action_lst_cnt =0;
	
	private swapItemDetailsContactBean Req_Info = new swapItemDetailsContactBean() ;
	private swapItemDetailsContactBean Acp_Info = new swapItemDetailsContactBean();

	private swapEnquiryBean [] dependant_sw = new swapEnquiryBean [100];
	private int dependant_sw_cnt =0;
	
	private boolean have_accept_action = false;
		
	private String req_ern;
	private String acp_ern;

	private String req_crew_id;
	private String acp_crew_id;

	private String req_cat_sen;
	private String acp_cat_sen;

	private String swap_id;
	private String swapStatus;
	private String swapRemark;
	private String iern;
    	
	public swapItemDetails() {
		super();
	}

	public swapItemDetails(String swap_key,String ern) {
		this.iern = ern;	
		this.swap_id = swap_key;
		getItemList(swap_key);
	}

	public void getItemList(String swap_key) {

		String SQL=null;
		String PeriodStart="";
		String PeriodEnd="";
		String swapStatus="";
		String txtTemp="";		   
		int cnt=0;
		
		try {	
			//1.0 setup db connection
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt= con.createStatement();
			
			//2.0 get request swap_key details
			SQL =   "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID, TO_CHAR(PERIOD_START,'DD-MON-YY') AS S_DATE, " +				    "TO_CHAR(PERIOD_END,'DD-MON-YY') AS E_DATE, LAST_STATUS, TIME_LOG, NVL(REMARK,' ') AS REMARK " +					   					   							          
					"FROM CREWDIR.SWAP_REQ "+
					"WHERE REQ_KEY='" +swap_key+ "' ";
			rs= stmt.executeQuery(SQL);
			while(rs.next()){																					
				 swapRemark  = rs.getString("REMARK");
				 PeriodStart = rs.getString("S_DATE");
				 PeriodEnd = rs.getString("E_DATE");				 				 
				 swapStatus = rs.getString("LAST_STATUS");
			 	 req_ern = rs.getString("REQ_ID");
				 acp_ern = rs.getString("ACP_ID");			 	 				 
				 break;			 
			}									        
			rs.close();
			 
			//3.0 get Contact information of both party
			//3.1 for requester
			SQL = "SELECT DISTINCT x.ROSTER_INFO as P_ROSTER_INFO, x.MAIL_BOX as P_MAILBOX, x.P_PHONE as P_P_PHONE, " +				  "x.S_PHONE as P_S_PHONE, x.GALACXY_ID as P_GALACXY_ID, x.COS as P_COS, " +
				  "y.CREDIT_SCHEME as COS, y.PID as PID, y.MAIL_BOX as MAILBOX, y.CREW_ID as CREW_ID, Y.CAT as FULL_CAT, "+
				  "NVL(y.LOCAL_TEL_1, ' ') as P_PHONE, NVL(y.LOCAL_TEL_2, ' ') as S_PHONE " +
				  "FROM CREWDIR.KA_CREW_PROFILE x, ISDCREW.CREW_BASIC y " +
				  "WHERE x.STAFFID='"+req_ern+"' AND x.STAFFID = y.ern";
			rs= stmt.executeQuery(SQL);
			while(rs.next()){
				//CREW ID 
				req_crew_id = rs.getString("CREW_ID");
				//CATEGORY - QFPNN
				req_cat_sen = rs.getString("FULL_CAT");
				//Roster Info
				txtTemp = rs.getString("P_ROSTER_INFO").equals("Y")?rs.getString("P_ROSTER_INFO"):"Not Disclosed";								
				Req_Info.setRoster_info(txtTemp);			
				//MailBox
				txtTemp = rs.getString("P_MAILBOX").equals("Y")?rs.getString("MAILBOX"):"Not Disclosed";
				Req_Info.setMailbox(txtTemp);
				//COS
				txtTemp = rs.getString("P_COS").equals("Y")?rs.getString("COS"):"Not Disclosed";
				Req_Info.setCos(txtTemp);
				//Primary Phone
				txtTemp = rs.getString("P_P_PHONE").equals("Y")?rs.getString("P_PHONE"):"Not Disclosed";
				Req_Info.setP_phone(txtTemp);
				//Secondary Phone
				txtTemp = rs.getString("P_S_PHONE").equals("Y")?rs.getString("S_PHONE"):"Not Disclosed";
				Req_Info.setS_phone(txtTemp);
				//Galaxcy_ID
				txtTemp = rs.getString("P_GALACXY_ID").equals("Y")?rs.getString("PID"):"Not Disclosed";
				Req_Info.setGalacxy_id(txtTemp);
				break;
			}												        
			rs.close();

			//3.2 for acceptor
			SQL = "SELECT DISTINCT x.ROSTER_INFO as P_ROSTER_INFO, x.MAIL_BOX as P_MAILBOX, x.P_PHONE as P_P_PHONE, " +
				  "x.S_PHONE as P_S_PHONE, x.GALACXY_ID as P_GALACXY_ID, x.COS as P_COS, " +
				  "y.CREDIT_SCHEME as COS, y.PID as PID,y.MAIL_BOX as MAILBOX, y.CREW_ID as CREW_ID, Y.CAT as FULL_CAT, " +
				  "NVL(y.LOCAL_TEL_1, ' ') as P_PHONE, NVL(y.LOCAL_TEL_2, ' ') as S_PHONE " +
				  "FROM CREWDIR.KA_CREW_PROFILE x, ISDCREW.CREW_BASIC y " +
				  "WHERE x.STAFFID='"+acp_ern+"' AND x.STAFFID = y.ern";
			rs= stmt.executeQuery(SQL);
			while(rs.next()){
				//CREW ID 
				acp_crew_id = rs.getString("CREW_ID");
				//CATEGORY - QFPNN
				acp_cat_sen = rs.getString("FULL_CAT");
				//Roster Info
				txtTemp = rs.getString("P_ROSTER_INFO").equals("Y")?rs.getString("P_ROSTER_INFO"):"Not Disclosed";								
				Acp_Info.setRoster_info(txtTemp);			
				//MailBox
				txtTemp = rs.getString("P_MAILBOX").equals("Y")?rs.getString("MAILBOX"):"Not Disclosed";
				Acp_Info.setMailbox(txtTemp);
				//COS
				txtTemp = rs.getString("P_COS").equals("Y")?rs.getString("COS"):"Not Disclosed";
				Acp_Info.setCos(txtTemp);
				//Primary Phone
				txtTemp = rs.getString("P_P_PHONE").equals("Y")?rs.getString("P_PHONE"):"Not Disclosed";
				Acp_Info.setP_phone(txtTemp);
				//Secondary Phone
				txtTemp = rs.getString("P_S_PHONE").equals("Y")?rs.getString("S_PHONE"):"Not Disclosed";
				Acp_Info.setS_phone(txtTemp);
				//Galaxcy_ID
				txtTemp = rs.getString("P_GALACXY_ID").equals("Y")?rs.getString("PID"):"Not Disclosed";
				Acp_Info.setGalacxy_id(txtTemp);
				break;
			}												        
			rs.close();

			//3.3 set partner_info
			partner_info.setSwap_no(swap_id);
			partner_info.setInv_from(req_crew_id);
			partner_info.setInv_to(acp_crew_id);
			partner_info.setPeriod(PeriodStart+" to "+PeriodEnd );
			partner_info.setReq_info(Req_Info);
			partner_info.setAcp_info(Acp_Info);
			
			//4.0 Gettig a list of action allow in current status
			setAction_lst(swapStatus);					
			//4.1  show dependant swap list if allow action having "Accept"
			if (have_accept_action){
				// invitation being sent			 			 					 			 		
				SQL = "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID, " +
					  "TO_CHAR(PERIOD_START, 'DDMON')||' - '||TO_CHAR(PERIOD_END, 'DDMON') AS PERIOD," +
					  "LAST_STATUS, TO_CHAR(TIME_LOG,'DD-MON-YY HH24:MI:SS') AS TIME_LOG " +							          
					  "FROM CREWDIR.SWAP_REQ "+
					  "WHERE REQ_ID='"+req_ern+"' AND " +
					  "UPPER(LAST_STATUS) IN ('ACCEPTED (INVITER READ)','ACCEPTED')";	
				rs= stmt.executeQuery(SQL);
				while(rs.next()){																	
					String type      = "INVITE";
					String id        = rs.getString("REQ_KEY");
					String period    = rs.getString("PERIOD");						
					String timestamp = rs.getString("TIME_LOG");
					String status    = rs.getString("LAST_STATUS");													
					swapEnquiryBean myDepBean = new swapEnquiryBean(type,id,period,timestamp,status);
					dependant_sw[dependant_sw_cnt] = myDepBean;												
					dependant_sw_cnt++;											
				}									        
				rs.close();				 				
			}
					
			//5.0 get Item history list from swap_status table			 			 					 			 					
			SQL = "SELECT DISTINCT REQ_KEY, STATUS, WHOM, NVL(REMARK,' ') AS REMARK," +					   
				  "TO_CHAR(TIME_LOG, 'DD-MON-YY HH24:MI:SS') AS TIME_LOG, TIME_LOG AS TIME_ORDER " +							          
				  "FROM CREWDIR.SWAP_STATUS "+
				  "WHERE REQ_KEY='" +swap_key+ "' "+
				  "ORDER BY TIME_ORDER ASC";
			rs= stmt.executeQuery(SQL);
			while(rs.next()){																					
				String status    = rs.getString("STATUS");
				String whom      = rs.getString("WHOM");						
				String remark    = rs.getString("REMARK");
				String timelog   = rs.getString("TIME_LOG");															
				hist_lst[hist_lst_cnt] = new swapItemHistoryBean(timelog,status,whom,remark);
				hist_lst_cnt++;								
			}									        
			rs.close();
			  						   
			//6.0 get both party saved roster info (if case)
			//6.1.1 accepter get current roster by startdate - 5 & + 5 days
			SQL = "SELECT DISTINCT TO_CHAR(ROSTER_DATE,'DD-MON-YY') AS RDATE,ROSTER_DATE, NVL(DUTY,' ') as DUTY, NVL(SP_DUTY,' ') as SP_DUTY, NVL(SECTOR_FROM||SECTOR_TO,' ') AS SECTOR, SORT_ORDER " +
				  "FROM CREWDIR.V_ROSTER_MASTER "+
				  "WHERE STAFFID='"+acp_ern+"' AND ROSTER_DATE BETWEEN to_date('"+PeriodStart+"','DD-MON-YY')-5 AND to_date('" +PeriodEnd +"','DD-MON-YY')+5 "+
				  "ORDER BY ROSTER_DATE,SORT_ORDER";
			rs= stmt.executeQuery(SQL);
			cnt=0;						

			while(rs.next()) {
				if (cnt == 0) {
					//1st element
					acp_roster_cnt=0;				
					acp_roster[acp_roster_cnt][0] = rs.getString("RDATE");;
					if (rs.getString("SP_DUTY").equals(" "))
						acp_roster[acp_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
					else
						acp_roster[acp_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
				} else {				
					if (acp_roster[acp_roster_cnt][0].equals(rs.getString("RDATE"))) {
						//same date add <BR>
						if (rs.getString("SP_DUTY").equals(" " ))
							acp_roster[acp_roster_cnt][1] = acp_roster[acp_roster_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							acp_roster[acp_roster_cnt][1] = acp_roster[acp_roster_cnt][1]+"<BR>"+ rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");						
					} else {
						//add to new row
						acp_roster_cnt++;
						acp_roster[acp_roster_cnt][0] = rs.getString("RDATE");;
						if (rs.getString("SP_DUTY").equals(" " ))
							acp_roster[acp_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							acp_roster[acp_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");										    	
					}
				}
				cnt++;
			}												        
			rs.close();

			//6.1.2 get Accepter saved rosters			
			SQL =   "SELECT DISTINCT TO_CHAR(ROSTER_DATE,'DD-MON-YY') AS RDATE,ROSTER_DATE,nvl(DUTY,' ') as DUTY, NVL(SP_DUTY,' ') as SP_DUTY, NVL(SECTOR_FROM||SECTOR_TO,' ') AS SECTOR, SORT_ORDER " +
					"FROM CREWDIR.V_SWAP_SAVE_ROSTER "+
					"WHERE ERN='"+acp_ern+"' AND REQ_KEY='"+swap_id+"' " +					"ORDER BY ROSTER_DATE,SORT_ORDER";
			rs= stmt.executeQuery(SQL);
			cnt = 0 ;			
			while(rs.next()){
				if (cnt == 0) {
					//1st element
					acp_roster_save_cnt=0;
					acp_roster_save[acp_roster_save_cnt][0] = rs.getString("RDATE");
					if (rs.getString("SP_DUTY").equals(" " ))
						acp_roster_save[acp_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
					else
						acp_roster_save[acp_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
				} else {
					//other elements
					if (acp_roster_save[acp_roster_save_cnt][0].equals(rs.getString("RDATE"))){
						//append <BR>
						if (rs.getString("SP_DUTY").equals(" " ))
							acp_roster_save[acp_roster_save_cnt][1] = acp_roster_save[acp_roster_save_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							acp_roster_save[acp_roster_save_cnt][1] = acp_roster_save[acp_roster_save_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");						
					} else {
						//add new row						
						acp_roster_save_cnt++;
						acp_roster_save[acp_roster_save_cnt][0] = rs.getString("RDATE");
						if (rs.getString("SP_DUTY").equals(" " ))
							acp_roster_save[acp_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							acp_roster_save[acp_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
					}
				}												
				cnt++;																	
			}												        
			rs.close();
			 
			//6.2 get Requester rosters			
			//6.2.1 requester get current roster by startdate - 5+5
			SQL =   "SELECT DISTINCT TO_CHAR(ROSTER_DATE,'DD-MON-YY') AS RDATE, ROSTER_DATE, NVL(DUTY,' ') as DUTY, NVL(SP_DUTY,' ') AS SP_DUTY, NVL(SECTOR_FROM||SECTOR_TO,' ' ) AS SECTOR,SORT_ORDER " +
					"FROM CREWDIR.V_ROSTER_MASTER "+
					"WHERE STAFFID='"+req_ern+"' AND ROSTER_DATE BETWEEN to_date('"+PeriodStart+"','DD-MON-YY')-5  AND to_date('" +PeriodEnd +"','DD-MON-YY') + 5"+
					"ORDER BY ROSTER_DATE,SORT_ORDER";
			rs= stmt.executeQuery(SQL);
			cnt = 0 ;			
			while(rs.next()) {
				if (cnt==0) {
					//1st element
					req_roster_cnt=0;
					req_roster[req_roster_cnt][0] = rs.getString("RDATE");
					if (rs.getString("SP_DUTY").equals(" " ))
						req_roster[req_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
					else
						req_roster[req_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");					
				} else {
					//other elements
					if (req_roster[req_roster_cnt][0].equals(rs.getString("RDATE"))){
						//append <BR>
						if (rs.getString("SP_DUTY").equals(" " ))
							req_roster[req_roster_cnt][1] = req_roster[req_roster_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							req_roster[req_roster_cnt][1] = req_roster[req_roster_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");					
					} else {
						//add new row
						req_roster_cnt++;
						req_roster[req_roster_cnt][0] = rs.getString("RDATE");
						if (rs.getString("SP_DUTY").equals(" " ))
							req_roster[req_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							req_roster[req_roster_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");					
					}
				}
				cnt++;																	
			}												        
			rs.close();

			//6.2.2  get Requester saved rosters			
			SQL =   "SELECT DISTINCT TO_CHAR(ROSTER_DATE,'DD-MON-YY') AS RDATE, ROSTER_DATE, NVL(DUTY,' ') as DUTY, NVL(SP_DUTY,' ') AS SP_DUTY, NVL(SECTOR_FROM||SECTOR_TO,' ' ) AS SECTOR,SORT_ORDER " +
					"FROM CREWDIR.V_SWAP_SAVE_ROSTER "+
					"WHERE ERN='"+req_ern+"' AND REQ_KEY='"+swap_id+"' " +
					"ORDER BY ROSTER_DATE,SORT_ORDER";
			rs= stmt.executeQuery(SQL);
			cnt = 0;			
			while(rs.next()){
				if (cnt==0){
					//1st element
					req_roster_save_cnt=0;
					req_roster_save[req_roster_save_cnt][0] = rs.getString("RDATE");
					if (rs.getString("SP_DUTY").equals(" " ))
						req_roster_save[req_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
					else
						req_roster_save[req_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
				} else {
					//other elements
					if (req_roster_save[req_roster_save_cnt][0].equals(rs.getString("RDATE"))){
						//append <BR>
						if (rs.getString("SP_DUTY").equals(" " ))
							req_roster_save[req_roster_save_cnt][1] = req_roster_save[req_roster_save_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							req_roster_save[req_roster_save_cnt][1] = req_roster_save[req_roster_save_cnt][1]+"<BR>"+rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
					} else {
						//add new row
						req_roster_save_cnt++;
						req_roster_save[req_roster_save_cnt][0] = rs.getString("RDATE");
						if (rs.getString("SP_DUTY").equals(" " ))
							req_roster_save[req_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR");
						else
							req_roster_save[req_roster_save_cnt][1] = rs.getString("DUTY")+" "+rs.getString("SECTOR")+"/"+rs.getString("SP_DUTY");
					}
				}
				cnt++;								
			}												        
			rs.close(); 
            stmt.close();			

		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					} catch(SQLException e) {
					   e.printStackTrace();
					}		   	  
			  } //if    			

		} catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally {
			if (con!=null) {
			   try {
					 con.close();
			   } catch( SQLException e) {
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try			
	}

	/**
	 * @param strings
	 */
	public void setAction_lst(String status) {
		//Here is action & Status available
		//Not-Opened (when invitation sent)
		//Read (receiver) (When the invitation is opened)
		//Decline (When crew wants to turndown the offer)
		//Accept (When crew accepts the offer)
		//Inviter_Read (When inviting pary read)		
		//Change_to_decline  (When crew wants to change her mind)
		//Sent_to_Crew_Control [Requesting] (when the request is sent to Crew Control)
		//Withdraw (when crew want to change their mind before ICM has processed the swap.)
		//Processing (requst already send to ICM) 
         //Swap_Over_Swap (Assigned by Admin)
		
		String tmp[] = new String [5];
		have_accept_action = false;
		//1.0 action available for requester 		
		if (iern.equals(req_ern)) {
			
			if (status.equals("New request")) {
				 tmp[0] = "Delete";
				 action_lst_cnt = 1;
			}
			
			if (status.equals("Read by receiver" )) {
				 tmp[0] = "Delete";
				 action_lst_cnt = 1;
			}

			if (status.equals("Declined")) {
				 tmp[0] = "Delete";
				 action_lst_cnt = 1;
			}

			if (status.equals("Declined (inviter read)")) {
				 tmp[0] = "Delete";
				 action_lst_cnt = 1;
			}
			
			if (status.equals("Accepted")) {
				 have_accept_action = true;
				 tmp[0] = "Requesting";
				 tmp[1] = "Delete";
				 action_lst_cnt = 2;
			}

			if (status.equals("Cencel swap")) {
				 tmp[0] = "Delete";
				 action_lst_cnt = 1;
			}
			
			if (status.equals("Accepted (inviter read)")) {
				 have_accept_action = true;
				 tmp[0] = "Requesting";
				 tmp[1] = "Delete";
				 action_lst_cnt = 2;
			}
			
			if (status.equals("Processing")) {				 
				 tmp[0] = "Inviter requests to withdraw";				 
				 action_lst_cnt = 1;
			}

			if (status.equals("Receiver requests to withdraw" )) {				 
				 tmp[0] = "Send withdrawal request to ICM";
				 action_lst_cnt = 1;
			}
			
		} else {
			//2.0 action available for accepter
			if (iern.equals(acp_ern)) {
			     	
				if (status.equals("New request")) {
					 tmp[0] = "Accepted";
					 tmp[1] = "Declined";					 
					 action_lst_cnt = 2;
				}

				if (status.equals("Accepted")) {					 					 
					 tmp[0] = "Cancel swap";
					 action_lst_cnt = 1;
				}

				if (status.equals("Accepted (inviter read)")) {
					tmp[0] = "Cancel swap";
					action_lst_cnt = 1;
				}

				if (status.equals("Read by receiver")) {
					 tmp[0] = "Accepted";
					 tmp[1] = "Declined";
					 action_lst_cnt = 2;
				}

				if (status.equals("Processing")) {				 
					 tmp[0] = "Receiver requests to withdraw";					 					 
					 action_lst_cnt = 1;
				}

				if (status.equals("Inviter requests to withdraw")) {				 
					 tmp[0] = "Send withdrawal request to ICM";
					 action_lst_cnt = 1;
				}
			}
		}
		this.action_lst = tmp;
	}
    //--------------------------

	/**
	 * @return
	 */
	public String getAcp_crew_id() {
		return acp_crew_id;
	}

	/**
	 * @return
	 */
	public String getAcp_ern() {
		return acp_ern;
	}

	/**
	 * @return
	 */
	public swapItemDetailsContactBean getAcp_Info() {
		return Acp_Info;
	}

	/**
	 * @return
	 */
	public String[][] getAcp_roster() {
		return acp_roster;
	}

	/**
	 * @return
	 */
	public int getAcp_roster_cnt() {
		return acp_roster_cnt;
	}

	/**
	 * @return
	 */
	public String[] getAction_lst() {
		return action_lst;
	}

	/**
	 * @return
	 */
	public int getAction_lst_cnt() {
		return action_lst_cnt;
	}

	/**
	 * @return
	 */
	public swapEnquiryBean[] getDependant_sw() {
		return dependant_sw;
	}

	/**
	 * @return
	 */
	public int getDependant_sw_cnt() {
		return dependant_sw_cnt;
	}

	/**
	 * @return
	 */
	public boolean isHave_accept_action() {
		return have_accept_action;
	}

	/**
	 * @return
	 */
	public swapItemHistoryBean[] getHist_lst() {
		return hist_lst;
	}

	/**
	 * @return
	 */
	public int getHist_lst_cnt() {
		return hist_lst_cnt;
	}

	/**
	 * @return
	 */
	public swapPartnerInfoBean getPartner_info() {
		return partner_info;
	}

	/**
	 * @return
	 */
	public String getReq_crew_id() {
		return req_crew_id;
	}

	/**
	 * @return
	 */
	public String getReq_ern() {
		return req_ern;
	}

	/**
	 * @return
	 */
	public swapItemDetailsContactBean getReq_Info() {
		return Req_Info;
	}

	/**
	 * @return
	 */
	public String[][] getReq_roster() {
		return req_roster;
	}

	/**
	 * @return
	 */
	public int getReq_roster_cnt() {
		return req_roster_cnt;
	}

	/**
	 * @return
	 */
	public String getSwap_id() {
		return swap_id;
	}

	/**
	 * @return
	 */
	public String getSwapRemark() {
		return swapRemark;
	}

	/**
	 * @return
	 */
	public String getSwapStatus() {
		return swapStatus;
	}

	/**
	 * @return
	 */
	public String[][] getAcp_roster_save() {
		return acp_roster_save;
	}

	/**
	 * @return
	 */
	public int getAcp_roster_save_cnt() {
		return acp_roster_save_cnt;
	}

	/**
	 * @return
	 */
	public String[][] getReq_roster_save() {
		return req_roster_save;
	}

	/**
	 * @return
	 */
	public int getReq_roster_save_cnt() {
		return req_roster_save_cnt;
	}

	/**
	 * @return
	 */
	public String getAcp_cat_sen() {
		return acp_cat_sen;
	}

	/**
	 * @return
	 */
	public String getReq_cat_sen() {
		return req_cat_sen;
	}
}