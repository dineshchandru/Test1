package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.services.number2alpha;

//This is the first step of eswap

public class setNewSwap {
	
	private Connection con=null;
	private String iern;	
	private String [] ipartners;
	private String [] swapNumber = new String [10];
	private String [] err_code = new String [10];
	private int ern_cnt=0;	 	
	private String swapStart;
	private String swapEnd;
	private String swapRemark;
		
	public setNewSwap() {
		super();		
	}

	public setNewSwap(String iern,String [] erns,String swapStart,String swapEnd,String swapRemark) {
		this.iern = iern;
		this.ipartners = erns;
		this.swapStart = swapStart;
		this.swapEnd = swapEnd;
		if (swapRemark == null ){
			this.swapRemark = " ";
		}else{
			this.swapRemark = format_str(swapRemark);	
		}				
		createSwap();
	}


public void createSwap(){
	String SQL;
	String myStatus = "New request";		
	String mySwapKey = "";
	String ern="";
	int row1 = 0;
	int row2 =0;
	int rowy =0;
	int rows=0;		

	try{	
		
		dbconnect db = new dbconnect();
		con = db.getConn();
		ResultSet rs=null;
		Statement stmt = con.createStatement();
		
		ResultSet rsx=null;					 			 					 			 		
		Statement stmtx = con.createStatement();							        
		Statement stmty = con.createStatement();

		for (int r=0;r<ipartners.length;r++){	
		  if (ipartners[r] !=null){
		  
            //	1.0 update SWAP_REQ Table
            //1.1 get Eswap REQ_KEY
			SQL = "select swap_key.nextval as swapkey from dual"; 			
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){
				number2alpha  mynum=new number2alpha();										
				mySwapKey =mynum.genAlphaNumber(rs.getString("swapkey")); 											
			}									        
			rs.close();
							 	        	    			
            //2.0 execute sql & update main table(swap_req+swap_status)
			SQL = "INSERT INTO CREWDIR.SWAP_REQ (REQ_KEY,REQ_ID,ACP_ID,PERIOD_START,PERIOD_END,LAST_STATUS,REMARK,TIME_LOG) VALUES " +
				  " ('" + mySwapKey + "','" + iern + "','" + ipartners[r] + "','" + swapStart + "','" + swapEnd+ "','" + myStatus + "','" + swapRemark+  "', sysdate)";
		    row1 = stmtx.executeUpdate(SQL);

			SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
				  " ('" + mySwapKey + "','" + myStatus + "','" + iern + "', sysdate)";
			row2 = stmtx.executeUpdate(SQL);

				
			rows=row1+row2;
			
			//update others Table							
			if (rows == 2) {	

					swapNumber[r] =mySwapKey;
														
					//3.0 crew web_hidden table				
					SQL = "INSERT INTO CREWDIR.SWAP_WEB_HIDDEN (SWAP_KEY,ERN,HIDE) VALUES " +
						  " ('" + mySwapKey + "','" + iern + "','N')";
					rowy = stmty.executeUpdate(SQL);
				
					SQL = "INSERT INTO CREWDIR.SWAP_WEB_HIDDEN (SWAP_KEY,ERN,HIDE) VALUES " +
						  " ('" + mySwapKey + "','" + ipartners[r] + "','N')";
					rowy = stmty.executeUpdate(SQL);
									
					//4.0 log down both party roster dates	
					//4.1 (requester)			
					SQL = "INSERT INTO SWAP_REQ_ROSTER ("+
						  "select distinct x.req_key,x.req_id,y.roster_date,y.duty,y.sp_duty,y.sector_from,y.sector_to,y.sort_order "+
						  "FROM SWAP_REQ X,V_ROSTER_MASTER Y " +
						  "WHERE x.req_id ='"+iern+"' and x.req_key='"+mySwapKey+"' and "+
								"x.req_id = y.staffid and y.roster_date between '"+swapStart+"' and '" +swapEnd+ "')";
					rowy = stmty.executeUpdate(SQL);
					
					//4.2  accepter	
					SQL = "INSERT INTO SWAP_REQ_ROSTER ("+
						  "select distinct x.req_key,x.acp_id,y.roster_date,y.duty,y.sp_duty,y.sector_from,y.sector_to,y.sort_order "+
						  "FROM SWAP_REQ X,V_ROSTER_MASTER Y " +
						  "WHERE x.acp_id ='"+ipartners[r]+"' and x.req_key='"+mySwapKey+"' and "+
						  "x.acp_id = y.staffid and y.roster_date between '"+swapStart+"' and '" +swapEnd+ "')";
					rowy = stmty.executeUpdate(SQL);
					
					
					err_code [r] =" ";
					 
				} else {
					err_code[r] = "Fail! E-S0";					
				}
		  }
		}//for
			
		stmt.close();
		stmtx.close();
		stmty.close();	
	}catch (SQLException sqlex) {
		  sqlex.printStackTrace();	
		  if (con!=null) {
				try {
				   con.close();
				}catch( SQLException e){
				   e.printStackTrace();
				}		   	  
		  } //if    			
				 
	}catch (Exception ex) {
		ex.printStackTrace();		    			
	} finally{
		if (con!=null) {
		   try {
				 con.close();
		   }catch( SQLException e){
			  e.printStackTrace();
		   }
		} //if  
	}//catch/try						
}
	



	private String format_str(String str){
	   String myRtn="";
	   for(int x=0;x<str.length();x++ ){
		  if (str.substring(x,x+1).equals("'" )){
			 myRtn = myRtn + str.substring(x,x+1)+"'";
		  }else{
			myRtn = myRtn + str.substring(x,x+1);
		  }
	   }
	   return myRtn;	   	
	}

	private String NewSwapNo(String num){
		String rtn="";
		return rtn; 
	}

	/**
	 * @return
	 */
	public int getErn_cnt() {
		return ern_cnt;
	}

	/**
	 * @return
	 */
	public String[] getErr_code() {
		return err_code;
	}

	/**
	 * @return
	 */
	public String[] getIpartners() {
		return ipartners;
	}

	/**
	 * @return
	 */
	public String[] getSwapNumber() {
		return swapNumber;
	}

}
