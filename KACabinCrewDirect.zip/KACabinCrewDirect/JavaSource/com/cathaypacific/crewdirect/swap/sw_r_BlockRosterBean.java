/*
 * Created on Aug 12, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

import java.util.Date;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class sw_r_BlockRosterBean {
	
	private Date BlockDate;
	public sw_r_BlockRosterBean() {
		super();		
	}

	public sw_r_BlockRosterBean(Date blkdate) {
		this.BlockDate=blkdate;
	}


	/**
	 * @return
	 */
	public Date getBlockDate() {
		return BlockDate;
	}

	/**
	 * @param date
	 */
	public void setBlockDate(Date date) {
		BlockDate = date;
	}

}
