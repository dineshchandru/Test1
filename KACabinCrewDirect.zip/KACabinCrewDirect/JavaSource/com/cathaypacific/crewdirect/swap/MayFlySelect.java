/*
 * Created on Aug 10, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MayFlySelect {
	private String err_msg;
	private Connection con=null;
	
	private String [][] mayfly_flt_list = new String [500][3];
	private int mayfly_rec_cnt=0; 
	
	public MayFlySelect() {
		super();		
	}

	public MayFlySelect(String flt_date) {
		
		String myDates [] = new String [100];
		try{	
			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
	    
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 					
			
			//1.0 get available dates & FLT NO		
			String SQL = "SELECT DISTINCT FLT_NO,SECTOR_FROM,SECTOR_TO " +				  "FROM CREWDIR.V_MAYFLY WHERE FLT_DATE='"+flt_date.toUpperCase() +"' ORDER BY FLT_NO,SECTOR_FROM";
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);
			mayfly_rec_cnt=0;
			while(rs.next()){				
				mayfly_flt_list [mayfly_rec_cnt][0] = rs.getString("FLT_NO" );	
				mayfly_flt_list [mayfly_rec_cnt][1] = rs.getString("SECTOR_FROM" );				
				mayfly_flt_list [mayfly_rec_cnt][2] = rs.getString("FLT_NO" ) + " " +rs.getString("SECTOR_FROM" )+ " "+rs.getString("SECTOR_TO" );								
				mayfly_rec_cnt++;	
			}									        
			rs.close();
			stmt.close();
		  
		  
			//set return data			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  
		
	}
	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String[][] getMayfly_flt_list() {
		return mayfly_flt_list;
	}

	/**
	 * @return
	 */
	public int getMayfly_rec_cnt() {
		return mayfly_rec_cnt;
	}

}
