/*
 * Created on Apr 29, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;




/**
 * @author IMTAMM
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class setMultiDelete {

	private Connection con=null;
	private String err_code="no_err";
	/**
	 * 
	 */
	public setMultiDelete() {
		super();
		// TODO Auto-generated constructor stub
	}

	public setMultiDelete(String iern,String swapKey) {
		String SQL;
		int rows=0;
		String myKey="";		
		
		//create myKey 
		int pos_start=0;
		int pos_end=0;		
		if (swapKey.indexOf(",",0) > 0){
			for (int x=0; x<swapKey.length();x++ ){
				pos_end = swapKey.indexOf(",",x);	
				
				if (pos_end >0)	{					
					myKey = myKey + swapKey.substring(pos_start,pos_end)+"','";
				}else{
					//last key 
					myKey = myKey + swapKey.substring(pos_start,swapKey.length());
					break;
				}
				x = pos_end;
				pos_start = pos_end +1;
			}				
		}else{
			myKey = swapKey;
		}

        //db operation
		try{	
				
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			Statement stmtx = con.createStatement();
			
			con.setAutoCommit(false);
			SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Delete',TIME_LOG = SYSDATE " +
				  "WHERE REQ_KEY IN ('"+myKey +"') AND REQ_ID ='"+iern+"' AND "+
				  "LAST_STATUS NOT IN ('Processing','Rejected','Disapproved','Approved','Withdrawn','Inviter requests to withdraw','Receiver requests to withdraw')";
				  
			rows = stmtx.executeUpdate(SQL);
			if (rows>0){      
				// insert  swap_status table
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG)  " +
					  " SELECT REQ_KEY,'DELETE',REQ_ID,sysdate FROM SWAP_REQ "+
					  " WHERE REQ_KEY IN ('"+myKey +"') AND REQ_ID ='"+iern+"' AND "+
				      " LAST_STATUS NOT IN ('Processing','Rejected','Disapproved','Approved','Withdrawn','Inviter requests to withdraw','Receiver requests to withdraw')";
				rows = stmtx.executeUpdate(SQL);
			}
			

			if (rows <0){
				err_code = "Fail to update database.";
				con.rollback();			
			}else{
				con.commit();
			}					

			stmtx.close();		

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
		
	}

	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

}
