/*
 * Created on Mar 25, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

public class swapPartnerInfoBean {
	private String swap_no;
	private String inv_from;
	private String inv_to;
	private String period;
	private swapItemDetailsContactBean req_info;
	private swapItemDetailsContactBean acp_info;

	public swapPartnerInfoBean(){
		super();
	}
	
	public swapPartnerInfoBean(String swap_no,String inv_from, String inv_to, String period) {
		this.swap_no = swap_no;
		this.inv_from = inv_from;
		this.inv_to = inv_to;
		this.period = period;
	}
	
	
	/**
	 * @return
	 */
	public String getInv_from() {
		return inv_from;
	}

	/**
	 * @return
	 */
	public String getInv_to() {
		return inv_to;
	}

	/**
	 * @return
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param string
	 */
	public void setInv_from(String string) {
		inv_from = string;
	}

	/**
	 * @param string
	 */
	public void setInv_to(String string) {
		inv_to = string;
	}

	/**
	 * @param string
	 */
	public void setPeriod(String string) {
		period = string;
	}

	/**
	 * @return
	 */
	public swapItemDetailsContactBean getAcp_info() {
		return acp_info;
	}

	/**
	 * @return
	 */
	public swapItemDetailsContactBean getReq_info() {
		return req_info;
	}

	/**
	 * @param bean
	 */
	public void setAcp_info(swapItemDetailsContactBean bean) {
		acp_info = bean;
	}

	/**
	 * @param bean
	 */
	public void setReq_info(swapItemDetailsContactBean bean) {
		req_info = bean;
	}

	/**
	 * @return
	 */
	public String getSwap_no() {
		return swap_no;
	}

	/**
	 * @param string
	 */
	public void setSwap_no(String string) {
		swap_no = string;
	}

}
