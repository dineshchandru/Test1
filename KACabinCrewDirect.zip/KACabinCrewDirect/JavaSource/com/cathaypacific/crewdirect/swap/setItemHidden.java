package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;


public class setItemHidden {
	
	private Connection con=null;
	private String iern;
	private String action_type;
	private String hidden_item;
	private boolean success;
	
	public setItemHidden() {
		super();		
	}

	public setItemHidden(String iern,String action_type,String str_hidden) {
		int pos_start=0;
		int pos_end=0;
		
		String temp="";
		if (str_hidden.indexOf(",",0) > 0){
			for (int x=0; x<str_hidden.length();x++ ){
				pos_end = str_hidden.indexOf(",",x);	
				
				if (pos_end >0)	{					
					temp = temp + str_hidden.substring(pos_start,pos_end)+"','";
				}else{
					//last key 
					temp = temp + str_hidden.substring(pos_start,str_hidden.length());
					break;
				}
				x = pos_end;
				pos_start = pos_end +1;
			}				
		}else{
			temp = str_hidden;
		}
		
		
		
		this.iern = iern;
		this.action_type = action_type;
		this.hidden_item = temp;
		
		

		
		updating();
	}

	public void updating(){
		String SQL;
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			
			Statement stmt = con.createStatement();
			if (action_type.equals("SHOW_ALL" )){
				SQL="UPDATE CREWDIR.SWAP_WEB_HIDDEN SET HIDE ='N' WHERE ERN='"+iern+"'";
			}else{
				SQL="UPDATE CREWDIR.SWAP_WEB_HIDDEN SET HIDE ='Y' WHERE ERN='"+iern+"' AND "+
				         " SWAP_KEY IN ('"+hidden_item +"')"; 
			}
			int rows = stmt.executeUpdate(SQL);
			if (rows >= 1){			
				setSuccess(true);
			}else{
			   setSuccess(false);	
			}				
			stmt.close();		

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
	}
	


	/**
	 * @return
	 */
	public String getIern() {
		return iern;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param string
	 */
	public void setIern(String string) {
		iern = string;
	}

	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

}
