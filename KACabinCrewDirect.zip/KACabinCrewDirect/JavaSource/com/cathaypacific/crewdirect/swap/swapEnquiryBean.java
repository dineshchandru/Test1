/*
 * Created on Mar 22, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

public class swapEnquiryBean {

	private String type;
	private String id;
	private String whom;
	private String period;
	private String timestamp;
	private String status;
	 
	public swapEnquiryBean(){
		super();
	}

	public swapEnquiryBean(String type,String id,String whom,String period,String timestamp,String status){
		this.type = type;
		this.id  = id;
		this.whom = whom;
		this.period = period;
		this.timestamp = timestamp;
		this.status = status;
	}

    //for dependant swap
	public swapEnquiryBean(String type,String id,String period,String timestamp,String status){
		this.type = type;
		this.id  = id;		
		this.period = period;
		this.timestamp = timestamp;
		this.status = status;
	}


	/**
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @return
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param string
	 */
	public void setId(String string) {
		id = string;
	}

	/**
	 * @param string
	 */
	public void setPeriod(String string) {
		period = string;
	}

	/**
	 * @param string
	 */
	public void setStatus(String string) {
		status = string;
	}

	/**
	 * @param string
	 */
	public void setTimestamp(String string) {
		timestamp = string;
	}

	/**
	 * @param string
	 */
	public void setType(String string) {
		type = string;
	}

	/**
	 * @return
	 */
	public String getWhom() {
		return whom;
	}

	/**
	 * @param string
	 */
	public void setWhom(String string) {
		whom = string;
	}

}
