/*
 * Created on Apr 21, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class eswapLogicCheck {
	
	private String Req_ERN;
	private String [] Acp_ERN;
	private String SwapStartDate;
	private String SwapEndDate;
	private boolean AllowInvitation;
	
	private String errorCode;
	private boolean haveError;
	private Connection con=null;
	
	private eswapLogicResultBean [] CheckResult = new eswapLogicResultBean [10];  //max staff

	//	-------------------------------------------------			
	public eswapLogicCheck() {
		super();
	}
	
	//-------------------------------------------------
	public eswapLogicCheck(String ern,String [] partners,String SwapStart,String SwapEnd){
		this.Req_ERN = ern;
		this.SwapStartDate = SwapStart;
		this.SwapEndDate = SwapEnd;
		this.Acp_ERN = partners;
			
			MainLogic();
	}
	
	//	===========================================
    private void MainLogic (){
    	
    	String myCheck;
    	String myCheckDuplicate;
    	String err_txt;
    	String crew_id="";    		
		eswapLogicResultBean  myBean;
		AllowInvitation = false;
		
		try {	
		//**************************************************
			dbconnect db = new dbconnect();
			con = db.getConn();
		    	
			//1.0 check my req_ern dutycode		
			crew_id = getCrewID(Req_ERN);//get crewid			
			eswapLogicDutyCheck DutyChk = new eswapLogicDutyCheck(Req_ERN,SwapStartDate,SwapEndDate);				
		
			if (DutyChk.isHaveError() == false) {						
				//1.0 add my info to logic result bean
				myBean = new eswapLogicResultBean(Req_ERN,crew_id,"REQ","N");
				CheckResult[0] = myBean;					
				
				//2.0 loop other partners
				for (int p=0;p<Acp_ERN.length;p++ ) {
					if (Acp_ERN[p].length() == 7 ) {					

						crew_id = getCrewID(Acp_ERN[p]); //get crewid
							
						//2.1 check details logics						
						myCheck = DetailLogicCheck(Req_ERN,Acp_ERN[p]); 
						if (myCheck.equals("no_err")) {
								
							//2.2 check duplication of swaps
						   eswapCheckDuplication dup_chk = new eswapCheckDuplication(Req_ERN,Acp_ERN[p],SwapStartDate,SwapEndDate);
						   myCheckDuplicate = dup_chk.getErr_msg();						
						   if (myCheckDuplicate.equals("no_err")) {
							   myBean = new eswapLogicResultBean(Acp_ERN[p],crew_id,"ACP","N");
							   CheckResult[p+1] = myBean;
							   AllowInvitation = true;
						   } else {
							   myBean = new eswapLogicResultBean(Acp_ERN[p],crew_id,"ACP","Y",myCheckDuplicate);
							   CheckResult[p+1] = myBean;													
						   }
					   } else {
						   myBean = new eswapLogicResultBean(Acp_ERN[p],crew_id,"ACP","Y",myCheck);
						   CheckResult[p+1] = myBean;				
					   }				
					}
				}		
					 
			} else {
				//duty check have error create error messages
				err_txt = DutyChk.getErr_msg();			
				myBean = new eswapLogicResultBean(Req_ERN,crew_id,"REQ","Y",err_txt);
				CheckResult[0] = myBean;	
				//put msg for other partners
				for (int p=0;p<Acp_ERN.length;p++ ) {				
					crew_id = getCrewID(Acp_ERN[p]) ; //get crewid
						
					if (Acp_ERN[p].length() == 7 ) {
						myBean = new eswapLogicResultBean(Acp_ERN[p],crew_id,"ACP","Y","Request not processed");
						CheckResult[p+1] = myBean;									
					}
				}								
				AllowInvitation = false;			
			}    	      
		//**************************************************

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   } catch( SQLException e) {
				  e.printStackTrace();
			   }
			} //if
		}//catch/try
    }

	//	===========================================
	private String DetailLogicCheck(String Req_ERN,String Acp_ERN) {
        
		String err_txt="no_err";

		//1.0 check both crew basic info
		err_txt = BasicInfoCheck(Req_ERN,Acp_ERN,SwapStartDate);
		if (err_txt.equals("no_err")) {
			
			//1.1 - Add on 10 Jul 2006 : New Request Quota Checking, only check the requester
			err_txt = NewRequest_Check(Req_ERN); 

			if (err_txt.equals("no_err")) {
				//2.0 check Acp_ern duty 
				eswapLogicDutyCheck DutyChk = new eswapLogicDutyCheck(Acp_ERN,SwapStartDate,SwapEndDate);
				if (DutyChk.isHaveError()== true) {
					err_txt = DutyChk.getErr_msg();   
				} else {
					//3.0 check sp_duty BD
					err_txt = BD_Check(Req_ERN,Acp_ERN,SwapStartDate,SwapEndDate); 
				}			
			}
		}
		return err_txt;
	}

	//========================== Check Staff Basic Info =================	
	public String BasicInfoCheck(String myERN,String PartnerERN,String swap_sdate) {

		String SQL;		
		String err_msg="no_err";
		String CAT=null;

		try {	

			if (con==null) {			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}

			Statement stmt = con.createStatement();		
			ResultSet rs=null;
			ResultSet rs1=null;
			ResultSet rs2=null;
			boolean exit;	
			
			exit = true;
			
			
			if (!myERN.equals(PartnerERN))
			{
				exit = false;
				err_msg = "no_err";
			}
			else
			{
				err_msg = "You cannot make swap request to yourself.";
			}
					
			
			
			if (exit == false) {
			
				SQL="select distinct SUBSTR(CATEGORY,2,2) as cat from isdcrew.staff_category " +
				"where ern='"+myERN+"' and (TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE) and "+ 				
				"SUBSTR(CATEGORY,2,2) = (select distinct substr(category,2,2) as cat from isdcrew.staff_category " +
				"where ern='"+PartnerERN+"' and "+
				"(TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE))";
				exit = true;
				err_msg = "Category not matched.";
				rs= stmt.executeQuery(SQL);
				
				while(rs.next()){
					CAT = rs.getString("cat");
					exit = false;
					err_msg = "no_err";
					break;
				}			
				rs.close();
				
				
				
			}
			
			if (exit == false){
				
				//String temp = new String();
				//temp = swStart.substring(6);
				
				if (swap_sdate.substring(7).equals("09"))
				{
					err_msg = "2009 duty swap is not allowed.";
					exit = true;
				}
				
			}
			
			
 		
			
        
			if (exit == false) {
				
				
				
				
			
				
				 
				if (CAT.equals("BC")){
					
//					1.3 category checking for KBC, RBC & HBC	
					/*SQL = "select SUM(count(distinct CATEGORY)) as CNT from isdcrew.staff_category " +
					"where ern in ('"+myERN+"','"+PartnerERN+"') " +
					"and (TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE) " +
					//"and CATEGORY_GROUP in ('Y') " +
					"group by CATEGORY";
					rs= stmt.executeQuery(SQL);
					while(rs.next()) {
						int myNum = rs.getInt("CNT");
						if (myNum == 1) {
							exit = false;
							err_msg = "no_err";							
						} else {
							exit = true;
							err_msg = "Category not matched.";							
						}					
						break;
					}			
					rs.close();*/
					
					
					
					
					
//					1.3 category checking for BCNY & BCNN
					SQL = "select SUM(count(distinct CATEGORY_GROUP)) as CNT from isdcrew.staff_category " +
					"where ern in ('"+myERN+"','"+PartnerERN+"') " +
					"and (TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE) " +
					"group by CATEGORY_GROUP";
					rs= stmt.executeQuery(SQL);
					while(rs.next()) {
						int myNum = rs.getInt("CNT");
						if (myNum == 1) {
							exit = false;
							err_msg = "no_err";							
						} else {
							exit = true;
							err_msg = "Category not matched.";							
						}					
						break;
					}			
					rs.close();
					
					
				    
				}
				
				
			}
        		
		  //-------------------2.0 Same Base Port
		  if (exit == false) {
			  SQL = "select rownum from isdcrew.crewdb_4_all where ern = '"+myERN+ "' "+ 
					"and base_port=(select base_port from isdcrew.crewdb_4_all where ern='"+PartnerERN+"')";
			  exit = true;
			  err_msg = "Base port not matched.";
			  rs= stmt.executeQuery(SQL);
			  while(rs.next()) {
				  exit = false;
				  err_msg = "no_err";
				  break;
			  }			
			  rs.close();
		  }	 
		
		  //-------------------3.0 AC Type Qualication
		  if (exit == false) {
		  	  /* add 24 Feb 2009 waived ac type qualication checking for YVR crew*/
		  	  /*String tmpCOS = null;
			  SQL="select COS from isdcrew.crewdb_4_all " +
				  "where ern='"+myERN+"' "; 				
			  rs= stmt.executeQuery(SQL);
			  while (rs.next()){
				    tmpCOS = rs.getString("COS");				
			        break;
			  }	
			  rs.close();*/
			  
			  
			  if (!CAT.equals("IM")) {
			     SQL = "select rownum from isdcrew.staff_category " +
				  	   "where ern = '"+myERN+ "' "+ 
					   "and (TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE) "+				
					   "and SUBSTR(CATEGORY,1,1)=(select SUBSTR(CATEGORY,1,1) " +
					   "from isdcrew.staff_category where ern='"+PartnerERN+"' " +
					   "and (TO_DATE('"+swap_sdate+"','DD-MON-YY') BETWEEN EFFECTIVE_DATE AND EXPIRY_DATE))";
			     exit = true;
			     err_msg = "Aircraft type quailification not matched.";
			     rs1 = stmt.executeQuery(SQL);
			     while (rs1.next()) {
				       exit = false;
				       err_msg = "no_err";
				       break;
			     }			
			     rs1.close();
			  };   
		  }	 
		  stmt.close();

		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					} catch(SQLException e) {
					   e.printStackTrace();
					}		   	  
			  } //if    			

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 

		} finally{
		}//catch/try						    	    	
    
		return err_msg;	
	}
	
	//========================== Check Bar Sales (BD) special duty code Info =================	
	public String BD_Check(String ern,String partner,String SwapStart,String SwapEnd) {
		String err_msg="no_err";
		boolean Req_BD = false;
		boolean Acp_BD = false;
				
		try {
			if (con==null) {			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}
			ResultSet rs=null;			
			Statement stmt = con.createStatement();
			String SQL = null;
			//1.0 check if requester BD			
			SQL = "SELECT rownum FROM CREWDIR.V_ROSTER_PUBLIC " +				  "WHERE STAFFID='"+ern+"' AND ROSTER_DATE BETWEEN '"+SwapStart+"' AND '"+SwapEnd+"'" +				  "AND SP_DUTY='BD'";			
			rs= stmt.executeQuery(SQL);		
			while(rs.next()) {				
				Req_BD = true; 						
			}									        
			rs.close();
			
			//1.1 check partner cat for have BD case
			if (Req_BD == true) {
				SQL = "SELECT rownum FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+partner+"' AND CAT='FAY' ";
				rs = stmt.executeQuery(SQL);		
				while(rs.next()){				
					err_msg = "Partner category not matched for BD."; 						
				}									        
				rs.close();
				
				//1.2 check partner language req.				
				if (err_msg.equals("no_err")) { 
					SQL="SELECT ROWNUM FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+partner+"' AND "+ 
						"(LANG_1 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
						 "LANG_2 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
						 "LANG_3 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
						 "LANG_4 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') )" ;
					rs= stmt.executeQuery(SQL);
					//err_msg = "Agreed language not matched for BD.";
					err_msg = "no_err";		
					while(rs.next()){				
						err_msg = "no_err"; //have record means having require language						
					}									        
					rs.close();
				}			
			}

			//2.0 Check accepter BD Code
			if (err_msg.equals("no_err" )) {
				//2.1 check if acceptor BD			
				SQL = "SELECT rownum FROM CREWDIR.V_ROSTER_PUBLIC " +
					  "WHERE STAFFID='"+partner+"' AND ROSTER_DATE BETWEEN '"+SwapStart+"' AND '"+SwapEnd+"'" +
					  "AND SP_DUTY='BD'";			
				rs= stmt.executeQuery(SQL);		
				while(rs.next()) {				
					Acp_BD = true; 						
				}									        
				rs.close();

				if (Acp_BD == true) {
					SQL = "SELECT rownum FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+ern+"' AND CAT='FAY' ";
					rs= stmt.executeQuery(SQL);		
					while(rs.next()) {				
						err_msg = "Your category not matched for BD."; 						
					}									        
					rs.close();
				
					//1.2 check partner language req.				
					if (err_msg.equals("no_err")) { 
						SQL="SELECT ROWNUM FROM ISDCREW.CREWDB_4_ALL WHERE ERN='"+ern+"' AND "+ 
							"(LANG_1 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
							 "LANG_2 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
							 "LANG_3 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') or "+
							 "LANG_4 IN (SELECT VALUE FROM SW_R_SP_DUTY WHERE CODE='BD' AND REQUEST='LANG_REQ') )" ;
						rs= stmt.executeQuery(SQL);
						//err_msg = "Your language not matched for BD.";
						err_msg = "no_err";		
						while(rs.next()) {				
							err_msg = "no_err"; //have record means having require language						
						}									        
						rs.close();
					}			
				}				
			}
			
			stmt.close();
			 
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					} catch (SQLException e) {
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 		    			
		} finally {
		}//catch/try						    	    	
		
		return err_msg;
	}		

	//========== Add on 10 Jul 2006 - Checking : the total number of swaps sent by the crew per day ==========
	public String NewRequest_Check (String ern) {

		String err_msg = "no_err";
			
		try {
			String strSql = new String(""); 
			String params_enable = new String("");
			String params_value = new String("");
			int quota_allow = 0;
			int req_count = 0;

			//try to connect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}
			Statement stmt=con.createStatement();						
			ResultSet rs=null;				

			//1.0 get the parameters 
			strSql = "select params_value, params_enable from admin_parameter where params = 'NEW_REQUEST_QUOTA'";
			rs= stmt.executeQuery(strSql);		
			while(rs.next()){			
				params_enable = rs.getString("params_enable");
				params_value = rs.getString("params_value");
			}									        
			rs.close();
			if (params_value.equals("")) {
				quota_allow = 0;
			}
			else
			{
				quota_allow = Integer.parseInt(params_value);	
			}
			
			

			//2.0 Send invitation quota checking enabled
			if (params_enable.equals("Y")) {

				//Get the total number of invitation sent on the same day
				//If exceeded the quota, prompt error message and ask the crew to send on the next day
				strSql = "select req_id, count(*) as req_count from swap_req " +
						 "where last_status='New request' and req_id = '"+ern+"' " +
						 "and to_char(time_log, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd') " +
						 "group by req_id";
				rs = stmt.executeQuery(strSql);		
				while(rs.next()) {						
					req_count = rs.getInt("req_count");
				}						        
				rs.close();
				
				if (req_count > quota_allow){
					err_msg = "You have sent more invitations than the system allows today. Please send the invitations tomorrow.";
				}
			} 
			stmt.close();
						 			
		}catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con!=null) {
				  try {
					 con.close();
				  } catch (SQLException e) {
					 e.printStackTrace();
				  }		   	  
			} //if    			
			err_msg = sqlex.toString();

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString() ;

		} finally{
		}//catch/try
	
		return err_msg;							
	}
	
	//=========================================
	private String getCrewID(String iern){
		String rtn="";
		try {
			if (con==null){			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}
			Statement stmt=con.createStatement();			 			 					 			 		 		
			String SQL =  "SELECT DISTINCT CREW_ID FROM ISDCREW.CREWDB_4_ALL WHERE ERN ='"+iern+"'";
			ResultSet rs= stmt.executeQuery(SQL);		
			while(rs.next()){				
				rtn  = rs.getString("CREW_ID");
				break;
			}									        
			rs.close();
			stmt.close(); 

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con!=null) {
				  try {
					 con.close();
				  } catch(SQLException e) {
					 e.printStackTrace();
				  }		   	  
			} //if    			

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally{
	  
		}//catch/try						    	    	
			
		return rtn;
	}

	//========================= Return Values ================================
	/**
	 * @return
	 */
	public boolean isHaveError() {
		return haveError;
	}

	/**
	 * @param string
	 */
	public void setErrorCode(String string) {
		errorCode = string;
	}

	/**
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @return
	 */
	public eswapLogicResultBean[] getCheckResult() {
		return CheckResult;
	}

	/**
	 * @return
	 */
	public boolean isAllowInvitation() {
		return AllowInvitation;
	}

	/**
	 * @param b
	 */
	public void setAllowInvitation(boolean b) {
		AllowInvitation = b;
	}

}
