/*
 * Created on Jul 27, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

public class swapSimulateRosterBean {
	
	private String crew_id;
	private String cat_seniority;
	private String [][] roster;
	
	public swapSimulateRosterBean() {
		super();
	}

	public swapSimulateRosterBean(String crew_id,String cat_seniority,String [][]roster) {
		this.crew_id = crew_id;
		this.cat_seniority = cat_seniority;		
		this.roster = roster;
	}


	/**
	 * @return
	 */
	public String getCat_seniority() {
		return cat_seniority;
	}

	/**
	 * @return
	 */
	public String getCrew_id() {
		return crew_id;
	}

	/**
	 * @return
	 */
	public String[][] getRoster() {
		return roster;
	}

	/**
	 * @param string
	 */
	public void setCat_seniority(String string) {
		cat_seniority = string;
	}

	/**
	 * @param string
	 */
	public void setCrew_id(String string) {
		crew_id = string;
	}

	/**
	 * @param strings
	 */
	public void setRoster(String[][] strings) {
		roster = strings;
	}

}
