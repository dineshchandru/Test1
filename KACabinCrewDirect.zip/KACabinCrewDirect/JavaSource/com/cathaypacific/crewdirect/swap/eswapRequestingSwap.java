package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.cathaypacific.crewdirect.common.GenericCrewDirect;
import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.services.MQServices;


public class eswapRequestingSwap {
	
	private Connection con=null;
	private String iern;
	private String swap_remark =" ";
	private String err_code ="";
	private boolean success;
	private String sw_type;
	private String [] arr_sw_no = new String [3]; 


    private String MQ_ACTION="ADD";
	
	private String MQ_Send_Key ="";
	private String MQ_Send_Text ="";
	

	String err_msg = "no_err";
	
	public eswapRequestingSwap() {
		super();		
	}
   
   
    //for single swap request
	public eswapRequestingSwap(String MQ_ADD_DEL,String ern,String swap_no) {
				
		try{
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
			//get connect 							
			dbconnect db = new dbconnect();
			con = db.getConn();				        

			this.iern=ern;
			this.MQ_ACTION = MQ_ADD_DEL;
			//0.0 Directly send request if this is withdraw
			if (MQ_ACTION.equals("DEL")){
				err_msg = Requesting(swap_no);
				if (err_msg.equals("no_err" )){				
					err_msg = Updating(swap_no," ");
				}				    				
			}else{
				//1.0 checking 
				err_msg = SingleChecking(swap_no);
				if (err_msg.equals("no_err" )){
					//	2.0 requsting 		
					err_msg = Requesting(swap_no);
					if (err_msg.equals("no_err" )){
						///2.2 update status
						err_msg = Updating(swap_no," ");
					}		
				}		    				
			}
			
			//3.0 set return
			if (err_msg.equals("no_err")){
				success = true;
			}else{			
				success = false;
				err_code = err_msg;
			}
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
		}catch (Exception ex) {
			ex.printStackTrace();
			success = false;
			err_code = ex.toString() ;		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  success = false;
				  err_code = e.toString();
			   }
			} //if  
		}//catch/try
		
	}


//--------------------------------------------------------------
    // for dependant swap 
	public eswapRequestingSwap(String iern,String sw_type,String sw_opt0,String sw_opt1,String sw_opt2) {		

		this.iern = iern;		
		this.sw_type = sw_type;		
		this.MQ_ACTION = "ADD";

		//1.0 put those dependant id into array
		arr_sw_no[0] = sw_opt0;
		arr_sw_no[1] = sw_opt1;
		arr_sw_no[2] = sw_opt2;

		try{
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			//get connect 							
			dbconnect db = new dbconnect();
			con = db.getConn();				        
		
	        //2.0 call checkings
	        err_msg = DependantCheck(arr_sw_no);
						
			//3.0 submit request
			if (err_msg.equals("no_err" )){
				setSwapRemark();
				for (int y=0;y<=2;y++){
					if (arr_sw_no[y].length()>1){
						///2.1 request to MQ						
					    err_msg = Requesting(arr_sw_no[y]);
						if (err_msg.equals("no_err" )){
							//2.2 update status
						    err_msg = Updating(arr_sw_no[y],swap_remark);
						}		
					}
				}			
			}
	
			//3.0 set return
			if (err_msg.equals("no_err")){
				success = true;
			}else{
				err_code = err_msg;
				success = false;
			}
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
		
		}catch (Exception ex) {
			ex.printStackTrace();
			success = false;
			err_code = ex.toString() ;		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  success = false;
				  err_code = e.toString();
			   }
			} //if  
		}//catch/try		
	}

//	------------------------------------------------------------
	public String DependantCheck(String [] SwapNo){
		String err_msg = "no_err";
		String SQL="";
		String [][] mySwapNo = new String [3][6]; //req_key,req_id,acp_id,swStart,swEnd,LastStatus
		int cnt=0;
		int quota=0;
		boolean SkipDateCheck = false;
		
		String tmptxt="";
		String tmpern="";
		Date s_date1=null; Date e_date1=null;
		Date s_date2=null; Date e_date2=null;
		
		String arrQuota [][]=new String [20][2]; //month,ern
		int arrQuotaUsed [] = new int [20];
		int arr_cnt=0;
		
		
		String [][] erns = new String [20][2]; //ern,month
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		try{	
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			Statement stmt=con.createStatement();						
			ResultSet rs=null;				
			Statement stmtx=con.createStatement();						
			ResultSet rsx=null;				
			Statement stmty=con.createStatement();						
			ResultSet rsy=null;				
			

			//0.0 get those swap details into array
			tmptxt = "'"+SwapNo[0]+"','"+SwapNo[1]+"','"+SwapNo[2]+"'";							 			 					 			 	
			SQL = "select req_key,last_status,req_id,acp_id,period_start," +
				  "to_char(period_start,'DD-MON-YY') as s_date,to_char(period_end,'DD-MON-YY') as e_date " +
				  "from crewdir.swap_req where req_key in ("+tmptxt+") order by period_start"; 			 		
			rs= stmt.executeQuery(SQL);
			cnt=0;		
			while(rs.next()){										
				mySwapNo [cnt][0] = rs.getString("req_key");
				mySwapNo [cnt][1] = rs.getString("req_id");
				mySwapNo [cnt][2] = rs.getString("acp_id");
				mySwapNo [cnt][3] = rs.getString("s_date");
				mySwapNo [cnt][4] = rs.getString("e_date");				
				mySwapNo [cnt][5] = rs.getString("last_status");
				cnt++;
			}									        
			rs.close();

			//0.1 find all erns	& months
			int i=0;
			for (int x=0;x<cnt;x++){
				erns[i][0]=mySwapNo[x][1]; //req_ern
				erns[i][1]=mySwapNo[x][3].substring(3,9); //month
				i++;
			}
			
			for (int y=0;y<cnt;y++){
				erns[i][0]=mySwapNo[y][2]; //acp_ern
				erns[i][1]=mySwapNo[y][3].substring(3,9); //month
				i++;
			}
			//0.0.1 final ern,month and counts
			arr_cnt=0;
			for (int m=0;m<i;m++){
				if (erns[m][0].length() == 7 ){
					tmpern = erns[m][0];
					tmptxt = erns[m][1];
										
					for (int n=m+1;n<i;n++){
						if (tmpern.equals(erns[n][0]) & tmptxt.equals(erns[n][1])){
							arrQuotaUsed[arr_cnt] = arrQuotaUsed[arr_cnt]+1;  //quota count
							erns[n][0] ="";
							erns[n][1] ="";	
						}					 
					}					
					arrQuota[arr_cnt][0] = tmpern; //ern
					arrQuota[arr_cnt][1] = tmptxt; //month & year
					arrQuotaUsed[arr_cnt] = arrQuotaUsed[arr_cnt]+1;		
					arr_cnt++;				
				}
				
			}



			//1.0 check overlap within  those requests  
			//method a: [not (end1 < start2 or end2 < start1)] method b: [( start1 <= end2 and start2 <= end1 )]
			for (int x=0;x<cnt;x++){
				if (err_msg.equals("no_err" )){
					s_date1 = formatter.parse(mySwapNo[x][3] );
					e_date1 = formatter.parse(mySwapNo[x][4] );
					for (int y=x+1;y<cnt;y++){
						s_date2 = formatter.parse(mySwapNo[y][3] );
						e_date2 = formatter.parse(mySwapNo[y][4] );
						
						//compare it
						if(s_date1.compareTo(s_date2) <= 0 & s_date2.compareTo(e_date1 ) <=0 ){
							err_msg = "Selected Dependant Swap requests #"+mySwapNo[x][0]+" overlapped with #"+mySwapNo[y][0]+".";
							break;
						}
					}
				}//if err_msg	
			}//for

			//2.0 check overlap of those request against existing request
			if (err_msg.equals("no_err" )){
				for (int x=0;x<cnt;x++){
					//2.1 check rquester as requested swaps
					if (err_msg.equals("no_err" )){
					/*	SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE REQ_ID='"+mySwapNo[x][1]+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+ mySwapNo[x][3] +"' and '"+ mySwapNo[x][4]+"' "+
										   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
										   "OR (period_start <= '"+mySwapNo[x][3]+"' and period_end >= '"+mySwapNo[x][4]+"')"+
										   ")" +
						             " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][1]+"'))";
					*/
						SQL = "SELECT /*+ index(swap_req idx_swap_req_04)*/ REQ_KEY FROM CREWDIR.SWAP_REQ " +
						      "WHERE REQ_ID='"+mySwapNo[x][1]+"' AND "+
							  "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
							  " AND (period_start between '"+ mySwapNo[x][3] +"' and '"+ mySwapNo[x][4]+"' "+
							  "      OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
							  "      OR (period_start <= '"+mySwapNo[x][3]+"' and period_end >= '"+mySwapNo[x][4]+"')"+
							  "      )" +
					          " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][1]+"'))";						
						rsx= stmtx.executeQuery(SQL);
						//System.out.println("CCD Swap Requesting REQ SQL - "+SQL);						
						tmptxt ="";		
						while(rsx.next()){
							tmptxt = tmptxt + rsx.getString("REQ_KEY") + " ";																						
							err_msg = "Selected Dependant Swap requests #"+mySwapNo[x][0]+" overlapped with your #"+tmptxt+"! "; 					
						}									        
						rsx.close();					
					}//2.1 
					
					//2.2 (as accept) check rquester as accepted swaps
					if (err_msg.equals("no_err" )){						 
					/*	SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE ACP_ID='"+mySwapNo[x][1]+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+mySwapNo[x][3] +"' and '"+mySwapNo[x][4]+"' "+
										   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
										   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
										   ")" +
						             " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][1]+"'))";						         
					*/
						SQL = "SELECT /*+ index(swap_req idx_swap_req_05) */ REQ_KEY FROM CREWDIR.SWAP_REQ " +
						      "WHERE ACP_ID='"+mySwapNo[x][1]+"' AND "+
								 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
								 " AND (period_start between '"+mySwapNo[x][3] +"' and '"+mySwapNo[x][4]+"' "+
									   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
									   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
									   ")" +
					             " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][1]+"'))";						         

						rsx = stmtx.executeQuery(SQL);	
						//System.out.println("CCD Swap Requesting ACP SQL - "+SQL);						
						tmptxt ="";
						while(rsx.next()){
							tmptxt = tmptxt + rsx.getString("REQ_KEY") + " ";																						
							err_msg = "Selected Dependant Swap requests #"+mySwapNo[x][0]+" overlapped with your #"+tmptxt+"! "; 					
						}									        
						rsx.close();
					}//2.2 
					
					//2.3 for agreed party  rquester as requested swaps
					if (err_msg.equals("no_err" )){						
					/*	SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE REQ_ID='"+mySwapNo[x][2]+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+ mySwapNo[x][3] +"' and '"+ mySwapNo[x][4]+"' "+
										   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
										   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
										   ")" +
						             " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][2]+"'))";
					*/
						SQL = "SELECT /*+ index(swap_req idx_swap_req_04) */ REQ_KEY FROM CREWDIR.SWAP_REQ " +
						  "WHERE REQ_ID='"+mySwapNo[x][2]+"' AND "+
								 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
								 " AND (period_start between '"+ mySwapNo[x][3] +"' and '"+ mySwapNo[x][4]+"' "+
									   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
									   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
									   ")" +
					             " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][2]+"'))";										   					         
						
						rsy= stmty.executeQuery(SQL);
						//System.out.println("CCD Swap Requesting REQ SQL 2 - "+SQL);						
						tmptxt ="";		
						while(rsy.next()){
							tmptxt = tmptxt + rsy.getString("REQ_KEY") + " ";																						
							err_msg = "Selected Dependant Swap requests #"+mySwapNo[x][0]+" overlapped with agreed party's #"+tmptxt+"! "; 					
						}									        
						rsy.close();					
					}//2.3
					
					//2.4 or agreed party  rquester as receiver
					if (err_msg.equals("no_err" )){
					/*		
						SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE ACP_ID='"+mySwapNo[x][2]+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+mySwapNo[x][3] +"' and '"+mySwapNo[x][4]+"' "+
										   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
										   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
										   ")" +
						            " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][2]+"'))";
						*/
						SQL = "SELECT /*+ index(swap_req idx_swap_req_05) */ REQ_KEY FROM CREWDIR.SWAP_REQ " +
						  "WHERE ACP_ID='"+mySwapNo[x][2]+"' AND "+
								 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
								 " AND (period_start between '"+mySwapNo[x][3] +"' and '"+mySwapNo[x][4]+"' "+
									   "OR period_end between '"+mySwapNo[x][3]+"' and '"+mySwapNo[x][4]+"' "+
									   "OR (period_start < '"+mySwapNo[x][3]+"' and period_end > '"+mySwapNo[x][4]+"')"+
									   ")" +
					            " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+mySwapNo[x][2]+"'))";						
						rsy= stmty.executeQuery(SQL);
						//System.out.println("CCD Swap Requesting ACP SQL 2 - "+SQL);						
						tmptxt ="";		
						while(rsy.next()){
							tmptxt = tmptxt + rsy.getString("REQ_KEY") + " ";																						
							err_msg = "Selected Dependant Swap requests Agreed party's #"+tmptxt +" overlappped with #"+mySwapNo[x][0]+"."; 					
						}									        
						rsy.close();					
					}//2.4 					
																								
				}//for
				
			}//2.0

			//3.0 Quota Limits.
			for (int p=0;p<arr_cnt;p++){
				quota = QuotaRemain(arrQuota[p][0],arrQuota[p][1]);
				if (quota - arrQuotaUsed[p] < 0){
					//get crew and format error message		 			 					 			 	
					SQL = "select distinct crew_id from isdcrew.crewdb_4_all where ern='" +arrQuota[p][0]+"'";
					rs= stmt.executeQuery(SQL);						
					while(rs.next()){										
						err_msg =rs.getString("crew_id" )+ " exceeded swap limit in month:"+arrQuota[p][1];							
					}									        
					rs.close();
					break;  //for
				}				
			}//3.0 


			//4.0 check start_date should be today + 2
			for (int k=0;k<cnt;k++){
				if (err_msg.equals("no_err" )){
					SkipDateCheck = false;
					SQL = "SELECT rownum from CREWDIR.SWAP_SEND_FACTS WHERE SWAP_NO='"+mySwapNo[k][0]+"' AND MSG_TYPE = 'LAST_MINUTE'";
					rs= stmt.executeQuery(SQL);		
					while(rs.next()){
						SkipDateCheck = true;
					}									        
					rs.close();
			
					//4.0.2 check date + 2  		
					if (SkipDateCheck == false){
						SQL = "SELECT TO_DATE('"+mySwapNo[k][3]+"','dd-mon-yy') - TO_DATE(SYSDATE,'dd-mon-yy') AS DATE_NUM FROM DUAL";
						rs= stmt.executeQuery(SQL);		
						while(rs.next()){
							if (rs.getInt("DATE_NUM")<4) 
								err_msg = "Swap #" +mySwapNo[k][0]+ " should be submited three full calendar before swap start date.";										
						}									        
						rs.close();
						
						
						
						//4.1 check swap date must >= 01-Jan-10
						if (err_msg.equals("no_err" )){
							
							//String temp = new String();
							//temp = swStart.substring(6);
							
							if (mySwapNo[k][3].substring(7).equals("09"))
							{
								err_msg = "2009 duty swap is not allowed.";	
							}
							
						}
						
					}
					
					
//					 
					
					//4.1 check roster has changed 
					if (err_msg.equals("no_err" )){
						eswapRequestingRosterCheck rst_check = new  eswapRequestingRosterCheck(mySwapNo[k][0]);
						err_msg = rst_check.getErr_msg(); 
					}
														
				}
			}
			
			stmt.close();						
			stmtx.close();
			stmty.close();



		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_msg = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString() ;		    			
		} finally{
		}//catch/try
		
		return err_msg;
	}
	
//	------------------------------------------------------------
	public String swapFrozenChecking(String SwStart,String SwEnd){
  	 	String myRTN="N";
		String tmp_txt="";	
		String roster_day=null;
        String SQL=null; 
		String Frozen_Start=null;
		String Frozen_End=null;
		String Roster_Date=null;
		String Roster_Time = null;				
		int cnt=0;		 
		try {	
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			Statement stmt=con.createStatement();						
			ResultSet rs=null;				

			//1.0 get swap frozen period								 			 					 			 	
			SQL = "SELECT PARAMS,PARAMS_VALUE FROM crewdir.ADMIN_PARAMETER " +
			      "WHERE PARAMS_ENABLE='Y'";
 			 		
			rs= stmt.executeQuery(SQL);		
			while (rs.next()){								
				   if (rs.getString("PARAMS").equalsIgnoreCase("SWAP_FROZEN_START")) { 
				       Frozen_Start = rs.getString("PARAMS_VALUE");
				       cnt++;
				   };
				   if (rs.getString("PARAMS").equalsIgnoreCase("SWAP_FROZEN_END")) { 
				      Frozen_End = rs.getString("PARAMS_VALUE");
				      cnt++;
				   };				
				   if (rs.getString("PARAMS").equalsIgnoreCase("ROSTER_PUBLISH_DATE")) { 
				      Roster_Date = rs.getString("PARAMS_VALUE");
				      cnt++;
			       };
				   if (rs.getString("PARAMS").equalsIgnoreCase("ROSTER_PUBLISH_TIME")) { 
					  Roster_Time = rs.getString("PARAMS_VALUE");
					  cnt++;
				   };
				  
			}	
			rs.close();		    
		    stmt.close();		    
		    if (cnt < 4) {
		    	myRTN = "--";
		    } else {
				GregorianCalendar cal = new GregorianCalendar();
				DateFormat df = DateFormat.getDateInstance();
		        // Get the components of the date
		        int era = cal.get(Calendar.ERA);               // 0=BC, 1=AD
		        int year = cal.get(Calendar.YEAR);             // 2002
		        int month = cal.get(Calendar.MONTH);           // 0=Jan, 1=Feb, ...
		        int day = cal.get(Calendar.DAY_OF_MONTH);      // 1...
		        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK); // 1=Sunday, 2=Monday, ...
		         
		        // Get the components of the time
		        int hour12 = cal.get(Calendar.HOUR);            // 0..11
		        int hour24 = cal.get(Calendar.HOUR_OF_DAY);     // 0..23
		        int min = cal.get(Calendar.MINUTE);             // 0..59
		        int sec = cal.get(Calendar.SECOND);             // 0..59
		        int ms = cal.get(Calendar.MILLISECOND);         // 0..999
		        int ampm = cal.get(Calendar.AM_PM);             // 0=AM, 1=PM
		        int LastDayOfMonth = 0;
		    	System.out.println("today is "+cal.getTime()+"/"+df.format(cal.getTime()));    	
		        cal.add(Calendar.MONTH,5);
		        System.out.println("Tomorrow is "+cal.getTime()+"/"+df.format(cal.getTime())); 
		        Calendar test = new GregorianCalendar(year, month,day);
		        System.out.println("Test     is "+test.getTime());
		        GregorianCalendar thisday = new GregorianCalendar(); 
		        Date d = thisday.getTime();
		        String s = df.format(d); 
		        System.out.println("Today is " + s);       
		        Calendar roster_date = Calendar.getInstance();
		        roster_date.set(year,month,Integer.valueOf(Roster_Date).intValue());
		        if (day >= Integer.valueOf(Roster_Date).intValue()) {
		           System.out.println("Frozen_Start : "+Frozen_Start);
		           System.out.println("Frozen_End   : "+Frozen_End);
		           if (day == Integer.valueOf(Roster_Date).intValue()) {
		              if (hour24<=Integer.valueOf(Roster_Time.substring(0,2)).intValue()) {
		                 if (min>0) {
		                    Calendar aa1 = Calendar.getInstance();
		                    aa1.set(year, month, 1);
		                    aa1.roll(Calendar.DATE, -1);
		                    LastDayOfMonth = aa1.get(Calendar.DATE);
		                    System.out.println("date11 is "+aa1.getTime());
		        	     }   
		              } else {
		                 Calendar aa1 = Calendar.getInstance();
		                 aa1.set(year, month+1, 1);
		                 aa1.roll(Calendar.DATE, -1);
		                 LastDayOfMonth = aa1.get(Calendar.DATE);
		                 System.out.println("date22 is "+aa1.getTime());        	   	
		                 year = aa1.get(Calendar.YEAR);   
		                 month = aa1.get(Calendar.MONTH);        	   
		        	  }        		 
		           } else {
		              Calendar aa1 = Calendar.getInstance();
		              aa1.set(year, month, 1);
		              aa1.roll(Calendar.DATE, -1);
		              LastDayOfMonth = aa1.get(Calendar.DATE);
		              System.out.println("date33 is "+aa1.getTime());        	
		           }
		        } else {
		           System.out.println("Roster_Date  : "+Roster_Date);
		           System.out.println("Roster_Time  : "+Roster_Time);
		           Calendar aa = Calendar.getInstance();
		           aa.set(year, month, 1);
		           aa.roll(Calendar.DATE, -1);
		           LastDayOfMonth = aa.get(Calendar.DATE);        
		           System.out.println("date44 is "+aa.getTime());        
		       }
		       System.out.println("Last Day :"+LastDayOfMonth);
		       Frozen_End =Integer.toString(LastDayOfMonth);  
		  
		       Calendar start_date = Calendar.getInstance();
		       start_date.set(year,month,Integer.valueOf(Frozen_Start).intValue());
		       Calendar end_date = Calendar.getInstance();
		       end_date.set(year,month,Integer.valueOf(Frozen_End).intValue());
		       System.out.println("Start Date : " +start_date.getTime());
		       System.out.println("End Date   : " +end_date.getTime());
		       System.out.println("Roster Date: " +roster_date.getTime());
		       SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		       sdf.setCalendar(Calendar.getInstance());
		       Date s_start = sdf.parse(SwStart);
		       /*
		        ** create a GregorianCalendar from a Date object
		        */
		       GregorianCalendar swap_start = new GregorianCalendar();
		       swap_start.setTime(s_start);
		       Date s_end   = sdf.parse(SwEnd);
		       GregorianCalendar swap_end = new GregorianCalendar();
		       swap_end.setTime(s_end);		       
			   System.out.println("Swap Start: "+swap_start.getTime());
			   System.out.println("SwapEnd  : "+SwStart);
			   System.out.println("Swap End  : "+swap_end.getTime());
			   System.out.println("SwapEnd  : "+SwEnd);
		       if ((swap_start.after(start_date) && swap_start.before(end_date)) || (swap_end.after(start_date) && swap_end.before(end_date))) {
		          System.out.println("Roster Date: " + roster_date.getTime());
		          myRTN = "Y";
  		       }
		    }   
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
  		          if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
 			myRTN = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			myRTN = ex.toString() ;		    			
		} finally{
		}//catch/try
	
		return myRTN;							
	}
//	------------------------------------------------------------
	public String SingleChecking(String SwapNo){
  	 	String err_msg="no_err";
		String SQL;
		String req_id=null;
		String acp_id=null;
		String swNo=null;
		String swStart=null;
		String swEnd=null;
		String swPeriodMQ=null;
		String myLastStatus=null;		
		String rtn_txt=null;
		String ask_txt=null;
		String tmp_txt="";		
		boolean SkipDateCheck = false;
		boolean SkipAllChecks =false;		
		int RequstQuotaLeft=0;	
		int cnts;
		int rows;
		int row;
		try{	
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			Statement stmt=con.createStatement();						
			ResultSet rs=null;				
			Statement stmtx=con.createStatement();						
			ResultSet rsx=null;				
			Statement stmty=con.createStatement();						
			ResultSet rsy=null;				


			//1.0 get swap details								 			 					 			 	
			SQL = "select distinct last_status,req_id,acp_id," +
				  "to_char(period_start,'dd-mon-yy') as period_start,to_char(period_end,'dd-mon-yy') as period_end," +
				  "to_char(Period_start,'yyyymmdd')||to_char(period_end,'yyyymmdd') as total_period, " +
				  "lpad(req_key,10,' ') as swap_no " +
				  "from crewdir.swap_req where req_key ='"+SwapNo+"'"; 			 		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				myLastStatus = rs.getString("last_status");
				swNo=rs.getString("swap_no");
				req_id = rs.getString("req_id");
				acp_id = rs.getString("acp_id");
				swStart= rs.getString("period_start");
				swEnd= rs.getString("period_end");
				swPeriodMQ = rs.getString("total_period");			
			}									        
			rs.close();
 	 	
			//2.0 authorized no checking for this swap_no 
			SkipAllChecks = false;
			SQL = "SELECT rownum from CREWDIR.SWAP_SEND_FACTS WHERE SWAP_NO='"+SwapNo+"' AND MSG_TYPE = 'SKIP_CHECK'";
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){
				SkipAllChecks = true;
			}									        
			rs.close();
			
		    if (SkipAllChecks == true){		    	
		    	err_msg = "no_err";		    
		    }else{  //2.0
			
				//3.0 check start_date should be today + 2
				//3.1 last minute swap
				SkipDateCheck = false;
				SQL = "SELECT rownum from CREWDIR.SWAP_SEND_FACTS WHERE SWAP_NO='"+SwapNo+"' AND MSG_TYPE = 'LAST_MINUTE'";
				rs= stmt.executeQuery(SQL);		
				while(rs.next()){
					SkipDateCheck = true;
				}									        
				rs.close();
			
				//3.2 check date + 2  		
				if (SkipDateCheck == false){
					SQL = "SELECT TO_DATE('"+swStart+"','dd-mon-yy') - TO_DATE(SYSDATE,'dd-mon-yy') AS DATE_NUM FROM DUAL";
					rs= stmt.executeQuery(SQL);		
					while(rs.next()){
						if (rs.getInt("DATE_NUM")<4) {
							err_msg = "Request should be submitted three full calendar days before swap start date.";										
						}				
					}									        
					rs.close();
				}
				stmt.close();				
 			
				
//				 3.3 check swap date must >= 01-Jan-10
				if (err_msg.equals("no_err" )){
					
					//String temp = new String();
					//temp = swStart.substring(6);
					
					if (swStart.substring(7).equals("09"))
					{
						err_msg = "2009 duty swap is not allowed.";	
					}
					
				}
				
				
				///4.0 Check last status and Request Limits					 			
				if (err_msg.equals("no_err" )){
 							
					if (!((myLastStatus.equals("Accepted (inviter read)"))|(myLastStatus.equals("Accepted")))){
						err_msg = "The other party does not agree.";
					}else{				
						//3.1  check no of request for Requester limit				
						RequstQuotaLeft = QuotaRemain(req_id,swStart.substring(3,9 ));									
						if (RequstQuotaLeft <=0){
							err_msg ="Exceeded swap limit.";
						}else{					
							//3.2  check no of request for accapter
							RequstQuotaLeft = QuotaRemain(acp_id,swStart.substring(3,9 ));					
							if (RequstQuotaLeft <=0){
									err_msg ="Agree party exceeded swap limit."; 					
							}										
						}
					}
				}
							
						
				//5.0 Check overlap of requster existing swap requests  
				if (err_msg.equals("no_err" )){
					//5.1 (as requesting) get existing request start/end date 
					SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
						  "WHERE REQ_ID='"+req_id+"' AND "+
								 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
								 " AND (period_start between '"+swStart +"' and '"+swEnd+"' "+
									   "OR period_end between '"+swStart+"' and '"+swEnd+"' "+
									   "OR period_start <= '"+swStart+"' and period_end >= '"+swEnd+"'"+
									   ") " +
								 " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+req_id+"'))";
					         
					rsx= stmtx.executeQuery(SQL);		
					while(rsx.next()){
						tmp_txt = tmp_txt + rsx.getString("REQ_KEY") + " ";																						
						err_msg = "Swap #"+SwapNo+" overlapped with your #"+tmp_txt+"! "; 					

					}									        
					rsx.close();					

					if (err_msg.equals("no_err" )){
						//5.2 (as accept) get existing request start/end date 
						SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE ACP_ID='"+req_id+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+swStart +"' and '"+swEnd+"' "+
										   "OR period_end between '"+swStart+"' and '"+swEnd+"' "+
										   "OR period_start <= '"+swStart+"' and period_end >= '"+swEnd+"'"+
										   ") " +
									 " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+req_id+"'))";    
						rsx = stmtx.executeQuery(SQL);		
						while(rsx.next()){
							tmp_txt = tmp_txt + rsx.getString("REQ_KEY") + " ";																						
							err_msg = "Swap #"+SwapNo+" overlapped with your #"+tmp_txt+"! "; 					

						}									        
						rsx.close();
					}										
				} //if 5.0
				


				//6.0  Check overlap of agreed party
				if (err_msg.equals("no_err" )){
					//6.1 get existing request start/end date
					SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
						  "WHERE REQ_ID='"+acp_id+"' AND "+
								 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
								 " AND (period_start between '"+swStart +"' and '"+swEnd+"' "+
									   "OR period_end between '"+swStart+"' and '"+swEnd+"' "+
									   "OR period_start <= '"+swStart+"' and period_end >= '"+swEnd+"'"+
									   ") " +
								 " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+acp_id+"'))";								   
					         
					rsy= stmty.executeQuery(SQL);		
					while(rsy.next()){
						tmp_txt = tmp_txt + rsy.getString("REQ_KEY") + " ";
						//comment on 3 Nov 2005, explain the error message in details																						
						//err_msg = "Swap #"+SwapNo+" overlapped with agreed party's #"+tmp_txt+"! ";
						err_msg = "The agreed party has accepted and sent another swap #"+tmp_txt+" that overlaps with your swap #"+SwapNo+" to ICM. This swap is therefore cannot be sent to ICM."; 					
					}									        
					rsy.close();					
				
					if (err_msg.equals("no_err" )){
						//6.2 get existing request start/end date (as accepter)
						SQL = "SELECT REQ_KEY FROM CREWDIR.SWAP_REQ " +
							  "WHERE ACP_ID='"+acp_id+"' AND "+
									 "UPPER(last_status) in ('PROCESSING','INVITER REQUESTS TO WITHDRAW','RECEIVER REQUESTS TO WITHDRAW') " +
									 " AND (period_start between '"+swStart +"' and '"+swEnd+"' "+
										   "OR period_end between '"+swStart+"' and '"+swEnd+"' "+
										   "OR period_start <= '"+swStart+"' and period_end >= '"+swEnd+"'"+
										   ") " +
									 " AND (req_key not in (select distinct swap_no from swap_send_facts where msg_type='SWAP_OVER_SWAP' and ern='"+acp_id+"'))";						         
						rsy= stmty.executeQuery(SQL);		
						while(rsy.next()){
							tmp_txt = tmp_txt + rsy.getString("REQ_KEY") + " ";																						
							//comment on 3 Nov 2005, explain the error message in details																						
							//err_msg = "Swap #"+SwapNo+" overlapped with agreed party's #"+tmp_txt+"! ";
							err_msg = "The agreed party has accepted and sent another swap #"+tmp_txt+" that overlaps with your swap #"+SwapNo+" to ICM. This swap is therefore cannot be sent to ICM."; 					
							 					
						}									        
						rsy.close();					
					}
				}//if 6.0
				
				
				//7.0 check if any roster changed since invitation create
				if (err_msg.equals("no_err" )){
					eswapRequestingRosterCheck rst_check = new  eswapRequestingRosterCheck(SwapNo);
					err_msg = rst_check.getErr_msg(); 
				}//7.0
		    	
		    	
		    }//2.0
		    
		    stmt.close();
			stmtx.close();				
			stmty.close();							 			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
 			err_msg = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString() ;		    			
		} finally{
		}//catch/try
	
		return err_msg;							
	}
	
//	------------------------------------------------------------
	public String Requesting(String SwapNo){
		String err_msg = "no_err";
		String SQL= null;
		String swRemark=null;
		String roster_remark="";
		String Req_rmk ="";
		String Acp_rmk ="";
		String rtn_txt=null;
		String ask_txt=null;	
		String tmp_txt=null;
		String req_id=null;
		String acp_id=null;
		String swNo=null;
		String swStart=null;
		String swEnd=null;
		String swPeriodMQ=null;
		String myLastStatus=null;		
		String mq_rtn_swp_no = "";
		String mq_rtn_swp_type="";
		String myRTN = null;

		int tmp_cnt=0;
		try{	

			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			Statement stmt=con.createStatement();						
			ResultSet rs=null;				

			Statement stmt0=con.createStatement();						
			ResultSet rs0=null;				

			Statement stmt1=con.createStatement();						
			ResultSet rs1=null;				

			Statement stmtu=con.createStatement();
		

			//0.0 get swap details								 			 					 			 	
			SQL = "select distinct last_status,req_id,acp_id," +
				  "to_char(period_start,'dd-mon-yy') as period_start,to_char(period_end,'dd-mon-yy') as period_end," +
				  "to_char(Period_start,'yyyymmdd')||to_char(period_end,'yyyymmdd') as total_period, " +
				  "lpad(req_key,10,' ') as swap_no " +
				  "from crewdir.swap_req where req_key ='"+SwapNo+"'"; 			 		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				myLastStatus = rs.getString("last_status");
				swNo=rs.getString("swap_no");
				req_id = rs.getString("req_id");
				acp_id = rs.getString("acp_id");
				swStart= rs.getString("period_start");
				swEnd= rs.getString("period_end");
				swPeriodMQ = rs.getString("total_period"); 				 						
			}									        
			rs.close();
			stmt.close(); 
	
		    MQ_Send_Key =swNo;
			
								 
			//1.0 send request to FACTS by MQ (ACD07/ACD08)
			//1.1 FORMAT ACD07 MESSAGE
			//2.1.0 format remarks
	        //2.1.1.1 for req ern roster remarks
	        SQL = "SELECT to_char(R_DATE,'DD/MM') as R_DATE,REASON FROM SW_R_ROSTER_DATE " +	        	  "WHERE ERN='"+req_id+"' AND SWAP='Y' AND " +	        	  "REASON IS NOT NULL AND R_DATE BETWEEN '"+swStart+"' AND '"+swEnd+"'";
			rs0= stmt0.executeQuery(SQL);		
			while(rs0.next()){										
				Req_rmk = rs0.getString("R_DATE")+" "+rs0.getString("REASON")+" ";
			}									        
			rs0.close();
            if (Req_rmk.length() > 4 )
            	roster_remark = req_id + ":"+Req_rmk;


			//2.1.1.2 for acp ern roster remarks
			SQL = "SELECT to_char(R_DATE,'DD/MM') as R_DATE,REASON FROM SW_R_ROSTER_DATE " +
				  "WHERE ERN='"+acp_id+"' AND SWAP='Y' AND " +
				  "REASON IS NOT NULL AND R_DATE BETWEEN '"+swStart+"' AND '"+swEnd+"'";
			rs0= stmt0.executeQuery(SQL);		
			while(rs0.next()){										
				Acp_rmk = rs0.getString("R_DATE")+" "+rs0.getString("REASON")+" ";
			}									        
			rs0.close();
			stmt0.close(); 
			
			if (Acp_rmk.length() > 4 )
				roster_remark = roster_remark + acp_id + ":"+Acp_rmk;

			swRemark = swap_remark + roster_remark;
			swRemark=fixlen(swRemark,100);
			//1.0 checking 
			myRTN = swapFrozenChecking(swStart,swEnd);
			
			
			// Y = Auto Approve, N = No Auto Approve
			if (myRTN.equals("N" )||myRTN.equals("Y" )){
				
			   ask_txt = "KAD09" + swNo+ MQ_ACTION+myRTN +req_id+acp_id+swPeriodMQ+swRemark;
		    } else {
			   ask_txt = "KAD09" + swNo+ MQ_ACTION+"N"+req_id+acp_id+swPeriodMQ+swRemark;
		    };
//System.out.println("Swap Frozen Checking: "+myRTN+"/"+ask_txt);
			//-----------------------------				
			//3.1.1 get Requseter roster
			SQL = "SELECT to_char(ROSTER_DATE,'yyyymmdd') as roster_date, " +
					 "'KA '||RPAD(nvl(DUTY,' '),5,' ') AS DUTY," +
					 "RPAD(nvl(SECTOR_FROM,' '),4,' ') AS SECTOR_FROM,RPAD(nvl(SECTOR_TO,' '),4,' ') AS SECTOR_TO," +
					 "RPAD(nvl(SP_DUTY,' '),2,' ') AS SP_DUTY,SORT_ORDER " +
				  "FROM SWAP_REQ_ROSTER " +
				  "WHERE REQ_KEY='"+SwapNo+"' AND ERN='"+req_id+"'"+
				  "ORDER BY ROSTER_DATE,SORT_ORDER";       
			rs1= stmt1.executeQuery(SQL);
			tmp_txt ="";
			tmp_cnt=0;		
			while(rs1.next()){
				//detail roster
				tmp_txt = tmp_txt + rs1.getString("roster_date")+rs1.getString("duty")+rs1.getString("sector_from")+
						  rs1.getString("sector_to")+ rs1.getString("sp_duty");
				tmp_cnt++;					
			}													       
			rs1.close();	
				
			if (tmp_cnt >=10){  //No of entry   
				ask_txt = ask_txt + Integer.toString(tmp_cnt);				
			}else{
				ask_txt = ask_txt + '0' +Integer.toString(tmp_cnt);
			}			   
			ask_txt = ask_txt + fixlen(tmp_txt,1170);  //DUTYS

			//-----------------------------
			//3.2.1 get Accepter roster
			SQL = "SELECT to_char(ROSTER_DATE,'yyyymmdd') as roster_date, " +
					 "'KA '||RPAD(nvl(DUTY,' '),5,' ') AS DUTY," +
					 "RPAD(nvl(SECTOR_FROM,' '),4,' ') AS SECTOR_FROM,RPAD(nvl(SECTOR_TO,' '),4,' ') AS SECTOR_TO," +
					 "RPAD(nvl(SP_DUTY,' '),2,' ') AS SP_DUTY,SORT_ORDER " +
					  "FROM SWAP_REQ_ROSTER " +
					"WHERE REQ_KEY='"+SwapNo+"' AND ERN='"+acp_id+"'" +					  
					  "ORDER BY ROSTER_DATE,SORT_ORDER";       
			rs1= stmt1.executeQuery(SQL);
			tmp_txt ="";
			tmp_cnt=0;		
			while(rs1.next()){
				//detail roster
				tmp_txt = tmp_txt + rs1.getString("roster_date")+rs1.getString("duty")+rs1.getString("sector_from")+
				rs1.getString("sector_to")+ rs1.getString("sp_duty");
				tmp_cnt++;					
			}													       
			rs1.close();
			stmt1.close(); 					
			if (tmp_cnt >=10){  //No of entry   
				ask_txt = ask_txt + Integer.toString(tmp_cnt);				
			}else{
				ask_txt = ask_txt + '0' +Integer.toString(tmp_cnt);
			}			   
			ask_txt = ask_txt + fixlen(tmp_txt,1170);  //DUTYS
			
			MQ_Send_Text =ask_txt;	

			System.out.println("KACCD_LOG:MQ request message: "  + ask_txt);	
			 GenericCrewDirect.writeInfoLog("KACCD_LOG:MQ request message: "  + ask_txt);	
			//4.0 Send now MQ  (NOT READY) try 3 times if have error
			for (int s=0;s<2;s++){						
				MQServices swpMQ = new MQServices("eswap");										
				swpMQ.setMq_ask_txt(ask_txt);	            
				if (swpMQ.call_mq()==true){
					rtn_txt = swpMQ.getMq_rtn_txt();
								System.out.println("KACCD_LOG:MQ response message: "  + rtn_txt);	
								 GenericCrewDirect.writeInfoLog("KACCD_LOG:MQ response message: "  + rtn_txt);	
					//4.1 check error					
					if (!rtn_txt.substring(5,7).equals("  " )){
						    //handle errors	
							if (rtn_txt.substring(5,7).equals("01") || rtn_txt.substring(5,7).equals("02") ||
							    rtn_txt.substring(5,7).equals("03") || rtn_txt.substring(5,7).equals("04") || 
							    rtn_txt.substring(5,7).equals("05") || rtn_txt.substring(5,7).equals("06") ||
							    rtn_txt.substring(5,7).equals("07") || rtn_txt.substring(5,7).equals("08") ||
							    rtn_txt.substring(5,7).equals("09") || rtn_txt.substring(5,7).equals("ER")) {
							//add on 08 Apr 2009 to display full message from MQ - rtn_txt.substring(7)	
									err_msg = "CCS: "+rtn_txt;
									break; 										
							}else{
								err_msg = "Sorry, system is busy at this moment (E005), swap request cannot be submitted. Please try it later, if problem still exists, call Crew Control at your earliest convenience.<br>"+rtn_txt;
							}						
						
					}else{
						mq_rtn_swp_no = rtn_txt.substring(7,17).trim() ;
						mq_rtn_swp_type =rtn_txt.substring(17,20).trim() ;
						if (!mq_rtn_swp_no.equals(swNo.trim())){
							err_msg = "Sorry, system is busy at this moment (E005), swap request cannot be submitted. Please try it later, if problem still exists, call Crew Control at your earliest convenience.<br>"+rtn_txt;						 
						}else{
							err_msg = "no_err";
							break; //no error exit loop							
						}
					} //4.1
				}//call mq
			}//s
			
			  GenericCrewDirect.writeInfoLog("err_msg:"+err_msg);
			//5.0 update data string being send to MQ for batch job resend again
			 SQL = "INSERT INTO CREWDIR.MQ_RESEND (SWAP_KEY,STR_DATA,SENT) VALUES " +
				   " ('"+MQ_Send_Key+"','"+MQ_Send_Text.trim()+"','N')";
		
			 int rows = stmtu.executeUpdate(SQL);
             
             stmtu.close();
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  GenericCrewDirect.writeInfoLog(sqlex.getMessage());
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_msg = sqlex.toString();
		}catch (Exception ex) {
			ex.printStackTrace();
			 GenericCrewDirect.writeInfoLog(ex.getMessage());
			err_msg = ex.toString() ;		    			
		} finally{
		}//catch/try
	
		return err_msg;							
	}


//------------------------------------------------------------
	public String Updating(String SwapNo,String SwapRemark){
		String SQL;
		String req_id=null;
		String acp_id=null;
		String myLastStatus=null;
		String err_msg = "no_err";
		int rows;
		int row;
		try{	

			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}			
			Statement stmtu = con.createStatement();			        


			if (MQ_ACTION.equals("ADD")){							
				//5.1 update last status in swap_req table
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Processing' ,SYS_REMARK = '"+SwapRemark+ "' " +
					  "WHERE REQ_KEY='" + SwapNo + "'";			
				rows = stmtu.executeUpdate(SQL);      
		
				//5.2. update swap_status			
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,REMARK,TIME_LOG) VALUES " +
					  " ('" + SwapNo + "','Processing','" + iern +"','"+SwapRemark+"', sysdate)";
				row = stmtu.executeUpdate(SQL);
			
				if (row < 1)
					err_msg = "Fail, System update error.";												

			}

			if (MQ_ACTION.equals("DEL")){							
				//5.1 update last status in swap_req table
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Withdrawn' ,SYS_REMARK = '"+SwapRemark+ "' " +
					  "WHERE REQ_KEY='" + SwapNo + "'";			
				rows = stmtu.executeUpdate(SQL);      
		
				//5.2. update swap_status			
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,REMARK,TIME_LOG) VALUES " +
					  " ('" + SwapNo + "','Withdrawn','" + iern +"','"+SwapRemark+"', sysdate)";
				row = stmtu.executeUpdate(SQL);
			
				if (row < 1)
					err_msg = "Fail, System update error.";												

			}

			

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_msg = sqlex.toString();																																		
		}catch (Exception ex) {
			ex.printStackTrace();		
			err_msg = ex.toString();    			
		} finally{
		}//catch/try
		return err_msg;						
	}
//	------------------------------------------------------------	


//	=========================================
 private int QuotaRemain(String ern,String swStart){
		
	    //int quota_limit=5;
 		int quota_limit=3;
		int myrtn=0;
		
		// 1 request and 2 accept 
		int quota_request_limit = 1;
		int quota_accept_limit = 2;
		try{	
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			ResultSet rs1=null;			
			Statement stmt1 = con.createStatement();

			ResultSet rs2=null;			
			Statement stmt2 = con.createStatement();

			ResultSet rs3=null;			
			Statement stmt3 = con.createStatement();
			
			ResultSet rs4=null;			
			Statement stmt4 = con.createStatement();
			
			ResultSet rs5=null;			
			Statement stmt5 = con.createStatement();
		
			ResultSet rs6=null;			
			Statement stmt6 = con.createStatement();
			
			
			String SQL = null;
		//	String yr_month=null;
			int extra_quota =0;
		//	int extra_request_quota =0;
		//	int extra_accept_quota =0;
			int used_as_request =0;
			int used_as_accept=0;			
		//	int used_quota = 0;
		//	int cnts =0;
			
			
			
			
			


			//1.0 get admin input user limations
			/*SQL ="select DISTINCT EXTRA_QUOTA from crewdir.sw_r_request_lmt "+
				 "where ern='"+ern+"' AND upper(to_char(to_date(MONTH_YEAR,'YYYYMM'),'MON-YY'))='"+ swStart.toUpperCase()+"'";
			rsl= stmtl.executeQuery(SQL);		
			while(rsl.next()){										
				extra_quota = rsl.getInt("EXTRA_QUOTA");				
				break;
			}									        
			rsl.close();
			stmtl.close();
			
			quota_limit=quota_limit + extra_quota;*/
			
			
			// get request and accept quota input by Admin
			SQL ="select PARAMS_VALUE from crewdir.ADMIN_PARAMETER " +
			 " WHERE PARAMS_ENABLE ='Y' AND PARAMS ='MONTHLY_REQUEST_QUOTA' ";
			rs5= stmt5.executeQuery(SQL);		
			while(rs5.next()){
				quota_limit = Integer.parseInt(rs5.getString("PARAMS_VALUE"));				
				break;
			}									        
			rs5.close();
			stmt5.close();
			
			/*removed by PAX 1153
			SQL ="select PARAMS_VALUE from crewdir.ADMIN_PARAMETER " +
			 " WHERE PARAMS_ENABLE ='Y' AND PARAMS ='ACCEPT_QUOTA' ";
			rs6= stmt6.executeQuery(SQL);		
			while(rs6.next()){
				quota_accept_limit = Integer.parseInt(rs6.getString("PARAMS_VALUE"));				
				break;
			}									        
			rs6.close();
			stmt6.close();
			*/
			
			
			
			// get individual extra request quota input by Admin 
			SQL ="select DISTINCT EXTRA_QUOTA from crewdir.sw_r_request_lmt "+
			 "where ern='"+ern+"' AND upper(to_char(to_date(MONTH_YEAR,'YYYYMM'),'MON-YY'))='"+ swStart.toUpperCase()+"'";// AND QUOTA_TYPE ='R' ";
			rs1= stmt1.executeQuery(SQL);		
			while(rs1.next()){
				
				extra_quota = rs1.getInt("EXTRA_QUOTA");				
				break;
			}									        
			rs1.close();
			stmt1.close();
			
			quota_request_limit = quota_limit + extra_quota;
			/*removed by PAX1153
			// get individual extra accept quota input by Admin
			SQL ="select DISTINCT EXTRA_QUOTA from crewdir.sw_r_request_lmt "+
			 "where ern='"+ern+"' AND upper(to_char(to_date(MONTH_YEAR,'YYYYMM'),'MON-YY'))='"+ swStart.toUpperCase()+"' AND QUOTA_TYPE ='A' ";
			rs4= stmt4.executeQuery(SQL);		
			while(rs4.next()){
				extra_accept_quota = rs4.getInt("EXTRA_QUOTA");				
				break;
			}									        
			rs4.close();
			stmt4.close();
			*/
			
			quota_accept_limit =  quota_limit + extra_quota;
			
			
										
			//2.0   check no of request for Requester
			//Comment on 8May2007 SQL Tuning
			/* SQL ="select count (*) as cnt from crewdir.swap_req "+
				 "where last_status in ('Processing','Approved','Disapproved','Inviter requests to withdraw','Receiver requests to withdraw','Swap over swap') and "+
				 "to_char(period_start,'MON-yy') = '"+swStart.toUpperCase() +"' and req_id='"+ern+"'";
            */
			SQL ="select /*+ index(swap_req idx_swap_req_04) */ count (*) as cnt from crewdir.swap_req "+
			 "where last_status in ('Processing','Approved','Disapproved','Inviter requests to withdraw','Receiver requests to withdraw','Swap over swap') and "+
			 "to_char(period_start,'MON-yy') = '"+swStart.toUpperCase() +"' and req_id='"+ern+"'";
			
			rs2= stmt2.executeQuery(SQL);
			System.out.println("CCD Swap Requesting Count SQL - "+SQL);			
			while(rs2.next()){										
				used_as_request = rs2.getInt("cnt");
			}									        
			rs2.close();
			stmt2.close();
						

			//3.0   check no of request for acceptor
			//Comment on 8May2007 SQL Tuning
			/* SQL ="select count (*) as cnt from crewdir.swap_req "+
			        "where last_status in ('Processing','Approved','Disapproved','Inviter requests to withdraw','Receiver requests to withdraw','Swap over swap') and "+			 
				 "to_char(period_start,'MON-yy') = '"+swStart.toUpperCase() +"' and acp_id='"+ern+"'";
            */
			SQL ="select /*+ index(swap_req idx_swap_req_05) */ count (*) as cnt from crewdir.swap_req "+
	             "where last_status in ('Processing','Approved','Disapproved','Inviter requests to withdraw','Receiver requests to withdraw','Swap over swap') and "+			 
  		         "to_char(period_start,'MON-yy') = '"+swStart.toUpperCase() +"' and acp_id='"+ern+"'";
			
			rs3= stmt3.executeQuery(SQL);
			System.out.println("CCD Swap Requesting Count SQL 2- "+SQL);			
			while(rs3.next()){										
				used_as_accept = rs3.getInt("cnt");
			}									        
			rs3.close();
			stmt3.close();
			
			//4.0 return no of limit available
			//used_quota=used_quota + used_as_request + used_as_accept;			
			//myrtn = quota_limit - used_quota;
			
			quota_request_limit = quota_request_limit - used_as_request;
			quota_accept_limit = quota_accept_limit - used_as_accept;
			
			myrtn = (quota_request_limit > quota_accept_limit) ? quota_accept_limit : quota_request_limit;
			
			
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
	                
		}catch (Exception ex) {
			ex.printStackTrace();			 		    			
		} finally{
		}//catch/try						    	    	
				
		return myrtn;
	}
	//------------------------------
	
	


//----------------------------------	
	private String fixlen(String iTXT,int len){
		String tmp="";
		for (int x=0;x<len-iTXT.length();x++){
			tmp=tmp+" ";
		}	
		return iTXT+tmp;	
	}

	//------------------------------
	private void setSwapRemark(){
		String myRTN = " ";
		if (sw_type.equals("SEQ")){
			swap_remark = "SEQ:"+arr_sw_no[0]+","+arr_sw_no[1]+","+arr_sw_no[2];
		}else{
			if (sw_type.equals("ALL")){
				swap_remark = "ALL:"+arr_sw_no[0]+","+arr_sw_no[1];
			}else{
				swap_remark = " ";
			}
		}
				
	}
	//	------------------------------
	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

}
