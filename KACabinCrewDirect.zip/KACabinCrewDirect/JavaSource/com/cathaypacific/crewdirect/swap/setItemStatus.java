package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;


public class setItemStatus {
	
	private Connection con=null;
	private String iern;
	private String action_request;
	private String item_key;
	private String item_remark;
	private String err_code;
	private boolean success;
	
	public setItemStatus() {
		super();		
	}

	public setItemStatus(String iern,String action_req,String item_key) {
		this.iern = iern;				
		this.action_request = action_req;
		this.item_key = item_key;
				 
		err_code = Update_Status();
		
		
		if (err_code.equals("no_err")){
			success = true;
		}else{
			success = false;
		}
		
	}

	//batch delete 
	public setItemStatus(String iern,String start_date,String end_date,String last_status) {
		String SQL;
		String req_id=null;
		String acp_id=null;
		String myLastStatus=null;
		String arrReqKey [] = new String [1000];
		int arr_cnt=0;
		
		boolean go = true;
		int rows;
		int row;
		try{	
			
			err_code = "no_err";
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			Statement stmt=con.createStatement();;
			Statement stmtx=stmt = con.createStatement();			
			//1.0 get swap id details for this criteria
			ResultSet rs=null;									 			 					 			 	
			SQL = "select distinct req_key from crewdir.swap_req "+  			
						"WHERE REQ_ID='"+iern+"' AND LAST_STATUS='" + last_status + "' AND  LAST_STATUS NOT IN ('Processing','Rejected','Disapproved','Approved','Withdrawn','Inviter requests to withdraw','Receiver requests to withdraw') " +
				              "AND (PERIOD_START BETWEEN to_date('"+start_date.toUpperCase()+"','DD-MON-YY') AND to_date('"+end_date.toUpperCase()+"','DD-MON-YY'))";

			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				arrReqKey[arr_cnt]= rs.getString("req_key");
				arr_cnt++;
			}									        
			rs.close();
			stmt.close();

			//2.0 update status
			for (int x=0;x<arr_cnt;x++){
				con.setAutoCommit(false);
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Delete',TIME_LOG = SYSDATE " +
					  "WHERE REQ_KEY='"+arrReqKey[x]+"'";
				rows = stmtx.executeUpdate(SQL);      
			
				// insert  swap_status table
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
					  " ('" + arrReqKey[x] + "','DELETE','" + iern + "', sysdate)";
				rows = stmtx.executeUpdate(SQL);

				if (rows <0){
					err_code = "Fail to update database.";
					con.rollback();			
				}else{
					con.commit();
				}					
				
			}
			stmtx.close();

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.rollback();
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_code = sqlex.toString();			
		}catch (Exception ex) {
			ex.printStackTrace();		
			err_code = ex.toString();    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  err_code= e.toString();
			   }
			} //if  
		}//catch/try
										
				
	}	

//------------------------------------------------------------
	public String Update_Status(){
		String SQL;
		String req_id=null;
		String acp_id=null;
		String myLastStatus=null;
		String err_msg = "no_err";
		boolean go = true;
		int rows;
		int row;
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			Statement stmt=con.createStatement();;
			Statement stmtx=stmt = con.createStatement();			
			//0.0 get swap id details
			ResultSet rs=null;									 			 					 			 	
			SQL = "select distinct last_status,req_id,acp_id,to_char(period_start,'dd-mon-yy') as period_start,to_char(period_end,'dd-mon-yy') as period_end from crewdir.swap_req where req_key ='"+item_key+"'"; 			
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				myLastStatus = rs.getString("last_status");
				req_id = rs.getString("req_id");
				acp_id = rs.getString("acp_id"); 							
			}									        
			rs.close();
			stmt.close();
System.out.println("key:"+item_key+"/req:"+action_request+"/last:"+myLastStatus);			
			go = true;
			if (action_request.toUpperCase().equals("DELETE")){
				if (myLastStatus.equals("Processing")||myLastStatus.equals("Rejected")||
					myLastStatus.equals("Disapproved")||myLastStatus.equals("Approved")||
					myLastStatus.equals("Withdrawn")||myLastStatus.equals("Inviter requests to withdraw")||
					myLastStatus.equals("Receiver requests to withdraw")){
					go =false;
					err_msg = "Error! This swap cannot be deleted.";
				}
			} else {	
				if (myLastStatus.equals("Rejected")||myLastStatus.equals("Disapproved")||
					    myLastStatus.equals("Approved")||myLastStatus.equals("Withdrawn")) {
					go =false;
					err_msg = "Error! The swap request is released.";
				} else {
					if (myLastStatus.equalsIgnoreCase("processing")) {
						if (action_request.equalsIgnoreCase("Inviter requests to withdraw")||
							action_request.equalsIgnoreCase("Receiver requests to withdraw")){
						   go = true;
						} else {	
						   go =false;
						   err_msg = "Error! The swap request is being processed.";
						}
					}				
					
				}					
			}
			
			if (go){			
				if (!myLastStatus.equals(action_request)){  //prevent duplication of status //don't update new status if last status is
  				   //2.0 update other New status  						
				   //2.1 update last status in swap_req table
				   SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = '"+action_request + "',TIME_LOG = SYSDATE " +
					     "WHERE REQ_KEY='" + item_key + "'";
				   rows = stmtx.executeUpdate(SQL);      
                   if (rows > 0 ) {			
					  //2.2 update swap_status
					  SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
					        " ('" + item_key + "','" + action_request + "','" + iern + "', sysdate)";
				      rows = stmtx.executeUpdate(SQL);				
					  if (rows <0) {			
					     err_msg = "Fail to update swap status to database.";
					     con.rollback();
					  } else {
					  	con.commit();
					  }
                   } else {
                      err_msg = "Fail to update last status to database.";
                      con.rollback();
                   }
				}			
			}
			stmtx.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			err_msg = sqlex.toString();			
		}catch (Exception ex) {
			ex.printStackTrace();		
			err_msg = ex.toString();    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  err_msg= e.toString();
			   }
			} //if  
		}//catch/try
		return err_msg;						
	}
	


	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}


	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

	/**
	 * @param string
	 */
	public void setErr_code(String string) {
		err_code = string;
	}

}
