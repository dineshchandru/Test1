/*
 * Created on Jul 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class eswapCheckDuplication {
	private boolean isDuplicated = false;
	private String err_msg;
	private Connection con=null;
		 
	public eswapCheckDuplication() {
		super();
	}


	public eswapCheckDuplication(String req_ern,String acp_ern, String swStart,String swEnd) {
		String err_code = "Duplicated with swap #";
		try{	

			dbconnect db = new dbconnect();
			con = db.getConn();
			ResultSet rs=null;			
			Statement stmt = con.createStatement();
									
			String SQL ="SELECT DISTINCT  REQ_KEY  FROM SWAP_REQ "+ 
				         "where  REQ_ID='"+req_ern+"' AND ACP_ID='"+acp_ern+"' AND " +				         	     "PERIOD_START ='"+swStart+"' AND PERIOD_END = '"+swEnd+"' AND " +				         	     	"UPPER(LAST_STATUS) IN ('NOT_OPENED')";
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				err_code = err_code + rs.getString("REQ_KEY")+" ";
				isDuplicated = true;								
			}									        
			rs.close();
			stmt.close(); 
			
			if (isDuplicated){
				err_msg = err_code;
			}else{
				err_msg = "no_err";
			}
						
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  err_msg = e.toString();
			   }
			} //if  
		}//catch/try						    	    	


	}


	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public boolean isDuplicated() {
		return isDuplicated;
	}

}
