
package com.cathaypacific.crewdirect.swap;

import java.util.Date;


public class sw_r_PeriodBean {

	/**
	 * @param ern
	 * @param startdate
	 * @param enddate
	 * @param reason
	 */
	private String ern;
	private Date start_date;
	private Date end_date;
	private String reason;
	
	public sw_r_PeriodBean() {
		super();		
	}

	public sw_r_PeriodBean(String ern,Date sdate,Date edate,String reason) {
		this.ern = ern;
		this.start_date = sdate;
		this.end_date = edate;
		this.reason = reason;		
	}

	/**
	 * @return
	 */
	public Date getEnd_date() {
		return end_date;
	}

	/**
	 * @return
	 */
	public String getErn() {
		return ern;
	}

	/**
	 * @return
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @return
	 */
	public Date getStart_date() {
		return start_date;
	}

	/**
	 * @param date
	 */
	public void setEnd_date(Date date) {
		end_date = date;
	}

	/**
	 * @param string
	 */
	public void setErn(String string) {
		ern = string;
	}

	/**
	 * @param string
	 */
	public void setReason(String string) {
		reason = string;
	}

	/**
	 * @param date
	 */
	public void setStart_date(Date date) {
		start_date = date;
	}

}
