/*
 * Created on Jul 27, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class swapSimulateRoster {

	private String err_code ="no_err";
	private Connection con=null;
	private int ern_cnts=0;
	
	private String [][] lst_date = null;
	private int lst_date_cnt = 0;
	
	private ArrayList arr_roster = new ArrayList(); 
	private int arr_roster_cnt=0;  
	private String cat_seniority= new String("");
		 	  
	public swapSimulateRoster() {
		super();
	}
	
    //max 9 people can be simulate 
	public swapSimulateRoster(String iern,String StartDate,String EndDate,String date_offset,String [] erns) {
		String crew_id="";
		try{
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			//0.0 get connect 							
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			
			//1.0 find no of erns 
			for (int x=0;x<erns.length;x++){
				if (!erns[x].equals(""))
				    ern_cnts++;
			}  

			//2.0 Make array of date
			lst_date = makeDates(StartDate,EndDate,date_offset);
						
			//3.0 get all erns roster 
			//3.1 put myern 1st	
			crew_id = "My Roster";
			cat_seniority = "";
			arr_roster.add(new swapSimulateRosterBean(crew_id,cat_seniority,createRosters(iern,StartDate,EndDate,date_offset)));
			arr_roster_cnt++;
			
			//put other erns
			for (int p=0;p<ern_cnts;p++){
				crew_id = getCrewID(erns[p]);
				arr_roster.add(new swapSimulateRosterBean(crew_id,cat_seniority,createRosters(erns[p],StartDate,EndDate,date_offset)));
				arr_roster_cnt++;
			}
			
		//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
		}catch (Exception ex) {
			ex.printStackTrace();
			err_code = ex.toString() ;		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();					  
				  err_code = e.toString();
			   }
			} //if  
		}//catch/try		
	}
	
  //-------------------------------
	public String [][] createRosters(String ern,String s_date,String e_date,String date_offset){
			
		String myRoster [][]  = new String [200][3];  //date,duty,swapable
		String tmpRoster[][] = new String [200][2];
		int myRosterCnt=0;		
		int rcnt=0;
		int tmp_cnt=0;
		String duty="";
		Date StartDate=null;
		Date EndDate=null;
		Date tempdate=null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		try{
			ResultSet rs=null;
			String SQL="";
			Statement stmt=con.createStatement();
			
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			for (int k=0;k<200;k++){
				myRoster[k][0]="";
				myRoster[k][1]="";
				myRoster[k][2]="";
				
				tmpRoster[k][0]="";
				tmpRoster[k][1]="";								
			}

						
			//1.0 get roster details for input date ranage
			SQL = "SELECT to_char(roster_date,'DD-MON-YY') as rdate,DUTY,SP_DUTY,SECTOR_FROM," +						"SECTOR_TO,roster_date,sort_order FROM V_ROSTER_PUBLIC " +				  "WHERE STAFFID='"+ern+"' AND " +				  	     "roster_date between to_date('"+s_date+"','DD-MON-YY')-"+date_offset+" and to_date('"+e_date+ "','DD-MON-YY')+ "+date_offset+" "+				  "ORDER BY ROSTER_DATE,SORT_ORDER";
				   
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){															
				//format duty -->eg: 0251[bd] HKGLON
				duty = rs.getString("DUTY");
				if (!rs.getString("SP_DUTY").equals(" "))
					duty = duty+"/"+rs.getString("SP_DUTY");								
				duty = duty +" "+rs.getString("SECTOR_FROM")+rs.getString("SECTOR_TO");
				
				tmpRoster[rcnt][0] = rs.getString("RDATE");  //date
				tmpRoster[rcnt][1] = duty; //duty								
				rcnt++;		
			}									        
			rs.close();
						
			
			
			//2.0 format return array
			myRosterCnt=0;			
			
			for (int p=0;p<lst_date_cnt;p++){
	            duty="";
				myRosterCnt=0;
				for (int x=0;x<rcnt;x++){
					if (lst_date[p][0].equals(tmpRoster[x][0])){
						if (myRosterCnt ==0){
							duty = tmpRoster[x][1];											
						}else{
							duty=duty+"<BR>"+tmpRoster[x][1];
						}
						myRosterCnt++;						
					}					           						
				}
				myRoster[p][0] = lst_date[p][0]; //date
				myRoster[p][1] = duty; //duty
			}										

						
			//3.0 check any date block by user or systems.
			//3.1 get user-self block date
			SQL =  "SELECT to_char(B_DATE,'DD-MON-YY') as BDATE,B_DATE FROM CREWDIR.SW_R_BLOCK_ROSTER " +
				   "WHERE ERN='"+ern+"' AND " +				   	"B_DATE between to_date('"+s_date+"','DD-MON-YY')-"+date_offset+" and to_date('"+e_date+ "','DD-MON-YY')+ "+date_offset+" "+				   	"ORDER BY B_DATE";						   			
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){
				for (int p=0;p<lst_date_cnt;p++){
					if (myRoster[p][0].equals( rs.getString("BDATE" )))
					    myRoster[p][2] = "B";
				}																			
			}
			rs.close();

			//3.2 system blocked Dates by Peroid
			SQL =  "SELECT DISTINCT START_DATE,END_DATE " +
							"FROM CREWDIR.SW_R_RESTRICT_PERIOD " +
							"WHERE ERN='" +ern+ "' AND START_DATE  >= to_date('" +s_date+"','DD-MON-YY') " +
						  "ORDER BY START_DATE";
					
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){
				StartDate = rs.getDate("START_DATE" );
				EndDate = rs.getDate("END_DATE");		
				for (int k=0;k<lst_date_cnt;k++){
					tempdate = formatter.parse(myRoster[k][0] );
					if (tempdate.compareTo(StartDate) >= 0){				    	 
						if (tempdate.compareTo(EndDate) <= 0)
							myRoster[k][2]="N";						   						   		
					}							
				}																			
			}									        
			rs.close();


			//3.3 system blocked Dates
			SQL =  "SELECT to_char(R_DATE,'DD-MON-YY') as RDATE,R_DATE FROM CREWDIR.SW_R_ROSTER_DATE " +
				   "WHERE ERN='"+ern+"' ORDER BY R_DATE";						   			
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				for (int p=0;p<lst_date_cnt;p++){
					if (myRoster[p][0].equals( rs.getString("RDATE" )))
						myRoster[p][2] = "N";
				}																			
			}
			rs.close();
			
			
			
			stmt.close();					
			
						
						
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
		}//catch/try						
		
		return myRoster;
	}

//------------------------------------------------------

	public String [][] makeDates(String s_date,String e_date,String offset){

		String [][] rtn = new String[200][3];
		lst_date_cnt=0;
		boolean markexchange=false;
		try{
			//try to conect if no connection
			if (con ==null) {						
				dbconnect db = new dbconnect();
				con = db.getConn();				        
			}

			for(int x=0;x<200;x++){
				rtn[x][0]="";
				rtn[x][1]="";
				rtn[x][2]="";
			}

					
			Statement stmt=con.createStatement();						
			ResultSet rs=null;
			//1.0 get date ranage +/- 10 days
			String SQL ="SELECT to_char((TO_DATE('"+s_date+"','DD-MON-YY')-"+offset+") + (ROWNUM - 1),'DD-MON-YY') DATEGEN," +				        "substr(to_char((TO_DATE('"+s_date+"','DD-MON-YY')-"+offset+") + (ROWNUM - 1),'DY'),1,1) as WK "+
			 			"FROM ALL_OBJECTS WHERE "+ 
						"rownum <= (TO_DATE('"+e_date+"','DD-MON-YY')+"+offset+") - (TO_DATE('"+s_date+"','DD-MON-YY')-"+offset+") + 1 ";
				   
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){
				rtn[lst_date_cnt][0] = rs.getString("DATEGEN");  //date
				rtn[lst_date_cnt][2] = rs.getString("WK");  //week
				//don't change following three if statement sequence as it mark swap period	
				if (s_date.equals(rs.getString("DATEGEN") ))
					markexchange = true;
														
				if (markexchange)
				    rtn[lst_date_cnt][1] = "X";  //swap period								
				
				if (e_date.equals(rs.getString("DATEGEN") ))
					markexchange = false;

				lst_date_cnt++;
			}									        
			rs.close();
			stmt.close();			

		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
		}//catch/try						
		
		return rtn;
	}

	//=========================================
	private String getCrewID(String iern){
		String rtn="";
		try{
			if (con==null){			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}
			Statement stmt=con.createStatement();			 			 					 			 		 		
			String SQL =  "SELECT DISTINCT CREW_ID, (CAT1 || CAT || CAT2) AS CATEGORY FROM ISDCREW.CREWDB_4_ALL  " +
								  "WHERE ERN ='"+iern+"'";
			ResultSet rs= stmt.executeQuery(SQL);		
			while(rs.next()){				
				rtn  = rs.getString("CREW_ID");
				setCat_seniority(rs.getString("CATEGORY"));
				break;
			}									        
			rs.close();
			stmt.close(); 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace(); 		    			
		} finally{
	  
		}//catch/try						    	    	
			
		return rtn;
	}

	/**
	 * @return
	 */
	public ArrayList getArr_roster() {
		return arr_roster;
	}

	/**
	 * @return
	 */
	public int getArr_roster_cnt() {
		return arr_roster_cnt;
	}

	/**
	 * @return
	 */
	public int getErn_cnts() {
		return ern_cnts;
	}

	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

	/**
	 * @return
	 */
	public String[][] getLst_date() {
		return lst_date;
	}

	/**
	 * @return
	 */
	public int getLst_date_cnt() {
		return lst_date_cnt;
	}

	/**
	 * @param string
	 */
	public void setCat_seniority(String string) {
		cat_seniority = string;
	}

}
