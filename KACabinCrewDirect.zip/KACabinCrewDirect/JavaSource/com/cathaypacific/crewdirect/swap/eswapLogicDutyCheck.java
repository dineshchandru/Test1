package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.roster.othsRosterBean;

public class eswapLogicDutyCheck {
	
	private Connection con=null;
	private othsRosterBean[] rosters = new othsRosterBean[500];
	
	//sw indicator variables
	private sw_r_PeriodBean [] rPeriod = new sw_r_PeriodBean[500];
	private int  r_Period_cnt = 0;  
	private sw_r_DutyBean [] rDuty = new sw_r_DutyBean[500];
	private int  r_Duty_cnt = 0;  
	private sw_r_RosterDateBean [] rRosterDate = new sw_r_RosterDateBean[500];
	private int  r_RosterDate_cnt = 0;  
	private sw_r_BlockRosterBean [] rBlockDate = new sw_r_BlockRosterBean[500];
	private int r_BlockDate_cnt=0 ;  

	private int lst_count=0;

	private boolean haveNBCode;
	private boolean haveError;	
	private String err_msg;
	
	private Date swStart;
	private Date swEnd;
	private SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");	 


	//	----------------------------------------------------------------------------------		
	public eswapLogicDutyCheck() {
		super();
	}		

//	----------------------------------------------------------------------------------		
	public eswapLogicDutyCheck(String ern,String StartDate,String EndDate) {
		String err_txt="";
		try{
			swStart  = formatter.parse(StartDate);
			swEnd = formatter.parse(EndDate);
		}catch(Exception e){
			e.printStackTrace(); 
		}

		try{
		//***********************************************		
			dbconnect db = new dbconnect();
			con = db.getConn();
									
			//0.0 get Swap Constraint
			getSwapRestriction(ern);
			
			//1.0 swap indicator
			err_txt = SwapIndicatorCheck(ern,StartDate,EndDate);
			if (err_txt.equals("no_err" )){
				//2.0 duty code (NB)
				err_txt = NB_CodeCheck(ern,StartDate,EndDate);									 
			}  //1.0	
			
			//4.0 set return variables
			if (err_txt.equals("no_err" )){
				haveError = false;	
			}else{
				haveError = true;			
			}		
			err_msg = err_txt;		
		
		//***********************************************	
		
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();				  
			   }
			} //if  
		}//catch/try							
	}

	
	//	----------------------------------------------------------------------------------	
	public String SwapIndicatorCheck(String iern,String StartDate,String EndDate) {
		String err_msg = "no_err";
		String SQL = null;
		try{				
			if (con==null){			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}
			ResultSet rs=null;			
			Statement stmt = con.createStatement();
			
			//1.0 get all roster details 			
			SQL =  "SELECT DISTINCT * " +
				   "FROM CREWDIR.V_ROSTER_PUBLIC "+
				   "WHERE STAFFID='"+iern+"' AND ROSTER_DATE BETWEEN '"+StartDate+"' AND '"+EndDate+"'" +
				   "ORDER BY ROSTER_DATE,sort_order";
				   
					
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				String ern         = rs.getString("STAFFID");
				Date roster_date   = rs.getDate("ROSTER_DATE");
				String duty        = rs.getString("DUTY");						
				String sp_duty     = rs.getString("SP_DUTY");	
				// check swapable duty 
				String eswap       = getSwapIndicator(roster_date,duty,sp_duty); 			
				othsRosterBean myBean = new othsRosterBean(ern,roster_date,duty,sp_duty,eswap);
				rosters[lst_count] = myBean;
				lst_count++;
			}
			rs.close();
			stmt.close();
			
		   //=================SPILIUZ=================
		   //=================PAX1153=================
		   Date	_StartDate=formatter.parse(StartDate);
		   Date _EndDate=formatter.parse(EndDate);
		   Calendar _StartDate1=Calendar.getInstance();
//		   Calendar _EndDate1=Calendar.getInstance();
		   _StartDate1.setTime(_StartDate);
//		   _EndDate1.setTime(_EndDate);
		   while(_StartDate.compareTo(_EndDate)<=0){
			   if (r_Period_cnt > 0){
				   for (int x=0;x<r_Period_cnt;x++) {
					   if (_StartDate.compareTo(rPeriod[x].getStart_date()) >= 0){				    	 
						   if (_EndDate.compareTo(rPeriod[x].getEnd_date()) <= 0){
							   err_msg = formatter.format(_StartDate) + "  Non-swappable duty involved.";
							   return err_msg;
						   }   		
					   }
				   }
			   }
			   _StartDate1.add(Calendar.DAY_OF_MONTH, 1);
			   _StartDate=_StartDate1.getTime();
		   }
		  //=================END=================
			
			//3.0 Check if any Nonswap duty date
			for (int x=0;x<lst_count;x++){
			  if (formatter.parse(rosters[x].getRoster_date()).compareTo(swStart)>=0 & formatter.parse(rosters[x].getRoster_date()).compareTo(swEnd)<=0 ) {				  
					if (rosters[x].getEswap().equals("N")){
						err_msg = rosters[x].getRoster_date() + "  Non-swappable duty involved.";
						break; 
					}
			  }
			}	
			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    						
		}catch (Exception ex) {
			ex.printStackTrace();		 
			err_msg = ex.toString();   			
		} finally{
		}//catch/try							

		return err_msg;
	}
	
	//	----------------------------------------------------------------------------------	
	private String NB_CodeCheck(String iern,String StartDate,String EndDate){
		String err_msg = "no_err";		
		try{				
			if (con==null){			
				dbconnect db = new dbconnect();
				con = db.getConn();
			}
			ResultSet rs=null;			
			Statement stmt = con.createStatement();
			String SQL = null;
			
			
			//1.0 Reject duty code have NB 			
			SQL =  "SELECT DUTY FROM CREWDIR.V_ROSTER_PUBLIC "+ 				   
				   "WHERE STAFFID='"+iern+"'  AND ROSTER_DATE = to_date('"+StartDate+"') - 1 AND DUTY = 'NB'";
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){
				err_msg = " NB before the duty must be inclued.";
				break;										
			}
			rs.close();			
			stmt.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		 
			err_msg = ex.toString();   			
		} finally{
		}//catch/try							

		return err_msg; 
	}

//	----------------------------------------------------------------------------------	
	private String getSwapIndicator(Date irdate,String iDuty,String iSP){
		
		String myReturn = "Y";

		//2.1 added on 1 Aug 2005, standby duty('N', 'R') usually ends with different pattern code 
		//only read the first 3 chars to identify the duty code
		if (iDuty.trim().length() >= 3 && (iDuty.startsWith("N") || iDuty.startsWith("R"))) {
			iDuty = iDuty.substring(0, 3);
		}
		  
		//2.2 duty code (no flight)
		if (myReturn.equals("Y")){		
			if (isFlightDuty(iDuty)==false) {
				myReturn ="N";						
				if (r_Duty_cnt > 0){				
					for (int y=0;y<r_Duty_cnt;y++) {
						if (rDuty[y].getR_type().equals("EX_DUTY")){
							if (rDuty[y].getCode().equals(iDuty)){
							   myReturn ="Y";
							   break;	
							}
						}						
					}//for
				}	
			}
		}					
	
		//2.2 sp_duty
		if (myReturn.equals("Y")){		
			if (!iSP.equals(" ")){
				myReturn ="N";
				if (r_Duty_cnt > 0){				
					for (int y=0;y<r_Duty_cnt;y++) {
							if (rDuty[y].getR_type().equals("EX_SP")){
								if (rDuty[y].getCode().equals(iSP)){
								   myReturn ="Y";
								   break;	
								}
							}						
					}//for				
				} 
			}			
		}//myReturn			
			
//	   }//2.0	

	   //moved on 1 Aug 05, the "RED" roster block indicator override the "GREY" roster block (EX_DUTY/EX_SP_DUTY) 
	   //2.8 user self blocked roster date
	   //0.0 user self blocked roster date
	   if (r_BlockDate_cnt > 0){
		   for (int x=0;x<r_BlockDate_cnt;x++) {
			 if (irdate.compareTo(rBlockDate[x].getBlockDate()) == 0){				    	 
					myReturn = "N";
					break;				   		
			 }
		 }
	   } //2.8


	   //moved on 1 Aug 05, the "RED" roster block indicator override the "GREY" roster block (EX_DUTY/EX_SP_DUTY) 
	   //2.9 (no swap period blocked)
	   if (r_Period_cnt > 0){
		   for (int x=0;x<r_Period_cnt;x++) {
			   if (irdate.compareTo(rPeriod[x].getStart_date()) >= 0){				    	 
				   if (irdate.compareTo(rPeriod[x].getEnd_date()) <= 0){
					  myReturn = "N";
					  break;
				   }   		
			   }
		   }
	   } //2.9

	   //3.0 (admin approved date action allow)	
	   if (r_RosterDate_cnt > 0){
			for (int z=0;z<r_RosterDate_cnt;z++) {
				if (rRosterDate[z].getR_date().compareTo(irdate) ==0  ){
					myReturn = rRosterDate[z].getAction_type();
					break; 		
				}
			}			
	   }
		
		///4.0 set return	
		return myReturn;
	}


//	----------------------------------------------------------------------------------     
	public void getSwapRestriction(String iern){
		try{	
			  if (con ==null) {						
				  dbconnect db = new dbconnect();
				  con = db.getConn();				        
			  }

			ResultSet rs=null;			
			Statement stmt = con.createStatement();
			String SQL = null;
			 			 		
			//1.1 (no swap period)
			r_Period_cnt=0;
			SQL =  "SELECT to_date(start_date,'dd-mon-yy') as start_date,to_date(end_date,'dd-mon-yy') as end_date,reason,ern FROM CREWDIR.SW_R_RESTRICT_PERIOD " +
				   "WHERE ERN='"+iern+"'";						   							  
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				String ern = rs.getString("ERN");
				Date startdate = rs.getDate("START_DATE");
				Date enddate = rs.getDate("END_DATE");
				String reason = rs.getString("REASON");
				sw_r_PeriodBean sw_crew = new sw_r_PeriodBean(ern,startdate,enddate,reason);
				rPeriod [r_Period_cnt] = sw_crew;
				r_Period_cnt++;
			}
			rs.close();
            
			//1.2 (duty code)
			r_Duty_cnt=0;
			SQL =  "SELECT * FROM CREWDIR.SW_R_DUTY "; 				   						   					
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				String rtype = rs.getString("R_TYPE");
				String code = rs.getString("CODE");
				sw_r_DutyBean  sw_duty = new sw_r_DutyBean(rtype,code);
				rDuty [r_Duty_cnt] = sw_duty;
				r_Duty_cnt++;
			}
			rs.close();
		  
			//1.3 (admin approved date)
			r_RosterDate_cnt=0;
			SQL =  "SELECT * FROM CREWDIR.SW_R_ROSTER_DATE " +
				   "WHERE ERN='"+iern+"' ORDER BY R_DATE";						   			
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				String ern = rs.getString("ERN");
				Date rdate = rs.getDate("R_DATE");
				String actiontype = rs.getString("SWAP");
				String reason = rs.getString("REASON");  
				sw_r_RosterDateBean sw_rdate = new sw_r_RosterDateBean(ern,rdate,actiontype,reason);
				rRosterDate [r_RosterDate_cnt] = sw_rdate;
				r_RosterDate_cnt++;
			}
			rs.close();
		  
			//1.4 user blocked roster date
			r_BlockDate_cnt=0;
			SQL =  "SELECT * FROM CREWDIR.SW_R_BLOCK_ROSTER " +
				   "WHERE ERN='"+iern+"' ORDER BY B_DATE";						   			
			rs= stmt.executeQuery(SQL);			
			while(rs.next()){										
				  Date bdate = rs.getDate("B_DATE");
				  sw_r_BlockRosterBean sw_bdate = new sw_r_BlockRosterBean(bdate);
				  rBlockDate [r_BlockDate_cnt] = sw_bdate;
				  r_BlockDate_cnt++;
			}
			rs.close();
		  
			stmt.close();
		  									        
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
		}//catch/try

	}
	
//	----------------------------------------------------------------------------------
	private boolean isFlightDuty(String duty){
			boolean myreturn = true;
			int num;
			if (!duty.equals(" ")){    	
				for (int x=0;x<duty.length();x++ ){    		
					try 
					 { 
						num = Integer.parseInt(duty.substring(x,x+1)); 					  
					 }catch(NumberFormatException nfe){
						myreturn = false;
						break; 
					 } 
				}
			}	
			return myreturn;
	}

//  ------------------------------
	private Date String2Date(String myDate){
		Date str=null;
		try{
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");				
			str = (Date) formatter.parse(myDate);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return str;
	}


	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public boolean isHaveError() {
		return haveError;
	}

	/**
	 * @return
	 */
	public boolean isHaveNBCode() {
		return haveNBCode;
	}


	/**
	 * @param string
	 */
	public void setErr_msg(String string) {
		err_msg = string;
	}

	/**
	 * @param b
	 */
	public void setHaveError(boolean b) {
		haveError = b;
	}

	/**
	 * @param b
	 */
	public void setHaveNBCode(boolean b) {
		haveNBCode = b;
	}

}
