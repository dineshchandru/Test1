/*
 * Created on Mar 24, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;


public class swapItemHistoryBean {
	private String time_log;
	private String status;
	private String remarks;
	private String whom;
	
	public swapItemHistoryBean() {
		 super();
	}	

	public swapItemHistoryBean(String time_log,String status,String whom,String remarks) {
		 this.time_log = time_log;
		 this.status = status;
		 this.remarks = remarks;
		 this.whom = whom;
	}	

	
	/**
	 * @return
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @return
	 */
	public String getTime_log() {
		return time_log;
	}

	/**
	 * @param string
	 */
	public void setRemarks(String string) {
		remarks = string;
	}

	/**
	 * @param string
	 */
	public void setStatus(String string) {
		status = string;
	}

	/**
	 * @param string
	 */
	public void setTime_log(String string) {
		time_log = string;
	}

	/**
	 * @return
	 */
	public String getWhom() {
		return whom;
	}

	/**
	 * @param string
	 */
	public void setWhom(String string) {
		whom = string;
	}

}
