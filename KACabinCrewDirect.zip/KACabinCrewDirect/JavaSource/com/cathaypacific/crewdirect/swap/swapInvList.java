package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.basicInfo;
import com.cathaypacific.crewdirect.databeans.dbconnect;
 
public class swapInvList {
	
	private Connection con=null;
	
	private basicInfo [] crews = new basicInfo [10];	
	private int crews_cnt = 0;
	
	private swapRosterSimBean [][] myRosters = new swapRosterSimBean[10][200];
	private swapRosterSimBean [][] partnerRosters = new swapRosterSimBean[10][200];	
	private int [] myRostersCNT = new int [10];
	private int [] partnerRostersCNT = new int [10];

			
	private String myReqID;
	private String myPartners[];		
	private Date myPeriodStart;
	private Date myPeriodEnd; 

	private String PeriodStart;
	private String PeriodEnd;
				
	public swapInvList() {
		super();
	}

	public swapInvList(String requester,String partners[],String swapStart,String swapEnd) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");									
		ParsePosition pos = new ParsePosition(0);

		this.myReqID = requester;
		this.myPartners = partners;
		this.myPeriodStart = Str2Date(swapStart);
		this.myPeriodEnd = Str2Date(swapEnd);
		 
		this.PeriodStart = swapStart; 
		this.PeriodEnd = swapEnd;		
						
		getRosterList();
	}
	
	
	private Date Str2Date(String date){
		Date temp;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");									
		ParsePosition pos = new ParsePosition(0);
		temp =(Date) formatter.parse(date,pos);
		return temp;		
	}


	public void getRosterList(){

		String SQL=null;
		int rcnt =0;
		String SwapStatus=null;
		boolean showRoster=true;
		
		//variable for if-case simulation
		Date [] ReqDate = new Date [200];
		String [] ReqDuty = new String [200];
		String [] ReqSP = new String [200];
		int ReqCnt=0;									 			 					 			 	
		Date [] AcpDate = new Date [200];
		String [] AcpDuty = new String [200];
		String [] AcpSP = new String [200];
		int AcpCnt=0;									 			 					 			 	
		//------------------------------

		
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt=null;

			
			//0.0 GET ERN,CREW OF PARTNERS
			rcnt=0;
			for (int x=0;x<myPartners.length;x++){
				if (myPartners[x].length() == 7) {

					SQL =   "SELECT DISTINCT ERN,CREW_ID,CAT  " +
							"FROM isdcrew.crewdb_4_all  " +
							"WHERE ERN='"+myPartners[x]+"'";					 				
					stmt = con.createStatement();		
					rs= stmt.executeQuery(SQL);
					while(rs.next()){																	
						String ERN = rs.getString("ERN");
						String CREWID = rs.getString("CREW_ID");
						String CAT = rs.getString("CAT");
						crews[rcnt] = new basicInfo(ERN,CREWID,CAT);
						rcnt++;
						break;
					}												        
					rs.close();
					stmt.close(); 				
				}
			}
		
		
			//1.0 get both party roster info (if case)

			//1.1 get Requester rosters			
			SQL =   "SELECT DISTINCT ROSTER_DATE,DUTY,SP_DUTY,SORT_ORDER " +
					"FROM CREWDIR.V_ROSTER_MASTER "+
					"WHERE ERN='"+myReqID+"' AND ROSTER_DATE >= SYSDATE " +
					"ORDER BY ROSTER_DATE,SORT_ORDER,DUTY DESC" ;					 
			ReqCnt=0;
			stmt = con.createStatement();		
			rs= stmt.executeQuery(SQL);
			while(rs.next()){																	
				ReqDate [ReqCnt] = rs.getDate("ROSTER_DATE");
				ReqDuty [ReqCnt] = rs.getString("DUTY");						
				ReqSP   [ReqCnt] = rs.getString("SP_DUTY");
				ReqCnt++;				
			}												        
			rs.close();
			stmt.close(); 
			 

			//2.0 get Partners rosters by looping 
			for (int y=0;y<myPartners.length;y++ ) {
				if (myPartners[y].length() == 7) {
					//2.1 Check profile setting										             
					showRoster=true;             
					SQL = "SELECT ROSTER_INFO FROM CREW_PROFILE WHERE ERN='" + myPartners[y] + "'";
					stmt = con.createStatement();
					rs= stmt.executeQuery(SQL);
					while(rs.next()){	
						if (!rs.getString("ROSTER_INFO").equals("Y" )){
							showRoster=false;						
						}
						break;
					}
					rs.close();								                       
					
					if (showRoster){
						//2.2 get partners rosters			
						SQL =   "SELECT DISTINCT ROSTER_DATE,DUTY,SP_DUTY,SORT_ORDER " +
								"FROM CREWDIR.V_ROSTER_PUBLIC "+
								"WHERE ERN='"+myPartners[y]+"' AND ROSTER_DATE >= SYSDATE " +
								"ORDER BY ROSTER_DATE,sort_order,DUTY DESC" ;;					 
						AcpCnt=0;
						stmt = con.createStatement();		
						rs= stmt.executeQuery(SQL);
						while(rs.next()){																	
							AcpDate [AcpCnt] = rs.getDate("ROSTER_DATE");
							AcpDuty [AcpCnt] = rs.getString("DUTY");						
							AcpSP   [AcpCnt] = rs.getString("SP_DUTY");
							AcpCnt++;				
						}												        
						rs.close();
					}
 
		
					//2.2 call sub-routine to form boths parties roster
					makeRosters(ReqDate,ReqDuty,ReqSP,ReqCnt,AcpDate,AcpDuty,AcpSP,AcpCnt);
					crews_cnt++;
				}								
			}
			stmt.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			

		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
	}


	
	public void makeRosters(Date ReqDate[], String ReqDuty[],String ReqSP[], int req_cnt,Date AcpDate[], String AcpDuty[],String AcpSP[], int acp_cnt){
		Date rdate   = null;
		String duty1 = null;
		String sp1   = null;
		String duty2 = null;
		String sp2   = null;
		String color = null;

		//1.0 for request 
		for (int y=0; y<req_cnt; y++) {
			rdate   = ReqDate[y];
			duty1 = ReqDuty[y];
			sp1   = ReqSP[y];								
			duty2 = ReqDuty[y];
			sp2   = ReqSP[y];
			color = "Y";				
			if (rdate.compareTo(myPeriodStart) >= 0 & rdate.compareTo(myPeriodEnd) <= 0) {
				//find Acp Duty if with date range
				for (int m=0;m<acp_cnt;m++){
					if (rdate.compareTo(AcpDate[m])==0){
						duty2 = AcpDuty[m];
						sp2   = AcpSP[m];
						break;					 							
					}						
				}
				color = "X";	
			}				
			myRosters [crews_cnt][y] = new swapRosterSimBean(rdate,duty1,sp1,duty2,sp2,color);														
		}
		
		myRostersCNT [crews_cnt] = req_cnt;		

		//2.0 for accepter
		for (int x=0; x<acp_cnt; x++) {
			rdate = AcpDate[x];
			duty1 = AcpDuty[x];
			sp1   = AcpSP[x];
			duty2 = AcpDuty[x];
			sp2   = AcpSP[x];
			color = "Y";				
			if (rdate.compareTo(myPeriodStart) >= 0 & rdate.compareTo(myPeriodEnd) <= 0) {					
				//find Req Duty if with date range
				for (int m=0;m<req_cnt;m++){
					if (rdate.compareTo(ReqDate[m])==0){
						duty2 = ReqDuty[m];
						sp2   = ReqSP[m];
						break;					 							
					}						
				}
				color = "X";					
			}
			partnerRosters [crews_cnt][x] = new swapRosterSimBean(rdate,duty1,sp1,duty2,sp2,color);											
		}
		
		partnerRostersCNT[crews_cnt] = acp_cnt;
	}

	/**
	 * @return
	 */
	public int getCrews_cnt() {
		return crews_cnt;
	}

	/**
	 * @return
	 */
	public String[] getMyPartners() {
		return myPartners;
	}

	/**
	 * @return
	 */
	public swapRosterSimBean[][] getMyRosters() {
		return myRosters;
	}

	/**
	 * @return
	 */
	public int[] getMyRostersCNT() {
		return myRostersCNT;
	}

	/**
	 * @return
	 */
	public swapRosterSimBean[][] getPartnerRosters() {
		return partnerRosters;
	}

	/**
	 * @return
	 */
	public int[] getPartnerRostersCNT() {
		return partnerRostersCNT;
	}

	/**
	 * @return
	 */
	public basicInfo[] getCrews() {
		return crews;
	}

	/**
	 * @return
	 */
	public String getPeriodEnd() {
		return PeriodEnd;
	}

	/**
	 * @return
	 */
	public String getPeriodStart() {
		return PeriodStart;
	}

}
