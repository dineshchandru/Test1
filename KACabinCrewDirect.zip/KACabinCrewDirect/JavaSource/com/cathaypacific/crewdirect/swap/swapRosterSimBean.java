/*
 * Created on Mar 25, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;

import java.text.SimpleDateFormat;
import java.util.Date;

public class swapRosterSimBean {

	private String crew;
	private String date;
	private String duty0;
	private String sp0;
	private String duty1;
	private String sp1;	
	private String color;
	
	public swapRosterSimBean(){
		super();
	}
	public swapRosterSimBean(Date date,String duty0,String sp0,String duty1,String sp1,String color){		
		this.date = Date2String(date);
		this.duty0 = duty0;
		this.sp0 = sp0;
		this.duty1 = duty1;
		this.sp1 = sp1;
		this.color = color;
	}

	private String Date2String(Date myDate){
		String str=null;
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMMyy");				
		str = formatter.format(myDate);
		return str;
	}

	
	/**
	 * @return
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @return
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @return
	 */
	public String getDuty0() {
		return duty0;
	}

	/**
	 * @return
	 */
	public String getDuty1() {
		return duty1;
	}

	/**
	 * @return
	 */
	public String getSp0() {
		return sp0;
	}

	/**
	 * @return
	 */
	public String getSp1() {
		return sp1;
	}

	/**
	 * @param string
	 */
	public void setColor(String string) {
		color = string;
	}

	/**
	 * @param string
	 */
	public void setDate(String string) {
		date = string;
	}

	/**
	 * @param string
	 */
	public void setDuty0(String string) {
		duty0 = string;
	}

	/**
	 * @param string
	 */
	public void setDuty1(String string) {
		duty1 = string;
	}

	/**
	 * @param string
	 */
	public void setSp0(String string) {
		sp0 = string;
	}

	/**
	 * @param string
	 */
	public void setSp1(String string) {
		sp1 = string;
	}

}
