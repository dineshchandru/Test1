package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class setItemReadStatus {
	
	private Connection con=null;
	private String iern;
	private String item_key;
	private String err_code;
	private boolean success = true;
	
	public setItemReadStatus() {
		super();		
	}

	public setItemReadStatus(String iern,String item_key) {
		this.iern = iern;				
		this.item_key = item_key;
		updating();
	}

	public void updating(){
		String SQL;		
		String myLastStatus = null;
		String req_id=null;
		String acp_id=null;
		try{	
			
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			//find last status & associated info
			ResultSet rs=null;			
			Statement stmt=con.createStatement();	
			Statement stmtx=con.createStatement(); 			 					 			 		
			int row1=0;
			int row2=0;
			SQL = "select distinct * from crewdir.swap_req where req_key ='"+item_key+"'"; 						 		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){										
				myLastStatus = rs.getString("last_status");
				req_id = rs.getString("req_id");
				acp_id = rs.getString("acp_id"); 							
			}									        
			rs.close();
			stmt.close(); 
  
  			//update status accordingly
            if (acp_id.equals(iern) & myLastStatus.equals("New request")){
				//1.0 update last status in swap_req table
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Read by receiver',time_log=sysdate " +
					  "WHERE REQ_KEY='" + item_key + "'";
				row1 = stmtx.executeUpdate(SQL);      
			
				//2.0 update swap_status
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
					  " ('" + item_key + "','Read by receiver','" + iern + "', sysdate)";
				row2 = stmtx.executeUpdate(SQL);
				if (row1+row2 !=2)
				   success = false;				
            }

			if (req_id.equals(iern) & myLastStatus.equals("Accepted")){
				//1.0 update last status in swap_req table
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Accepted (inviter read)',time_log=sysdate " +
					  "WHERE REQ_KEY='" + item_key + "'";
				row1 = stmtx.executeUpdate(SQL);      
			
				//2.0 update swap_status
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
					  " ('" + item_key + "','Accepted (inviter read)','" + iern + "', sysdate)";
				row2 = stmtx.executeUpdate(SQL);
				if (row1+row2 !=2)
				   success = false;				
			}

			if (req_id.equals(iern) & myLastStatus.equals("Declined")){
				//1.0 update last status in swap_req table
				SQL = "UPDATE CREWDIR.SWAP_REQ SET LAST_STATUS = 'Declined (inviter read)',time_log=sysdate " +
					  "WHERE REQ_KEY='" + item_key + "'";
				row1 = stmtx.executeUpdate(SQL);      
			
				//2.0 update swap_status
				SQL = "INSERT INTO CREWDIR.SWAP_STATUS (REQ_KEY,STATUS,WHOM,TIME_LOG) VALUES " +
					  " ('" + item_key + "','Declined (inviter read)','" + iern + "', sysdate)";
				row2 = stmtx.executeUpdate(SQL);
				if (row1+row2 !=2)
				   success = false;				
			}


			stmtx.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try						
	}
	


	/**
	 * @return
	 */
	public String getIern() {
		return iern;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param string
	 */
	public void setIern(String string) {
		iern = string;
	}

	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

	/**
	 * @return
	 */
	public String getErr_code() {
		return err_code;
	}

	/**
	 * @param string
	 */
	public void setErr_code(String string) {
		err_code = string;
	}

}
