package com.cathaypacific.crewdirect.swap;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class swapEnquiryList {

	private String iern = new String("");
	private String s_date = new String("");
	private String e_date = new String("");
	private String myStatus = new String("");
	private swapEnquiryBean [] inv_lst = new swapEnquiryBean[1000];
	private int inv_lst_cnt=0;
	private swapEnquiryBean [] rev_lst = new swapEnquiryBean[1000];
	private int rev_lst_cnt=0;
	private Connection con;
			 
	public swapEnquiryList() {
		super();
	}
	
    //By Date Range
	public swapEnquiryList(String iern, String s_date, String e_date, String istatus) {
		this.iern = iern;
		this.s_date = s_date.toUpperCase() ;
		this.e_date = e_date.toUpperCase() ;
		this.myStatus = istatus;		
		getSwapList("RANGE");
	}
	
    //Beginning of the web 
	public swapEnquiryList(String iern) {
		this.iern = iern;		
		getSwapList("NONE");
	}

	public void getSwapList(String myType) {
		
		String SQL = new String("");		
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs_x=null;			
			Statement stmt_x =null;
			
			// 1.0 invitation being sent AS Requester
			if (myType.equals("RANGE")) {
				
				if (myStatus.equals("All_Status")) {
					//Comment on 25 Oct 2006 
					//1.1  Get record by range and status
					/*SQL = "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID, " +
						  "TO_CHAR(PERIOD_START, 'DDMON') || ' - ' || TO_CHAR(PERIOD_END, 'DDMON') AS PERIOD, LAST_STATUS, " +
						  "TO_CHAR(TIME_LOG, 'DD/MM/YY HH24:MI:SS') AS TIME_LOG, PERIOD_START, PERIOD_END,Y.CREW_ID AS CREW_ID " +							          
						  "FROM CREWDIR.SWAP_REQ x, ISDCREW.CREWDB_4_ALL Y "+
						  "WHERE REQ_ID = '"+iern+"' AND X.ACP_ID = Y.ERN " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +								 
						  "AND REQ_KEY IN (SELECT DISTINCT SWAP_KEY FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE = 'N' AND ERN = '"+iern+"') " +
						  "ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";
					*/

					//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
					//Comment on 08 May 2007 : SQL Tuning 
					//1.1  Get all records of all the status
					//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
					//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					//	  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
					//	  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
					//	  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
					//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
					SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
						  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
						  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
						  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
						  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
						  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
						  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
						  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
                    
				} else {
					//Comment on 25 Oct 2006 
					//1.1  Get record by range and status
					//SQL = "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID, " +
					//	  "TO_CHAR(PERIOD_START, 'DDMON') || ' - ' || TO_CHAR(PERIOD_END, 'DDMON') AS PERIOD, LAST_STATUS, " +
					//	  "TO_CHAR(TIME_LOG, 'DD/MM/YY HH24:MI:SS') AS TIME_LOG, PERIOD_START, PERIOD_END, Y.CREW_ID AS CREW_ID " +							          							
					//	  "FROM CREWDIR.SWAP_REQ x, ISDCREW.CREWDB_4_ALL Y "+
					//	  "WHERE REQ_ID = '"+iern+"' AND X.ACP_ID = Y.ERN " +
					//	  "AND PERIOD_START >='"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +
					//	  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') " +  
					//	  "AND REQ_KEY IN (SELECT DISTINCT SWAP_KEY FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE = 'N' AND ERN = '"+iern+"') " +
					//	  "ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";

					//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
					//1.1  Get all records of all the status
					//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
					//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					//	  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
					//	  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
					//	  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') " +  
					//	  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
					//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
					SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
						  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
						  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
						  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
						  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
						  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
						  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') " +  
						  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
						  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
				}

			} else {
				//Comment on 25 Oct 2006 
				//1.2  get all records default status
				//SQL = "SELECT DISTINCT REQ_KEY,REQ_ID,ACP_ID," +
				//		" TO_CHAR(PERIOD_START,'DDMON')||' - '||TO_CHAR(PERIOD_END,'DDMON') AS PERIOD," +
				//		"LAST_STATUS,TO_CHAR(TIME_LOG,'DD/MM/YY HH24:MI:SS') AS TIME_LOG,period_start,period_end,Y.CREW_ID AS CREW_ID " +							          
				//		"FROM CREWDIR.SWAP_REQ x,ISDCREW.CREWDB_4_ALL Y "+
				//		"WHERE REQ_ID='"+iern+"' AND X.ACP_ID = Y.ERN AND " +
				//		"LAST_STATUS IN ('Cancel swap','Declined','Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') AND " +  
				//		"REQ_KEY IN (SELECT DISTINCT SWAP_KEY  FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE='N' AND ERN='"+iern+"') " +
				//		"ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";
				
 
				//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
				//1.2  get all records default status
				//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
				//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
				//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
				//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
				//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
				//	  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
				//	  "AND x.last_status IN ('Cancel swap','Declined','Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') " +
				//	  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
				//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
				SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
					  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					  "WHERE x.req_id = '"+iern+"' AND x.acp_id = y.ern " +
					  "AND x.last_status IN ('Cancel swap','Declined','Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') " +
					  "AND temp0.col1 = x.req_id AND temp0.col2 = x.req_key " +
					  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
			}
			 			 					 			 		
			stmt_x = con.createStatement();		
			rs_x= stmt_x.executeQuery(SQL);	
			//System.out.println("CCD Swap Enquiry - "+SQL);			
			while(rs_x.next()){																	
				String type      = "INVITE";
				String id        = rs_x.getString("REQ_KEY");
				String period    = rs_x.getString("PERIOD");						
				String timestamp = rs_x.getString("TIME_LOG");
				String status    = rs_x.getString("LAST_STATUS");
				String myID      = rs_x.getString("ACP_ID");							
				String whom 	 = rs_x.getString("CREW_ID");
				swapEnquiryBean myBean = new swapEnquiryBean(type,id,whom,period,timestamp,status);								
				inv_lst[inv_lst_cnt] = myBean;
				inv_lst_cnt++;											
			}									        
			rs_x.close();
			 
			// 2.0 invitation being received AS Receiver
			if (myType.equals("RANGE")) {

				if (myStatus.equals("All_Status")) {
					//Comment on 25 Oct 2006
					//1.1  get record by range and status
					/*SQL = "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID, " +
						  "TO_CHAR(PERIOD_START, 'DDMON') || ' - ' || TO_CHAR(PERIOD_END, 'DDMON') AS PERIOD, LAST_STATUS, " +
						  "TO_CHAR(TIME_LOG, 'DD/MM/YY HH24:MI:SS') AS TIME_LOG, PERIOD_START, PERIOD_END, Y.CREW_ID AS CREW_ID " +							          
					      "FROM CREWDIR.SWAP_REQ x, ISDCREW.CREWDB_4_ALL Y "+							
						  "WHERE ACP_ID = '"+iern+"' AND X.REQ_ID = Y.ERN " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +								 
						  "AND REQ_KEY IN (SELECT DISTINCT SWAP_KEY FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE = 'N' AND ERN = '"+iern+"') " +
						  "ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";
					*/

					//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
					//1.1  get all records default status
					//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
					//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					//	  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
					//	  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
					//	  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
					//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
					SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
						  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
						  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
						  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
						  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
						  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +	
						  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
						  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;

						  						  
				} else {
					//Comment on 25 Oct 2006
					//1.1  get record by range and status
					/*SQL = "SELECT DISTINCT REQ_KEY, REQ_ID, ACP_ID," +
						  "TO_CHAR(PERIOD_START, 'DDMON')||' - '||TO_CHAR(PERIOD_END, 'DDMON') AS PERIOD, LAST_STATUS, " +
						  "TO_CHAR(TIME_LOG, 'DD/MM/YY HH24:MI:SS') AS TIME_LOG, PERIOD_START, PERIOD_END, Y.CREW_ID AS CREW_ID " +							          
						  "FROM CREWDIR.SWAP_REQ x, ISDCREW.CREWDB_4_ALL Y "+							
						  "WHERE ACP_ID = '"+iern+"' AND X.REQ_ID = Y.ERN " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +
						  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') "+  
						  "AND REQ_KEY IN (SELECT DISTINCT SWAP_KEY FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE = 'N' AND ERN = '"+iern+"') " +
						  "ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";
					*/
					//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
					//1.1  get all records default status
					//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
					//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					//	  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
					//	  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +
					//	  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') "+	
					//	  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
					//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
					SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
						  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
						  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
						  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
						  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
						  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
						  "AND PERIOD_START >= '"+s_date+"' AND PERIOD_END <= '"+e_date+"' " +
						  "AND UPPER(LAST_STATUS) = UPPER('"+myStatus+"') "+	
						  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
						  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
				}
				
			} else {
				//Comment on 25 Oct 2006
				//1.2  get all records default status
				/*SQL = "SELECT DISTINCT REQ_KEY,REQ_ID,ACP_ID," +
						" TO_CHAR(PERIOD_START,'DDMON')||' - '||TO_CHAR(PERIOD_END,'DDMON') AS PERIOD," +
						"LAST_STATUS,TO_CHAR(TIME_LOG,'DD/MM/YY HH24:MI:SS') AS TIME_LOG,period_start,period_end,Y.CREW_ID AS CREW_ID " +							          
						"FROM CREWDIR.SWAP_REQ x,ISDCREW.CREWDB_4_ALL Y "+							
						"WHERE ACP_ID='"+iern+"' AND X.REQ_ID = Y.ERN AND " +
						"LAST_STATUS IN ('Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','New request','Read by receiver','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') AND " +
						"REQ_KEY IN (SELECT DISTINCT SWAP_KEY  FROM CREWDIR.SWAP_WEB_HIDDEN WHERE HIDE='N' AND ERN='"+iern+"') " +
						"ORDER BY PERIOD_START, PERIOD_END, LAST_STATUS";
				*/
				//Amended on 25 Oct 2006 : SQL Tuning (performance increased by 10+%)
				//1.2  get all records default status
				//SQL = "SELECT /*+ cursor_sharing_exact dynamic_sampling(0) no_monitoring no_expand index_ffs(x,IDX_SWAP_REQ_03) parallel_index(x,IDX_SWAP_REQ_03, 4) PARALLEL(X, 2) PARALLEL(TEMP0, 2) PARALLEL(Y, 2) */ " +
				//	  "DISTINCT x.req_key, x.req_id, x.acp_id, TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
				//	  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
				//	  "(SELECT /*+ PARALLEL(SWAP_WEB_HIDDEN, 2) */ DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
				//	  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
				//	  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
				//	  "AND x.last_status IN ('Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','New request','Read by receiver','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') " +
				//	  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
				//	  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
				SQL = "SELECT DISTINCT x.req_key, x.req_id, x.acp_id, " +
					  "TO_CHAR(x.period_start, 'DDMON') || ' - ' || TO_CHAR(x.period_end, 'DDMON') AS period, x.last_status, TO_CHAR(x.time_log, 'DD/MM/YY HH24:MI:SS') AS time_log, " +
					  "x.period_start, x.period_end, y.crew_id AS crew_id FROM crewdir.swap_req x, isdcrew.crewdb_4_all y, " +
					  "(SELECT DISTINCT swap_web_hidden.ern col1, swap_web_hidden.swap_key col2 " +
					  "FROM crewdir.swap_web_hidden WHERE swap_web_hidden.hide = 'N') temp0 " +
					  "WHERE x.acp_id = '"+iern+"' AND x.req_id = y.ern " +
					  "AND x.last_status IN ('Accepted','Accepted (inviter read)','Processing','Approved','Disapproved','Rejected','New request','Read by receiver','Receiver requests to withdraw','Inviter requests to withdraw','Withdrawn') " +
					  "AND temp0.col1 = x.acp_id AND temp0.col2 = x.req_key " +
					  "AND '"+iern+"' = temp0.col1 ORDER BY period_start, period_end, last_status" ;
			}
					
			rs_x= stmt_x.executeQuery(SQL);
			System.out.println(myType+"/CCD Swap Enquiry SQL 2 - "+SQL);
			
			while(rs_x.next()){																	
				String type      = "RECEIVED";
				String id        = rs_x.getString("REQ_KEY");
				String period    = rs_x.getString("PERIOD");						
				String timestamp = rs_x.getString("TIME_LOG");
				String status    = rs_x.getString("LAST_STATUS");
				String myID      = rs_x.getString("REQ_ID");							
				String whom 	 = rs_x.getString("CREW_ID");				
				rev_lst[rev_lst_cnt] = new swapEnquiryBean(type,id,whom,period,timestamp,status);
				rev_lst_cnt++;								
			}									        
			rs_x.close();
			stmt_x.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} //if    			
			
		} catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally {
			if (con != null) {
				try {
					con.close();
			   } catch (SQLException e) {
					e.printStackTrace();
				}
			} //if  
		}//catch/try						
	}

	/**
	 * @return
	 */
	public Connection getCon() {
		return con;
	}

	/**
	 * @return
	 */
	public String getIern() {
		return iern;
	}

	/**
	 * @return
	 */
	public swapEnquiryBean[] getInv_lst() {
		return inv_lst;
	}

	/**
	 * @return
	 */
	public int getInv_lst_cnt() {
		return inv_lst_cnt;
	}

	/**
	 * @return
	 */
	public swapEnquiryBean[] getRev_lst() {
		return rev_lst;
	}

	/**
	 * @return
	 */
	public int getRev_lst_cnt() {
		return rev_lst_cnt;
	}

	/**
	 * @param connection
	 */
	public void setCon(Connection connection) {
		con = connection;
	}

	/**
	 * @param string
	 */
	public void setIern(String string) {
		iern = string;
	}

	/**
	 * @param beans
	 */
	public void setInv_lst(swapEnquiryBean[] beans) {
		inv_lst = beans;
	}

	/**
	 * @param i
	 */
	public void setInv_lst_cnt(int i) {
		inv_lst_cnt = i;
	}

	/**
	 * @param beans
	 */
	public void setRev_lst(swapEnquiryBean[] beans) {
		rev_lst = beans;
	}

	/**
	 * @param i
	 */
	public void setRev_lst_cnt(int i) {
		rev_lst_cnt = i;
	}

}
