/*
 * Created on Jul 23, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class MayFlyCrewList {

	private String ern_lst [][] = new String [100][3];	
	private String [] CREW_ID = new String [100];
	private String [] BADGENAME = new String [100];
	private String [] COS = new String [100];
	private String [] CAT = new String [100];
	private String [] LANG = new String [100];
	private String [] Swappable = new String [100];
	private String [] CockpitCrew = new String [100];
	private String [] MailBox = new String [100];
	int CockpitCrewCnt =0;
	int ern_lst_cnt =0;
	
	private Connection con;
	private String flt_no ="";
	private String flt_date="";
	private String sector="";
	private String ac_type="";
	private String dep_time="";
	private String arr_time="";
	private String err_msg="no_err";	
	
	public MayFlyCrewList() {
		super();
	}

	public MayFlyCrewList(String iflt_date,String iflt_no,String isector_from) {
		try {	
			dbconnect db = new dbconnect();
			con = db.getConn(); 
			String cos="";
			ResultSet rs=null;			
			Statement stmt=null;			 			 					 			 		
			ResultSet rs1=null;			
			Statement stmt1=null;			 			 					 			 		
			ResultSet rs2=null;			
			Statement stmt2=null;			 			 					 			 		
			ResultSet rs3=null;			
			Statement stmt3=null;			 			 					 			 		
			String myCat[] = new String [100];
			String SQL="";
			
			String crew_list [][] = new String [100][3]; //ern,cat,sp_duty

			//1.0 find flt details
			SQL = "SELECT DISTINCT FLT_NO,to_char(flt_date,'DD-MON-YY') AS FDATE,ACFT_TYPE,SECTOR_FROM,SECTOR_TO," +
				  "to_char(FLT_ARR,'DD MON HH24:MI') as flt_arr,to_char(FLT_DEP,'DD MON HH24:MI') as flt_dep " +
				  "FROM crewdir.v_mayfly " +
				  "WHERE FLT_DATE='"+iflt_date+"' AND SECTOR_FROM ='"+isector_from+"' AND FLT_NO='" +iflt_no+"'";
			stmt1 = con.createStatement();		
			rs1= stmt1.executeQuery(SQL);
			ern_lst_cnt=0;		
			while(rs1.next()) {
				flt_no = rs1.getString("FLT_NO");
				flt_date = rs1.getString("FDATE");
				sector = rs1.getString("SECTOR_FROM") + " " + rs1.getString("SECTOR_TO");
				ac_type = rs1.getString("ACFT_TYPE");
				dep_time = rs1.getString("FLT_DEP")+"L";
				arr_time = rs1.getString("FLT_ARR")+"L";
			}	        
			rs1.close();
			stmt1.close();		
			
			//1.1 get cockpit crew list
			//start edit of R20091001 
			SQL = "SELECT * FROM crewdir.KA_COCKPIT_CREW " +
				  "WHERE to_char(FLIGHT_DATE,'dd-mon-yy')='"+(iflt_date==null?"":iflt_date.toLowerCase())+"' AND DEP_STATION ='"+isector_from+"' AND FLIGHT_NO='" +iflt_no+"'";
			stmt1 = con.createStatement();		
			rs1 = stmt1.executeQuery(SQL);
			CockpitCrewCnt=0;		
			while(rs1.next()){
				CockpitCrew[CockpitCrewCnt]= "<TD>"+ rs1.getString("FLEET")+ rs1.getString("CREW_CATEGORY")+ rs1.getString("CREW_SENIORITY")+"</TD><TD>"+rs1.getString("BADGE_NAME")+"</TD><TD>"+rs1.getString("CREW_ID")+"</TD>";
				CockpitCrewCnt++;
			}									        
			rs1.close();
			stmt1.close();		
			//end edit of R200910001
			
			//2.0 find the crewlist ern  
			SQL = "SELECT DISTINCT x.ERN as ERN, NVL(SP_DUTY,' ') as SP_DUTY, y.cat as CAT " +
				  "FROM CREWDIR.V_MAYFLY x, ISDCREW.CREW_BASIC y " +
				  "WHERE x.ern = y.ern AND " +
				  "FLT_DATE = '"+iflt_date+"' AND " +
				  "FLT_NO = '"+iflt_no +"' AND SECTOR_FROM = '"+isector_from+"'";						
			stmt2 = con.createStatement();		
			rs2= stmt2.executeQuery(SQL);					
			while(rs2.next()) {
				crew_list[ern_lst_cnt][0] =	rs2.getString("ERN");
				crew_list[ern_lst_cnt][1] =	rs2.getString("CAT");
				crew_list[ern_lst_cnt][2] =	rs2.getString("SP_DUTY");								
				ern_lst_cnt++;
			}				        
			rs2.close();
			stmt2.close();
			ern_lst = SortOrder(crew_list,ern_lst_cnt);

			//3.0 find Info details
			stmt3 = con.createStatement();
			stmt = con.createStatement();
			for (int x = 0; x < ern_lst_cnt; x++) {
				SQL= "SELECT DISTINCT x.CREW_ID, x.BADGE_NAME, NVL(x.MAIL_BOX, ' ') as MAIL_BOX, x.CAT, x.LANG_1 || decode(x.LANG_2, null, '', '/' || x.LANG_2) as LANG, 'Y' as PCOS, NVL(y.mail_box, ' ') as PMAILBOX, y.ROSTER_INFO as PROSTER " +
					 "FROM ISDCREW.CREW_BASIC x, KA_CREW_PROFILE y WHERE x.ERN ='"+ern_lst[x][0]+"' and x.ern=y.staffid ";						
				rs3= stmt3.executeQuery(SQL);			

				while(rs3.next()) {							
					if (rs3.getString("PROSTER").equals("N")){
						CREW_ID[x] = "Not Disclosed";
						BADGENAME[x] = "Not Disclosed";;
					} else {
						CREW_ID[x] = rs3.getString("CREW_ID");
						BADGENAME[x] = rs3.getString("BADGE_NAME");									
					}
					if (rs3.getString("PMAILBOX").equals("N")) {
						MailBox[x] = "Not Disclosed";						
					} else {
						MailBox[x] = rs3.getString("MAIL_BOX");														
					}
					//CAT[x] = rs3.getString("CAT1")+"-"+rs3.getString("CAT")+"-"+rs3.getString("CAT2");
					CAT[x] = rs3.getString("CAT");				
					LANG[x] =rs3.getString("LANG");								
				}									        
				rs3.close();

				Swappable[x] = "Y";
				//4.0 get swappable indicator			   
				//4.1 get user-self block date
				SQL =  "SELECT rownum FROM CREWDIR.SW_R_BLOCK_ROSTER " +
				  	   "WHERE ERN='"+ern_lst[x][0]+"' AND " +
				 	   "B_DATE = to_date('"+iflt_date+"','DD-MON-YY')";
			   rs= stmt.executeQuery(SQL);			
			   while(rs.next()){
				  Swappable[x]="N";
			   }
			   rs.close();

			   if (Swappable[x].equals("Y")){
					//4.2 system blocked Dates by Peroid
					SQL =  "SELECT rownum FROM CREWDIR.SW_R_RESTRICT_PERIOD " +
						   "WHERE ERN='" +ern_lst[x][0]+ "' AND to_date('"+iflt_date+"','DD-MON-YY') between START_DATE AND END_DATE";
					rs= stmt.executeQuery(SQL);		
					while(rs.next()){
						Swappable[x]="N";
					}									        
					rs.close();			   		
			   }

			   if (Swappable[x].equals("Y")){
				   //4.3 system blocked Dates
				   SQL =  "SELECT rownum FROM CREWDIR.SW_R_ROSTER_DATE " +
						  "WHERE ERN='"+ern_lst[x][0]+"' AND R_DATE = to_date('"+iflt_date+"','DD-MON-YY')";						   			
				   rs= stmt.executeQuery(SQL);			
				   while(rs.next()){
					   Swappable[x]="N";
				   }
				   rs.close();
			   }
			 }
			 stmt.close();
			 stmt3.close();
		  
			 //3.0 set return data
		} catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					} catch( SQLException e) {
					   e.printStackTrace();
					}
			  } //if

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			if (con != null) {
				try {
					con.close();
			   } catch( SQLException e) {
			   		e.printStackTrace();
			   }
			} //if  
		}//catch/try
		//set return  
	}

	private String [][] SortOrder (String ern[][],int cnt){
		String temp[][]= new String[100][3]; //ern,cat,duty
		int tmp_cnt = 0;
		//IM CAT
		// start edit of R200910001
		//CP change to IM 
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("IM")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}
        //SP 
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("SP")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}
		//FP
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("FP")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}
		//FPF
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("FPF")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}		
		//BC
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("FJ")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}
//		BC
		for (int x=0;x<cnt;x++){
			if (ern[x][1].equals("FAY")){
				temp[tmp_cnt][0] = ern[x][0];
				temp[tmp_cnt][1] = ern[x][1];
				temp[tmp_cnt][2] = ern[x][2];
				tmp_cnt++;
			}
		}
		//end edit of R20091001
		return temp;
	}

	/**
	 * @return
	 */
	public String[] getBADGENAME() {
		return BADGENAME;
	}

	/**
	 * @return
	 */
	public String[] getCAT() {
		return CAT;
	}

	/**
	 * @return
	 */
	public String[] getCOS() {
		return COS;
	}

	/**
	 * @return
	 */
	public String[] getCREW_ID() {
		return CREW_ID;
	}

	/**
	 * @return
	 */
	public String[][] getErn_lst() {
		return ern_lst;
	}

	/**
	 * @return
	 */
	public int getErn_lst_cnt() {
		return ern_lst_cnt;
	}

	/**
	 * @return
	 */
	public String[] getLANG() {
		return LANG;
	}

	/**
	 * @return
	 */
	public String getAc_type() {
		return ac_type;
	}

	/**
	 * @return
	 */
	public String getArr_time() {
		return arr_time;
	}

	/**
	 * @return
	 */
	public String getDep_time() {
		return dep_time;
	}

	/**
	 * @return
	 */
	public String getFlt_date() {
		return flt_date;
	}

	/**
	 * @return
	 */
	public String getFlt_no() {
		return flt_no;
	}

	/**
	 * @return
	 */
	public String getSector() {
		return sector;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String[] getSwappable() {
		return Swappable;
	}

	/**
	 * @return
	 */
	public String[] getCockpitCrew() {
		return CockpitCrew;
	}

	/**
	 * @return
	 */
	public int getCockpitCrewCnt() {
		return CockpitCrewCnt;
	}

	/**
	 * @return
	 */
	public String[] getMailBox() {
		return MailBox;
	}

	/**
	 * @param strings
	 */
	public void setMailBox(String[] strings) {
		MailBox = strings;
	}
}
