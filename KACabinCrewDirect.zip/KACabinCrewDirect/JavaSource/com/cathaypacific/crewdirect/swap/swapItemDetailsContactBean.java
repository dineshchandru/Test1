/*
 * Created on Jun 9, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;


public class swapItemDetailsContactBean {
	private String mailbox;
	private String p_phone;
	private String s_phone;
	private String memo;
	private String galacxy_id;
	private String cos;
	private String roster_info;
	
	public swapItemDetailsContactBean(String mailbox,String p_phone,String s_phone,String memo,String galacxy_id,String cos) {
		this.mailbox = mailbox;
		this.p_phone = p_phone;
		this.s_phone = s_phone;
		this.memo = memo;
		this.galacxy_id = galacxy_id;
		this.cos = cos;	
	}
	
	public swapItemDetailsContactBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return
	 */
	public String getMailbox() {
		return mailbox;
	}

	/**
	 * @return
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * @return
	 */
	public String getP_phone() {
		return p_phone;
	}

	/**
	 * @return
	 */
	public String getS_phone() {
		return s_phone;
	}

	/**
	 * @param string
	 */
	public void setMailbox(String string) {
		mailbox = string;
	}

	/**
	 * @param string
	 */
	public void setMemo(String string) {
		memo = string;
	}

	/**
	 * @param string
	 */
	public void setP_phone(String string) {
		p_phone = string;
	}

	/**
	 * @param string
	 */
	public void setS_phone(String string) {
		s_phone = string;
	}

	/**
	 * @return
	 */
	public String getGalacxy_id() {
		return galacxy_id;
	}

	/**
	 * @param string
	 */
	public void setGalacxy_id(String string) {
		galacxy_id = string;
	}

	/**
	 * @return
	 */
	public String getCos() {
		return cos;
	}

	/**
	 * @param string
	 */
	public void setCos(String string) {
		cos = string;
	}

	/**
	 * @return
	 */
	public String getRoster_info() {
		return roster_info;
	}

	/**
	 * @param string
	 */
	public void setRoster_info(String string) {
		roster_info = string;
	}

}
