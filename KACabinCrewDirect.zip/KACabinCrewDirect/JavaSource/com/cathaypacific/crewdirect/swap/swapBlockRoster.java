/*
 * Created on Oct 10, 2009
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.swap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author IMTMMN
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class swapBlockRoster {

	private Connection con = null;
	private String ern = new String("");
	private String err_msg = new String("");
	private String start_month = new String("");
	private String end_month = new String("");
	private int roster_cnt = 0;
	private String roster [][]; 
	
	// ------ Constructor 1 ------
	public swapBlockRoster() {
		super();		
	}
	
	// ------ Constructor 2 : start ------
	public swapBlockRoster(String ern) {
		this.ern = ern;				
		Date date = new Date(); 
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMM");

		//Start Month
		Calendar cal = Calendar.getInstance();  
		String start_date = formatter.format(cal.getTime());
		//End Month
		cal.add(Calendar.MONTH, 1);
		String end_date = formatter.format(cal.getTime());
		
		start_month = start_date;
		end_month = end_date;
		roster = show(start_date, end_date);		
	}

	// ------ Constructor 3 : search ------
/*	public swapBlockRoster(String ern, String s_date) {
		this.ern =ern;				
		roster = show(s_date);
	}
*/
	//-----------------------------------------------------------------
	//call set block
	public swapBlockRoster(String ern, String [] s_date, String s_month, String e_month) {
		this.ern = ern;				
		err_msg = setBlock(s_date, s_month, e_month);
	}

    //------------------------------------------------------------------
	public void deleteMonth(String ern, String s_month, String e_month) {

		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn();
			con.setAutoCommit(false);			 	    			
			Statement stmt = con.createStatement();
			int row = 0;
			
			String sql = "DELETE FROM CREWDIR.SW_R_BLOCK_ROSTER " +
						 "WHERE ERN = '"+ern+"' AND TO_CHAR(B_DATE,'YYYYMM') BETWEEN '"+s_month+"' AND '"+e_month+"'";
			row = stmt.executeUpdate(sql);
			
			//1.0 delete this month records
			if (row > 0) {
				con.commit();
				err_msg = "All your swap block dates request removed successfully.";
			} else {
				con.rollback();
				err_msg = "All your swap block dates request removed unsuccessfully.";				
			}
			stmt.close();
			
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();			  
			err_msg = sqlex.toString();
			if (con != null) {
				try {
					con.rollback();	
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if

		} catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString();

		} finally {
			if (con != null) {
				try {
					con.rollback();
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			} //if  
		}//catch/try
	}

	//-----------------------------------------------------------------
	public String [][] show(String s_date, String e_date) {

		String [][] master_roster = new String [100][4];
		String [][] rtn_roster = new String [100][4];  //date,duty,block,week
		int rtn_roster_cnt = 0;
		int myroster_cnt = 0;
		Date tempdate = null;
		String duty = new String("");
		String rdate = new String("");
		String rweek = new String("");
		Date start_date = null;
		Date end_date = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
		
		for (int v = 0; v < 100; v++) {
			rtn_roster[v][0] = "";
			rtn_roster[v][1] = "";
			rtn_roster[v][2] = "";
			rtn_roster[v][3] = "";			
		}
		
		try {			
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 	    
			ResultSet rs = null;			
			Statement stmt = null;			 			 					 			 		
 			String sql = "";
 			
 			//1.0 get roster_master record
 			sql = "SELECT ROSTER_DATE, SUBSTR(TO_CHAR(ROSTER_DATE, 'DY'),1,1) as WK, TO_CHAR(ROSTER_DATE, 'DD-MON-YY') AS RDATE, DUTY, "+
				  "NVL(SECTOR_FROM, ' ') as SECTOR_FROM, NVL(SECTOR_TO, ' ') as SECTOR_TO, SP_DUTY FROM V_ROSTER_MASTER " +
				  "WHERE STAFFID = '"+ern+"' AND TO_CHAR(ROSTER_DATE, 'yyyymm') BETWEEN '"+s_date+"' AND '"+e_date+"' " +
				  "ORDER BY ROSTER_DATE";
			stmt = con.createStatement();		
			rs = stmt.executeQuery(sql);
			int cnt=0;					
			while(rs.next()) {
				master_roster [cnt][0]= rs.getString("RDATE");
				master_roster [cnt][1]= rs.getString("DUTY")+" "+rs.getString("SECTOR_FROM")+rs.getString("SECTOR_TO");
				master_roster [cnt][2]= rs.getString("SP_DUTY");
				master_roster [cnt][3]= rs.getString("WK");								
				cnt++;																		
			}									        
			rs.close();
			stmt.close();
 
 			//2.0 format records
			rtn_roster_cnt = 0;
 			for (int p = 0; p < cnt; p++) {
				if (master_roster[p][0].length() > 0 ) {
	 				rdate = master_roster[p][0];
	 				rweek = master_roster[p][3];
					duty = master_roster[p][1];
					for (int m = p+1; m < cnt; m++){
						if (rdate.equals(master_roster[m][0])) {
							duty = duty + "<BR>" + master_roster[m][1];
							master_roster[m][1] = "&nbsp;";  //set blank
							master_roster[m][0] = "";  //set blank
						}
					}								
					rtn_roster[rtn_roster_cnt][0] = rdate;
					rtn_roster[rtn_roster_cnt][3] = rweek;
					rtn_roster[rtn_roster_cnt][1] = duty; 							
					rtn_roster_cnt++;		 	 								 					
 				}
 			}
 			
			//3.0 get blocked date by user		 	
			sql = "SELECT DISTINCT B_DATE,TO_CHAR(B_DATE,'DD-MON-YY') AS MYDATE " +
				  "FROM CREWDIR.SW_R_BLOCK_ROSTER " +
				  "WHERE ERN = '" +ern+ "' AND to_char(B_DATE, 'yyyymm') BETWEEN '" +s_date+"' AND '"+e_date+"' " +
				  "ORDER BY B_DATE";
			stmt = con.createStatement();		
			rs = stmt.executeQuery(sql);		
			while(rs.next()){
				for (int k = 0; k < rtn_roster_cnt; k++){
					if (rtn_roster[k][0].equals(rs.getString("MYDATE")))
						rtn_roster[k][2] = "B";										
				}
			}									        
			rs.close();
			stmt.close();		

			//5.0 get System block date by period
			sql =  "SELECT DISTINCT START_DATE,END_DATE " +
				   "FROM CREWDIR.SW_R_RESTRICT_PERIOD " +
				   "WHERE ERN = '" +ern+ "' AND to_char(START_DATE, 'yyyymm') BETWEEN '" +s_date+"' AND '"+e_date+"' " +
				   "ORDER BY START_DATE";
			stmt = con.createStatement();		
			rs= stmt.executeQuery(sql);		
			while(rs.next()) {
				start_date = rs.getDate("START_DATE");
				end_date = rs.getDate("END_DATE");		
				for (int k=0; k<rtn_roster_cnt; k++) {
					tempdate = formatter.parse(rtn_roster[k][0]);
					if (tempdate.compareTo(start_date) >= 0) {				    	 
						if (tempdate.compareTo(end_date) <= 0)
							rtn_roster[k][2]="S";						   						   		
					}							
				}																			
			}									        
			rs.close();
			stmt.close();		
			
			//4.0 get System lock date by date
			sql = "SELECT DISTINCT R_DATE, TO_CHAR(R_DATE, 'DD-MON-YY') AS MYDATE " +
				  "FROM CREWDIR.SW_R_ROSTER_DATE " +
				  "WHERE SWAP = 'N' AND ERN = '" +ern+ "' AND to_char(R_DATE, 'yyyymm') BETWEEN '" +s_date+"' AND '"+e_date+"' " +
				  "ORDER BY R_DATE";
			stmt = con.createStatement();		
			rs= stmt.executeQuery(sql);		
			while(rs.next()) {
				for (int k=0; k<rtn_roster_cnt; k++) {
					if (rtn_roster[k][0].equals(rs.getString("MYDATE")))
						 rtn_roster[k][2]="S";										
				}
			}									        
			rs.close();
			stmt.close();		
			
			roster_cnt =rtn_roster_cnt;
					 		
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			if (con != null) {
				try {
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if

		} catch (Exception ex) {
			ex.printStackTrace();		    			
		
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if
		}//catch/try
		return rtn_roster;
	}

	//-----------------------------------------------------------------
	public String setBlock(String [] b_date, String s_month, String e_month) {
		
		String err_code = "no_err";
		String sql = new String("");
		int myroster_cnt = 0;
		
		try {	
			dbconnect db = new dbconnect();
			Connection con = db.getConn();
			con.setAutoCommit(false);			 	    
			ResultSet rs = null;			
			Statement stmt = null;
			
			String block_date = new String("");
			int row = 0;
			int total_row = 0;
			stmt = con.createStatement();

			//1.0 delete this month records
			if (b_date[0] != null) {
				sql = "DELETE FROM CREWDIR.SW_R_BLOCK_ROSTER  " +
				  	  "WHERE ERN='"+ern+"' AND TO_CHAR(B_DATE,'YYYYMM') BETWEEN '"+s_month+"' AND '"+e_month+"'";
				row = stmt.executeUpdate(sql);

				//2.0 insert those record
				for (int y = 0; y < b_date.length; y++) {
					if (b_date[y] != null){
						sql = "INSERT INTO CREWDIR.SW_R_BLOCK_ROSTER (ERN, B_DATE, BLOCKED) " +
							  "VALUES ('"+ern+"','"+b_date[y]+ "', 'Y')";
						row = stmt.executeUpdate(sql);
						total_row = total_row + row;
						block_date = block_date + b_date[y] +", ";
					}
				}
				block_date = block_date.substring(0, (block_date.length()-2));
			}
			if (total_row > 0) {
				con.commit();
				err_code = "Your swap block dates request of "+block_date+" updated successfully.";
			} else {
				con.rollback();
				err_code = "Your swap block dates request of "+block_date+" updated unsuccessfully.";		
			}
			
			stmt.close();
					
		} catch (SQLException sqlex) {
			sqlex.printStackTrace();			  
			err_code = sqlex.toString();
			if (con != null) {
				try {
					con.rollback();	
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}		   	  
			} //if			 						
		} catch (Exception ex) {
			ex.printStackTrace();
			err_code = ex.toString();		    			
		} finally {
			if (con != null) {
				try {
					con.rollback();
					con.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			} //if  
		}//catch/try						
		return err_code;
	}

	/**
	 * @return
	 */
	public String[][] getRoster() {
		return roster;
	}

	/**
	 * @return
	 */
	public int getRoster_cnt() {
		return roster_cnt;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public String getStart_month() {
		return start_month;
	}
	
	/**
	 * @return Returns the end_month.
	 */
	public String getEnd_month() {
		return end_month;
	}
}