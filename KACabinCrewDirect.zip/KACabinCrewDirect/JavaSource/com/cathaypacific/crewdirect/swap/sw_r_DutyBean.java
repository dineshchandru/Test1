
package com.cathaypacific.crewdirect.swap;


public class sw_r_DutyBean {
	
	private String r_type;
	private String code;
	
	public sw_r_DutyBean() {
		super();
	}

	public sw_r_DutyBean(String rtype,String code) {
		this.r_type = rtype;
		this.code =code;
	}

	/**
	 * @return
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return
	 */
	public String getR_type() {
		return r_type;
	}

	/**
	 * @param string
	 */
	public void setCode(String string) {
		code = string;
	}

	/**
	 * @param string
	 */
	public void setR_type(String string) {
		r_type = string;
	}

}
