package com.cathaypacific.crewdirect.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cathaypacific.crewdirect.databeans.dbconnect;

/**
 * @author��Wender
 * @version Date:Oct 24, 2011 12:25:58 PM �
 */
public class ComputeRosterDelta {
    
    private final static String GET_CHANGED_DELTA_COUNT_SQL = "select count(*) as COUNT from KA_DC_DELTA_TMP where STAFF_ID=? ";
    private final static String DELETE_CHANGED_DELTA_SQL  = "delete from KA_DC_DELTA where STAFF_ID = ? ";
    private final static String DELETE_CHANGED_DELTA_FROM_TEMP_SQL  = "delete from KA_DC_DELTA_TMP where STAFF_ID = ? ";
    private final static String INSERT_CHANGED_DELTA_FROM_TEMP_SQL = "insert into KA_DC_DELTA (STAFF_ID, ROSTER_DATE_W_DELTA, ACK_KEY, ACK_TIME) select STAFF_ID, ROSTER_DATE_W_DELTA, ACK_KEY, ACK_TIME from KA_DC_DELTA_TMP where STAFF_ID =? ";
    
    private Connection con = null;
    private PreparedStatement stmt = null;
    private boolean isSuccess = false;

    /**
     * Copy and insert the new change delta from KA_DC_DELTA_TMP into KA_DC_DELTA table by staff id.
     * Delete the data in KA_DC_DELTA_TMP once the data have been copied into KA_DC_DELTA successfully.
     * @param��staffId - Staff ID
     */
    public void recordChangedDelta(String staffId) {

        try {
            //Retrieve the changed duty from table KA_ROSTER_MASTER and KA_ROSTER_FROM_MQ by staff id
            int count = getChangedDeltaCountFromTempTable(staffId);

            if (count > 0) {
                //Delete all records in table KA_DC_DELTA by staff id
                deleteOutdateChangedDelta(staffId, false);

                //Copy and insert the new change delta from KA_DC_DELTA_TMP into KA_DC_DELTA table by staff id.
                insertChangedDelta(staffId);
                
                //Delete records in table KA_DC_DELTA_TMP by staff id
                deleteOutdateChangedDelta(staffId, true);
            }
            isSuccess = true;
        }
        catch (Exception e) {
            e.printStackTrace();
            isSuccess = false;
        }
    }

    /**
     * Get the record count from KA_DC_DELTA_TMP table by staff id.
     * @param��staffId - Staff ID
     * @return count - Record count
     */
    public int getChangedDeltaCountFromTempTable(String staffId) throws Exception {
        ResultSet rs = null;
        int count = 0;
        try {
            dbconnect db = new dbconnect();
            con = db.getConn();
            stmt = con.prepareStatement(GET_CHANGED_DELTA_COUNT_SQL);
            System.out.println("Get changed delta count from temp table SQL: " + GET_CHANGED_DELTA_COUNT_SQL);
            stmt.setString(1, staffId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt("COUNT");
            }
            rs.close();
            stmt.close();

        }
        catch (SQLException sqlex) {
            sqlex.printStackTrace();
            if (con != null) {
                try {
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            throw new Exception(sqlex.getCause());
        }
        finally {
            if (con != null) {
                try {
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return count;
    }

    /**
     * Delete the outdate change delta from KA_DC_DELTA/KA_DC_DELTA_TMP table by staff id.
     * @param��staffId - Staff ID
     * @param��isDeleteTemp - Flag to identify KA_DC_DELTA or it's temp table.
     */
    public void deleteOutdateChangedDelta(String staffId, boolean isDeleteTemp) throws Exception {

        try {
            dbconnect db = new dbconnect();
            Connection con = db.getConn();
            con.setAutoCommit(false);
            
            if (isDeleteTemp){
                stmt = con.prepareStatement(DELETE_CHANGED_DELTA_FROM_TEMP_SQL);
                System.out.println("Delete outdate change delta from temp table SQL: " + DELETE_CHANGED_DELTA_FROM_TEMP_SQL);
            }
            else{
                stmt = con.prepareStatement(DELETE_CHANGED_DELTA_SQL);
                System.out.println("Delete outdate change delta SQL: " + DELETE_CHANGED_DELTA_SQL);
            }
            
            stmt.setString(1, staffId);
            stmt.executeUpdate();

            stmt.close();
            con.commit();
        }
        catch (SQLException sqlex) {
            sqlex.printStackTrace();
            if (con != null) {
                try {
                    con.rollback();
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            throw new Exception(sqlex.getCause());
        }
        finally {
            if (con != null) {
                try {
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Copy and insert the new change delta from KA_DC_DELTA_TMP into KA_DC_DELTA table by staff id.
     * @param��staffId - Staff ID
     */
    public void insertChangedDelta(String staffId) throws Exception {

        try {
            dbconnect db = new dbconnect();
            Connection con = db.getConn();
            con.setAutoCommit(false);

            stmt = con.prepareStatement(INSERT_CHANGED_DELTA_FROM_TEMP_SQL);
            System.out.println("Insert new change delta SQL: " + INSERT_CHANGED_DELTA_FROM_TEMP_SQL);
            stmt.setString(1, staffId);
            stmt.executeUpdate();

            stmt.close();
            con.commit();
        }
        catch (SQLException sqlex) {
            sqlex.printStackTrace();
            if (con != null) {
                try {
                    con.rollback();
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            throw new Exception(sqlex.getCause());
        }
        finally {
            if (con != null) {
                try {
                    con.close();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @return Returns the isSuccess.
     */
    public boolean isSuccess() {
        return isSuccess;
    }

    /**
     * @param isSuccess
     *            The isSuccess to set.
     */
    public void setSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }
}