
package com.cathaypacific.crewdirect.utils;

public class mq_RosterBean {

	private String ERN;
	
	private String PatternDate;
	private String PatternCode;
		
	private String Lt_DutyStart;
	private String Lt_DutyEnd;
	private String Lt_Flt_Dep;
	private String Lt_Flt_Arr;

	private String Hkg_DutyStart;
	private String Hkg_DutyEnd;
	private String Hkg_Flt_Dep;
	private String Hkg_Flt_Arr;
		
	private String Flt_Date;
	private String Carrier_Code;
	private String Flt_No;
	private String Gr_Duty_Code;
	private String Sector_Conn;
	private String Sector_From;
	private String Sector_To;
		
	private String Sp_Duty;
	private String Acft_Type;
	private String Duty_End_Ind;
	
	private String msg_type;

	public mq_RosterBean() {
		super();
	}

	public mq_RosterBean(String ERN,String PatternDate,String PatternCode,String Gr_Duty_Code,
						 String Flt_Date,String Flt_No,String Sector_From,String msg_type) {
		//this construtctor for eswap
		this.ERN = ERN;	
		this.PatternDate = PatternDate;
		this.PatternCode = PatternCode;
		
		this.Flt_Date = Flt_Date;
		this.Flt_No = Flt_No;
		this.Gr_Duty_Code = Gr_Duty_Code;
		
		this.Sector_From = Sector_From;
		this.msg_type = msg_type;
		
	}
    
    public mq_RosterBean(String ERN,String PatternDate,String PatternCode,String Lt_DutyStart,String Lt_DutyEnd,
    				  String Lt_Flt_Dep,String Lt_Flt_Arr,String Hkg_DutyStart,String Hkg_DutyEnd,
    				  String Hkg_Flt_Dep,String Hkg_Flt_Arr,String Flt_Date,String Carrier_Code, String Flt_No,
    				  String Gr_Duty_Code,String Sector_Conn,String Sector_From,String Sector_To,
    				  String Sp_Duty,String Acft_type,String Duty_End_Ind,String msg_type ){
        //this constructor for ack & get note actions 
    	this.ERN = ERN;	
    	this.PatternDate = PatternDate;
    	this.PatternCode = PatternCode;
    	
    	this.Lt_DutyStart = Lt_DutyStart;
    	this.Lt_DutyEnd  = Lt_DutyEnd;
    	this.Lt_Flt_Dep = Lt_Flt_Dep;
    	this.Lt_Flt_Arr = Lt_Flt_Arr;
    	
    	this.Hkg_DutyStart = Hkg_DutyStart;
    	this.Hkg_DutyEnd = Hkg_DutyEnd;
    	this.Hkg_Flt_Dep = Hkg_Flt_Dep;
    	this.Hkg_Flt_Arr = Hkg_Flt_Arr;
    	
    	this.Flt_Date = Flt_Date;
    	this.Carrier_Code = Carrier_Code;
    	this.Flt_No = Flt_No;
    	this.Gr_Duty_Code = Gr_Duty_Code;
    	this.Sector_Conn = Sector_Conn;
    	this.Sector_From = Sector_From;
    	this.Sector_To = Sector_To;
    	this.Sp_Duty = Sp_Duty;
    	this.Acft_Type = Acft_type;
    	this.Duty_End_Ind = Duty_End_Ind;
    	this.msg_type = msg_type;
    	    	
    }
	/**
	 * @return
	 */
	public String getAcft_Type() {
		return Acft_Type;
	}

	/**
	 * @return
	 */
	public String getDuty_End_Ind() {
		return Duty_End_Ind;
	}

	/**
	 * @return
	 */
	public String getERN() {
		return ERN;
	}

	/**
	 * @return
	 */
	public String getFlt_Date() {
		return Flt_Date;
	}
	
	/**
	 * @return
	 */
	public String getCarrier_Code() {
		return Carrier_Code;
	}

	/**
	 * @return
	 */
	public String getFlt_No() {
		return Flt_No;
	}

	/**
	 * @return
	 */
	public String getGr_Duty_Code() {
		return Gr_Duty_Code;
	}

	/**
	 * @return
	 */
	public String getHkg_DutyEnd() {
		return Hkg_DutyEnd;
	}

	/**
	 * @return
	 */
	public String getHkg_DutyStart() {
		return Hkg_DutyStart;
	}

	/**
	 * @return
	 */
	public String getHkg_Flt_Arr() {
		return Hkg_Flt_Arr;
	}

	/**
	 * @return
	 */
	public String getHkg_Flt_Dep() {
		return Hkg_Flt_Dep;
	}

	/**
	 * @return
	 */
	public String getLt_DutyEnd() {
		return Lt_DutyEnd;
	}

	/**
	 * @return
	 */
	public String getLt_DutyStart() {
		return Lt_DutyStart;
	}

	/**
	 * @return
	 */
	public String getLt_Flt_Arr() {
		return Lt_Flt_Arr;
	}

	/**
	 * @return
	 */
	public String getLt_Flt_Dep() {
		return Lt_Flt_Dep;
	}

	/**
	 * @return
	 */
	public String getPatternCode() {
		return PatternCode;
	}

	/**
	 * @return
	 */
	public String getPatternDate() {
		return PatternDate;
	}

	/**
	 * @return
	 */
	public String getSector_Conn() {
		return Sector_Conn;
	}

	/**
	 * @return
	 */
	public String getSector_From() {
		return Sector_From;
	}

	/**
	 * @return
	 */
	public String getSector_To() {
		return Sector_To;
	}

	/**
	 * @return
	 */
	public String getSp_Duty() {
		return Sp_Duty;
	}

	/**
	 * @param string
	 */
	public void setAcft_Type(String string) {
		Acft_Type = string;
	}

	/**
	 * @param string
	 */
	public void setDuty_End_Ind(String string) {
		Duty_End_Ind = string;
	}

	/**
	 * @param string
	 */
	public void setERN(String string) {
		ERN = string;
	}

	/**
	 * @param string
	 */
	public void setFlt_Date(String string) {
		Flt_Date = string;
	}
	
	/**
	 * @param string
	 */
	public void setCarrier_Code(String string) {
		Carrier_Code = string;
	}

	/**
	 * @param string
	 */
	public void setFlt_No(String string) {
		Flt_No = string;
	}

	/**
	 * @param string
	 */
	public void setGr_Duty_Code(String string) {
		Gr_Duty_Code = string;
	}

	/**
	 * @param string
	 */
	public void setHkg_DutyEnd(String string) {
		Hkg_DutyEnd = string;
	}

	/**
	 * @param string
	 */
	public void setHkg_DutyStart(String string) {
		Hkg_DutyStart = string;
	}

	/**
	 * @param string
	 */
	public void setHkg_Flt_Arr(String string) {
		Hkg_Flt_Arr = string;
	}

	/**
	 * @param string
	 */
	public void setHkg_Flt_Dep(String string) {
		Hkg_Flt_Dep = string;
	}

	/**
	 * @param string
	 */
	public void setLt_DutyEnd(String string) {
		Lt_DutyEnd = string;
	}

	/**
	 * @param string
	 */
	public void setLt_DutyStart(String string) {
		Lt_DutyStart = string;
	}

	/**
	 * @param string
	 */
	public void setLt_Flt_Arr(String string) {
		Lt_Flt_Arr = string;
	}

	/**
	 * @param string
	 */
	public void setLt_Flt_Dep(String string) {
		Lt_Flt_Dep = string;
	}

	/**
	 * @param string
	 */
	public void setPatternCode(String string) {
		PatternCode = string;
	}

	/**
	 * @param string
	 */
	public void setPatternDate(String string) {
		PatternDate = string;
	}

	/**
	 * @param string
	 */
	public void setSector_Conn(String string) {
		Sector_Conn = string;
	}

	/**
	 * @param string
	 */
	public void setSector_From(String string) {
		Sector_From = string;
	}

	/**
	 * @param string
	 */
	public void setSector_To(String string) {
		Sector_To = string;
	}

	/**
	 * @param string
	 */
	public void setSp_Duty(String string) {
		Sp_Duty = string;
	}

	/**
	 * @return
	 */
	public String getMsg_type() {
		return msg_type;
	}

	/**
	 * @param string
	 */
	public void setMsg_type(String string) {
		msg_type = string;
	}

}
