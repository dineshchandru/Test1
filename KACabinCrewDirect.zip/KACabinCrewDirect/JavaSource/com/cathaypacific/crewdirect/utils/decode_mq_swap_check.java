/*
 * Created on May 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.utils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class decode_mq_swap_check {
	private Connection con=null;
	
	private mq_RosterBean [] req_roster = new mq_RosterBean[50];
	int req_roster_cnt = 0;
	private mq_RosterBean [] acp_roster = new mq_RosterBean[50];
	int acp_roster_cnt = 0;	
	private String swap_no=null;
	private String acp_ern=null;
	private String req_ern=null;	
	private String msg_type=null;
	private String err_msg;
	private boolean success;
		
	public decode_mq_swap_check() {
		super();
	}

	public decode_mq_swap_check(String swap_no,String mq_msg) {
		this.swap_no =swap_no;
		String entry_num;
		String entry_txt;
		int Spos=0; int Epos=0;		
		
		//1.0 start decoding
		//1.1 get two party ern
		Spos = 7;		
        req_ern = mq_msg.substring(Spos,Spos+7);
        Spos = Spos +7 ;
		acp_ern = mq_msg.substring(Spos,Spos+7);
		  		 
		//1.2 Total num of entry for 1st ern
		Spos = 37;  
		Epos = Spos + 2; 
		entry_num = mq_msg.substring(Spos,Epos); //N2		
		//1.2.1 loop detail entry for 1st ERN
		for (int x=0;x<Integer.parseInt(entry_num);x++){
			Spos = Epos;
			Epos = Spos + 148;  
			entry_txt = mq_msg.substring(Spos,Epos );			
			CreateEntry("req",entry_txt);	             
		}
						
		//1.3 Total num of entry for 2nd ern
		Spos = 7439;
		Epos = Spos + 2;
		entry_num = mq_msg.substring(Spos,Epos); //N2
		//1.2.1 loop detail entry for 2nd ERN
		for (int x=0;x<Integer.parseInt(entry_num);x++){
			Spos = Epos;
			Epos = Spos + 148;  
			entry_txt = mq_msg.substring(Spos,Epos );			
			CreateEntry("acp",entry_txt);	             
		}
		
		//2.0 cross check with saved roster
		err_msg = chkSavedRoster();
		if (err_msg.equals("no_err" )){
			success = true;
		}else{
			success = false;
		}
		
                       
	}

//	---------------------------------------------------------------------
	public void CreateEntry(String user,String entry){
						
		//1.0 break down the entry
		String PatternDate = entry.substring(0,8).trim() ;
		String PatternCode = entry.substring(8,15).trim();
		
		String Lt_DutyStart = entry.substring(15,27).trim();
		String Lt_DutyEnd = entry.substring(27,39).trim();
		String Lt_Flt_Dep = entry.substring(39,51).trim();
		String Lt_Flt_Arr = entry.substring(51,63).trim();

		String Hkg_DutyStart = entry.substring(63,75).trim();
		String Hkg_DutyEnd = entry.substring(75,87).trim();
		String Hkg_Flt_Dep = entry.substring(87,99).trim();
		String Hkg_Flt_Arr = entry.substring(99,111).trim();
		
		String Flt_Date = entry.substring(111,119).trim();
		
		//add on 06 Oct 2009 
		String Carrier_Code = entry.substring(119, 122).trim(); //added for KACCD
		//System.out.println("Carrier_Code : " + Carrier_Code);
		String Flt_No = entry.substring(122,126).trim();
		//System.out.println("Flt_No : " + Flt_No);
		String Gr_Duty_Code = entry.substring(126,131).trim();
		//System.out.println("Gr_Duty_Code: " + Gr_Duty_Code);
		String Sector_Conn = entry.substring(131,138).trim();
		//System.out.println("Sector_Conn : " + Sector_Conn);
		String Sector_From = entry.substring(138,141).trim();
		//System.out.println("Sector_From : " + Sector_From);
		String Sector_To = entry.substring(141,144).trim();
		//System.out.println("Sector_To : " + Sector_To);
		
		String Sp_Duty = entry.substring(144,146).trim();
		//System.out.println("Sp_Duty : " + Sp_Duty);
		String Acft_Type = entry.substring(146,150).trim();
		//System.out.println("Acft_Type : " + Acft_Type);
		String Duty_End_Ind = entry.substring(150,151).trim();
		//System.out.println("Duty_End_Ind : " + Duty_End_Ind);
		String Msg_Type = entry.substring(151,152).trim();	
		//System.out.println("Msg_Type : " + Msg_Type);
		
		/*String Flt_No = entry.substring(119,123).trim();
		String Gr_Duty_Code = entry.substring(123,128).trim();
		String Sector_Conn = entry.substring(128,135).trim();
		String Sector_From = entry.substring(135,138).trim();
		String Sector_To = entry.substring(138,141).trim();
		
		String Sp_Duty = entry.substring(141,143).trim();
		String Acft_Type = entry.substring(143,147).trim();
		String Duty_End_Ind = entry.substring(147,148).trim();
		*/
		
	    if (user.equals("req" )){
			mq_RosterBean myBean = new mq_RosterBean(req_ern,PatternDate,PatternCode,Lt_DutyStart,Lt_DutyEnd,Lt_Flt_Dep,Lt_Flt_Arr,
													 Hkg_DutyStart,Hkg_DutyEnd,Hkg_Flt_Dep,Hkg_Flt_Arr,Flt_Date,Carrier_Code,Flt_No,
													 Gr_Duty_Code,Sector_Conn,Sector_From,Sector_To,Sp_Duty,Acft_Type,Duty_End_Ind,Msg_Type);		   	
			req_roster[req_roster_cnt] = myBean;
			req_roster_cnt++;
	    }else{
			mq_RosterBean myBean = new mq_RosterBean(acp_ern,PatternDate,PatternCode,Lt_DutyStart,Lt_DutyEnd,Lt_Flt_Dep,Lt_Flt_Arr,
													 Hkg_DutyStart,Hkg_DutyEnd,Hkg_Flt_Dep,Hkg_Flt_Arr,Flt_Date,Carrier_Code,Flt_No,
													 Gr_Duty_Code,Sector_Conn,Sector_From,Sector_To,Sp_Duty,Acft_Type,Duty_End_Ind,Msg_Type);
			acp_roster[acp_roster_cnt] = myBean; 													 	    				
			acp_roster_cnt++;
	    }
		
	}
	
//---------------------------------------------------------------------	
public String chkSavedRoster(){
	    String err_msg ="no_err";
		mq_RosterBean [] req_rst = new mq_RosterBean[50];
		int req_rst_cnt = 0;
		mq_RosterBean [] acp_rst = new mq_RosterBean[50];
		int acp_rst_cnt = 0;	

		String ern = "";
		String pattern_code = "";
		String pattern_date = "";
		String flt_date = "";
		String flt_no = "";
		String sector_from = "";
		String gr_duty_code = "";
		String SQL =null;		

		try{	

			dbconnect db = new dbconnect();
			con = db.getConn();				        
			Statement stmt=con.createStatement();						
			ResultSet rs=null;				
			//2.0 get saved roster patterns for REQ 
			SQL = "select ern,to_char(pattern_date,'yyyymmdd') as pattern_date," +				      "pattern_code,nvl(to_char(flt_date,'yyyymmdd'),' ') as flt_date," +				      "nvl(flt_no,' ') as flt_no,nvl(sector_from,' ') as sector_from,nvl(gr_duty_code,' ') as gr_duty_code " +				      "from crewdir.swap_req_save_pattern " +				   "where swap_id ='"+swap_no+"' and ern = '"+req_ern+"'";				   			 		
			rs= stmt.executeQuery(SQL);		
			while(rs.next()){		
				ern = rs.getString("ern").trim();
				pattern_date = rs.getString("pattern_date").trim();
				pattern_code = rs.getString("pattern_code").trim();
				flt_date = rs.getString("flt_date").trim();
				flt_no = rs.getString("flt_no").trim();								
				sector_from = rs.getString("sector_from").trim();
				gr_duty_code = rs.getString("gr_duty_code").trim();
				mq_RosterBean myBean = new mq_RosterBean(req_ern,pattern_date,pattern_code,gr_duty_code,flt_date,flt_no,sector_from,"");
				req_rst[req_rst_cnt] = myBean; 													 	    				
				req_rst_cnt++;	
			}									        
			rs.close();

			//2.1 check no of pattern match
			if (req_rst_cnt != req_roster_cnt){
				err_msg = "Requster roster not match.";
			}else{
				//2.2 loop both array for match case
				//2.2.1 mark match roster by stamping 'Y'
				for (int y=0;y<req_rst_cnt;y++){
					for (int r=0;r<req_roster_cnt;r++){
						if (req_rst[y].getERN().equals(req_roster[r].getERN()) &&
							req_rst[y].getPatternCode().equals(req_roster[r].getPatternCode()) &&
							req_rst[y].getPatternDate().equals(req_roster[r].getPatternDate()) &&
							req_rst[y].getGr_Duty_Code().equals(req_roster[r].getGr_Duty_Code()) &&
							req_rst[y].getFlt_Date().equals(req_roster[r].getFlt_Date()) &&
							req_rst[y].getFlt_No().equals(req_roster[r].getFlt_No()) &&
							req_rst[y].getSector_From().equals(req_roster[r].getSector_From()) ){ 					    
						    
							//-------------------------
							req_rst[y].setMsg_type("Y");
							//-------------------------    	 	
						}						
					}
				}
				
				//2.2.2 check any roster doesn't have Y indector
				for (int y=0;y<req_rst_cnt;y++){
					if (!req_rst[y].getMsg_type().equals("Y") ){
						err_msg = "Requster roster not match.";
					}					
				}	
			}
			stmt.close();				 			
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    			
			
		}catch (Exception ex) {
			ex.printStackTrace();
			err_msg = ex.toString(); 			 		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
				  err_msg = e.toString();
			   }
			} //if  
		}//catch	   			
	
	   return err_msg;			
	}
	

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

}
