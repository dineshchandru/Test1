/*
 * Created on May 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.utils;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleTypes;

import com.cathaypacific.crewdirect.databeans.dbconnect;

public class decode_mq_roster {
	private Connection con=null;
	
	private mq_RosterBean [] lst = new mq_RosterBean[200];
	private int rcnt=0;
	private String ERN=null;
	private String msg_type=null;
	private String err_msg;
	private boolean success;
		
	public decode_mq_roster() {
		super();
	}

	public decode_mq_roster(String ern,String mq_msg,String msg_type) {
		//System.out.println("decode_mq_roster check 1");
		this.ERN = ern;
		this.msg_type = msg_type;
		
		//1.0 start decoding 
		String entry_num;
		String entry_txt;
		int Spos=0; int Epos=0;		
		//1.1Total num of entry
		if (msg_type.equals("RC")) {
			Spos = 45;  //start pos
		}else{
			if (msg_type.equals("CN")) {
				Spos = 45;
			}		 
		}						

		Epos = Spos + 3; 
		entry_num = mq_msg.substring(Spos,Epos); //N3
		//System.out.println("decode_mq_roster check 2");
		//1.2 loop detail entry
		for (int x=0;x<Integer.parseInt(entry_num);x++){
			Spos = Epos;
			Epos = Spos + 152;  
			entry_txt = mq_msg.substring(Spos,Epos );			
			CreateEntry(entry_txt);	             
		}
		//System.out.println("decode_mq_roster check 3");
        //2.0 update corrsponding tables
		updateRosterTables();        
		//System.out.println("decode_mq_roster check 4");
                       
	}

	public void CreateEntry(String entry){
						
		//1.0 break down the entry
		String PatternDate = entry.substring(0,8).trim() ;
		//System.out.println("CreateEntry PatternDate : " + PatternDate);
		String PatternCode = entry.substring(8,15).trim();
		//System.out.println("PatterCode: " + PatternCode);		
		String Lt_DutyStart = entry.substring(15,27).trim();
		//System.out.println("Lt_DutyStart : " + Lt_DutyStart);
		String Lt_DutyEnd = entry.substring(27,39).trim();
		//System.out.println("Lt_DutyEnd : " + Lt_DutyEnd);
		String Lt_Flt_Dep = entry.substring(39,51).trim();
		//System.out.println("Lt_Flt_Dep : " + Lt_Flt_Dep);
		String Lt_Flt_Arr = entry.substring(51,63).trim();
		//System.out.println("Lt_Flt_Arr : " + Lt_Flt_Arr);

		String Hkg_DutyStart = entry.substring(63,75).trim();
		//System.out.println("Hkg_DutyStart: " + Hkg_DutyStart);
		String Hkg_DutyEnd = entry.substring(75,87).trim();
		//System.out.println("Hkg_DutyEnd : " + Hkg_DutyEnd);
		String Hkg_Flt_Dep = entry.substring(87,99).trim();
		//System.out.println("Hkg_Flt_Dep : " + Hkg_Flt_Dep);
		String Hkg_Flt_Arr = entry.substring(99,111).trim();	
		//System.out.println("Hkg_Flt_Arr: " + Hkg_Flt_Arr);
		String Flt_Date = entry.substring(111,119).trim();
		//System.out.println("Flt_Date : " + Flt_Date);
		String Carrier_Code = entry.substring(119, 122).trim(); //added for KACCD
		//System.out.println("Carrier_Code : " + Carrier_Code);
		String Flt_No = entry.substring(122,126).trim();
		//System.out.println("Flt_No : " + Flt_No);
		String Gr_Duty_Code = entry.substring(126,131).trim();
		//System.out.println("Gr_Duty_Code: " + Gr_Duty_Code);
		String Sector_Conn = entry.substring(131,138).trim();
		//System.out.println("Sector_Conn : " + Sector_Conn);
		String Sector_From = entry.substring(138,141).trim();
		//System.out.println("Sector_From : " + Sector_From);
		String Sector_To = entry.substring(141,144).trim();
		//System.out.println("Sector_To : " + Sector_To);
		
		String Sp_Duty = entry.substring(144,146).trim();
		//System.out.println("Sp_Duty : " + Sp_Duty);
		String Acft_Type = entry.substring(146,150).trim();
		//System.out.println("Acft_Type : " + Acft_Type);
		String Duty_End_Ind = entry.substring(150,151).trim();
		//System.out.println("Duty_End_Ind : " + Duty_End_Ind);
		String Msg_Type = entry.substring(151,152).trim();	
		//System.out.println("Msg_Type : " + Msg_Type);
				
		mq_RosterBean myBean = new mq_RosterBean(ERN,PatternDate,PatternCode,Lt_DutyStart,Lt_DutyEnd,Lt_Flt_Dep,Lt_Flt_Arr,
													 Hkg_DutyStart,Hkg_DutyEnd,Hkg_Flt_Dep,Hkg_Flt_Arr,Flt_Date,Carrier_Code, Flt_No,
													 Gr_Duty_Code,Sector_Conn,Sector_From,Sector_To,Sp_Duty,Acft_Type,Duty_End_Ind,Msg_Type);
        //2.0 add to RosterList Array				
		lst[rcnt] = myBean;
		rcnt++;				
		//System.out.println("decode_mq_roster CreateEntry rcnt : " + rcnt);
		
	}
	
	
	public void updateRosterTables(){

		String SQL =null;
		String MQ_RPC_RTN = null;
		int rows;
		try{	
			//System.out.println("decode_mq_roster updateRosterTables");
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 	    
			con.setAutoCommit(false);
			//1.0 Prepare Data			
			Statement stmt = con.createStatement();
			//System.out.println("decode_mq_roseter updateRosterTables : rcnt " + rcnt);
			for (int x=0;x<rcnt;x++){
				//insert data into mq_data_raw table (this is oracle session-specific temp table keep until this sessin finished)
				SQL = "INSERT INTO CREWDIR.MQ_TMP_FACTS_ROSTER ("+			
							"STAFFID,PATTERN_DATE,PATTERN_CODE," +           
							"LT_DUTY_START,LT_DUTY_END,LT_FLT_DEP,"+             
							"LT_FLT_ARR,HKG_DUTY_START,HKG_DUTY_END,"+           
							"HKG_FLT_DEP,HKG_FLT_ARR,FLT_DATE,"+               
							"FLT_NO,GR_DUTY_CODE,SECTOR_CONN,"+            
							"SECTOR_FROM,SECTOR_TO,SP_DUTY,"+                
							"ACFT_TYPE,DUTY_END_INDICATOR,MSG_TYPE, CARRIER_CODE) " +     
					  " VALUES ('" +
					        lst[x].getERN()+"',to_date('"+lst[x].getPatternDate()+"','yyyymmdd'),'"+lst[x].getPatternCode()+"',"+   
					        "to_date('"+lst[x].getLt_DutyStart()+"','yyyymmddhh24mi'),to_date('"+lst[x].getLt_DutyEnd()+"','yyyymmddhh24mi'),to_date('"+lst[x].getLt_Flt_Dep()+"','yyyymmddhh24mi'),"+   
					        "to_date('"+lst[x].getLt_Flt_Arr() +"','yyyymmddhh24mi'),to_date('"+lst[x].getHkg_DutyStart()+"','yyyymmddhh24mi'),to_date('"+lst[x].getHkg_DutyEnd()+"','yyyymmddhh24mi'),"+
					        "to_date('"+lst[x].getHkg_Flt_Dep() +"','yyyymmddhh24mi'),to_date('"+lst[x].getHkg_Flt_Arr() +"','yyyymmddhh24mi'),to_date('"+ lst[x].getFlt_Date() +"','yyyymmdd'),'"+
					        lst[x].getFlt_No() +"','"+lst[x].getGr_Duty_Code() +"','"+lst[x].getSector_Conn() +"','"+
					        lst[x].getSector_From() +"','"+lst[x].getSector_To() +"','"+lst[x].getSp_Duty() +"','"+
					        lst[x].getAcft_Type() +"','"+lst[x].getDuty_End_Ind()+"','"+lst[x].getMsg_type() +"', '" + lst[x].getCarrier_Code() + "')"; 
				//System.out.println("updateRosterTables : SQL " + SQL);
				   rows = stmt.executeUpdate(SQL);
			}
			
			stmt.close();
			
			//2.0 Run romote procedure call (those data insert into table: mq_tmp_data_patterns,mq_tmp_data_patterns_temp,mq_tmp_data_roster
			//                               are transaction-spcecific will keep until the 'commit' issued in this rpc.
			CallableStatement MQ_RPC = con.prepareCall("{? = call crewdir.MQ_ROSTER(?,?)}");

			// set output param
			MQ_RPC.registerOutParameter(1, OracleTypes.VARCHAR); //err_msg
			// set input param
			MQ_RPC.setString (2,ERN);  //iern
			MQ_RPC.setString (3,msg_type);  //msg_type

			// to call it
			MQ_RPC.execute ();

			// get Returns		
			MQ_RPC_RTN = MQ_RPC.getString(1);			
			
			con.commit();
			 
			if (MQ_RPC_RTN.equals("OK")){
				success = true;
			}else{
				success = false;
				err_msg = MQ_RPC_RTN; 
			}
			
			MQ_RPC.close();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.rollback();
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    						 
		}catch (Exception ex) {
			ex.printStackTrace();
			success = false;			
			err_msg = MQ_RPC_RTN; 		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch	   			
			
	}
	
	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param string
	 */
	public void setErr_msg(String string) {
		err_msg = string;
	}

	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

}
