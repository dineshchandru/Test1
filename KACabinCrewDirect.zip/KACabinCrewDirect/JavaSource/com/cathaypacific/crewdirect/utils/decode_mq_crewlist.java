package com.cathaypacific.crewdirect.utils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cathaypacific.crewdirect.databeans.dbconnect;


public class decode_mq_crewlist {
    
	private mq_CrewlistBean CrewListBean = new mq_CrewlistBean();
    
    private int rcnt =0;
	private String ERN[]= new String[30];
	
	public decode_mq_crewlist() {
		super();
	}

	public decode_mq_crewlist(String mq_msg) {
				
		//1.0 start decoding 
		String msg_id;
		int Spos; int Epos;		
		Spos = 0;
		Epos = Spos + 5; 
		msg_id = mq_msg.substring(Spos,Epos); //N3
		if (msg_id.equals("AP002")){		
			CreateEntry(mq_msg);	             			
		}
                       
	}

	public void CreateEntry(String entry){
		
		String SP_DUTY[]= new String[30];
		String CockRank[] = new String [30];
		String CockCrewID[] = new String [30];
		String CockBadge[]	= new String [30];		
        int cock_cnt =0;
		int Epos = 0; int Spos=0;						
		String CrewNum =null;
		String CockNum = null;				
						

		//1.0 break down the entry
		String flt_date = entry.substring(56,60).trim()+"-"+entry.substring(60,62).trim()+"-"+entry.substring(62,64).trim();
		String flt_no = entry.substring(64,68).trim();
		String dep_port =  entry.substring(68,71).trim();
		String sector = entry.substring(71,74).trim()+" "+entry.substring(74,77).trim() ;
		String ac_type = entry.substring(77,81).trim();
		String dep_time =entry.substring(81,85).trim()+"-"+entry.substring(85,87).trim()+"-"+entry.substring(87,89).trim()+" "+
						 entry.substring(89,91).trim()+":"+entry.substring(91,93).trim();

		CrewListBean.setFlt_date(flt_date);
		CrewListBean.setFlt_no(flt_no );
		CrewListBean.setDep_port(dep_port );
		CrewListBean.setSector(sector );
		CrewListBean.setAc_type(ac_type);
		CrewListBean.setDep_time(dep_time );		
		
		CrewNum =  entry.substring(93,95).trim();
		CrewListBean.setLstcount(Integer.parseInt(CrewNum));
		//2.0 find list of ern
		Spos = 95;
		for (int x=0;x<Integer.parseInt(CrewNum);x++){			
			Epos = Spos + 9;  
			ERN[x] = entry.substring(Spos,Epos-2);			
			SP_DUTY[x] = entry.substring(Epos-2,Epos);
			Spos = Spos + 9;
			rcnt++;				             
		}					
		//find cockpit info
		Spos =635;		 
		CockNum =  entry.substring(Spos,Spos+2);
		Spos = 637;
		for (int y=0;y<Integer.parseInt(CockNum);y++){						  
			CockRank[y] = entry.substring(Spos,Spos+5);
			CockCrewID[y] =entry.substring(Spos+5,Spos+20);
			CockBadge[y]=entry.substring(Spos+20,Spos+35);			
			Spos = Spos + 35;
			cock_cnt++;				             
		}					
		
		CrewListBean.setCockBadge(CockBadge);
		CrewListBean.setCockCrewID(CockCrewID);
		CrewListBean.setCockRank(CockRank);
		CrewListBean.setCock_cnt(cock_cnt);
		CrewListBean.setSP_DUTY(SP_DUTY);
		
		//3.0 find crewid of the ern list
		getCrewID();	
	}


    private void getCrewID(){
		Connection con=null;
		String erns = new String();
		String CREWID[] = new String [30];
		String BADGENAME[] = new String [30];
		String COS[] = new String [30];
		String CAT[] = new String [30];
		String LANG[] = new String [30];
		int y=0;
		try{	
			
			//connect to db and put data by month into list
			dbconnect db = new dbconnect();
			con = db.getConn();				        
			ResultSet rs=null;			
			Statement stmt=null;
            
 for (int x=0;x<rcnt;x++){
        
	String SQL =  "SELECT DISTINCT * " + 
				  "FROM ISDCREW.CREWDB_4_ALL "+
				  "WHERE ERN = '"+ERN[x]+"'";
						  
	stmt = con.createStatement();		
	rs= stmt.executeQuery(SQL);			
	while(rs.next()){															
		CREWID[x] = rs.getString("CREW_ID");
		BADGENAME[x] = rs.getString("BADGE_NAME");
		String cos = rs.getString("COS");
		
		if (cos.equals("P") || cos.equals("O") ){
			COS[x] = "Monthly";
		}else{
			if (cos.equals("L")){
				COS[x] = "LON";	
			}else{
				if (cos.equals("V")){
					COS[x] = "YVR";
				}else{
					if (cos.equals("U" )){
						COS[x] = "MU";						
					}else{
						if (cos.equals("M" )){
							COS[x] = "Hourly";
						}else{
							COS[x] = " ";
						}
					}
				}
			}			
		}					
		
		CAT[x] = rs.getString("CAT1")+"-"+rs.getString("CAT")+"-"+rs.getString("CAT2");
		LANG[x] =rs.getString("LANG");								
		break;				
	}									        
	rs.close();

 }
          
			stmt.close(); 
			 
			//add to bean
			CrewListBean.setCREW_ID(CREWID);
			CrewListBean.setBADGENAME(BADGENAME);
			CrewListBean.setCOS(COS);
			CrewListBean.setCAT(CAT);
			CrewListBean.setLANG(LANG); 
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    						 						
		}catch (Exception ex) {
			ex.printStackTrace();		    			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch/try
		
    	
    }
	/**
	 * @return
	 */
	public mq_CrewlistBean getCrewListBean() {
		return CrewListBean;
	}

}
