/*
 * Created on May 13, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.utils;

public class mq_CrewlistBean {
	private String flt_date;
	private String flt_no;
	private String dep_port;
	private String sector;
	private String ac_type;
	private String dep_time;
    
    private String [] CREW_ID;
    private String [] BADGENAME;
    private String [] COS;
    private String [] CAT;
    private String [] LANG;
    private String [] SP_DUTY;
	
	private String CockRank[];
	private String CockCrewID[];
	private String CockBadge[];		
	
	private int cock_cnt;

    
	private int lstcount;    
	public mq_CrewlistBean() {
		super();
	}

	public mq_CrewlistBean(String [] id) {
		this.CREW_ID = id;
	}

	public mq_CrewlistBean(String flt_date,String flt_no,String dep_port,String sector,String ac_type,String dep_time,int lstcount) {
	    this.flt_date = flt_date;
	    this.flt_no = flt_no;
	    this.dep_port = dep_port;
	    this.dep_time = dep_time;
	    this.sector = sector;
	    this.ac_type = ac_type;
	    this.lstcount = lstcount;
	}

	/**
	 * @return
	 */
	public String getAc_type() {
		return ac_type;
	}

	/**
	 * @return
	 */
	public String[] getCREW_ID() {
		return CREW_ID;
	}

	/**
	 * @return
	 */
	public String getDep_port() {
		return dep_port;
	}

	/**
	 * @return
	 */
	public String getDep_time() {
		return dep_time;
	}

	/**
	 * @return
	 */
	public String getFlt_date() {
		return flt_date;
	}

	/**
	 * @return
	 */
	public String getFlt_no() {
		return flt_no;
	}

	/**
	 * @return
	 */
	public String getSector() {
		return sector;
	}

	/**
	 * @param string
	 */
	public void setAc_type(String string) {
		ac_type = string;
	}

	/**
	 * @param strings
	 */
	public void setCREW_ID(String[] strings) {
		CREW_ID = strings;
	}

	/**
	 * @param string
	 */
	public void setDep_port(String string) {
		dep_port = string;
	}

	/**
	 * @param string
	 */
	public void setDep_time(String string) {
		dep_time = string;
	}

	/**
	 * @param string
	 */
	public void setFlt_date(String string) {
		flt_date = string;
	}

	/**
	 * @param string
	 */
	public void setFlt_no(String string) {
		flt_no = string;
	}

	/**
	 * @param string
	 */
	public void setSector(String string) {
		sector = string;
	}



	/**
	 * @return
	 */
	public int getLstcount() {
		return lstcount;
	}

	/**
	 * @param i
	 */
	public void setLstcount(int i) {
		lstcount = i;
	}

	/**
	 * @return
	 */
	public String[] getBADGENAME() {
		return BADGENAME;
	}

	/**
	 * @return
	 */
	public String[] getCAT() {
		return CAT;
	}

	/**
	 * @return
	 */
	public String[] getCOS() {
		return COS;
	}

	/**
	 * @return
	 */
	public String[] getLANG() {
		return LANG;
	}

	/**
	 * @param strings
	 */
	public void setBADGENAME(String[] strings) {
		BADGENAME = strings;
	}

	/**
	 * @param strings
	 */
	public void setCAT(String[] strings) {
		CAT = strings;
	}

	/**
	 * @param strings
	 */
	public void setCOS(String[] strings) {
		COS = strings;
	}

	/**
	 * @param strings
	 */
	public void setLANG(String[] strings) {
		LANG = strings;
	}

	/**
	 * @return
	 */
	public String[] getSP_DUTY() {
		return SP_DUTY;
	}

	/**
	 * @param strings
	 */
	public void setSP_DUTY(String[] strings) {
		SP_DUTY = strings;
	}

	/**
	 * @return
	 */
	public int getCock_cnt() {
		return cock_cnt;
	}

	/**
	 * @return
	 */
	public String[] getCockBadge() {
		return CockBadge;
	}

	/**
	 * @return
	 */
	public String[] getCockCrewID() {
		return CockCrewID;
	}

	/**
	 * @return
	 */
	public String[] getCockRank() {
		return CockRank;
	}

	/**
	 * @param i
	 */
	public void setCock_cnt(int i) {
		cock_cnt = i;
	}

	/**
	 * @param strings
	 */
	public void setCockBadge(String[] strings) {
		CockBadge = strings;
	}

	/**
	 * @param strings
	 */
	public void setCockCrewID(String[] strings) {
		CockCrewID = strings;
	}

	/**
	 * @param strings
	 */
	public void setCockRank(String[] strings) {
		CockRank = strings;
	}

}
