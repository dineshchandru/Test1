/*
 * Created on June 25, 2010
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.cathaypacific.crewdirect.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import com.cathaypacific.crewdirect.roster.BCMsgDropListBean;

public class Decode_MQ_BCMsg {
    
	private Connection con=null;
	
	private BCMsgDropListBean msg = new BCMsgDropListBean();
	private String err_msg;
	private boolean success;
	private DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
		
	public Decode_MQ_BCMsg() {
		super();
	}

	public Decode_MQ_BCMsg(String ern,String mq_msg) {
		this.msg.setStaffID(ern);
		this.msg.setAck_time(format.format(new Date(System.currentTimeMillis())));
		this.msg.setCreate_time(format.format(new Date(System.currentTimeMillis())));
		this.msg.setCss_msg(mq_msg);
		
		updateBCMsgTable();        
                       
	}

	public void updateBCMsgTable(){

		String SQL =null;
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn();
			con.setAutoCommit(false);
			
			Statement stmt = con.createStatement();
			//insert data into KA_MQ_BCMSG table
            SQL = "INSERT INTO KA_MQ_BCMSG ("+          
                        "STAFFID, ACK_TIME, CREATE_TIME, CCS_MSG)" +           
                  " VALUES ('" +
                        msg.getStaffID() + "', to_date('" + msg.getAck_time() + "','yyyy-mm-dd hh24:mi:ss')," +
                        " to_date('" + msg.getCreate_time() + "','yyyy-mm-dd hh24:mi:ss'), '" + msg.getCss_msg() + "')";
            stmt.executeUpdate(SQL);
			
			stmt.close();
			success = true;
			con.commit();
		}catch (SQLException sqlex) {
			  sqlex.printStackTrace();	
			  if (con!=null) {
					try {
					   con.rollback();
					   con.close();
					}catch( SQLException e){
					   e.printStackTrace();
					}		   	  
			  } //if    						 
		}catch (Exception ex) {
			ex.printStackTrace();
			success = false;			
		} finally{
			if (con!=null) {
			   try {
					 con.close();
			   }catch( SQLException e){
				  e.printStackTrace();
			   }
			} //if  
		}//catch	   			
			
	}
	
	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public boolean isSuccess() {
		return success;
	}

	/**
	 * @param string
	 */
	public void setErr_msg(String string) {
		err_msg = string;
	}

	/**
	 * @param b
	 */
	public void setSuccess(boolean b) {
		success = b;
	}

}
