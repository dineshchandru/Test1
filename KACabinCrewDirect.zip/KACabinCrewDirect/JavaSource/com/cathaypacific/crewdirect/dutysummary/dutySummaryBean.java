/***************************************************
 * Name : dutySummaryBean.java
 * Date : 26 Aug 2004 
 * Desc : Config the duty summary fields
 ***************************************************/
package com.cathaypacific.crewdirect.dutysummary;

public class dutySummaryBean {

	private float net_swap = 0 ;
	private float duty_travel_minutes = 0 ;
	private float manual_adj_minutes = 0 ;
	private float minimum_adj_minutes  = 0 ;	
	private float efp_minutes = 0 ;
	private float ldaa = 0 ;
	private float ldab = 0 ;
	private float net_swap_ground = 0 ;
	
	private String duty_start_date = "" ;
	private String duty_weekday = "" ;	
	private String duty_start_time = "" ;
	private String duty1 = "" ;
	private String acft1 = "" ;
	private String spduty1 = "" ;
	private String sector1 = "" ;
	private String deptime1 = "" ;
	private String arrtime1 = "" ;
	private String duty2 = "" ;
	private String acft2 = "" ;
	private String spduty2 = "" ;
	private String sector2 = "" ;
	private String deptime2 = "" ;
	private String arrtime2 = "" ;
	private String duty3 = "" ;
	private String acft3 = "" ;
	private String spduty3 = "" ;
	private String sector3 = "" ;
	private String deptime3 = "" ;
	private String arrtime3 = "" ;
	private String duty4 = "" ;
	private String acft4 = "" ;
	private String spduty4 = "" ;
	private String sector4 = "" ;
	private String deptime4 = "" ;
	private String arrtime4 = "" ;	
	private float fly_hours = 0 ;
	private float credit_hours = 0 ;
	private float ground_hours = 0 ;	
	private String period = "";
	private String duty_end_date;
	
	private double fdpp = 0;

	public String getDuty_end_date() {
		return duty_end_date;
	}

	public dutySummaryBean() {
		super();		
	}

	/**
	 * For Monthly Paid Crew
	 * Parameters 6 : MANUAL_ADJ_MINUTES, NEW_SWAP, EFP_MINUTES, LDAA, LDAB, DUTY_TRAVEL_MINUTES
	 */	
	public dutySummaryBean(float manual_adj_minutes, float net_swap, float efp_minutes, float ldaa, float ldab, float duty_travel_minutes) {							
		this.manual_adj_minutes = manual_adj_minutes;
		this.net_swap = (net_swap + manual_adj_minutes);		
		this.efp_minutes = efp_minutes;
		this.ldaa = ldaa;
		this.ldab = ldab;
		this.duty_travel_minutes = duty_travel_minutes;		
	}

	/**
	 * For Hourly Paid Crew
	 * Parameters 5 : MANUAL_ADJ_MINUTES, NEW_SWAP, MINIMUM_ADJ_MINUTES, DUTY_TRAVEL_MINUTES, NET_SWAP_GROUND
	 */		
	public dutySummaryBean(float manual_adj_minutes, float net_swap, float minimum_adj_minutes, float duty_travel_minutes, float net_swap_ground) {
		this.manual_adj_minutes = manual_adj_minutes;
		this.net_swap = (net_swap + manual_adj_minutes);	
		this.minimum_adj_minutes = minimum_adj_minutes;
		this.duty_travel_minutes = duty_travel_minutes;
		this.net_swap_ground = net_swap_ground;		
	}

	/**
	 * For Crew Duty Details
	 * Parameters : 24 FIELDS
	 */		
	public dutySummaryBean(String duty_start_date, String duty_weekday, String duty_start_time,
	String duty1, String acft1, String spduty1, String sector1, String deptime1, String arrtime1,
	String duty2, String acft2, String spduty2, String sector2, String deptime2, String arrtime2,
	String duty3, String acft3, String spduty3, String sector3, String deptime3, String arrtime3,
	String duty4, String acft4, String spduty4, String sector4, String deptime4, String arrtime4,	
	float fly_hours, float credit_hours, float ground_hours,String duty_end_date) {
		
		if (duty_start_date == null) { duty_start_date = ""; }
		if (duty_end_date == null) { duty_end_date = ""; }
		if (duty_weekday == null) { duty_weekday = ""; }
		if (duty_start_time == null) { duty_start_time = ""; }
		if (duty1 == null) { duty1 = ""; }					
		if (acft1 == null) { acft1 = ""; }
		if (spduty1 == null) { spduty1 = ""; }
		if (sector1 == null) { sector1 = ""; }
		if (deptime1 == null) { deptime1 = ""; }
		if (arrtime1 == null) { arrtime1 = ""; }
		if (duty2 == null) { duty2 = ""; }					
		if (acft2 == null) { acft2 = ""; }
		if (spduty2 == null) { spduty2 = ""; }
		if (sector2 == null) { sector2 = ""; }
		if (deptime2 == null) { deptime2 = ""; }
		if (arrtime2 == null) { arrtime2 = ""; }
		if (duty3 == null) { duty3 = ""; }					
		if (acft3 == null) { acft3 = ""; }
		if (spduty3 == null) { spduty3 = ""; }
		if (sector3 == null) { sector3 = ""; }
		if (deptime3 == null) { deptime3 = ""; }
		if (arrtime3== null) { arrtime3 = ""; }	
		if (duty4 == null) { duty4 = ""; }					
		if (acft4 == null) { acft4 = ""; }
		if (spduty4 == null) { spduty4 = ""; }
		if (sector4 == null) { sector4 = ""; }
		if (deptime4 == null) { deptime4 = ""; }
		if (arrtime4== null) { arrtime4 = ""; }	

		this.duty_start_date = duty_start_date;
		this.duty_end_date=duty_end_date;
		this.duty_weekday = duty_weekday;		
		this.duty_start_time = duty_start_time;
		this.duty1 = duty1;
		this.acft1 = acft1;
		this.spduty1 = spduty1;
		this.sector1 = sector1;
		this.deptime1 = deptime1;
		this.arrtime1 = arrtime1;
		this.duty2 = duty2;
		this.acft2 = acft2;
		this.spduty2 = spduty2;
		this.sector2 = sector2;
		this.deptime2 = deptime2;
		this.arrtime2 = arrtime2;
		this.duty3 = duty3;
		this.acft3 = acft3;
		this.spduty3 = spduty3;
		this.sector3 = sector3;
		this.deptime3 = deptime3;
		this.arrtime3 = arrtime3;
		this.duty4 = duty4;
		this.acft4 = acft4;
		this.spduty4 = spduty4;
		this.sector4 = sector4;
		this.deptime4 = deptime4;
		this.arrtime4 = arrtime4;		
		this.fly_hours = fly_hours;
		this.credit_hours = credit_hours;		
		this.ground_hours = ground_hours;
	}

	/**
	 * For Yearly Summary
	 * Parameters 4 : PERIOD, FLY_HOURS, CREDIT_HOURS, GROUND_HOURS
	 */	
	public dutySummaryBean(String period, float fly_hours, float credit_hours, float ground_hours) {
		this.period = period;
		this.fly_hours = fly_hours;
		this.credit_hours = credit_hours;		
		this.ground_hours = ground_hours;		
	}
	
	/**
	 * For monthly FDPP
	 * Parameters 2 : PERIOD, FDPP
	 */	
	public dutySummaryBean(String period, double fdpp) {
		this.period = period;
		this.fdpp = fdpp;
	}
	
	/**
	 * @return
	 */
	public float getManual_adj_minutes() {
		return manual_adj_minutes;
	}

	/**
	 * @return
	 */
	public float getNet_swap() {
		return net_swap;
	}

	/**
	 * @return
	 */
	public float getEfp_minutes() {
		return efp_minutes;
	}

	/**
	 * @return
	 */
	public float getLdaa() {
		return ldaa;
	}

	/**
	 * @return
	 */
	public float getLdab() {
		return ldab;
	}

	/**
	 * @return
	 */
	public float getMinimum_adj_minutes() {
		return minimum_adj_minutes;
	}

	/**
	 * @return
	 */
	public float getDuty_travel_minutes() {
		return duty_travel_minutes;
	}
	
	/**
	 * @return
	 */
	public float getNet_swap_ground() {
		return net_swap_ground;
	}
		
	/**
	 * @return
	 */
	public String getDuty_start_date() {
		return duty_start_date;
	}

	/**
	 * @return
	 */
	public String getDuty_weekday() {
		return duty_weekday;
	}
	
	/**
	 * @return
	 */
	public String getDuty_start_time() {
		return duty_start_time;
	}

	/**
	 * @return
	 */
	public String getDuty1() {
		return duty1;
	}

	/**
	 * @return
	 */
	public String getAcft1() {
		return acft1;
	}

	/**
	 * @return
	 */
	public String getSpduty1() {
		return spduty1;
	}

	/**
	 * @return
	 */
	public String getSector1() {
		return sector1;
	}

	/**
	 * @return
	 */
	public String getDeptime1() {
		return deptime1;
	}

	/**
	 * @return
	 */
	public String getArrtime1() {
		return arrtime1;
	}

	/**
	 * @return
	 */
	public String getDuty2() {
		return duty2;
	}

	/**
	 * @return
	 */
	public String getAcft2() {
		return acft2;
	}

	/**
	 * @return
	 */
	public String getSpduty2() {
		return spduty2;
	}

	/**
	 * @return
	 */
	public String getSector2() {
		return sector2;
	}

	/**
	 * @return
	 */
	public String getDeptime2() {
		return deptime2;
	}

	/**
	 * @return
	 */
	public String getArrtime2() {
		return arrtime2;
	}

	/**
	 * @return
	 */
	public String getDuty3() {
		return duty3;
	}

	/**
	 * @return
	 */
	public String getAcft3() {
		return acft3;
	}

	/**
	 * @return
	 */
	public String getSpduty3() {
		return spduty3;
	}

	/**
	 * @return
	 */
	public String getSector3() {
		return sector3;
	}

	/**
	 * @return
	 */
	public String getDeptime3() {
		return deptime3;
	}

	/**
	 * @return
	 */
	public String getArrtime3() {
		return arrtime3;
	}

	/**
	 * @return
	 */
	public String getDuty4() {
		return duty4;
	}

	/**
	 * @return
	 */
	public String getAcft4() {
		return acft4;
	}

	/**
	 * @return
	 */
	public String getSpduty4() {
		return spduty4;
	}

	/**
	 * @return
	 */
	public String getSector4() {
		return sector4;
	}

	/**
	 * @return
	 */
	public String getDeptime4() {
		return deptime4;
	}

	/**
	 * @return
	 */
	public String getArrtime4() {
		return arrtime4;
	}

	/**
	 * @return
	 */
	public float getFly_hours() {
		return fly_hours;
	}

	/**
	 * @return
	 */
	public float getCredit_hours() {
		return credit_hours;
	}

	/**
	 * @return
	 */
	public float getGround_hours() {
		return ground_hours;
	}

	/**
	 * @return
	 */
	public String getPeriod() {
		return period;
	}

	public double getFdpp() {
		return fdpp;
	}

	public void setFdpp(double fdpp) {
		this.fdpp = fdpp;
	}
}
