/**************************************************************
 * Name : radiationDosage.java
 * Date : 26 Aug 2004 
 * Desc : Retrieve the cosmic radiation dosage figure from DB
 **************************************************************/
package com.cathaypacific.crewdirect.dutysummary;
import com.cathaypacific.crewdirect.databeans.dbconnect;
import oracle.sql.*;
import java.sql.*;

public class radiationDosage {
	
	private Connection con = null;
	private int list_cnt = 0 ;
	private String err_msg = "no_err";
	private String[][] dosage_list = new String[24][2]; //for 24 months,(2 elements - period, dosage)
	
	public radiationDosage() {
		super();
	}
		
	/**
	 * Retrieve the cosmic radiation dosage from DB
	 * Parameter : ERN
	 */	
	public radiationDosage(String ern) {
	
		try{	
			dbconnect db = new dbconnect();
			Connection con = db.getConn(); 
  			
			ResultSet rs = null;			
			Statement stmt = null;		
			stmt = con.createStatement();
			
			String start_period = new String("");
			String end_period = new String("");
			
			//Get the max month in the DB and determine the period of the 24 months record
			String strsql = "SELECT to_char(add_months(max(period), -23)) as start_period, to_char(max(period)) as end_period FROM crewdir.cosmic_radiation" ;
			rs = stmt.executeQuery(strsql);
			while(rs.next()){	
				start_period = rs.getString("start_period");
				end_period = rs.getString("end_period");				
			}
			rs.close();
			
			//Get the radiation dosage data order by period in ascending order
			strsql = "SELECT to_char(period, 'Mon yy') as period, to_char(dosage, '0.00') as dosage " +
					 "FROM crewdir.cosmic_radiation WHERE ern = '"+ern+"' AND period >= '"+start_period+
					 "' AND period <= '"+end_period+"' ORDER BY to_date(period, 'Mon-yy')";		
			rs = stmt.executeQuery(strsql);
			while(rs.next()){	
				dosage_list[list_cnt][0] = rs.getString("period");
				dosage_list[list_cnt][1] = rs.getString("dosage");				
				list_cnt++;
			}
			rs.close();
			
			stmt.close();		
			con.close();
			
		}catch (SQLException sqlex) {
			sqlex.printStackTrace();	
			err_msg = "No Record Found. " + sqlex.getMessage();

			if (con != null) {
				try {
					con.close();
				}catch( SQLException e){
					e.printStackTrace();
				}		   	  
			} //if  
			    						
		}catch (Exception ex) {
			ex.printStackTrace();		  
			
		} finally{

			if (con != null) {
				try {
					con.close();		
			   } catch( SQLException e){
				  e.printStackTrace();
			   }
			
			} //if  
		
		}//catch/try
	}

	/**
	 * @return
	 */
	public String[][] getDosage_list() {
		return dosage_list;
	}

	/**
	 * @return
	 */
	public int getList_cnt() {
		return list_cnt;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}
}
