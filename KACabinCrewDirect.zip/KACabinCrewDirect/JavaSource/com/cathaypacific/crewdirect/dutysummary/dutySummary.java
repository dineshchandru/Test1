/***************************************************
 * Name : dutySummary.java
 * Date : 26 Aug 2004 
 * Desc : Retrieve the duty summary data from DB
 ***************************************************/
package com.cathaypacific.crewdirect.dutysummary;

import com.cathaypacific.crewdirect.databeans.dbconnect;
import oracle.sql.*;
import java.sql.*;

public class dutySummary {

	private Connection con = null;
	private int maxShowMonth = 6;
	private int maxShowYear = 3;

	private String err_msg = "no_err";
	private String credit_scheme = "";
	private int[] summary_count = new int[maxShowMonth];
	private int[] duty_count = new int[maxShowMonth];
	private int[] year_count = new int[maxShowYear];
	private int year_distinct_count = 0;
	private int year_total_record = 0;

	private String[] M = new String[maxShowMonth];
	private dutySummaryBean[] monthSummary = new dutySummaryBean[maxShowMonth]; // 6  months data
	// spileoy
	private dutySummaryBean[][] monthDuty = new dutySummaryBean[maxShowMonth][600]; // 6 months each max 60 records

	private dutySummaryBean[][] yearSummary = new dutySummaryBean[maxShowYear][12]; // 36 months, max 3 year 12 months

	// FDPP
	private dutySummaryBean[] monthlyFdpp = new dutySummaryBean[maxShowMonth]; // 6 months FDPP


	public dutySummary() {
		super();
	}

	/**
	 * Get the Duty Summary record from DB
	 */
	public dutySummary(String ern) {

		try {
			dbconnect db = new dbconnect();
			Connection con = db.getConn();

			ResultSet rs = null;
			Statement stmt = null;
			stmt = con.createStatement();
			String base_port = new String("");

			String strsql = "select base_port from isdcrew.crewdb_4_all where ern='" + ern + "'";
			rs = stmt.executeQuery(strsql);
			while (rs.next()) {
				base_port = rs.getString("base_port");
			}
			rs.close();

			if (base_port.equals("HKG")) {
				// Get the max period from the DB and detemine the num of months
				// for display
				for (int i = 0; i < maxShowMonth; i++) {
					/*
					 * Amendent on 08 May 2007 : SQL Tuning * strsql =
					 * "SELECT to_char(add_months(to_date(max(period), 'yyyymm'), "
					 * +(i-(maxShowMonth-1))+"), 'Mon yy') as Period " +
					 * "FROM crewdir.crew_duty_summary" ;
					 */
					strsql = "SELECT /*+ index(ka_crew_duty_summary idx_crew_duty_summary_01) */"
							+ " to_char(add_months(to_date(max(period), 'yyyymm'), " + (i - (maxShowMonth - 1))
							+ "), 'Mon yy') as Period FROM crewdir.ka_crew_duty_summary WHERE ern='" + ern + "'";

					rs = stmt.executeQuery(strsql);

//					System.out.println("CCD Duty Summary SQL - " + strsql);
					while (rs.next()) {
						M[i] = rs.getString("Period");
					}
					rs.close();
				}

				int cntSum = 0;
				int cntDuty = 0;
				// Get the monthly summary records from crew_duty_summary
				for (int i = 0; i < maxShowMonth; i++) {
					if (M[i] == null)
						continue;
					summary_count[i] = 0;
					strsql = "SELECT credit_scheme, net_swap, manual_adj_minutes, minimum_adj_minutes, efp_minutes, ldaa, ldab, duty_travel_minutes, net_swap_ground "
							+ "FROM crewdir.ka_crew_duty_summary WHERE ern='" + ern + "' and period = to_char(to_date('"
							+ M[i] + "', 'Mon yy'), 'yyyymm')";
					rs = stmt.executeQuery(strsql);
					while (rs.next()) {
						credit_scheme = rs.getString("credit_scheme");
						float net_swap = rs.getFloat("net_swap");
						float manual_adj_minutes = rs.getFloat("manual_adj_minutes");
						float minimum_adj_minutes = rs.getFloat("minimum_adj_minutes");
						float efp_minutes = rs.getFloat("efp_minutes");
						float ldaa = rs.getFloat("ldaa");
						float ldab = rs.getFloat("ldab");
						float duty_travel_minutes = rs.getFloat("duty_travel_minutes");
						float net_swap_ground = rs.getFloat("net_swap_ground");

						// For monthly-paid crew
						if (credit_scheme.equals("P") || credit_scheme.equals("O")) {
							dutySummaryBean monthBean = new dutySummaryBean(manual_adj_minutes, net_swap, efp_minutes,
									ldaa, ldab, duty_travel_minutes);
							monthSummary[i] = monthBean;
							// For hourly-paid crew, 'U' - MU Crew, 'A' - Air
							// China Crew
						} else if (credit_scheme.equals("M") || credit_scheme.equals("U")
								|| credit_scheme.equals("A")) {
							dutySummaryBean monthBean = new dutySummaryBean(manual_adj_minutes, net_swap,
									minimum_adj_minutes, duty_travel_minutes, net_swap_ground);
							monthSummary[i] = monthBean;
							// For credit scheme : "L" - LON, "Y" - YVR, "U" -
							// MU
						} else {
							err_msg = "Sorry ! You do not have right to view this function.";
						}
						summary_count[i]++;
						cntSum++;
					}
					rs.close();
				}

				// Get the daily hours record from crew_duty_details
				for (int i = 0; i < maxShowMonth; i++) {
					if (M[i] == null)
						continue;
					duty_count[i] = 0;
					strsql = "SELECT seq,to_char(duty_end_date, 'dd-Mon-yy') as duty_end_date,to_char(duty_start_date, 'dd-Mon-yy') as duty_start_date, substr(to_char(duty_start_date, 'DY'), 0, 1) as duty_weekday, duty_start_time, "
							+ "duty1, acft1, spduty1, sector1, deptime1, arrtime1, duty2, acft2, spduty2, sector2, deptime2, arrtime2, "
							+ "duty3, acft3, spduty3, sector3, deptime3, arrtime3, duty4, acft4, spduty4, sector4, deptime4, arrtime4, "
							+ "fly_hours, credit_hours, ground_hours " + "FROM crewdir.ka_crew_duty_details WHERE ern='"
							+ ern + "' and period = to_char(to_date('" + M[i] + "', 'Mon yy'), 'yyyymm') "
							+ "order by seq";
					rs = stmt.executeQuery(strsql);

					while (rs.next()) {
						String duty_start_date = rs.getString("duty_start_date");
						String duty_end_date = rs.getString("duty_end_date");
						String duty_weekday = rs.getString("duty_weekday");
						String duty_start_time = rs.getString("duty_start_time");
						String duty1 = rs.getString("duty1");
						String acft1 = rs.getString("acft1");
						String spduty1 = rs.getString("spduty1");
						String sector1 = rs.getString("sector1");
						String deptime1 = rs.getString("deptime1");
						String arrtime1 = rs.getString("arrtime1");
						String duty2 = rs.getString("duty2");
						String acft2 = rs.getString("acft2");
						String spduty2 = rs.getString("spduty2");
						String sector2 = rs.getString("sector2");
						String deptime2 = rs.getString("deptime2");
						String arrtime2 = rs.getString("arrtime2");
						String duty3 = rs.getString("duty3");
						String acft3 = rs.getString("acft3");
						String spduty3 = rs.getString("spduty3");
						String sector3 = rs.getString("sector3");
						String deptime3 = rs.getString("deptime3");
						String arrtime3 = rs.getString("arrtime3");
						String duty4 = rs.getString("duty4");
						String acft4 = rs.getString("acft4");
						String spduty4 = rs.getString("spduty4");
						String sector4 = rs.getString("sector4");
						String deptime4 = rs.getString("deptime4");
						String arrtime4 = rs.getString("arrtime4");
						float fly_hours = rs.getFloat("fly_hours");
						float credit_hours = rs.getFloat("credit_hours");
						float ground_hours = rs.getFloat("ground_hours");
						dutySummaryBean myBean = new dutySummaryBean(duty_start_date, duty_weekday, duty_start_time,
								duty1, acft1, spduty1, sector1, deptime1, arrtime1, duty2, acft2, spduty2, sector2,
								deptime2, arrtime2, duty3, acft3, spduty3, sector3, deptime3, arrtime3, duty4, acft4,
								spduty4, sector4, deptime4, arrtime4, fly_hours, credit_hours, ground_hours,
								duty_end_date);
						monthDuty[i][duty_count[i]] = myBean;
						duty_count[i]++;
						cntDuty++;
					}
					rs.close();
				}



				// get FDPP from KA_CREW_DUTY_FDPP
				for (int i = 0; i < maxShowMonth; i++) {
					if (M[i] == null)
						continue;

					double fdpp = 0;
					String period = M[i];

					strsql = "SELECT fdpp FROM crewdir.ka_crew_duty_fdpp WHERE ern='" + ern
							+ "' AND period = TO_CHAR(TO_DATE('" + M[i] + "', 'Mon yy'), 'yyyymm') ";
					rs = stmt.executeQuery(strsql);
					//
					while (rs.next()) {
						fdpp = rs.getDouble("FDPP");
					}
					dutySummaryBean myBean = new dutySummaryBean(period, fdpp);
					monthlyFdpp[i] = myBean;
					System.out.println("FDPP=" + myBean.getPeriod() + "," + myBean.getFdpp());

					rs.close();
				}

				// get the yearly summary hours from crew_duty_year
				int y = 0;
				year_count[y] = 0;
				String check_year = new String("");
				strsql = "SELECT to_char(to_date(period, 'YYYYMM'), 'yyyy') as next_year, to_char(to_date(period, 'YYYYMM'), 'Mon yyyy') as year_period, fly_hours, credit_hours, ground_hours "
						+ "FROM crewdir.ka_crew_duty_year WHERE ern='" + ern
						+ "' and period >= to_char(add_months(sysdate, -" + (12 * maxShowYear) + "), 'YYYYMM') "
						+ "ORDER BY to_date(period, 'YYYYMM') DESC";
				rs = stmt.executeQuery(strsql);
				while (rs.next()) {
					String next_year = rs.getString("next_year");
					String period = rs.getString("year_period");
					float fly_hours = rs.getFloat("fly_hours");
					float credit_hours = rs.getFloat("credit_hours");
					float ground_hours = rs.getFloat("ground_hours");
					dutySummaryBean yearBean = new dutySummaryBean(period, fly_hours, credit_hours, ground_hours);

					if (year_total_record == 0) {
						check_year = next_year;
					}

					if (!check_year.equals(next_year)) {
						y++;
						year_count[y] = 0;
						year_distinct_count++;
					}

					yearSummary[y][year_count[y]] = yearBean;
					year_count[y]++;
					year_total_record++;
					check_year = next_year;
				}
				rs.close();

				System.out.println("Exist dutySummary");
				if (cntSum == 0 && cntDuty == 0 && year_total_record == 0)
					err_msg = "No duty summary records found for the last " + maxShowMonth + " months.";

			} else {
				err_msg = "There is no record for basing crew as this function is applicable to HKG based crew only.";
			}

			stmt.close();
			con.close();

		} catch (SQLException sqlex) {
			sqlex.printStackTrace();
			err_msg = sqlex.getMessage();
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} // if

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {

			if (con != null) {

				try {
					con.close();

				} catch (SQLException e) {
					e.printStackTrace();
				}

			} // if

		} // catch/try
	}

	/**
	 * @return
	 */
	public int getMaxShowMonth() {
		return maxShowMonth;
	}

	/**
	 * @return
	 */
	public int getMaxShowYear() {
		return maxShowYear;
	}

	/**
	 * @return
	 */
	public String getCredit_scheme() {
		return credit_scheme;
	}

	/**
	 * @return
	 */
	public int[] getSummary_count() {
		return summary_count;
	}

	/**
	 * @return
	 */
	public int[] getDuty_count() {
		return duty_count;
	}

	/**
	 * @return
	 */
	public int[] getYear_count() {
		return year_count;
	}

	/**
	 * @return
	 */
	public String[] getM() {
		return M;
	}

	/**
	 * @return
	 */
	public dutySummaryBean[] getMonthSummary() {
		return monthSummary;
	}

	/**
	 * @return
	 */
	public dutySummaryBean[][] getMonthDuty() {
		return monthDuty;
	}

	/**
	 * @return
	 */
	public dutySummaryBean[][] getYearSummary() {
		return yearSummary;
	}

	/**
	 * @return
	 */
	public String getErr_msg() {
		return err_msg;
	}

	/**
	 * @return
	 */
	public int getYear_distinct_count() {
		return year_distinct_count;
	}

	/**
	 * @return
	 */
	public int getYear_total_record() {
		return year_total_record;
	}

	public dutySummaryBean[] getMonthlyFdpp() {
		return monthlyFdpp;
	}

	public void setMonthlyFdpp(dutySummaryBean[] monthlyFdpp) {
		this.monthlyFdpp = monthlyFdpp;
	}
}
