package com.cathaypacific.crewdirect.filter;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cathaypacific.crewdirect.databeans.basicInfo;
import com.cathaypacific.crewdirect.services.getBasicInfo;
import com.cathaypacific.utility.IntraCXLogin;

public class CheckSessionFilter implements Filter {
	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public CheckSessionFilter() {
		super();
	}

	/* (non-Java-doc)
	 * @see javax.servlet.Filter#init(FilterConfig arg0)
	 */
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
	}

	/* (non-Java-doc)
	 * @see javax.servlet.Filter#doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String myERN = "";
		String myID  = "";		
		basicInfo myInfo = null;
		Date startTime = Calendar.getInstance().getTime();
		String formatedTime;
		// TODO Auto-generated method stub
	    HttpServletRequest req = (HttpServletRequest)request;	     
	    HttpServletResponse rsp = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		String uri = ((HttpServletRequest) request).getRequestURI();   
        formatedTime = formatDate(startTime,"dd.MMM.yyyy HH:mm:ss");
        
        myERN = (String) session.getAttribute("MyERN");
        myID = (String) session.getAttribute("MyID");
        myInfo = (basicInfo) session.getAttribute("MyInfo");
        //getBasicInfo info = new getBasicInfo(ern);
         
        //if (uri.indexOf(".jsp") > 0 || uri.indexOf(".do") > 0 ) {
        if (uri.indexOf("test.jsp") < 0 && uri.indexOf("login_form.jsp") < 0 && uri.indexOf("home.jsp") < 0 ) {        	
        //} else {
		   if (myERN == null){
			//						
			  IntraCXLogin intracx = new IntraCXLogin();	
			  intracx.setRedirect(true);	
			  intracx.checkUserSession(req,rsp);			
			  if (intracx.isValidUser()) {
			     myERN = intracx.get_ldap_ern();
			     myID = intracx.get_ldap_firstname()+' '+intracx.get_ldap_lastname();
		   	     session.setAttribute("MyERN",myERN);
			     session.setAttribute("MyID",myID);  			   
			  }
			  if (myERN != null && (myERN.equalsIgnoreCase("0072"))) {
		         System.out.println("KACCD - CheckSessionFilter Start : " + formatedTime); 
		         System.out.println("  SSOA Header GiveName         : "+req.getHeader("givenname"));
 		         System.out.println("  SSOA Header StaffID          : "+req.getHeader("cpaern"));
 		         System.out.println("  Session Variable MyERN       : "+myERN);
 		  	     System.out.println("  KACCD LOG     set session            : Filter Start ("+myERN+")");
		 		 System.out.println("    The Session ID is                : "+session.getId());
		 		 System.out.println("    The Session is new               : "+session.isNew());
		 		 System.out.println("    Created Time of Session is       : "+new Date(session.getCreationTime()));
		 		 System.out.println("    Last Accessed Time of Session is : " + new Date(session.getLastAccessedTime()));  		     
		 		 System.out.println("    Max Inactive Interval of Session : " +session.getMaxInactiveInterval());
		 		 System.out.println("    request url                      : " + uri);
		 		 System.out.println("    Session Variable - MyERN         : " + myERN);
				 System.out.println("    Session Variable - MyID          : " + myID);
		 		 System.out.println("  KACCD LOG                            : Filter End");
			     startTime = Calendar.getInstance().getTime();
			     formatedTime = formatDate(startTime,"dd.MMM.yyyy HH:mm:ss");
			     System.out.println("KACCD - CheckSessionFilter End : " + formatedTime); 
			  }; 		
		   } else {
		   	  if (myERN.equalsIgnoreCase("0072")) {
		         System.out.println("KACCD - CheckSessionFilter Start : " + formatedTime); 
		         System.out.println("  SSOA Header GiveName         : "+req.getHeader("givenname"));
 		         System.out.println("  SSOA Header StaffID          : "+req.getHeader("cpaern"));
 		         System.out.println("  Session Variable MyERN       : "+myERN);
 		   	  	 System.out.println("  KACCD LOG      current session       : Filter Start ("+myERN+")");
	 		     System.out.println("    The Session ID is                : "+session.getId());
	 		     System.out.println("    The Session is new               : "+session.isNew());
	 		     System.out.println("    Created Time of Session is       : "+new Date(session.getCreationTime()));
	 		     System.out.println("    Last Accessed Time of Session is : " + new Date(session.getLastAccessedTime()));  		     
	 		     System.out.println("    Max Inactive Interval of Session : " +session.getMaxInactiveInterval());
	 		     System.out.println("    request url                      : " + uri); 		   
	 		     System.out.println("    Session Variable - MyERN         : " + myERN);
			     System.out.println("    Session Variable - MyID          : " + myID);
			     System.out.println("  KACCD LOG                            : Filter End");
			     startTime = Calendar.getInstance().getTime();
			     formatedTime = formatDate(startTime,"dd.MMM.yyyy HH:mm:ss");
			     System.out.println("KACCD - CheckSessionFilter End : " + formatedTime); 
		   	  }   
		   }
        }
        if(myInfo == null){
        	if("0072".equalsIgnoreCase(myERN) ){
        		System.out.println("######## unable to find myInfo ######### for ern:"+myERN);
        	}
            if (myERN != null){
            	getBasicInfo info = new getBasicInfo(myERN);
            	session.setAttribute("MyInfo", info.getMyInfo());
            } else {
            	System.out.println("######## unable to find myInfo ######### for ern is null");
            }
        }
		chain.doFilter(request, response);        
	}

	/* (non-Java-doc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}
    private static final String formatDate(Date date, String pattern) {
        DateFormat df =
            new SimpleDateFormat(pattern);
        
        return df.format(date);
        
    }
}