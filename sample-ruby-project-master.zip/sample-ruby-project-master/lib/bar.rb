# Another class
class Bar
  def print_fine
    'This is fine :)'
  end
end
