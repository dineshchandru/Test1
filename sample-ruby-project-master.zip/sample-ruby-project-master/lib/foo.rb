# Sample class
class Foo
  def print_hello
    'Hello world!'
  end

  def print_nothing; end
end
