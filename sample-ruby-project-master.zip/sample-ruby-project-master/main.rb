Bundler.require

puts 'YAY!'
