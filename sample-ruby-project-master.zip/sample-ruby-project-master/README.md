# sample-ruby-project

It is a part of internal training at ANIXE. Ruby for total noobs :)
